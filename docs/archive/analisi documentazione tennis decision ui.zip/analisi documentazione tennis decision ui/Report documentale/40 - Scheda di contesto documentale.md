# Scheda di contesto documentale

## Documento target

Percorso:
`docs/validations/betfair-live-validation-2026-07-04.md`

Tipo di documento:
validation storica; osservazione live manuale riferita al 4 luglio 2026.

Ruolo documentale:
conservare il resoconto storico delle sessioni live Betfair eseguite in quella data, distinguendo osservazioni effettuate, casi non eseguiti, informazioni soltanto riferite e limiti dell'evidenza. Non costituisce una specifica del comportamento corrente o futuro.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-191319).txt`
- `40 - Report betfair-live-validation-2026-07-04.md` — report `TDUI-DOC-REPORT-040`.
- `40 - TODO e Json.md` — riepilogo Markdown e record JSON delle task associate.

## Task storicamente associate

- `BETFAIR-VAL-001` — stato: completata  
  Argomento coinvolto: provenienza della migrazione e distinzione fra sorgente storica e destinazione corrente.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto documentale corrente pertinente, senza ricostruire SHA o ambiente non registrati.
- `BETFAIR-VAL-002` — stato: completata  
  Argomento coinvolto: fedeltà semantica della migrazione, in particolare la classificazione dell'osservazione storica `/api/match/:eventId/json = 200` con Sofa Connected.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente e mantenere distinti osservazione live, formulazione prudente e disponibilità degli artefatti.
- `BETFAIR-VAL-003` — stato: completata  
  Argomento coinvolto: completezza del riepilogo degli scenari non eseguiti, incluso il mismatch `marketId`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto documentale corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- Il contenuto risulta migrato dalla sorgente storica `docs/tennis-decision-ui/operations/07-betfair-live-validation.mdx` alla sezione `docs/validations/`.
- La modularizzazione è stata valutata e dichiarata non necessaria: le sessioni A, B e C appartengono alla stessa campagna di validazione e il loro contesto condiviso è rilevante.
- Non risultano nuovi documenti canonici creati per separare le singole sessioni.

## Struttura precedente da considerare

- Testata con data, natura storica, sorgente migrata e SHA della sessione dichiarato come non registrato.
- Sessioni A, B e C mantenute separatamente: Graph URL disponibili, Graph URL assenti, logout e recovery.
- Separazione fra osservazioni live, informazioni non archiviate o soltanto riferite e scenari non eseguiti.
- Sezione dei limiti, incluso il riuso dello stesso `eventId` fra le sessioni A e B.
- Tabella finale di interpretazione e collegamenti agli owner correnti.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- Documento target e relativa cronologia/provenienza documentale.
- Endpoint `/api/match/:eventId/json` e rappresentazione dello stato Sofa Connected.
- Dominio Betfair relativo a `graphHealth`, health UI, Graph URL e fallback `book_depth`.
- Dominio Money Flow relativo a `matchedVolume`, validità di visualizzazione e anomalie raw/computed.
- Dominio logout/recovery Betfair e tick status-only, limitatamente al significato necessario per descrivere correttamente l'osservazione storica.
- Test correnti direttamente collegati a questi comportamenti, usati soltanto per distinguere il contratto corrente dall'evidenza della run storica.

## Owner/documenti collegati

- `docs/validations/README.md` — definisce il ruolo e i confini generali delle validation storiche.
- `docs/tennis-decision-ui/operations/07-betfair-live-validation.mdx` — sorgente storica della migrazione, utile per il confronto di fedeltà semantica.
- `docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md` — owner corrente del lifecycle dello scraper Betfair.
- `docs/tennis-decision-ui/modules/betfair/02-technical-sample-validity.md` — owner corrente della validità tecnica dei sample.
- `docs/tennis-decision-ui/operations/03-betfair-diagnostics.md` — owner corrente della diagnostica Betfair.
- `docs/tennis-decision-ui/roadmap/01-current-state.md` — quadro corrente separato dall'evidenza storica.

Questi documenti servono a mantenere il confine fra resoconto della run storica e contratti o stato attuali; la scheda non implica modifiche ai documenti collegati.

## Guardrail specifici per questo documento

- Conservare la natura di artifact storico e non trasformarlo in specifica corrente, runbook o attestazione automatica.
- Non inventare SHA, ambiente, payload o artefatti della sessione non registrati.
- Mantenere distinte evidenza osservata in UI, stato tecnico riferito durante la run, test correnti e comportamento corrente del codice.
- Non reinterpretare le sessioni A e B come isolate, poiché usarono lo stesso `eventId`.
- Conservare come non eseguiti i casi dichiarati tali, inclusi login già scaduto, Graph URL malformate, mismatch `marketId`, errore reale API/rete e mercato realmente concluso.
- Conservare il buffering SofaScore come informazione riferita senza artifact allegato, non come evidenza live archiviata.
- Non reintrodurre nomi dei giocatori, URL Graph completi, credenziali o payload sensibili.
- Mantenere unite le tre sessioni salvo diversa evidenza strutturale nella baseline documentale.

## Informazioni storiche da NON assumere come correnti

- Il ritorno a Connected osservato dopo il login non definisce il contratto corrente generale di recovery o di clear dell'alert.
- Il tick status-only e `auth_suspected` non costituiscono prova archiviata del payload `/latest` post-fix.
- Le sequenze, il volume abbinato, la visibilità del grafico e gli stati health osservati valgono per le sessioni documentate, non come invarianti future.
- La mancata interruzione del tracking senza Graph URL vale come osservazione della sessione B, non come garanzia universale.
- Il mercato realmente concluso, gli errori API/rete reali, le Graph URL malformate e il mismatch `marketId` non risultano eseguiti nella validation storica.
- Implementazioni e test correnti non devono essere usati per attribuire retroattivamente alla run storica prove che non furono archiviate.

## Discrepanze o limiti delle fonti

- Markdown e JSON concordano su ID, associazione al documento e completamento delle tre task; nessuna discrepanza storica individuata fra queste fonti.
- Lo SHA della sessione live e l'ambiente non risultano registrati e non devono essere ricostruiti per inferenza.
- Il report documentale analizzava il commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`, mentre il technical writer dovrà usare come CODE AUTHORITY `12b344ea96e71b2bdaa6931c98419ce925b5c228`.
- La fonte storica indicava l'osservazione `/api/match/:eventId/json = 200` con Sofa Connected; il report segnalava che tale osservazione non era presente nell'artifact migrato allora esaminato. La task associata risulta successivamente completata, ma il contenuto corrente va verificato nella baseline indicata.
- Il payload `/latest` post-fix relativo alla sessione di logout/recovery non risultava archiviato.
