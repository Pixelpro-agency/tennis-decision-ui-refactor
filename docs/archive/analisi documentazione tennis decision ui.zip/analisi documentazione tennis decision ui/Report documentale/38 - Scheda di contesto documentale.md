# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/roadmap/01-current-state.md`

Tipo di documento:  
roadmap di stato corrente / vista sintetica trasversale.

Ruolo documentale:  
fornire una fotografia sintetica dello stato reale del progetto, distinguendo base implementata, limiti correnti, componenti deprecati, validazioni storiche e funzioni non presenti. Deve rimandare ai documenti owner per i dettagli tecnici, senza trasformarsi in una Todo o in una cronologia delle task.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `38 - Report 01-current-state.md` — report `TDUI-DOC-REPORT-038`.
- `38 - TODO e Json.md` — mappa sintetica e metadata strutturati delle task associate.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing`.

## Task storicamente associate

- `CURRENT-STATE-001` — stato: completata  
  Argomento coinvolto: distinzione tra baseline del codice/runtime e baseline dello stato documentale o del repository.  
  Uso consentito: verificare nel CODE AUTHORITY come viene rappresentata attualmente la provenance del Current State.

- `CURRENT-STATE-002` — stato: completata  
  Argomento coinvolto: riferimento storico a `docs/archive/README.md` e individuazione dell’owner corrente della provenance.  
  Uso consentito: verificare sullo stato corrente quali riferimenti esistono e quale fonte svolge effettivamente quel ruolo.

- `CURRENT-STATE-003` — stato: completata  
  Argomento coinvolto: inventario delle validazioni storiche e collegamento tra affermazioni di validazione e relativi artifact.  
  Uso consentito: verificare nel CODE AUTHORITY e nella documentazione corrente quali osservazioni sono supportate da artifact e con quale livello di prova.

## Cambiamenti strutturali storicamente rilevanti

- La precedente organizzazione basata sulla successione delle task è stata sostituita da una vista dello stato corrente.
- Sono state separate base implementata, limiti, componenti deprecati, validazioni storiche e funzioni non presenti.
- Le specifiche future sono state affidate ai registri anziché presentate come funzionalità correnti.
- La modularizzazione è stata valutata ma non ritenuta necessaria.
- Non risultano nuovi documenti canonici derivati dal documento target.

## Struttura precedente da considerare

- tabella o sintesi iniziale delle aree principali;
- comportamenti trasversali rilevanti;
- limiti correnti;
- componenti deprecati ma ancora presenti;
- validazioni storiche;
- funzioni non presenti;
- riferimenti alle fonti delle attività future.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente. La forma deve rimanere sintetica e orientata allo stato, senza reintrodurre una cronologia task-by-task.

## Aree da verificare nel CODE AUTHORITY

- `launcher/` e flusso di avvio/runtime locale;
- `backend/src/`, con attenzione a tracking, persistenza, journal/recovery, Evidence e integrazione Betfair;
- `scrapers/`, per i confini SofaScore e Betfair;
- `frontend/src/`, per stato della sessione, polling e rappresentazione dell’integrità;
- `scripts/cleanup_runtime_cache.py`, per distinguere cleanup manuale, applicazione reale e retention automatica;
- manifest, runner e artifact della validazione;
- relativi test soltanto come fonte per descrivere capacità effettivamente presenti.

## Owner/documenti collegati

- Documenti owner del runtime locale e del lifecycle: contengono i dettagli operativi che il Current State deve soltanto sintetizzare.
- Documenti owner di tracking e Source Identity: definiscono Start, Stop, mismatch, sessione e cleanup.
- Documenti owner SofaScore/localContext: descrivono PBP, current game e provenienza dei dati.
- Documenti owner Betfair: descrivono scraper, health, stato `finished`, diagnostica e superfici legacy.
- Documenti owner di storage, journal e recovery: contengono i contratti dettagliati della persistenza.
- Documenti owner di Evidence e frontend: descrivono provenienza, comparabilità e rappresentazione UI.
- `docs/validations/` e relativo indice: contengono gli artifact disponibili e il loro livello di evidenza.
- Registri Todo, audit, implementazioni e decisioni: conservano attività e specifiche future, senza costituire prova dello stato runtime.

## Guardrail specifici per questo documento

- Conservare il ruolo di fotografia sintetica dello stato corrente.
- Non trasformare il documento in una seconda Todo, in un audit o in un runbook.
- Distinguere chiaramente ciò che è implementato, implementato con limiti, deprecato, validato storicamente e non presente.
- Non aumentare il livello di prova rispetto agli artifact disponibili.
- Non descrivere come corrente una specifica presente soltanto nei registri.
- Evitare la duplicazione di procedure, payload, matrici di test e sequenze operative appartenenti ai documenti owner.
- Mantenere nello stesso documento le diverse aree: dalle fonti non emerge la necessità di dividerlo.
- Verificare sul CODE AUTHORITY ogni claim tecnico prima di conservarlo o riformularlo.

## Informazioni storiche da NON assumere come correnti

- La baseline tecnica storica `f86ac267919ca13859c98db7015362f26176ba36`.
- Il commit documentale analizzato dal report, `4c5f43b007149f3210c27d7565357a447a3a6ef4`.
- L’esistenza o il ruolo corrente di `docs/archive/README.md`.
- Conteggi storici di test riportati inline.
- Validazioni di launcher, Stop o lifecycle prive, nella fonte storica, di un artifact chiaramente associato.
- Elenchi storici di limiti, componenti deprecati o funzioni assenti.
- Finding, priorità e formulazioni progettuali contenuti nel report.
- Stati delle task appartenenti ai documenti owner diversi dal target.

## Discrepanze o limiti delle fonti

- Markdown e JSON concordano su ID, associazione al documento e completamento di `CURRENT-STATE-001…003`; non emerge una discrepanza storica tra queste fonti.
- Il report è materiale storico di audit e non costituisce authority tecnica corrente.
- Le task risultano completate storicamente, ma il loro effetto documentale deve essere verificato sul CODE AUTHORITY.
- Il documento target corrente non è stato fornito tra gli allegati; forma e contenuto effettivi devono quindi essere recuperati dalla baseline documentale e confrontati con lo stato corrente.
