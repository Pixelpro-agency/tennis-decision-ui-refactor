TODO:

Report: [`Report documentale/29 - 02-local-context-and-point-by-point.md`](../Report%20documentale/29%20-%2002-local-context-and-point-by-point.md) — `TDUI-DOC-REPORT-029`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`LOCAL-PBP-001`** — priorità `high` — Non equiparare automaticamente highest (set,game) al game corrente: validare la proprietà sul source contract e usare excludedCurrentGame:true soltanto con evidence; fail-closed se il current game non è identificabile.
- [x] **`LOCAL-PBP-002`** — priorità `high` — Definire dal provider reale integer semantics e uniqueness della coppia (set,game); rifiutare duplicati confliggenti e valori strutturalmente non canonici.
- [x] **`LOCAL-PBP-003`** — priorità `high` — Definire il domain contract di ALL/pointsTotal: tipo/formato realmente prodotto, conteggi interi, gestione duplicati e distinzione zero reale da valore non valido.
- [x] **`LOCAL-PBP-004`** — priorità `high` — Qualificare localContext.dataQuality complete come completezza derivativa e non come freshness, provenance o temporal alignment verificati; mantenere separati gli assi di qualità.
- [x] **`LOCAL-PBP-005`** — priorità `critical` — Classificare POST /api/match/analyze e /snapshot come compute-only oppure canonical writer; se restano writer devono rispettare le authority canoniche senza bypass implicito di gate/session sequencing, coordinando MATCH-API-008.
- [x] **`LOCAL-PBP-006`** — priorità `medium` — Correggere il bootstrap localContext: updateSofa lo calcola prima del gate e lo passa come persistenceData opaco; il matching Source Identity non lo usa e la recomputation è soltanto fallback.
- [x] **`LOCAL-PBP-007`** — priorità `high` — Creare una validation riproducibile del contratto PBP reale per set/game, ordering, current game, token, advantage/deuce, winning point, tie-break, set transition e unavailable; nessuna estensione decoder senza evidence.
- [x] **`LOCAL-PBP-008`** — priorità `high` — Riallineare la verification matrix ai test realmente presenti e aggiungere edge case per current game, identity, pointsTotal, source contract e writer /analyze; coordinare la reason propagation con MATCH-CONTEXT-003.

JSON:

    {
      "change_id": "LOCAL-PBP-001",
      "report_id": "TDUI-DOC-REPORT-029",
      "document_path": "docs/tennis-decision-ui/modules/sofa/02-local-context-and-point-by-point.md",
      "priority": "high",
      "type": "current_game_authority",
      "action": "Non equiparare automaticamente highest (set,game) al game corrente: validare la proprietà sul source contract e usare excludedCurrentGame:true soltanto con evidence; fail-closed se il current game non è identificabile.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LOCAL-PBP-002",
      "report_id": "TDUI-DOC-REPORT-029",
      "document_path": "docs/tennis-decision-ui/modules/sofa/02-local-context-and-point-by-point.md",
      "priority": "high",
      "type": "point_by_point_structural_identity",
      "action": "Definire dal provider reale integer semantics e uniqueness della coppia (set,game); rifiutare duplicati confliggenti e valori strutturalmente non canonici.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LOCAL-PBP-003",
      "report_id": "TDUI-DOC-REPORT-029",
      "document_path": "docs/tennis-decision-ui/modules/sofa/02-local-context-and-point-by-point.md",
      "priority": "high",
      "type": "statistics_count_validation",
      "action": "Definire il domain contract di ALL/pointsTotal: tipo/formato realmente prodotto, conteggi interi, gestione duplicati e distinzione zero reale da valore non valido.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LOCAL-PBP-004",
      "report_id": "TDUI-DOC-REPORT-029",
      "document_path": "docs/tennis-decision-ui/modules/sofa/02-local-context-and-point-by-point.md",
      "priority": "high",
      "type": "data_quality_semantics",
      "action": "Qualificare localContext.dataQuality complete come completezza derivativa e non come freshness, provenance o temporal alignment verificati; mantenere separati gli assi di qualità.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LOCAL-PBP-005",
      "report_id": "TDUI-DOC-REPORT-029",
      "document_path": "docs/tennis-decision-ui/modules/sofa/02-local-context-and-point-by-point.md",
      "priority": "critical",
      "type": "canonical_writer_authority",
      "action": "Classificare POST /api/match/analyze e /snapshot come compute-only oppure canonical writer; se restano writer devono rispettare le authority canoniche senza bypass implicito di gate/session sequencing, coordinando MATCH-API-008.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LOCAL-PBP-006",
      "report_id": "TDUI-DOC-REPORT-029",
      "document_path": "docs/tennis-decision-ui/modules/sofa/02-local-context-and-point-by-point.md",
      "priority": "medium",
      "type": "documentation_runtime_alignment",
      "action": "Correggere il bootstrap localContext: updateSofa lo calcola prima del gate e lo passa come persistenceData opaco; il matching Source Identity non lo usa e la recomputation è soltanto fallback.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LOCAL-PBP-007",
      "report_id": "TDUI-DOC-REPORT-029",
      "document_path": "docs/tennis-decision-ui/modules/sofa/02-local-context-and-point-by-point.md",
      "priority": "high",
      "type": "source_validation_provenance",
      "action": "Creare una validation riproducibile del contratto PBP reale per set/game, ordering, current game, token, advantage/deuce, winning point, tie-break, set transition e unavailable; nessuna estensione decoder senza evidence.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LOCAL-PBP-008",
      "report_id": "TDUI-DOC-REPORT-029",
      "document_path": "docs/tennis-decision-ui/modules/sofa/02-local-context-and-point-by-point.md",
      "priority": "high",
      "type": "verification_contract",
      "action": "Riallineare la verification matrix ai test realmente presenti e aggiungere edge case per current game, identity, pointsTotal, source contract e writer /analyze; coordinare la reason propagation con MATCH-CONTEXT-003.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }