TODO:

Report: [`../Report documentale/04 - 03-workflow-esecutivo.md`](../Report%20documentale/04%20-%2003-workflow-esecutivo.md) — `TDUI-DOC-REPORT-004`.

Modularizzazione: **richiesta**. File proposti: `docs/tennis-decision-ui/ai/04-diagnosi-e-modularizzazione.md`, `docs/tennis-decision-ui/ai/05-artefatti-esecutivi.md`.

- [x] **`WF-DOC-001`** — priorità `high` — Separare i requisiti comuni, quelli delle task che modificano file e quelli delle modalità read-only; aggiornare anche i criteri `PRONTO PER TASK`.
- [x] **`WF-DOC-002`** — priorità `high` — Eliminare `repomix@latest`: usare una versione approvata e dichiarata oppure introdurre, in una task separata, un generatore project-owned.
- [x] **`WF-DOC-003`** — priorità `high` — Definire un artefatto bounded e segmentabile con manifest, ordine, dimensioni e digest, senza inventare soglie prima della decisione dell’utente.
- [x] **`WF-DOC-004`** — priorità `medium` — Definire manifest e output Git richiesti per task di sola cancellazione, senza creare un falso `fileModificati.md`.
- [x] **`WF-DOC-005`** — priorità `high` — Mantenere lifecycle e ruoli in `03-workflow-esecutivo.md`, spostare la diagnosi in `04-diagnosi-e-modularizzazione.md` e gli artefatti esecutivi in `05-artefatti-esecutivi.md`, aggiornando indice e link.
- [x] **`WF-DOC-006`** — priorità `medium` — Rendere gli artefatti di revisione condizionali, distinguere le fasi di chiusura, completare i controlli Git e proteggere gli artefatti locali tramite `.gitignore` quando approvato.

JSON:

    {
      "change_id": "WF-DOC-001",
      "document_path": "docs/tennis-decision-ui/ai/03-workflow-esecutivo.md",
      "report_id": "TDUI-DOC-REPORT-004",
      "report_path": "../Report documentale/04 - 03-workflow-esecutivo.md",
      "priority": "high",
      "type": "mode_specific_requirements",
      "action": "Separare i requisiti comuni, quelli delle task che modificano file e quelli delle modalità read-only; aggiornare anche i criteri `PRONTO PER TASK`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "WF-DOC-002",
      "document_path": "docs/tennis-decision-ui/ai/03-workflow-esecutivo.md",
      "report_id": "TDUI-DOC-REPORT-004",
      "report_path": "../Report documentale/04 - 03-workflow-esecutivo.md",
      "priority": "high",
      "type": "artifact_reproducibility",
      "action": "Eliminare `repomix@latest`: usare una versione approvata e dichiarata oppure introdurre, in una task separata, un generatore project-owned.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "WF-DOC-003",
      "document_path": "docs/tennis-decision-ui/ai/03-workflow-esecutivo.md",
      "report_id": "TDUI-DOC-REPORT-004",
      "report_path": "../Report documentale/04 - 03-workflow-esecutivo.md",
      "priority": "high",
      "type": "context_integrity",
      "action": "Definire un artefatto bounded e segmentabile con manifest, ordine, dimensioni e digest, senza inventare soglie prima della decisione dell’utente.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "WF-DOC-004",
      "document_path": "docs/tennis-decision-ui/ai/03-workflow-esecutivo.md",
      "report_id": "TDUI-DOC-REPORT-004",
      "report_path": "../Report documentale/04 - 03-workflow-esecutivo.md",
      "priority": "medium",
      "type": "deletion_evidence",
      "action": "Definire manifest e output Git richiesti per task di sola cancellazione, senza creare un falso `fileModificati.md`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "WF-DOC-005",
      "document_path": "docs/tennis-decision-ui/ai/03-workflow-esecutivo.md",
      "report_id": "TDUI-DOC-REPORT-004",
      "report_path": "../Report documentale/04 - 03-workflow-esecutivo.md",
      "priority": "high",
      "type": "document_modularization",
      "action": "Mantenere lifecycle e ruoli in `03-workflow-esecutivo.md`, spostare la diagnosi in `04-diagnosi-e-modularizzazione.md` e gli artefatti esecutivi in `05-artefatti-esecutivi.md`, aggiornando indice e link.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "WF-DOC-006",
      "document_path": "docs/tennis-decision-ui/ai/03-workflow-esecutivo.md",
      "report_id": "TDUI-DOC-REPORT-004",
      "report_path": "../Report documentale/04 - 03-workflow-esecutivo.md",
      "priority": "medium",
      "type": "review_and_git_gate",
      "action": "Rendere gli artefatti di revisione condizionali, distinguere le fasi di chiusura, completare i controlli Git e proteggere gli artefatti locali tramite `.gitignore` quando approvato.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }