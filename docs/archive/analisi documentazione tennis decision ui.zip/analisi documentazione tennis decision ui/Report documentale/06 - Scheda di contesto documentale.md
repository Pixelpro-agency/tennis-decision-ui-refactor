# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/api/02-betfair.md`

Tipo di documento:  
API / contratto HTTP.

Ruolo documentale:  
Contratto HTTP del router Betfair. Nella versione storicamente analizzata censiva cinque endpoint del router e riuniva nello stesso file letture Betfair, integrity/health, Money Flow History, `/odds` e `/log`, e login-window. 
## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

Il CODE AUTHORITY costituisce la baseline tecnica della successiva verifica; la documentation structure baseline serve invece per recuperare forma e struttura precedente senza assumerla come stato tecnico corrente.

## Fonti storiche consultate

- `Report documentale/06 - 02-betfair.md` — `TDUI-DOC-REPORT-006`, relativo al documento target e al commit documentale `4c5f43b007149f3210c27d7565357a447a3a6ef4`.
- `06 - TODO e Json.md` — registro Markdown e JSON delle task associate al documento target.

## Task storicamente associate

- `BETFAIR-API-001` — stato: completata.
  Argomento coinvolto: contratto CDP status di `/latest`, `cdpUrl` e relativo comportamento di lettura.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-API-002` — stato: completata.
  Argomento coinvolto: contratto pubblico `integrity`, incluse reason di partial persistence e recovery.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-API-003` — stato: completata.
  Argomento coinvolto: shape HTTP della timeline Betfair, normalizzazione in lettura, `latest` e `integrity`.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-API-004` — stato: completata.
  Argomento coinvolto: semantica dei risultati del loader e distinzione fra risorsa mancante, errori di lettura e JSON non valido; relazione storica con `MATCH-API-005`.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-API-005` — stato: completata.
  Argomento coinvolto: risposta `/latest` in assenza di tick valido e significato distinto di `latestTimestamp` e `metadata.updatedAt`.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-API-006` — stato: completata.
  Argomento coinvolto: contratto numerico e anomalie del Money Flow History.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-API-007` — stato: completata.
  Argomento coinvolto: superficie deprecata `/odds`, validazione del target e mapping/redazione degli errori.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-API-008` — stato: completata.
  Argomento coinvolto: contratto login-window, `mode`, runtime identity e deduplica.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-API-009` — stato: completata.
  Argomento coinvolto: organizzazione documentale del contratto Betfair, facade, owner tematici, indice/link e sezione di verifica.
  Uso consentito: verificare nel CODE AUTHORITY e nella struttura documentale corrente quale assetto sia effettivamente presente.

Il registro Markdown marca tutte le nove task con `[x]`; il JSON associato registra inoltre le task come `completed`. 
## Cambiamenti strutturali storicamente rilevanti

- Al documento era associata una modularizzazione per responsabilità: `02-betfair.md` come facade e quattro owner tematici dedicati rispettivamente a letture/integrity/health, Money Flow History, odds/log e login-window.
- `BETFAIR-API-009` risulta storicamente completata nel registro task, ma le fonti fornite non dimostrano autonomamente che i quattro nuovi file siano stati realmente creati nello stato corrente della documentazione.
- La presenza effettiva della modularizzazione deve quindi essere verificata sulla documentation structure baseline e sulla struttura corrente, senza ricrearla sulla sola base del report storico.

## Struttura precedente da considerare

La versione analizzata aveva 659 righe e riuniva quattro responsabilità principali:

- letture `/latest` e `/json`, integrity e health;
- Money Flow History;
- `/odds` e `/log`;
- login-window.

Erano inoltre presenti una tabella generale degli endpoint e una sezione di verifica/test. Il report storico individuava come possibile assetto successivo una facade sintetica con scopo, mount, tabella completa degli endpoint, principi comuni, stato delle superfici deprecate, collegamenti agli owner e matrici sintetiche di status e test.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/routes/betfair.js`
- `backend/src/routes/betfair/latestPayload.js`
- `backend/src/routes/betfair/cdpStatus.js`
- `backend/src/routes/betfair/moneyFlowHistory.js` e `moneyFlowHistorySeries.js`
- `backend/src/routes/betfair/oddsResponse.js`
- `backend/src/routes/betfair/loginWindow.js` e `loginWindowLifecycle.js`
- `backend/src/runtime/runtimeLogger.js`
- `backend/src/sofa/betfairHealth.js`
- `backend/src/sofa/timelineStore.js`
- `backend/src/sofa/matchHistory/commitJournal/integrity.js`
- relativi test route, Money Flow, runtime logger e login.

Queste sono le principali sorgenti che il report storico dichiara di aver confrontato con il documento.

Possibile fonte da verificare quando pertinente al contratto `/odds`:  
`backend/src/sofa/betfair/url.js`.

## Owner/documenti collegati

Relazioni documentali storicamente associate alla modularizzazione:

- `docs/tennis-decision-ui/api/betfair/01-read-integrity-and-health.md` — letture `/latest` e `/json`, integrity, health e CDP status.
- `docs/tennis-decision-ui/api/betfair/02-money-flow-history.md` — Money Flow History.
- `docs/tennis-decision-ui/api/betfair/03-odds-and-log.md` — `/odds`, `/log` e relativi confini.
- `docs/tennis-decision-ui/api/betfair/04-login-window.md` — contratto e lifecycle login-window.

La loro esistenza nello stato documentale corrente non deve essere dedotta dal solo report.

`MATCH-API-005` è inoltre citata storicamente come relazione da considerare per la semantica degli errori di lettura; le fonti fornite non identificano qui un percorso documentale owner da assumere automaticamente.

## Guardrail specifici per questo documento

- Mantenere il ruolo di contratto HTTP/API Betfair; non trasformarlo in documento di implementazione interna o audit.
- Verificare nel CODE AUTHORITY i cinque endpoint e la loro shape corrente prima di descriverne il comportamento.
- Distinguere ciò che appartiene alla facade da ciò che, nella struttura corrente, è eventualmente posseduto da owner Betfair separati.
- Non duplicare nei diversi documenti owner dettagli già posseduti altrove.
- Conservare come confini tematici distinti letture/integrity/health, Money Flow, odds/log e login-window quando la struttura documentale corrente conferma tale separazione.
- Non trasformare task storicamente completate in istruzioni di implementazione o in garanzia che uno specifico comportamento storico sia ancora presente.

## Informazioni storiche da NON assumere come correnti

- Le descrizioni tecniche del report appartengono al commit storico analizzato e non costituiscono authority tecnica corrente.
- Le proposte contenute nell'audit, comprese alternative di implementazione o decisioni future, non devono essere riportate come comportamento esistente.
- L'eventuale introduzione di un loader strutturato per distinguere missing/read failure/JSON invalido non deve essere assunta come implementata sulla sola base del report storico.
- Le alternative storiche sul fallback di `mode`, sull'identità/deduplica login-window e sul destino della route `/odds` non rappresentano decisioni correnti senza verifica nel CODE AUTHORITY.
- I test elencati dal report come controlli previsti o da aggiungere non devono essere assunti come validation effettivamente create. Il report stesso distingueva test già presenti da un test CDP da aggiungere dopo implementazione.
- I quattro file della modularizzazione sono indicati nel materiale come file proposti/richiesti; la loro presenza effettiva deve essere verificata.

## Discrepanze o limiti delle fonti

**DISCREPANZA STORICA DA NON RISOLVERE AUTOMATICAMENTE**

Il registro delle task marca `BETFAIR-API-009` come completata, mentre la stessa fonte descrive ancora la modularizzazione come **“richiesta”** e i quattro owner come **“file proposti”**.

Il report di audit, inoltre, presenta esplicitamente quella struttura come “modularizzazione consigliata” e i quattro documenti come struttura proposta; durante l'analisi i file mappa non erano stati aggiornati. 
Di conseguenza, dalle sole fonti fornite non è possibile stabilire se la modularizzazione sia stata realmente materializzata, né quali validation aggiuntive siano state effettivamente create dopo l'audit. Questi punti devono essere determinati dalla struttura documentale e dal CODE AUTHORITY indicati nella baseline.