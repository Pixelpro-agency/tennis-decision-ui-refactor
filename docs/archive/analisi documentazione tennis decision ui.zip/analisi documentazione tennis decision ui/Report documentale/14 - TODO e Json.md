TODO:

Report: [`../Report documentale/14 - 01-scraper-lifecycle.md`](../Report%20documentale/14%20-%2001-scraper-lifecycle.md) — `TDUI-DOC-REPORT-014`.

Modularizzazione: **valutata, non necessaria**. Spawn, deduplica, runtime identity, terminazione, restore e confine di persistenza appartengono allo stesso lifecycle; va invece rimosso lo storico di collaudo inline e ridotta la duplicazione con gli owner specialistici.

- [x] **`BETFAIR-LIFE-001`** — priorità `critical` — Documentata la deduplica reale per scraper key URL e runtime identity, distinta dalla market authority globale prevista da `IMPL-016`.
- [x] **`BETFAIR-LIFE-002`** — priorità `critical` — Introdotto `trackingSessionId`: la Promise non viene condivisa tra sessioni e una callback stale viene scartata prima di runtime, gate e persistenza; aggiunti i test dedicati.
- [x] **`BETFAIR-LIFE-003`** — priorità `high` — Precisato che `profileDir` è soltanto sottoposto a trim e non rappresenta una physical-profile authority canonica.
- [x] **`BETFAIR-LIFE-004`** — priorità `critical` — Separati nel contratto `executionToken`, Python generation e tracking session authority, senza attribuire alla generation effetti JavaScript.
- [x] **`BETFAIR-LIFE-005`** — priorità `critical` — Corretto il lifecycle mismatch: il gate blocca normalmente il campione causale, ma generation e terminazione Betfair non rendono session-safe SofaScore già in volo.
- [x] **`BETFAIR-LIFE-006`** — priorità `critical` — Rimossi `/api/betfair/odds`, helper e test dedicati; riallineati indice, owner API e documenti collegati.
- [x] **`BETFAIR-LIFE-007`** — priorità `high` — Distinta la normalizzazione di `scraperKey()` dalla validazione backend-owned condivisa di protocollo e host.
- [x] **`BETFAIR-LIFE-008`** — priorità `high` — Corretto il confine read-only e documentato il probe CDP validato loopback e bounded di `/latest`.
- [x] **`BETFAIR-LIFE-009`** — priorità `high` — Il tracking canonico passa sempre `noCache:true` e il runner aggiunge `--no-cache`; copertura aggiornata.
- [x] **`BETFAIR-LIFE-010`** — priorità `high` — Limitato stdout a 4 MiB per default, con errore statico, terminazione del child e test overflow senza esposizione raw.
- [x] **`BETFAIR-LIFE-011`** — priorità `high` — Rimosse le fixture obsolete e concentrata la verifica sul runner corrente, includendo sessione, cache e output bounded.
- [x] **`BETFAIR-LIFE-012`** — priorità `medium` — Rimosso dall’owner il blocco storico `Stato Task 2`, mantenendo il documento sul contratto corrente senza inventare metadata di collaudo.

JSON:

    {
      "change_id": "BETFAIR-LIFE-001",
      "report_id": "TDUI-DOC-REPORT-014",
      "document_path": "docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md",
      "priority": "critical",
      "type": "scraper_key_vs_market_authority",
      "action": "Correggere la deduplica da market authority a URL-key + runtime identity e collegare IMPL-016 come target globale.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-LIFE-002",
      "report_id": "TDUI-DOC-REPORT-014",
      "document_path": "docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md",
      "priority": "critical",
      "type": "cross_session_promise_reuse",
      "action": "Dichiarare e correggere il riuso Promise non session-safe sulla stessa key/runtime, coordinando IMPL-006/016.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-LIFE-003",
      "report_id": "TDUI-DOC-REPORT-014",
      "document_path": "docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md",
      "priority": "high",
      "type": "persistent_runtime_identity",
      "action": "Precisare che profileDir è soltanto trimmed e non una physical-profile authority canonica; coordinare la futura identity con IMPL-016.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-LIFE-004",
      "report_id": "TDUI-DOC-REPORT-014",
      "document_path": "docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md",
      "priority": "critical",
      "type": "process_generation_semantics",
      "action": "Separare executionToken, Python generation e tracking session authority e rimuovere proprietà JavaScript erroneamente attribuite alla generation.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-LIFE-005",
      "report_id": "TDUI-DOC-REPORT-014",
      "document_path": "docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md",
      "priority": "critical",
      "type": "mismatch_stale_callback_semantics",
      "action": "Correggere la semantica mismatch/stale Sofa callback: la Python generation non è un effect guard applicativo; coordinare con IMPL-006.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-LIFE-006",
      "report_id": "TDUI-DOC-REPORT-014",
      "document_path": "docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md",
      "priority": "critical",
      "type": "legacy_odds_lifecycle_entrypoint",
      "action": "Documentare /api/betfair/odds come secondo ingresso mutante legacy che bypassa tracking/gate/deferPersistence e rimuoverlo con la task già approvata.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-LIFE-007",
      "report_id": "TDUI-DOC-REPORT-014",
      "document_path": "docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md",
      "priority": "high",
      "type": "betfair_url_authority",
      "action": "Dichiarare la Betfair URL authority condivisa ancora mancante e non confondere scraperKey con validazione URL.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-LIFE-008",
      "report_id": "TDUI-DOC-REPORT-014",
      "document_path": "docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md",
      "priority": "high",
      "type": "readonly_network_probe_semantics",
      "action": "Distinguere read-only da assenza assoluta di network I/O e confinare i diagnostic probe a target validati/bounded.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-LIFE-009",
      "report_id": "TDUI-DOC-REPORT-014",
      "document_path": "docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md",
      "priority": "high",
      "type": "tracking_cache_policy",
      "action": "Disabilitare sempre la cache nel tracking canonico e documentare il caso corrente senza Graph in cui --no-cache non viene passato.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-LIFE-010",
      "report_id": "TDUI-DOC-REPORT-014",
      "document_path": "docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md",
      "priority": "high",
      "type": "child_process_output_boundedness",
      "action": "Rendere bounded stdout, correggere la semantica stderr e aggiungere terminazione/error code statico su output troppo grande.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-LIFE-011",
      "report_id": "TDUI-DOC-REPORT-014",
      "document_path": "docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md",
      "priority": "high",
      "type": "lifecycle_verification_contract",
      "action": "Riallineare i test lifecycle al processRegistry corrente, includere scraperLifecycle.test.mjs e coprire key/session/profile/cache/output/legacy odds.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-LIFE-012",
      "report_id": "TDUI-DOC-REPORT-014",
      "document_path": "docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md",
      "priority": "medium",
      "type": "historical_validation_ownership",
      "action": "Spostare il collaudo storico fuori dall’owner lifecycle e mantenerlo soltanto in validation/registri con metadata reali.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }