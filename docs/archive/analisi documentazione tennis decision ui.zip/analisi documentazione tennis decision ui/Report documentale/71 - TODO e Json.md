TODO:

Report: [`Report documentale/71 - scripts-validation-README.md`](../Report%20documentale/71%20-%20scripts-validation-README.md) — `TDUI-DOC-REPORT-071`.

Modularizzazione: **valutata, non necessaria**.

- [ ] **`VALID-RUNNER-001`** — **HIGH** — Rendere fail-closed il boundary live/offline del validation runner a livello di entry/capability selezionata: una entry `liveRequired:true` non deve poter essere eseguita senza consenso esplicito indipendentemente dal profilo che la seleziona; `full-offline` deve rifiutare `browser`, `credentials`, `external-network` e `tracking`, e `backend/frontend/python` devono avere una policy esplicita. Aggiungere self-test sintetici senza browser/rete reali e riallineare il README; `TEST-073` resta completato perché copre correttamente il solo profilo `fast`.

JSON:

    {
      "change_id": "VALID-RUNNER-001",
      "report_id": "TDUI-DOC-REPORT-071",
      "document_path": "scripts/validation/README.md",
      "priority": "high",
      "type": "validation_runner_live_offline_safety_gate",
      "action": "Rendere fail-closed il boundary live/offline del validation runner a livello di entry/capability selezionata: una entry `liveRequired:true` non deve poter essere eseguita senza consenso esplicito indipendentemente dal profilo che la seleziona; `full-offline` deve rifiutare `browser`, `credentials`, `external-network` e `tracking`, e backend/frontend/python devono avere una policy esplicita. Aggiungere self-test sintetici senza browser/rete reali e riallineare il README; TEST-073 resta completato perché copre correttamente il solo profilo `fast`.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    }