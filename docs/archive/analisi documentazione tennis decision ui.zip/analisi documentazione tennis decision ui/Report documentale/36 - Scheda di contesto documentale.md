# Scheda di contesto documentale

## Documento target

Percorso:
`docs/tennis-decision-ui/operations/05-retention-and-cleanup.md`

Tipo di documento:
runbook operativo.

Ruolo documentale:
classificare gli artefatti locali e descrivere i confini operativi di retention delle cache, backup e pulizia controllata, mantenendoli distinti dalla persistence canonica, dal recovery e dal repair.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `Report documentale/36 - 05-retention-and-cleanup.md` — `TDUI-DOC-REPORT-036`.
- `36 - TODO e Json.md` — registro Markdown e JSON delle task `RETENTION-001`, `RETENTION-002` e `RETENTION-003`.

## Task storicamente associate

- `RETENTION-001` — stato: completata  
  Argomento coinvolto: dominio per-cache delle policy `max-files` e `max-total-bytes`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `RETENTION-002` — stato: completata  
  Argomento coinvolto: semantica best-effort per file dell'apply e possibile coesistenza tra esito non-zero, rimozioni già eseguite ed errori.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `RETENTION-003` — stato: non completata  
  Argomento coinvolto: coerenza multi-file dei backup destinati a restore o audit. Non deve essere assunta come comportamento implementato.  
  Uso consentito: evitare di descrivere come già presente una procedura project-owned con snapshot boundary coerente.

## Cambiamenti strutturali storicamente rilevanti

- Modularizzazione valutata e non ritenuta necessaria.
- Nessun nuovo documento canonico risulta creato per separare backup, cache cleanup o retention diagnostica.
- Il documento risulta storicamente aggiornato in modo mirato per esplicitare la semantica per-cache delle policy e l'esito potenzialmente parziale dell'apply.

## Struttura precedente da considerare

- Classificazione distinta degli artefatti locali.
- Separazione tra retention delle cache, retention diagnostica, backup e cleanup controllato.
- Confini espliciti rispetto a history, timeline, journal, writer authority, Source Identity ed Evidence derivata.
- Stato di validazione distinto tra test, dry-run e apply reale.
- Indicazioni operative su output strutturato e risultato delle esecuzioni.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `scripts/cleanup_runtime_cache.py`
- `scripts/cleanup_runtime_cache_test.py`
- `launcher/session.py`
- `launcher/services.py`
- `scrapers/sofa/cache.py`
- `scrapers/betfair/cache.py`
- `backend/match_history/.pending_commits/` e `.writer_authority/` come domini esclusi dalla pulizia delle cache

## Owner/documenti collegati

- `docs/tennis-decision-ui/reference/01-repository-map.md` — riferimento per collocazione e ownership dei principali artefatti del repository.
- Documentazione di persistence e writer authority — owner dei dati canonici, del journal e dell'autorità di scrittura; questo runbook ne descrive soltanto i confini rispetto alla retention.
- Documentazione di validation e rollback — owner della provenienza e del significato degli artefatti di validazione; l'output della utility non va assimilato automaticamente a una validazione completa.

## Guardrail specifici per questo documento

- Mantenere separate cache, history/timeline, journal, writer authority ed Evidence derivata.
- Mantenere separate retention, recovery, repair e cleanup manuale della persistence.
- Trattare la utility come cleanup a allow-list delle cache, non come strumento generico per directory arbitrarie.
- Non presentare dump diagnostici e runtime log come governati automaticamente dalla stessa policy delle cache senza conferma nel CODE AUTHORITY.
- Non descrivere Evidence come store persistito autonomo se continua a essere una vista derivata.
- Distinguere TTL applicativo delle cache e retention dei file su disco.
- Non trasformare il runbook in documento di implementazione, audit o roadmap.

## Informazioni storiche da NON assumere come correnti

- Le valutazioni tecniche e i finding contenuti nel report `TDUI-DOC-REPORT-036`.
- Lo stato storico dell'apply reale, dei controlli offline e della relativa validazione.
- Le porte, i lock, i manifest runtime e i controlli di identità file descritti dal report storico.
- L'esistenza di una procedura coerente di backup multi-file: `RETENTION-003` risulta non completata.
- L'esistenza di retention automatica per dump diagnostici e runtime log.
- I dettagli storici di test, conteggi, risultati dry-run e proposte di evoluzione dell'output strutturato.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza individuata tra il registro Markdown e il JSON: entrambi riportano `RETENTION-001` e `RETENTION-002` completate e `RETENTION-003` non completata.
- Le fonti consultate sono storiche e non costituiscono authority tecnica corrente.
- Il documento target corrente non era incluso tra gli allegati; forma e struttura precedente devono essere recuperate dalla documentation structure baseline.
