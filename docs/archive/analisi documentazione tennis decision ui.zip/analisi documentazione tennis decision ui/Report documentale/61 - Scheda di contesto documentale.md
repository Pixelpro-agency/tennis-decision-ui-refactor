# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/audit-documentazione/02-moduli-frontend-python.md`

Tipo di documento:  
facade / entrypoint stabile del modulo storico di audit documentale B3/B4.

Ruolo documentale:  
mantenere stabile il percorso già referenziato dagli indici, presentare il perimetro complessivo dei checkpoint storici B3/B4 e indirizzare ai due child che possiedono le schede owner dettagliate. La facade preserva il mapping complessivo `DOC-014…019`, ma non deve duplicare gli owner presenti nei child e non costituisce documentazione tecnica canonica dei domini citati.

Struttura corrente collegata:

- `implementazioni/audit-documentazione/02-moduli-frontend-python/01-moduli-owner-b3.md`
- `implementazioni/audit-documentazione/02-moduli-frontend-python/02-frontend-python-b4.md`

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `61 - Report 02-moduli-frontend-python.md` — `TDUI-DOC-REPORT-061`.
- `61 - TODO e Json.md`.
- `Report retroattivo — completamento DOC-AUDIT-B34-002`.

## Task storicamente associate

- `DOC-AUDIT-B34-001` — stato: completata  
  Argomento coinvolto: reconciliation tra checkpoint storici B3/B4 e stato documentale successivo/corrente.  
  Uso consentito: verificare nel CODE AUTHORITY gli effetti correnti pertinenti al ruolo del documento, mantenendo distinta la provenance storica.

- `DOC-AUDIT-B34-002` — stato: completata  
  Argomento coinvolto: modularizzazione del precedente contenitore unitario B3/B4, mantenendo `02-moduli-frontend-python.md` come facade stabile e separando B3 e B4 nei due child correnti.  
  Uso consentito: assumere lo split come struttura documentale già esistente e verificarne contenuto e pertinenza rispetto alle authority correnti.

## Cambiamenti strutturali storicamente rilevanti

- `DOC-AUDIT-B34-001` ha introdotto e preservato la distinzione tra checkpoint storico e stato successivo/corrente.
- `DOC-AUDIT-B34-002` ha modularizzato il precedente file unitario.
- `02-moduli-frontend-python.md` è rimasto facade stabile.
- Il checkpoint B3 è ora posseduto da `01-moduli-owner-b3.md`.
- Il checkpoint B4 è ora posseduto da `02-frontend-python-b4.md`.
- Gli owner `DOC-014…019` non sono stati rinumerati, persi o duplicati durante lo split.
- `DOC-014…017` appartengono al child B3.
- `DOC-018…019` appartengono al child B4.
- La provenance storica, inclusi baseline B3, riferimenti `.mdx` e qualifier `test letti/non eseguiti`, è stata preservata.

## Struttura precedente da considerare

Prima della modularizzazione, il file unitario conteneva:

- §12 — checkpoint B3, relativo ai documenti owner dei moduli;
- §13 — checkpoint B4, relativo a Frontend e Python.

Questa struttura resta rilevante come provenance storica, ma oggi le due responsabilità sono separate nei child B3 e B4.

Il perimetro storico B3 comprendeva principalmente:

- SofaScore;
- Betfair;
- Storage;
- Evidence;
- Source Identity.

Il perimetro storico B4 comprendeva principalmente:

- frontend/session shell;
- polling/view model;
- UI;
- componenti Python/scraper.

Il qualifier storico secondo cui i test del checkpoint furono letti/ispezionati ma non eseguiti deve essere mantenuto come provenance e non trasformato in PASS corrente.

## Aree da verificare nel CODE AUTHORITY

Per il contenuto collegato al B3:

- `backend/src/sofa/betfair/trackerUpdate.js`
- `backend/src/sofa/matchHistory.js`
- domini Storage / journal / recovery
- Evidence builder
- Source Identity

Per il contenuto collegato al B4:

- React hooks/components e view model
- launcher/runtime
- Python packages e scraper
- `backend/src/routes/betfair/oddsResponse.js`
- `scrapers/betfair/network_capture.py`
- `scrapers/betfair/scrape.py`

Usare queste aree soltanto per verificare il comportamento corrente pertinente alla documentazione; non assumere come correnti le conclusioni tecniche del report storico.

## Owner/documenti collegati

- `implementazioni/02-audit-documentazione.md` — parent che mantiene il riferimento stabile alla facade.
- `implementazioni/audit-documentazione/02-moduli-frontend-python/01-moduli-owner-b3.md` — child corrente del checkpoint B3; possiede `DOC-014`, `DOC-015`, `DOC-016`, `DOC-017`.
- `implementazioni/audit-documentazione/02-moduli-frontend-python/02-frontend-python-b4.md` — child corrente del checkpoint B4; possiede `DOC-018`, `DOC-019`.
- `FRONTEND-002` — owner separato dell'implementation gap storicamente collegato a `DOC-018`.
- `EVIDENCE-001`, `SOFA-001` e `TEST-001` — riferimenti coordinati preservati durante la modularizzazione.

## Guardrail specifici per questo documento

- Mantenere `02-moduli-frontend-python.md` come facade stabile.
- Non riportare nella facade le schede owner dettagliate già possedute dai child B3/B4.
- Preservare la distinzione tra checkpoint storico e stato corrente.
- Non convertire `test letti/non eseguiti` in PASS o validazione corrente.
- Trattare i riferimenti `.mdx` dei checkpoint come provenance storica, non come path correnti automaticamente validi.
- Mantenere separato il lifecycle documentale dagli owner di implementazione.
- Non rinumerare né duplicare `DOC-014…019`.
- Non trasformare facade o child in documentazione tecnica canonica dei domini che descrivono.
- Non attribuire retroattivamente PASS a registry checker, link checker o profilo `fast` in assenza di un'esecuzione separatamente documentata.

## Informazioni storiche da NON assumere come correnti

- Gli stati tecnici rilevati dal report storico `TDUI-DOC-REPORT-061`.
- Gli esiti originari dei checkpoint B3/B4.
- Le formulazioni `nessuna modifica a docs/ o codice`, che descrivevano l'esito del checkpoint al tempo dell'audit.
- I percorsi `.mdx` pre-migrazione.
- La baseline B3 storica `b277bd9b7373dfd8702e65446c88bab7a0f64dcc`.
- Finding, priorità, proposte di correzione e acceptance criteria storici del report, salvo quando servono esclusivamente come provenance.
- Eventuali PASS di `scripts/check_registry_consistency.py`, `scripts/check_documentation_links.py` o `node scripts/validation/run.mjs fast`: il completamento della modularizzazione è documentato, ma queste esecuzioni repository-wide non risultano dimostrate nel contesto del report retroattivo.

I due child B3/B4 non appartengono a questa lista: costituiscono ora struttura documentale corrente.

## Discrepanze o limiti delle fonti

Il report storico `TDUI-DOC-REPORT-061` e la precedente versione di `61 - TODO e Json.md` rappresentavano `DOC-AUDIT-B34-002` come task ancora aperta. Il report retroattivo successivo registra invece la sua applicazione e chiusura e richiede che gli artefatti derivati vengano aggiornati a posteriori, senza riscrivere il report storico.

Stato da assumere nella presente Scheda:

- `DOC-AUDIT-B34-001` — completata;
- `DOC-AUDIT-B34-002` — completata;
- `02-moduli-frontend-python.md` — facade stabile esistente;
- `01-moduli-owner-b3.md` — child B3 esistente;
- `02-frontend-python-b4.md` — child B4 esistente.

La fonte retroattiva aggiorna esclusivamente gli effetti del completamento di `DOC-AUDIT-B34-002`: non modifica il significato tecnico o il lifecycle degli owner `DOC-014…019`, non riapre `DOC-AUDIT-B34-001` e non rivaluta le priorità storiche.
