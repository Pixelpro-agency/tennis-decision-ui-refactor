# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/api/04-preflight.md`  
(storicamente `docs/tennis-decision-ui/api/05-preflight.md` prima della rimozione di Strategy e della successiva rinumerazione).

Tipo di documento:  
API / contratto HTTP.

Ruolo documentale:  
Contratto HTTP del Preflight locale e diagnostico. Il report storico attribuiva al documento la responsabilità di descrivere la superficie HTTP Preflight, mentre i dettagli runtime appartenenti ad altri owner dovevano restare separati. 
## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing` — definisce scopo, baseline, vincoli e forma della presente Scheda.
- `09 - Report 05-preflight.md` — report documentale `TDUI-DOC-REPORT-009` relativo alla precedente `05-preflight.md`.
- `09 - TODO e Json.md` — registro storico successivo delle task `PREFLIGHT-API-001..009`, tutte marcate completate, con percorso aggiornato a `04-preflight.md`.

## Task storicamente associate

- `PREFLIGHT-API-001` — stato: completata  
  Argomento coinvolto: boundedness del probe CDP, timeout e gestione degli esiti.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PREFLIGHT-API-002` — stato: completata  
  Argomento coinvolto: authority e validazione URL SofaScore, event ID e logging dell'input.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PREFLIGHT-API-003` — stato: completata  
  Argomento coinvolto: validator Betfair condiviso fra Preflight e altri consumer.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PREFLIGHT-API-004` — stato: completata  
  Argomento coinvolto: coerenza tra validazione Graph del Preflight e parser runtime Python.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PREFLIGHT-API-005` — stato: completata  
  Argomento coinvolto: semantica advisory dei check Preflight rispetto a `Link Accounts & Start`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PREFLIGHT-API-006` — stato: completata  
  Argomento coinvolto: superficie Health e rapporto tra `/api/test/health` e `/api/health`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PREFLIGHT-API-007` — stato: completata  
  Argomento coinvolto: coverage dei contratti Preflight backend/frontend.  
  Uso consentito: verificare nel CODE AUTHORITY quali verifiche esistono realmente e sono pertinenti al documento.

- `PREFLIGHT-API-008` — stato: completata  
  Argomento coinvolto: messaggi frontend Preflight, testo UI e boundedness degli errori esposti.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PREFLIGHT-API-009` — stato: completata  
  Argomento coinvolto: riscrittura e rinomina del documento, riduzione delle duplicazioni e mantenimento di un unico owner API.  
  Uso consentito: verificare nel CODE AUTHORITY la forma e il contenuto correnti di `04-preflight.md`.

## Cambiamenti strutturali storicamente rilevanti

- Il documento risulta storicamente rinominato da `05-preflight.md` a `04-preflight.md`.
- La modularizzazione è stata valutata ma non ritenuta necessaria; non risultano nuovi documenti derivati.
- Il registro storico indica una riscrittura più compatta del documento, mantenuto come unico owner API Preflight.
- Il registro storico indica la rimozione di `/api/test/health`, con `/api/health` indicato come authority Health. Tale stato deve essere confermato nel CODE AUTHORITY.

## Struttura precedente da considerare

La versione analizzata dal report era organizzata attorno ai cinque endpoint del router Preflight e comprendeva sezioni dedicate a CDP, SofaScore, Betfair, Graph URL, comportamento frontend, ownership e verifica.

Il report considerava pertinente mantenere nel documento API soprattutto metodo, path, input, shape dell'output, status, effetti collaterali, limiti del Preflight e rinvii agli owner runtime, evitando di duplicare dettagli posseduti altrove.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/routes/test.js`
- `backend/src/routes/test/graphUrlValidation.js`
- `backend/src/utils/cdpUrl.js`
- `backend/src/sofa/extractEventId.js`
- `backend/src/routes/betfair.js`
- `backend/src/routes/betfair/loginWindow.js`
- `backend/src/server.js`
- `scrapers/betfair/graph_url.py`
- `frontend/src/hooks/usePreflightChecks.js`
- `frontend/src/utils/preflight.js`
- `frontend/src/components/PreflightChecks.jsx`
- `frontend/src/components/StartAnalysisPanel.jsx`
- relativi test direttamente associati ai contratti Preflight.

Queste sono le principali aree indicate dal report come fonti del documento.

## Owner/documenti collegati

- `docs/tennis-decision-ui/api/06-runtime-health.md` — storico owner del contratto completo Runtime Health; il documento Preflight non dovrebbe duplicarne il contenuto.
- `docs/tennis-decision-ui/modules/python/04-betfair-graph-url-validation.md` — storico owner dei dettagli runtime relativi a parsing, mapping e validazione Graph Python.

Questi collegamenti servono esclusivamente a comprendere i confini di ownership del documento target.

## Guardrail specifici per questo documento

- Mantenere la natura di contratto API del Preflight; non trasformarlo in documento generale del runtime.
- Verificare nel CODE AUTHORITY la superficie HTTP realmente corrente prima di riportare endpoint o payload.
- Mantenere separati i dettagli Graph posseduti dal modulo Python e quelli Health posseduti dal relativo documento API.
- Non assumere che il Preflight sia un gate obbligatorio di Start soltanto perché esistono check frontend: il registro storico lo descrive come advisory.
- Non creare nuovi documenti o sottodocumenti Preflight sulla base del vecchio audit: la modularizzazione risulta storicamente non necessaria.

## Informazioni storiche da NON assumere come correnti

- La superficie di cinque endpoint descritta dal report appartiene alla baseline documentale precedente; in particolare `/api/test/health` risulta successivamente segnato come rimosso. - I comportamenti tecnici descritti dal report di audit rappresentano lo stato osservato al commit documentale `4c5f43b007149f3210c27d7565357a447a3a6ef4`, non la CODE AUTHORITY corrente.
- Finding, priorità, proposte di implementazione, ordine di applicazione e test suggeriti nel report non costituiscono descrizione del comportamento corrente.
- Il completamento storico delle task `PREFLIGHT-API-001..009` indica che il registro le considera applicate, ma il comportamento risultante deve essere ricavato dal CODE AUTHORITY e non dalle descrizioni delle task.

## Discrepanze o limiti delle fonti

- Il report `TDUI-DOC-REPORT-009` fotografa `05-preflight.md` prima delle modifiche successive, mentre il TODO/JSON registra le nove task come completate e il documento come rinominato `04-preflight.md`. Si tratta di due momenti storici differenti e non di una authority tecnica corrente. - Nei materiali forniti non è presente un report separato di applicazione/verifica che descriva in dettaglio l'esecuzione delle nove task; lo stato disponibile deriva dal TODO/JSON.
- Nessuna discrepanza Markdown ↔ JSON è individuata sullo stato delle task: entrambe le rappresentazioni presenti in `09 - TODO e Json.md` le indicano come completate. 