TODO:

Report: [`Report documentale/69 - 06-validazione-e-fixture.md`](../Report%20documentale/69%20-%2006-validazione-e-fixture.md) — `TDUI-DOC-REPORT-069`.

Modularizzazione: **eseguita**.

File creati:

```text
implementazioni/implementazioni-proposte/06-validazione-e-fixture/01-runner-e-result-ledger.md
implementazioni/implementazioni-proposte/06-validazione-e-fixture/02-fixture-e-sandbox.md
implementazioni/implementazioni-proposte/06-validazione-e-fixture/03-frontend-interaction-harness.md
```

Il file `implementazioni/implementazioni-proposte/06-validazione-e-fixture.md` resta come facade stabile.

- [x] **`IMPL-VALIDATION-001`** — **HIGH** — Riconciliare il boundary `IMPL-028↔IMPL-031`: mantenere `IMPL-028` completata e attribuirle runner, manifest e v1 run artifact già implementati; mantenere `IMPL-031` aperta come estensione del result contract/ledger storico, distinguendo i campi già presenti da quelli ancora mancanti e rendendo non ciclica la dependency `028↔031`. `TEST-069/070` restano parziali e non chiusi.
- [x] **`IMPL-VALIDATION-002`** — **MEDIUM-HIGH** — Mantenere `06-validazione-e-fixture.md` come facade stabile e separare runner + result ledger (`IMPL-028/031`), fixture + sandbox (`IMPL-029`) e frontend interaction harness (`IMPL-030`) nei tre child previsti, preservando closeout `IMPL-028`, `TEST-060…075`, estensioni condivise e ordine approvato senza duplicare owner.

JSON:

    {
      "change_id": "IMPL-VALIDATION-001",
      "report_id": "TDUI-DOC-REPORT-069",
      "document_path": "implementazioni/implementazioni-proposte/06-validazione-e-fixture.md",
      "priority": "high",
      "type": "implementation_coverage_owner_dependency_reconciliation",
      "action": "Riconciliare il boundary IMPL-028↔IMPL-031: mantenere IMPL-028 completata e attribuirle runner, manifest e v1 run artifact già implementati; mantenere IMPL-031 aperta come estensione del result contract/ledger storico, distinguendo i campi già presenti (SHA, profilo, timing, environment, workingTreeStatus, counts, warnings/limits, per-command results e output bounded/redacted) da quelli ancora mancanti (historical/latest-result authority, complete requirement coverage, blocked/planned/not-applicable semantics, buildResult, browserValidationStatus e top-level commands). Rendere non ciclica la dependency 028↔031 e non chiudere TEST-069/070.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "IMPL-VALIDATION-002",
      "report_id": "TDUI-DOC-REPORT-069",
      "document_path": "implementazioni/implementazioni-proposte/06-validazione-e-fixture.md",
      "priority": "medium-high",
      "type": "modularization_context_boundary",
      "action": "Mantenere `06-validazione-e-fixture.md` come facade stabile e separare le tre responsabilità reali in child dedicati: runner + result ledger (IMPL-028/031), fixture + sandbox (IMPL-029) e frontend interaction harness (IMPL-030), preservando closeout IMPL-028, TEST-060…075, estensioni condivise e ordine approvato senza duplicare owner.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }
