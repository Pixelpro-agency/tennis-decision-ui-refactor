TODO:

Report: [`Report documentale/39 - README-validations.md`](../Report%20documentale/39%20-%20README-validations.md) — `TDUI-DOC-REPORT-039`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`VALID-INDEX-001`** — priorità `high` — Definire la tassonomia historical evidence a livello documento/scenario (`live_observed`, `passed`, `failed`, `blocked`, `not_executed`, `not_applicable`, `historically_reported`) con qualificatori `not archived` e `not registered`.
- [x] **`VALID-INDEX-002`** — priorità `high` — Uniformare i metadata delle validation e le missing semantics (`known`, `non registrato`, `non archiviato`, `not applicable`); l’eventuale checker resta owner di `VALID-ROLL-006`.
- [x] **`VALID-INDEX-003`** — priorità `medium-high` — Definire run identity immutabile: una rerun produce un nuovo artifact/naming stabile e non sovrascrive retroattivamente l’evidenza precedente.

JSON:

    {
      "change_id": "VALID-INDEX-001",
      "report_id": "TDUI-DOC-REPORT-039",
      "document_path": "docs/validations/README.md",
      "priority": "high",
      "type": "historical_evidence_state_taxonomy",
      "action": "Definire la tassonomia historical evidence a livello documento/scenario (`live_observed`, `passed`, `failed`, `blocked`, `not_executed`, `not_applicable`, `historically_reported`) con qualificatori `not archived` e `not registered`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "VALID-INDEX-002",
      "report_id": "TDUI-DOC-REPORT-039",
      "document_path": "docs/validations/README.md",
      "priority": "high",
      "type": "validation_metadata_conformance",
      "action": "Uniformare i metadata delle validation e le missing semantics (`known`, `non registrato`, `non archiviato`, `not applicable`); l’eventuale checker resta owner di `VALID-ROLL-006`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "VALID-INDEX-003",
      "report_id": "TDUI-DOC-REPORT-039",
      "document_path": "docs/validations/README.md",
      "priority": "medium-high",
      "type": "immutable_validation_run_identity",
      "action": "Definire run identity immutabile: una rerun produce un nuovo artifact/naming stabile e non sovrascrive retroattivamente l’evidenza precedente.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }