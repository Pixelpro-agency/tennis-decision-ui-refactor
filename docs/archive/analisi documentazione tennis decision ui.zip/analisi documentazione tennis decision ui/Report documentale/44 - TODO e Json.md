TODO:

Report: [`Report documentale/44 - 00-metodo-e-stati.md`](../Report%20documentale/44%20-%2000-metodo-e-stati.md) — `TDUI-DOC-REPORT-044`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`METHOD-EVIDENCE-001`** — priorità `high` — Riformulare il modello di evidenza separando workflow lifecycle, implementation state, offline verification, live verification e provenance; preservare la gerarchia di affidabilità ma non comprimere dimensioni indipendenti in un solo stato.
- [x] **`METHOD-REG-001`** — priorità `high` — Allineare il contratto documentato del registry checker all’implementazione reale: discovery ricorsiva `implementazioni/**/*.md`, parity Block E+F, esclusione DEC, vocabolario status riconosciuto, controlli SHA/range/punto/prossimo-step e limiti; non attribuire controlli non implementati.
- [x] **`METHOD-LIFECYCLE-001`** — priorità `medium-high` — Convertire il metodo da istruzioni transitorie di migrazione/planning a steady-state: mantenere `.md`, separazione storico/corrente, artifact/link checks; marcare come storico o rimuovere dal flusso corrente coexistence MDX, mass conversion e cleanup di migrazione già conclusi.
- [x] **`METHOD-SCHEMA-001`** — priorità `medium` — Definire un minimum schema realistico per tipo di record (DOC/WORKFLOW, codice, IMPL, TEST, DEC) con grandfathering per le schede storiche; non imporre retroattivamente una card uniforme molto più ricca di quanto checker e registri correnti supportino.

JSON:

    {
      "change_id": "METHOD-EVIDENCE-001",
      "report_id": "TDUI-DOC-REPORT-044",
      "document_path": "implementazioni/00-metodo-e-stati.md",
      "priority": "high",
      "type": "evidence_state_model",
      "action": "Riformulare il modello di evidenza separando workflow lifecycle, implementation state, offline verification, live verification e provenance; preservare la gerarchia di affidabilità ma non comprimere dimensioni indipendenti in un solo stato.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "METHOD-REG-001",
      "report_id": "TDUI-DOC-REPORT-044",
      "document_path": "implementazioni/00-metodo-e-stati.md",
      "priority": "high",
      "type": "registry_checker_contract_alignment",
      "action": "Allineare il contratto documentato del registry checker all’implementazione reale: discovery ricorsiva `implementazioni/**/*.md`, parity Block E+F, esclusione DEC, vocabolario status riconosciuto, controlli SHA/range/punto/prossimo-step e limiti; non attribuire controlli non implementati.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "METHOD-LIFECYCLE-001",
      "report_id": "TDUI-DOC-REPORT-044",
      "document_path": "implementazioni/00-metodo-e-stati.md",
      "priority": "medium-high",
      "type": "steady_state_method_cleanup",
      "action": "Convertire il metodo da istruzioni transitorie di migrazione/planning a steady-state: mantenere `.md`, separazione storico/corrente, artifact/link checks; marcare come storico o rimuovere dal flusso corrente coexistence MDX, mass conversion e cleanup di migrazione già conclusi.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "METHOD-SCHEMA-001",
      "report_id": "TDUI-DOC-REPORT-044",
      "document_path": "implementazioni/00-metodo-e-stati.md",
      "priority": "medium",
      "type": "owner_card_schema_realism",
      "action": "Definire un minimum schema realistico per tipo di record (DOC/WORKFLOW, codice, IMPL, TEST, DEC) con grandfathering per le schede storiche; non imporre retroattivamente una card uniforme molto più ricca di quanto checker e registri correnti supportino.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }