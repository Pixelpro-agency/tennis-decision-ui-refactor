# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/modules/evidence/04-market-reactions.md`

Tipo di documento:  
Owner tecnico-documentale del dominio Evidence.

Ruolo documentale:  
Descrivere come vengono costruite e interpretate le osservazioni temporali Market Reactions, mantenendo confrontabili nello stesso documento i rami Significant Flow, Market → Field e Field → Market. Il dominio riguarda osservazioni temporali, non strategie, segnali, previsioni o attribuzioni causali.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- Report `TDUI-DOC-REPORT-019` relativo a `04-market-reactions.md`.
- Sezione TODO associata al report.
- JSON incrementale delle task `MARKET-REACT-001..010`.
- Prompt di preparazione della Scheda neutra.

## Task storicamente associate

- `MARKET-REACT-001` — stato: completata  
  Argomento coinvolto: distinzione tra attività Exchange isolata e osservazione temporale; contratto di interpretazione, causalità e disclaimer Market → Field.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `MARKET-REACT-002` — stato: completata  
  Argomento coinvolto: uso della confidence e della validazione Money Flow condivise nel ramo Significant Flow.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `MARKET-REACT-003` — stato: completata  
  Argomento coinvolto: criteri di eleggibilità di Significant Flow come `sourceMarketEvent`, inclusi suppression e disponibilità delle fonti necessarie.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `MARKET-REACT-004` — stato: completata  
  Argomento coinvolto: recency, clock skew e normalizzazione delle finestre Market → Field.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `MARKET-REACT-005` — stato: completata  
  Argomento coinvolto: distinzione tra risposta osservata, affidabilità della risposta e relative reason.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `MARKET-REACT-006` — stato: completata  
  Argomento coinvolto: distinzione tra qualità locale delle observation window e Data Quality globale dello snapshot Evidence.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `MARKET-REACT-007` — stato: completata  
  Argomento coinvolto: semantica separata di disponibilità della pipeline, large flow, rami Market-led e Field-led e risposta osservata.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `MARKET-REACT-008` — stato: completata  
  Argomento coinvolto: disponibilità delle card frontend e presentazione delle blocking reason possedute dal backend.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `MARKET-REACT-009` — stato: completata  
  Argomento coinvolto: mapping frontend dei campi backend, marker e disclaimer sulla causalità.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `MARKET-REACT-010` — stato: completata  
  Argomento coinvolto: validation storicamente associata a Significant Flow, recency, reliability, suppression, availability e mapping UI.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- Modularizzazione valutata ma non ritenuta necessaria.
- Nessun nuovo documento canonico risulta creato.
- Significant Flow, Market → Field e Field → Market sono rimasti nello stesso owner documentale.
- Il codice sottostante risultava già suddiviso in moduli distinti.

## Struttura precedente da considerare

- Contratto generale e confini del dominio Market Reactions.
- Significant Market Flow.
- Osservazioni Market → Field.
- Reazioni Field → Market.
- Semantica di causalità e interpretazione.
- Availability, reliability e quality locali.
- Gating Source Identity e persistence.
- Active Betfair epoch e limiti delle finestre temporali.
- Confine read-only.
- Consumo frontend e contratto di verifica.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/marketReactionEvidence.js`
- `backend/src/sofa/significantMarketFlowEvidence.js` e `backend/src/sofa/significantMarketFlow/`
- `backend/src/sofa/marketLedObservationEvidence.js` e relativo modulo `marketLedObservationEvidence/`
- `backend/src/sofa/fieldLedReactionEvidence.js`
- `backend/src/sofa/temporalAlignmentEvidence.js` e `backend/src/sofa/temporalAlignment/sofaMarker.js`
- `backend/src/sofa/matchEvidence/evidenceBuilder.js`
- `backend/src/sofa/matchEvidence/latestMatchEvidence.js`
- `backend/src/sofa/betfair/moneyFlow.js`
- `frontend/src/hooks/useMarketReactionEvidence.js`
- `frontend/src/components/MarketReactionsPage.jsx`
- `frontend/src/components/marketReactions/`
- Test direttamente associati ai tre rami e al gating Evidence.

## Owner/documenti collegati

- Owner Money Flow / Quality Flow: fonte delle semantiche di validazione, confidence e qualità degli input Exchange.
- Owner Temporal Alignment: riferimento per marker, finestre e regole temporali condivise.
- Owner Evidence Snapshot/Composer: possiede l’integrazione dei rami e i gate Source Identity e persistence.
- Owner UI/API Evidence: possiede polling e presentazione frontend; non appartiene al dominio computazionale Market Reactions.

I report storici citano come collegati `TDUI-DOC-REPORT-016`, `017` e `018`, senza fornire in questa fonte i rispettivi percorsi documentali.

## Guardrail specifici per questo documento

- Conservare Market Reactions come dominio di osservazione temporale.
- Non trasformarlo in documentazione di strategia, segnale o previsione.
- Tenere distinta la prossimità temporale dall’attribuzione causale.
- Distinguere disponibilità, osservazione e affidabilità secondo il contratto corrente verificato.
- Non confondere la quality locale delle finestre con la Data Quality globale di Evidence.
- Documentare Source Identity, persistence e active epoch soltanto come dipendenze o gate ricevuti dagli owner competenti.
- Mantenere il confine read-only del dominio.
- Conservare insieme i tre rami, salvo evidenza strutturale diversa nel CODE AUTHORITY.

## Informazioni storiche da NON assumere come correnti

- Il completamento delle task non dimostra da solo il comportamento presente nella nuova baseline.
- Campi, reason, soglie, tolleranze e finestre descritti dal report appartengono alla baseline storica analizzata.
- I valori storici delle soglie Significant Flow e delle finestre temporali devono essere verificati nel CODE AUTHORITY.
- I mapping frontend, i command path e la copertura dei test non devono essere ricavati automaticamente dal report.
- Le valutazioni tecniche e le proposte contenute nel report non costituiscono requisiti correnti.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza individuata tra TODO e JSON: entrambi associano al documento le task `MARKET-REACT-001..010` e le indicano come completate.
- Il documento target corrente non è incluso tra le fonti: la sua forma precedente dovrà essere recuperata dalla Documentation structure baseline.
- Le fonti storiche non attestano autonomamente lo stato del CODE AUTHORITY corrente.
