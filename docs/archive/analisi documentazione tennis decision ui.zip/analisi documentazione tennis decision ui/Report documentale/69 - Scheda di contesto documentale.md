# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/implementazioni-proposte/06-validazione-e-fixture.md`

Tipo di documento:  
registro owner modulare relativo alla validazione, con facade stabile e ownership specifica distribuita fra runner/result ledger, fixture/sandbox e frontend interaction harness.

Ruolo documentale:  
coordinare il modulo `IMPL-028…031` tramite la facade stabile `06-validazione-e-fixture.md`, mantenendo nei tre child l'ownership specifica delle card e preservando nella facade navigazione, stato sintetico, boundary, riferimenti TEST condivisi, estensioni trasversali e ordine approvato.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`
- `69 - Report 06-validazione-e-fixture.md` — `TDUI-DOC-REPORT-069`
- `69 - TODO e Json.md`
- handoff di aggiornamento successivo alla modularizzazione del modulo 069

## Task storicamente associate

- `IMPL-028` — stato: completata  
  Argomento coinvolto: manifest e runner canonico di validazione, incluso il run artifact JSON v1 attribuito al closeout di questo owner.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `IMPL-029` — stato: non completata  
  Argomento coinvolto: fixture catalog e sandbox condivisa.  
  Uso consentito: non assumerne il target come già implementato; verificare nel CODE AUTHORITY soltanto ciò che risulta corrente e pertinente.

- `IMPL-030` — stato: non completata  
  Argomento coinvolto: frontend interaction test harness; lo stato riportato dopo la modularizzazione resta aperto con copertura parziale.  
  Uso consentito: non assumerne il target come completato; verificare nel CODE AUTHORITY soltanto ciò che risulta corrente e pertinente.

- `IMPL-031` — stato: non completata  
  Argomento coinvolto: estensione del result contract e historical/result ledger; resta aperta con copertura parziale sopra la base introdotta da `IMPL-028`.  
  Uso consentito: verificare nel CODE AUTHORITY quali parti siano oggi effettivamente presenti senza trattare la task come completata.

- `IMPL-VALIDATION-001` — stato: completata  
  Argomento coinvolto: riconciliazione del confine di ownership fra `IMPL-028` e `IMPL-031`. Il run artifact JSON v1 è attribuito a `IMPL-028`; `IMPL-031` resta owner dell'estensione del result contract e del ledger storico. La relazione non è più ciclica.  
  Uso consentito: trattare il nuovo boundary documentale come eseguito, senza inferire la completion di `IMPL-031`.

- `IMPL-VALIDATION-002` — stato: completata  
  Argomento coinvolto: modularizzazione del registro con mantenimento del path storico come facade stabile e creazione dei tre child dedicati.  
  Uso consentito: trattare la struttura modulare come eseguita, senza inferire la completion degli owner ancora aperti.

## Cambiamenti strutturali storicamente rilevanti

- `implementazioni/implementazioni-proposte/06-validazione-e-fixture.md` è mantenuto come facade stabile del modulo.
- `implementazioni/implementazioni-proposte/06-validazione-e-fixture/01-runner-e-result-ledger.md` è stato creato e possiede `IMPL-028` e `IMPL-031`.
- `implementazioni/implementazioni-proposte/06-validazione-e-fixture/02-fixture-e-sandbox.md` è stato creato e possiede `IMPL-029`.
- `implementazioni/implementazioni-proposte/06-validazione-e-fixture/03-frontend-interaction-harness.md` è stato creato e possiede `IMPL-030`.
- Le card owner compaiono una sola volta nei rispettivi child; la facade non le duplica.
- Le estensioni condivise `IMPL-003`, `IMPL-005`, `IMPL-008`, `IMPL-012`, `IMPL-013` e `CODE-005` restano centralizzate nella facade.
- L'ordine approvato resta centralizzato nella facade.

## Struttura precedente da considerare

- perimetro owner `IMPL-028…031`;
- distinzione fra runner/result ledger, fixture/sandbox e frontend interaction harness;
- estensioni condivise e relazioni con test map, registry checker, persistence profile, replay, benchmark e lint;
- ordine documentale delle implementazioni e riferimenti di navigazione del registro;
- distribuzione dei TEST-ID fra i tre child, mantenendo nella facade il blocco condiviso dell'ordine approvato.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `scripts/validation/run.mjs`
- `scripts/validation/test-manifest.json`
- `scripts/validation/result-schema.json`
- `scripts/validation/support/result.mjs`
- `scripts/validation/support/process-runner.mjs`
- `scripts/validation/README.md`
- `backend/src/sofa/matchHistory/commitId.test.mjs`
- `frontend/package.json`
- relativi test e artefatti di validazione direttamente collegati al documento

## Owner/documenti collegati

- `implementazioni/implementazioni-proposte/06-validazione-e-fixture/01-runner-e-result-ledger.md` — owner specifico di `IMPL-028` e `IMPL-031`.
- `implementazioni/implementazioni-proposte/06-validazione-e-fixture/02-fixture-e-sandbox.md` — owner specifico di `IMPL-029`.
- `implementazioni/implementazioni-proposte/06-validazione-e-fixture/03-frontend-interaction-harness.md` — owner specifico di `IMPL-030`.
- `todo-list-tennis-decision-ui.md` — registro storico usato nel report per confrontare lo stato delle implementazioni e dei TEST-ID.
- `IMPL-003` — relazione storica con test map e consumo di manifest/results.
- `IMPL-005` — relazione storica con registry checker.
- `IMPL-008` — relazione storica con persistence profile.
- `IMPL-012` — relazione storica con replay.
- `IMPL-013` — relazione storica con benchmark.
- `CODE-005` — relazione storica con la superficie lint.

Queste relazioni servono a comprendere i confini del documento target; non implicano modifiche agli owner collegati.

## Guardrail specifici per questo documento

- non duplicare nella facade le card owner presenti nei tre child;
- mantenere distinto `IMPL-028`, completata e owner del run artifact JSON v1, da `IMPL-031`, ancora non completata e owner dell'estensione del result contract/ledger;
- non descrivere `IMPL-029`, `IMPL-030` o `IMPL-031` come completate;
- mantenere `TEST-069` e `TEST-070` come copertura parziale con requirement non chiuso;
- mantenere le estensioni condivise centralizzate nella facade;
- preservare l'ordine approvato nella facade;
- non interpretare la creazione dei child come completion degli owner ancora aperti;
- non assorbire `TEST-059` nel DOM harness: conserva anche la propria componente manuale/visuale responsive.

## Informazioni storiche da NON assumere come correnti

- priorità e giudizi dell'audit;
- elenco storico dei profili di validazione e relativo stato enabled/planned, salvo verifica nel CODE AUTHORITY;
- assenza storica di fixture catalog, sandbox condivisa o frontend DOM harness, salvo verifica nel CODE AUTHORITY;
- elenco dei campi presenti o mancanti nel result contract alla baseline del report, salvo verifica nel CODE AUTHORITY;
- stato storico dei singoli TEST-ID diverso da quanto esplicitamente riallineato dopo la modularizzazione;
- vecchia rappresentazione di `IMPL-031` come owner necessario all'introduzione del run artifact v1 di `IMPL-028`;
- vecchia rappresentazione della modularizzazione come proposta non ancora eseguita.

## Discrepanze o limiti delle fonti

- Il report documentale 069 descrive una fase precedente all'esecuzione di `IMPL-VALIDATION-001` e `IMPL-VALIDATION-002`; per lo stato di questi due Change ID e per la struttura modulare prevale l'handoff di aggiornamento successivo all'esecuzione.
- L'aggiornamento della Scheda è effettuato a posteriori e non costituisce una nuova verifica tecnica del CODE AUTHORITY.
- `TEST-069` e `TEST-070` restano esplicitamente parziali e non chiusi.
- Non sono stati introdotti nuovi Change ID.
