TODO:

Report: [`Report documentale/25 - 02-sofascore-scraper.md`](../Report%20documentale/25%20-%2002-sofascore-scraper.md) — `TDUI-DOC-REPORT-025`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`SOFA-SCRAPER-001`** — priorità `high` — Introdotta authority canonica HTTPS con host/path/eventId ammessi; input esterni o con componenti non autorizzati sono rifiutati prima del browser.
- [x] **`SOFA-SCRAPER-002`** — priorità `high` — Una invocazione accetta una match URL espandibile oppure endpoint API dello stesso eventId; mixed-event e multiple match URL sono rifiutati.
- [x] **`SOFA-SCRAPER-003`** — priorità `high` — Cache identity sostituita con SHA-256 della lista URL canonica serializzata deterministicamente.
- [x] **`SOFA-SCRAPER-004`** — priorità `high` — Cache limitata ai successi completi; failure e cache corrotte/non eleggibili diventano miss senza raw diagnostics persistite.
- [x] **`SOFA-SCRAPER-005`** — priorità `high` — Definita gerarchia 30s navigazione, 60s challenge, 15s endpoint, 105s Python e 120s parent Node.
- [x] **`SOFA-SCRAPER-006`** — priorità `high` — Allineato al runtime condiviso: stdout limitato a 2 MiB, stderr redatto/bounded e overflow con errore statico e terminazione owned.
- [x] **`SOFA-SCRAPER-007`** — priorità `medium` — Documentati persistenza, ownership locale, assenza di cleanup automatico, concorrenza manuale e privacy di `scraper_profile`, distinto dalla cache.
- [x] **`SOFA-SCRAPER-008`** — priorità `medium` — Challenge ancora presente dopo il budget produce `challenge_unresolved` e interrompe il fetch endpoint.
- [x] **`SOFA-SCRAPER-009`** — priorità `high` — Failure Python uniformate a `ok:false` con code/message bounded e status HTTP opzionale; nessuna raw exception nel result.
- [x] **`SOFA-SCRAPER-010`** — priorità `high` — Aggiunta matrice Python per URL, cache, output e timeout; mantenuti i test Node su overflow e lifecycle.

JSON:

    {
      "change_id": "SOFA-SCRAPER-001",
      "report_id": "TDUI-DOC-REPORT-025",
      "document_path": "docs/tennis-decision-ui/modules/python/02-sofascore-scraper.md",
      "priority": "high",
      "type": "input_authority_browser_request_boundary",
      "action": "Introdotta authority canonica HTTPS con host/path/eventId ammessi; input esterni o con componenti non autorizzati sono rifiutati prima del browser.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-SCRAPER-002",
      "report_id": "TDUI-DOC-REPORT-025",
      "document_path": "docs/tennis-decision-ui/modules/python/02-sofascore-scraper.md",
      "priority": "high",
      "type": "cli_semantics",
      "action": "Una invocazione accetta una match URL espandibile oppure endpoint API dello stesso eventId; mixed-event e multiple match URL sono rifiutati.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-SCRAPER-003",
      "report_id": "TDUI-DOC-REPORT-025",
      "document_path": "docs/tennis-decision-ui/modules/python/02-sofascore-scraper.md",
      "priority": "high",
      "type": "cache_identity",
      "action": "Cache identity sostituita con SHA-256 della lista URL canonica serializzata deterministicamente.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-SCRAPER-004",
      "report_id": "TDUI-DOC-REPORT-025",
      "document_path": "docs/tennis-decision-ui/modules/python/02-sofascore-scraper.md",
      "priority": "high",
      "type": "cache_content_contract",
      "action": "Cache limitata ai successi completi; failure e cache corrotte/non eleggibili diventano miss senza raw diagnostics persistite.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-SCRAPER-005",
      "report_id": "TDUI-DOC-REPORT-025",
      "document_path": "docs/tennis-decision-ui/modules/python/02-sofascore-scraper.md",
      "priority": "high",
      "type": "timeout_hierarchy",
      "action": "Definita gerarchia 30s navigazione, 60s challenge, 15s endpoint, 105s Python e 120s parent Node.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-SCRAPER-006",
      "report_id": "TDUI-DOC-REPORT-025",
      "document_path": "docs/tennis-decision-ui/modules/python/02-sofascore-scraper.md",
      "priority": "high",
      "type": "owner_alignment",
      "action": "Allineato al runtime condiviso: stdout limitato a 2 MiB, stderr redatto/bounded e overflow con errore statico e terminazione owned.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-SCRAPER-007",
      "report_id": "TDUI-DOC-REPORT-025",
      "document_path": "docs/tennis-decision-ui/modules/python/02-sofascore-scraper.md",
      "priority": "medium",
      "type": "browser_profile_lifecycle",
      "action": "Documentati persistenza, ownership locale, assenza di cleanup automatico, concorrenza manuale e privacy di `scraper_profile`, distinto dalla cache.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-SCRAPER-008",
      "report_id": "TDUI-DOC-REPORT-025",
      "document_path": "docs/tennis-decision-ui/modules/python/02-sofascore-scraper.md",
      "priority": "medium",
      "type": "browser_diagnostic_state",
      "action": "Challenge ancora presente dopo il budget produce `challenge_unresolved` e interrompe il fetch endpoint.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-SCRAPER-009",
      "report_id": "TDUI-DOC-REPORT-025",
      "document_path": "docs/tennis-decision-ui/modules/python/02-sofascore-scraper.md",
      "priority": "high",
      "type": "machine_readable_contract",
      "action": "Failure Python uniformate a `ok:false` con code/message bounded e status HTTP opzionale; nessuna raw exception nel result.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-SCRAPER-010",
      "report_id": "TDUI-DOC-REPORT-025",
      "document_path": "docs/tennis-decision-ui/modules/python/02-sofascore-scraper.md",
      "priority": "high",
      "type": "verification_contract",
      "action": "Aggiunta matrice Python per URL, cache, output e timeout; mantenuti i test Node su overflow e lifecycle.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }