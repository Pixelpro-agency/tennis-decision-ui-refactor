# Scheda di contesto documentale

## Documento target

**Percorso:**  
`implementazioni/implementazioni-proposte/02-runtime-betfair.md`

**Tipo di documento:**  
registro owner tecnico relativo al runtime Betfair e alla provenance di acquisizione. Il perimetro storico dichiarato comprende `IMPL-016…018`.

**Ruolo documentale:**  
raccogliere e mantenere distinti tre ambiti collegati dello stesso dominio: autorità dei comandi runtime Betfair, boundary locale del control plane e provenance/envelope dell’acquisizione Betfair. Il report considera tali responsabilità coese nello stesso documento e non individua necessità di modularizzazione.

## Baseline

**Code authority:**  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

**Documentation structure baseline:**  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `TDUI-DOC-REPORT-065`, report relativo a `implementazioni/implementazioni-proposte/02-runtime-betfair.md`.
- estratto TODO/JSON associato al report 065 e a `IMPL-BETFAIR-001`.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing`, usato esclusivamente come criterio di trasformazione del materiale storico in contesto documentale neutro.

## Task storicamente associate

- `IMPL-016` — **stato: non completata**  
  **Argomento coinvolto:** autorità dei comandi runtime Betfair e coordinamento tra lifecycle di login, tracking/scraper e relative identità runtime.  
  **Uso consentito:** verificare nel CODE AUTHORITY il comportamento corrente pertinente senza assumere che il contratto storico sia già implementato.

- `IMPL-017` — **stato: non completata**  
  **Argomento coinvolto:** boundary locale del backend/control plane, incluse esposizione di rete, gestione delle origin e separazione delle operazioni mutanti dalle letture.  
  **Uso consentito:** verificare nel CODE AUTHORITY il comportamento corrente pertinente senza assumere il target storico come presente.

- `IMPL-018` — **stato: non completata**  
  **Argomento coinvolto:** acquisizione Betfair, provenance temporale, distinzione tra acquisizione e registrazione, dati Graph e origine dei valori matched.  
  **Uso consentito:** verificare nel CODE AUTHORITY quali informazioni e contratti esistano realmente oggi.

- `IMPL-BETFAIR-001` — **stato: non completata**  
  **Argomento coinvolto:** metadata delle relazioni tra `IMPL-016…018` e distinzione storicamente richiesta fra tipi diversi di dipendenza.  
  **Uso consentito:** non assumere che la normalizzazione delle relazioni sia già stata applicata; usare la voce soltanto per riconoscere che la semantica storica del campo “Dipendenze” poteva essere ambigua.

- `TEST-012`, `TEST-016`, `TEST-017` — **stato storico: non completati**  
  **Argomento coinvolto:** verifiche associate rispettivamente al runtime command authority e all’acquisition/provenance Betfair. Il report li registra come mancanti, non come validation già eseguite.

## Cambiamenti strutturali storicamente rilevanti

- Modularizzazione valutata ma non eseguita; il documento è rimasto unico.
- Il report non registra nuovi documenti derivati dal modulo né modifiche della mappa Markdown o del ledger JSON durante l’audit 065.
- Le tre responsabilità `IMPL-016…018` sono state considerate appartenenti a un unico dominio Betfair runtime/acquisition.

## Struttura precedente da considerare

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente:

- separazione fra `IMPL-016`, `IMPL-017` e `IMPL-018`;
- distinzione concettuale fra session/runtime authority e command authority;
- separazione fra login lifecycle e scraper/tracking lifecycle;
- sezione dedicata al control-plane locale;
- distinzione tra `acquiredAt` e `recordedAt`;
- rappresentazione esplicita dello skew delle acquisizioni Graph;
- provenance dei matched value;
- Stream API mantenuta come estensione futura, non come comportamento corrente;
- distinzione tra movimento di prezzo e incremento del volume scambiato.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/betfair/scraperLifecycle.js` e relativo `scraperLifecycle/runner.js` — lifecycle e ownership dello scraper.
- `backend/src/routes/betfair/loginWindowLifecycle.js` — lifecycle della finestra di login.
- `backend/src/routes/betfair.js` — superficie delle route Betfair.
- `backend/src/server.js` — bootstrap, bind e configurazione HTTP/CORS.
- `backend/src/sofa/betfair/processor.js` — struttura del risultato acquisito/processato.
- `backend/src/sofa/betfair/processor/persistence.js` — passaggio dal risultato processato alla persistenza.
- `backend/src/sofa/betfairFetch.js` — percorso di acquisizione Betfair.

## Owner/documenti collegati

- `IMPL-006` — relazione storica con l’autorità/lifecycle dei processi; il confine con `IMPL-016` va mantenuto distinto e verificato sul CODE AUTHORITY.
- `IMPL-002` — storicamente citata in relazione all’inventario endpoint di `IMPL-017`; il materiale di audit non consente di trattarla automaticamente come prerequisito bloccante.
- `IMPL-012` e `IMPL-013` — storicamente collegate a dati di skew, fixture e misurazioni temporali derivabili dall’ambito di `IMPL-018`; il verso esatto della relazione non va dedotto dal solo materiale storico.

## Guardrail specifici per questo documento

- Mantenere il documento focalizzato sul dominio Betfair runtime/acquisition e sui tre owner `IMPL-016…018`.
- Non trasformare primitive locali presenti nel codice in prova automatica dell’esistenza dei contratti complessivi descritti storicamente.
- Non confondere ownership del processo Python con autorità del comando Betfair.
- Non descrivere Stream API come funzionalità corrente senza riscontro nel CODE AUTHORITY.
- Non presentare come sintetizzabili o attribuibili dati di volume quando il comportamento corrente non lo supporta.
- Conservare la distinzione semantica tra acquisizione del dato e sua successiva registrazione quando essa esiste nel codice corrente.

## Informazioni storiche da NON assumere come correnti

- l’esistenza di un’autorità globale dei comandi Betfair;
- l’esistenza di un control-plane boundary completo;
- l’esistenza di un acquisition envelope completo con `schemaVersion`, `scrapeId`, `trackingSessionId`, `commandId`, timestamp delle fasi, acquisizioni Graph e `maxGraphSkewMs`;
- l’esistenza dei test `TEST-012`, `TEST-016` e `TEST-017`;
- una semantica già normalizzata delle dipendenze tra `IMPL-016…018`, `IMPL-002`, `IMPL-012` e `IMPL-013`;
- qualsiasi implementazione corrente della Stream API.

## Discrepanze o limiti delle fonti

- Il report 065 è stato prodotto sulla documentation baseline `4c5f43b007149f3210c27d7565357a447a3a6ef4`, mentre la successiva verifica tecnica dovrà usare il CODE AUTHORITY `12b344ea96e71b2bdaa6931c98419ce925b5c228`; le descrizioni del “current code” contenute nel report non sono quindi authority tecnica corrente.
- La semantica storica del campo generico `Dipendenze` non risultava sufficientemente determinata; in particolare il materiale non stabilisce unilateralmente il verso definitivo delle relazioni `IMPL-018↔IMPL-012/013`.
- Nessuna discrepanza Markdown ↔ JSON è individuabile nei materiali forniti per `IMPL-BETFAIR-001`: entrambi la registrano come non completata.
