TODO:

Report: [`Report documentale/31 - 02-commit-journal-and-recovery.md`](../Report%20documentale/31%20-%2002-commit-journal-and-recovery.md) — `TDUI-DOC-REPORT-031`.

Modularizzazione: **eseguita**. File creati: `docs/tennis-decision-ui/modules/storage/05-writer-authority.md`.

- [x] **`JOURNAL-REC-001`** — priorità `critical` — Eliminare i cleanup completed residual blind di Sofa/Betfair e centralizzare una primitive verify+cleanup che riapre marker non verificabili e rimuove il journal solo dopo target verification.
- [x] **`JOURNAL-REC-002`** — priorità `critical` — Rafforzare la completed-target verification: JSON parsabile non basta; verificare target canonico, shape, event/source e coerenza con il documento journalizzato o validator typed equivalente.
- [x] **`JOURNAL-REC-003`** — priorità `critical` — Separare JSON safety da business validity: prima del repair validare payload.document/metadata e binding event/source/target tramite gli stessi validator canonici di history/timeline.
- [x] **`JOURNAL-REC-004`** — priorità `critical` — Non trasformare journal unreadable/scan failure in no_known_partial; preservare uno stato integrity degraded/unknown fail-closed e coordinare il contratto pubblico con API ed Evidence senza side effect.
- [x] **`JOURNAL-REC-005`** — priorità `high` — Definire la lifecycle authority di recovery_failed distinguendo retryable operational failure, terminal/blocked recovery e invalid structure; uno stato failed identificabile deve restare osservabile dall'integrity event-scoped.
- [x] **`JOURNAL-REC-006`** — priorità `high` — Loggare un recovery summary bounded con counters aggregate e severity distinta quando esistono retryablePending/recoveryFailed/invalidJournal, senza target path, payload o detail raw.
- [x] **`JOURNAL-REC-007`** — priorità `medium` — Rafforzare la safety strutturale delle stringhe diagnostiche tramite allow-list e URL canonicalizzate/redatte, includendo userinfo e valori raw sotto key neutre senza introdurre secret detector euristici globali.
- [x] **`JOURNAL-REC-008`** — priorità `medium` — Distinguere canonical new commitId source-UUID dal più ampio schema eventualmente accettato in recovery/legacy; se la compatibilità non serve, legare validator persisted a source/prefix/UUID.
- [x] **`JOURNAL-REC-009`** — priorità `high` — Completare i test per residual runtime, semantic target mismatch, invalid repair payload, integrity unreadable, recovery state, safety e commit identity; spostare i pass-count storici in artifact di validation.
- [x] **`JOURNAL-REC-010`** — priorità `medium` — Mantenere 02-commit-journal-and-recovery.md come owner journal/recovery e creare 05-writer-authority.md per process identity, acquire/reclaim, bootstrap e shutdown release; aggiornare index/link senza aggiungere il file all'inventario finché non esiste.

JSON:

    {
      "change_id": "JOURNAL-REC-001",
      "report_id": "TDUI-DOC-REPORT-031",
      "document_path": "docs/tennis-decision-ui/modules/storage/02-commit-journal-and-recovery.md",
      "priority": "critical",
      "type": "completed_residual_lifecycle",
      "action": "Eliminare i cleanup completed residual blind di Sofa/Betfair e centralizzare una primitive verify+cleanup che riapre marker non verificabili e rimuove il journal solo dopo target verification.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "JOURNAL-REC-002",
      "report_id": "TDUI-DOC-REPORT-031",
      "document_path": "docs/tennis-decision-ui/modules/storage/02-commit-journal-and-recovery.md",
      "priority": "critical",
      "type": "completed_target_verification",
      "action": "Rafforzare la completed-target verification: JSON parsabile non basta; verificare target canonico, shape, event/source e coerenza con il documento journalizzato o validator typed equivalente.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "JOURNAL-REC-003",
      "report_id": "TDUI-DOC-REPORT-031",
      "document_path": "docs/tennis-decision-ui/modules/storage/02-commit-journal-and-recovery.md",
      "priority": "critical",
      "type": "repair_input_validation",
      "action": "Separare JSON safety da business validity: prima del repair validare payload.document/metadata e binding event/source/target tramite gli stessi validator canonici di history/timeline.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "JOURNAL-REC-004",
      "report_id": "TDUI-DOC-REPORT-031",
      "document_path": "docs/tennis-decision-ui/modules/storage/02-commit-journal-and-recovery.md",
      "priority": "critical",
      "type": "integrity_read_authority",
      "action": "Non trasformare journal unreadable/scan failure in no_known_partial; preservare uno stato integrity degraded/unknown fail-closed e coordinare il contratto pubblico con API ed Evidence senza side effect.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "JOURNAL-REC-005",
      "report_id": "TDUI-DOC-REPORT-031",
      "document_path": "docs/tennis-decision-ui/modules/storage/02-commit-journal-and-recovery.md",
      "priority": "high",
      "type": "recovery_state_semantics",
      "action": "Definire la lifecycle authority di recovery_failed distinguendo retryable operational failure, terminal/blocked recovery e invalid structure; uno stato failed identificabile deve restare osservabile dall'integrity event-scoped.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "JOURNAL-REC-006",
      "report_id": "TDUI-DOC-REPORT-031",
      "document_path": "docs/tennis-decision-ui/modules/storage/02-commit-journal-and-recovery.md",
      "priority": "high",
      "type": "bootstrap_observability",
      "action": "Loggare un recovery summary bounded con counters aggregate e severity distinta quando esistono retryablePending/recoveryFailed/invalidJournal, senza target path, payload o detail raw.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "JOURNAL-REC-007",
      "report_id": "TDUI-DOC-REPORT-031",
      "document_path": "docs/tennis-decision-ui/modules/storage/02-commit-journal-and-recovery.md",
      "priority": "medium",
      "type": "journal_payload_safety",
      "action": "Rafforzare la safety strutturale delle stringhe diagnostiche tramite allow-list e URL canonicalizzate/redatte, includendo userinfo e valori raw sotto key neutre senza introdurre secret detector euristici globali.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "JOURNAL-REC-008",
      "report_id": "TDUI-DOC-REPORT-031",
      "document_path": "docs/tennis-decision-ui/modules/storage/02-commit-journal-and-recovery.md",
      "priority": "medium",
      "type": "commit_identity_contract",
      "action": "Distinguere canonical new commitId source-UUID dal più ampio schema eventualmente accettato in recovery/legacy; se la compatibilità non serve, legare validator persisted a source/prefix/UUID.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "JOURNAL-REC-009",
      "report_id": "TDUI-DOC-REPORT-031",
      "document_path": "docs/tennis-decision-ui/modules/storage/02-commit-journal-and-recovery.md",
      "priority": "high",
      "type": "verification_and_validation_provenance",
      "action": "Completare i test per residual runtime, semantic target mismatch, invalid repair payload, integrity unreadable, recovery state, safety e commit identity; spostare i pass-count storici in artifact di validation.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "JOURNAL-REC-010",
      "report_id": "TDUI-DOC-REPORT-031",
      "document_path": "docs/tennis-decision-ui/modules/storage/02-commit-journal-and-recovery.md",
      "priority": "medium",
      "type": "documentation_modularization",
      "action": "Mantenere 02-commit-journal-and-recovery.md come owner journal/recovery e creare 05-writer-authority.md per process identity, acquire/reclaim, bootstrap e shutdown release; aggiornare index/link senza aggiungere il file all'inventario finché non esiste.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }