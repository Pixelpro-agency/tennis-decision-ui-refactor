# TODO e JSON

TODO:

Report: [`Report documentale/64 - 01-utility-e-autorita-base.md`](../Report%20documentale/64%20-%2001-utility-e-autorita-base.md) — `TDUI-DOC-REPORT-064`.

Modularizzazione: **valutata ed eseguita**.

File creati:

```text
implementazioni/implementazioni-proposte/01-utility-e-autorita-base/01-utility-e-controlli.md
implementazioni/implementazioni-proposte/01-utility-e-autorita-base/02-autorita-boundary-e-supporto.md
implementazioni/implementazioni-proposte/01-utility-e-autorita-base/03-offline-replay-strategy-performance.md
```

Il file `implementazioni/implementazioni-proposte/01-utility-e-autorita-base.md` resta come facade stabile.

- [x] **`IMPL-BASE-001`** — **HIGH** — Riallineata la temporal authority del registro `IMPL-001…015`: problema originario, checkpoint, decisione successiva, stato corrente e closeout sono ora distinti; la frase `Manca però un controllo globale ripetibile` di `IMPL-001` è qualificata come problema originario al checkpoint B6, §13.1 e §14.1 sono sequencing storici e l'introduzione di §14 è temporalmente separata dall'approvazione successiva di `IMPL-006`, senza modificare gli stati tecnici correnti.
- [x] **`IMPL-BASE-002`** — **MEDIUM-HIGH** — Modularizzato il registro mantenendo `01-utility-e-autorita-base.md` come facade stabile e creando tre child owner per responsabilità: utility/controlli (`IMPL-001…005`), authority/boundary/supporto (`IMPL-006/007/008/009/011/015`) e offline/replay/strategy/performance (`IMPL-010/012/013/014`), preservando owner, provenance, estensione `IMPL-009` e closeout `IMPL-015`.

JSON:

```json
{
  "change_id": "IMPL-BASE-001",
  "report_id": "TDUI-DOC-REPORT-064",
  "document_path": "implementazioni/implementazioni-proposte/01-utility-e-autorita-base.md",
  "priority": "high",
  "type": "implementation_registry_temporal_authority",
  "action": "Riallineata la temporal authority del registro IMPL-001…015: problema originario, checkpoint, decisione successiva, stato corrente e closeout sono ora distinti; la frase `Manca però un controllo globale ripetibile` di IMPL-001 è qualificata come problema originario al checkpoint B6, §13.1 e §14.1 sono sequencing storici e l'introduzione di §14 è temporalmente separata dall'approvazione successiva di IMPL-006, senza modificare gli stati tecnici correnti.",
  "checkbox": "[x]",
  "completed": true,
  "status": "completed"
},
{
  "change_id": "IMPL-BASE-002",
  "report_id": "TDUI-DOC-REPORT-064",
  "document_path": "implementazioni/implementazioni-proposte/01-utility-e-autorita-base.md",
  "priority": "medium-high",
  "type": "modularization_context_boundary",
  "action": "Modularizzato il registro mantenendo `01-utility-e-autorita-base.md` come facade stabile e creando tre child owner per responsabilità: utility/controlli (IMPL-001…005), authority/boundary/supporto (IMPL-006/007/008/009/011/015) e offline/replay/strategy/performance (IMPL-010/012/013/014), preservando owner, provenance, estensione IMPL-009 e closeout IMPL-015.",
  "checkbox": "[x]",
  "completed": true,
  "status": "completed"
}
```