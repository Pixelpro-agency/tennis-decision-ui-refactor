# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/implementazioni-proposte/07-documentazione-e-normalizzazione.md`

Tipo di documento:  
closeout documentale della migrazione e della normalizzazione degli owner.

Ruolo documentale:  
registrare la chiusura storica di `IMPL-032`, i checkpoint dei checker documentali e la normalizzazione degli owner, mantenendo distinta la provenance storica dallo stato documentale corrente.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `70 - Report 07-documentazione-e-normalizzazione.md` — `TDUI-DOC-REPORT-070`.
- `70 - TODO e Json.md`.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing`.

## Task storicamente associate

- `IMPL-032` — stato: completata.  
  Argomento coinvolto: migrazione documentale canonica `.mdx → .md` e relativo closeout.  
  Uso consentito: verificare nel CODE AUTHORITY e nella baseline documentale quale stato corrente pertinente debba essere descritto, senza riaprire la task come attività da eseguire.

- `TEST-076…079` — stato: completate.  
  Argomento coinvolto: checkpoint e gate storici della migrazione documentale.  
  Uso consentito: trattare gli esiti come provenance del closeout e verificare soltanto se il documento corrente debba conservarne la descrizione storica.

- `IMPL-DOCNORM-001` — stato: non completata.  
  Argomento coinvolto: riconciliazione tra la matrice owner del checkpoint pre-modularizzazione e i current owner path successivi alla modularizzazione dei registri.  
  Uso consentito: non assumerla come comportamento o revisione già applicata; può essere usata soltanto per evitare di descrivere come corrente una riconciliazione non ancora attestata dalle fonti storiche fornite.

## Cambiamenti strutturali storicamente rilevanti

- Il documento target non risulta essere stato modularizzato; la review storica indica che lo split non era necessario.
- Dopo il checkpoint di normalizzazione, i registri `02-audit-documentazione.md`, `03-audit-codice.md` e `06-implementazioni-proposte.md` sono diventati indici/facade e le schede complete sono state distribuite nei rispettivi moduli child.
- La matrice owner della §24 appartiene quindi a un checkpoint precedente a tale modularizzazione e deve essere interpretata nel suo contesto temporale.

## Struttura precedente da considerare

- §22 — `IMPL-032`: migrazione documentale.
- §23 — checkpoint dei checker read-only.
- §24 — normalizzazione degli owner e relativa matrice storica.
- Catena documentale complessiva: migrazione → checker → normalizzazione owner → stato post-normalizzazione.

Da confrontare con il CODE AUTHORITY e con la documentation structure baseline e recuperare soltanto se ancora utile e pertinente, senza imporre uno schema nuovo.

## Aree da verificare nel CODE AUTHORITY

- `scripts/check_documentation_links.py`
- `scripts/check_registry_consistency.py`
- `scripts/validation/` come possibile fonte da verificare per il contesto delle validation storiche.
- Le attuali schede owner nei moduli child dei registri modularizzati, quando serve distinguere owner storico e owner corrente.

## Owner/documenti collegati

- `implementazioni/02-audit-documentazione.md` — indice/facade dell’audit documentale; gli owner correnti citati dal report vivono nei moduli child.
- `implementazioni/03-audit-codice.md` — indice/facade dell’audit codice; non va assunto come sede corrente delle schede owner solo perché era un path storico della matrice.
- `implementazioni/06-implementazioni-proposte.md` — indice/facade delle implementazioni proposte; le schede complete sono distribuite nei moduli tematici child.
- `implementazioni/audit-documentazione/` — moduli child rilevanti per gli owner DOC.
- `implementazioni/audit-codice/` — moduli child rilevanti per gli owner dell’audit codice.
- `implementazioni/implementazioni-proposte/01-utility-e-autorita-base.md`
- `implementazioni/implementazioni-proposte/02-runtime-betfair.md`
- `implementazioni/implementazioni-proposte/03-storage-recovery.md`
- `implementazioni/implementazioni-proposte/04-evidence-provenance.md`
- `implementazioni/implementazioni-proposte/05-frontend-session-polling.md`

## Guardrail specifici per questo documento

- Mantenere il ruolo di closeout documentale e di provenance storica; non trasformarlo in specifica tecnica di runtime.
- Distinguere gli esiti del checkpoint storico dallo stato corrente dei registri dopo la modularizzazione.
- Non trattare automaticamente i parent facade come owner current quando le schede owner risiedono nei child.
- Non dedurre l’owner corrente dal solo prefisso o dominio dell’ID; il report storico indica che owner e addenda possono risiedere in moduli differenti.
- Non interpretare addenda o ampliamenti collegati come sostituti automatici della card owner canonica.
- Conservare gli ID storici e la distinzione tra owner canonico e riferimenti/addenda senza inferire nuove normalizzazioni.

## Informazioni storiche da NON assumere come correnti

- I path owner riportati nella matrice della §24, perché appartengono al checkpoint pre-modularizzazione.
- Il workspace temporaneo e il piano batch della migrazione, che appartengono al processo storico di chiusura.
- Le priorità originarie associate alle task completate, che non rappresentano automaticamente priorità correnti.
- I conteggi della normalizzazione e gli esiti dei checker come stato runtime corrente: sono evidence del checkpoint storico.
- La riconciliazione descritta da `IMPL-DOCNORM-001`, perché la fonte TODO la registra ancora come non completata.

## Discrepanze o limiti delle fonti

- Non emerge una discrepanza tra TODO e JSON sullo stato di `IMPL-DOCNORM-001`: entrambe le rappresentazioni lo indicano come pending/non completato.
- Il report documentale è una fonte storica di audit e non costituisce authority tecnica corrente; gli owner path post-modularizzazione devono essere verificati sulla baseline appropriata quando rilevanti alla riscrittura.
- Le fonti fornite non attestano l’esecuzione successiva di `IMPL-DOCNORM-001`.
