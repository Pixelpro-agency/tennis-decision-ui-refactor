TODO:

Report: [`../Report documentale/15 - 02-technical-sample-validity.md`](../Report%20documentale/15%20-%2002-technical-sample-validity.md) — `TDUI-DOC-REPORT-015`.

Modularizzazione: **valutata, non necessaria**. Classifier, eligibility, repair boundary e status-only formano un unico contratto di validità; va ridotta la duplicazione con storage e separato lo storico di collaudo.

- [x] **`TECH-SAMPLE-001`** — priorità `critical` — Il classifier rifiuta runner non-object/non-array con `runner_invalid`; coperti `null`, primitive e array annidati prima di gate e commit.
- [x] **`TECH-SAMPLE-002`** — priorità `high` — Richiesto `selectionId` presente, normalizzabile e univoco; coperti missing, duplicati e rename con stesso ID.
- [x] **`TECH-SAMPLE-003`** — priorità `critical` — Rimosso il fallback `marketTotalMatched / runnerCount`; il volume assente resta `null` e Money Flow è suppressed.
- [x] **`TECH-SAMPLE-004`** — priorità `high` — Distinto il repair fisico di un commit journalizzato dalla creazione di nuovi dati derivati dal sample tecnico.
- [x] **`TECH-SAMPLE-005`** — priorità `medium` — Documentato il vocabolario reale `regressive_sample`, `regressive_tick` e `duplicate_tick` ai rispettivi livelli.
- [x] **`TECH-SAMPLE-006`** — priorità `high` — Precisato lo status-only con nuovo `seq`/`commitId`, timeline append, history invariata, `marketState` invariato e Money Flow suppressed.
- [x] **`TECH-SAMPLE-007`** — priorità `high` — Distinto il baseline `marketState` dal timestamp di acquisizione `lastSuccessfulScrapeAt`.
- [x] **`TECH-SAMPLE-008`** — priorità `high` — Completata la matrice per classifier, identity, volume unavailable e status-only canonico con `seq`/`commitId`, timeline append e history invariata.
- [x] **`TECH-SAMPLE-009`** — priorità `medium` — Rimossi dall’owner risultati live e dettagli di script storici; le evidenze storiche sono rinviate alle validation.

JSON:

   {
      "change_id": "TECH-SAMPLE-001",
      "report_id": "TDUI-DOC-REPORT-015",
      "document_path": "docs/tennis-decision-ui/modules/betfair/02-technical-sample-validity.md",
      "priority": "critical",
      "type": "technical_runner_shape",
      "action": "Validare la shape minima di ogni runner prima di usable:true, con reason stabile e test malformed runner.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "TECH-SAMPLE-002",
      "report_id": "TDUI-DOC-REPORT-015",
      "document_path": "docs/tennis-decision-ui/modules/betfair/02-technical-sample-validity.md",
      "priority": "high",
      "type": "canonical_runner_identity",
      "action": "Definire selectionId presente/normalizzabile/univoco come requisito della runner identity canonica e testare missing/duplicate/rename.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "TECH-SAMPLE-003",
      "report_id": "TDUI-DOC-REPORT-015",
      "document_path": "docs/tennis-decision-ui/modules/betfair/02-technical-sample-validity.md",
      "priority": "critical",
      "type": "synthetic_runner_matched_removal",
      "action": "Rimuovere il fallback sintetico runner matched, rappresentare l’assenza come unavailable e sopprimere Money Flow, coordinando DATA-001.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "TECH-SAMPLE-004",
      "report_id": "TDUI-DOC-REPORT-015",
      "document_path": "docs/tennis-decision-ui/modules/betfair/02-technical-sample-validity.md",
      "priority": "high",
      "type": "repair_write_semantics",
      "action": "Distinguere no new sample-derived data da no filesystem write: repairOnly può completare target di un commit pending preesistente.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "TECH-SAMPLE-005",
      "report_id": "TDUI-DOC-REPORT-015",
      "document_path": "docs/tennis-decision-ui/modules/betfair/02-technical-sample-validity.md",
      "priority": "medium",
      "type": "regression_reason_vocabulary",
      "action": "Distinguere regressive_sample interno da regressive_tick persistence e duplicate_tick, unificando solo se cambia anche il codice.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "TECH-SAMPLE-006",
      "report_id": "TDUI-DOC-REPORT-015",
      "document_path": "docs/tennis-decision-ui/modules/betfair/02-technical-sample-validity.md",
      "priority": "high",
      "type": "status_only_baseline_semantics",
      "action": "Separare marketState invariato e canonical timeline avanzata nello status-only, includendo history no-append e Money Flow suppressed.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "TECH-SAMPLE-007",
      "report_id": "TDUI-DOC-REPORT-015",
      "document_path": "docs/tennis-decision-ui/modules/betfair/02-technical-sample-validity.md",
      "priority": "high",
      "type": "runtime_vs_market_state",
      "action": "Distinguere runner marketState confermato dal runtime acquisition state/lastSuccessfulScrapeAt, coordinando DATA-LIFE-003.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "TECH-SAMPLE-008",
      "report_id": "TDUI-DOC-REPORT-015",
      "document_path": "docs/tennis-decision-ui/modules/betfair/02-technical-sample-validity.md",
      "priority": "high",
      "type": "technical_sample_verification",
      "action": "Completare i test classifier/runner identity/volume e aggiungere un test end-to-end dedicato allo status-only.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "TECH-SAMPLE-009",
      "report_id": "TDUI-DOC-REPORT-015",
      "document_path": "docs/tennis-decision-ui/modules/betfair/02-technical-sample-validity.md",
      "priority": "medium",
      "type": "historical_validation_ownership",
      "action": "Rimuovere dall’owner i dettagli di validazione storica e rinviare alle validation, mantenendo soltanto contratto, test e gap correnti.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }