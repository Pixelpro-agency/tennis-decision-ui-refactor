TODO:

Report: [`../Report documentale/16 - 01-match-evidence-snapshot.md`](../Report%20documentale/16%20-%2001-match-evidence-snapshot.md) — `TDUI-DOC-REPORT-016`.

Modularizzazione: **valutata, non necessaria**. Il documento deve restare il composer/facade unico di Evidence; va rafforzato il boundary degli input/errori e ridotta la duplicazione con Source Identity, storage e Market Reactions.

- [x] **`EVID-SNAPSHOT-001`** — priorità `high` — Introdotte viste canoniche Sofa e Betfair; eliminato il fallback wrong-source e filtrati legacy, `seq` non finiti e runner malformed.
- [x] **`EVID-SNAPSHOT-002`** — priorità `high` — Documentato il contratto Betfair-only degradato con Source Identity pending e nessun uso cross-source.
- [x] **`EVID-SNAPSHOT-003`** — priorità `high` — Chiarito che `*TimelineFound` indica almeno una entry caricata, non esistenza del file, e documentata l'assenza di recovery e read-result strutturata.
- [x] **`EVID-SNAPSHOT-004`** — priorità `high` — Il confirmation store resta fail-closed ed espone reason bounded per assenza, JSON/shape/record invalidi, read e lookup failure.
- [x] **`EVID-SNAPSHOT-005`** — priorità `critical` — La confirmation viene persistita dopo bootstrap riuscito; bootstrap o persistenza falliti lasciano il gate pending senza confirmation stale applicabile.
- [x] **`EVID-SNAPSHOT-006`** — priorità `medium` — Definito `metadata.updatedAt` come momento di costruzione, distinto dalla freshness delle fonti.
- [x] **`EVID-SNAPSHOT-007`** — priorità `high` — Sostituiti i path monolitici inesistenti con le suite modulari reali del composer, builder e route.
- [x] **`EVID-SNAPSHOT-008`** — priorità `high` — Documentata e verificata la separazione tra domain snapshot ed envelope HTTP statico e bounded, senza error message raw.
- [x] **`EVID-SNAPSHOT-009`** — priorità `medium` — Definita l'ownership del composer e rinviati algoritmo Source Identity, Graph/Money Flow, Market Reactions e recovery agli owner specialistici.

JSON:

     {
      "change_id": "EVID-SNAPSHOT-001",
      "report_id": "TDUI-DOC-REPORT-016",
      "document_path": "docs/tennis-decision-ui/modules/evidence/01-match-evidence-snapshot.md",
      "priority": "high",
      "type": "evidence_canonical_input_boundary",
      "action": "Rafforzare il canonical input boundary di Evidence, eliminando fallback wrong-source Sofa e allineando la view Betfair usata da epoch/quality.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVID-SNAPSHOT-002",
      "report_id": "TDUI-DOC-REPORT-016",
      "document_path": "docs/tennis-decision-ui/modules/evidence/01-match-evidence-snapshot.md",
      "priority": "high",
      "type": "betfair_only_snapshot_contract",
      "action": "Decidere e documentare il contratto Betfair-only, oggi supportato dal codice ma negato dal documento.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVID-SNAPSHOT-003",
      "report_id": "TDUI-DOC-REPORT-016",
      "document_path": "docs/tennis-decision-ui/modules/evidence/01-match-evidence-snapshot.md",
      "priority": "high",
      "type": "timeline_read_semantics",
      "action": "Distinguere missing/read/parse/shape failure nelle timeline Evidence, coordinando EVIDENCE-API-004 e senza recovery automatica.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVID-SNAPSHOT-004",
      "report_id": "TDUI-DOC-REPORT-016",
      "document_path": "docs/tennis-decision-ui/modules/evidence/01-match-evidence-snapshot.md",
      "priority": "high",
      "type": "confirmation_store_observability",
      "action": "Rendere osservabile il confirmation store unavailable/corrupt mantenendo fail-closed e dettagli pubblici bounded.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVID-SNAPSHOT-005",
      "report_id": "TDUI-DOC-REPORT-016",
      "document_path": "docs/tennis-decision-ui/modules/evidence/01-match-evidence-snapshot.md",
      "priority": "critical",
      "type": "confirmation_bootstrap_consistency",
      "action": "Impedire che una confirmation persistita dopo bootstrap fallito abiliti cross-source Evidence, coordinando EVIDENCE-API-008/DATA-LIFE-004.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVID-SNAPSHOT-006",
      "report_id": "TDUI-DOC-REPORT-016",
      "document_path": "docs/tennis-decision-ui/modules/evidence/01-match-evidence-snapshot.md",
      "priority": "medium",
      "type": "snapshot_timestamp_semantics",
      "action": "Chiarire che metadata.updatedAt è compute time dello snapshot e non freshness source; valutare computedAt additivo.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVID-SNAPSHOT-007",
      "report_id": "TDUI-DOC-REPORT-016",
      "document_path": "docs/tennis-decision-ui/modules/evidence/01-match-evidence-snapshot.md",
      "priority": "high",
      "type": "evidence_snapshot_verification",
      "action": "Correggere i test path inesistenti e completare la coverage diretta del composer Evidence per availability, input canonici, integrity e confirmation.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVID-SNAPSHOT-008",
      "report_id": "TDUI-DOC-REPORT-016",
      "document_path": "docs/tennis-decision-ui/modules/evidence/01-match-evidence-snapshot.md",
      "priority": "high",
      "type": "public_error_redaction",
      "action": "Allineare il boundary HTTP Evidence alla redazione promessa rimuovendo err.message raw e usando code/reason bounded.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVID-SNAPSHOT-009",
      "report_id": "TDUI-DOC-REPORT-016",
      "document_path": "docs/tennis-decision-ui/modules/evidence/01-match-evidence-snapshot.md",
      "priority": "medium",
      "type": "evidence_snapshot_owner_deduplication",
      "action": "Mantenere il facade Evidence unico riducendo duplicazioni con Source Identity, storage, Graph/Money Flow e Market Reactions.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }