TODO:

Report: [`Report documentale/27 - 04-betfair-graph-url-validation.md`](../Report%20documentale/27%20-%2004-betfair-graph-url-validation.md) — `TDUI-DOC-REPORT-027`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`GRAPH-URL-001`** — priorità `high` — Distinguere market identity upstream assente/invalid da vero `bad_graph_url_market_mismatch`.
- [x] **`GRAPH-URL-002`** — priorità `high` — Rilevare selectionId duplicate nel payload API e fail-closed sull'identità ambigua; coordinare `TECH-SAMPLE-002`.
- [x] **`GRAPH-URL-003`** — priorità `medium` — Definire canonical Graph URL: reject query/fragment oppure canonical navigation URL usata dal browser.
- [x] **`GRAPH-URL-004`** — priorità `high` — Aggiungere test integration del Graph loop per page skip, contatori, assignment, empty/error, duplicate reservation e mixed list.
- [x] **`GRAPH-URL-005`** — priorità `medium` — Separare verification deterministica da live observation: parser/mapping offline, live solo browser/source-dependent.
- [x] **`GRAPH-URL-006`** — priorità `medium` — Linkare l'artifact storico effettivo e non dichiarare `mode=cdp reale` senza evidenza archiviata.
- [x] **`GRAPH-URL-007`** — priorità `medium` — Aggiornare insieme a `PREFLIGHT-API-004`: grammatica condivisa; market/runner/ladder mapping resta runtime Python.

JSON:

    {
      "change_id": "GRAPH-URL-001",
      "report_id": "TDUI-DOC-REPORT-027",
      "document_path": "docs/tennis-decision-ui/modules/python/04-betfair-graph-url-validation.md",
      "priority": "high",
      "type": "diagnostic_mapping_authority",
      "action": "Distinguere market identity upstream assente/invalid da vero `bad_graph_url_market_mismatch`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "GRAPH-URL-002",
      "report_id": "TDUI-DOC-REPORT-027",
      "document_path": "docs/tennis-decision-ui/modules/python/04-betfair-graph-url-validation.md",
      "priority": "high",
      "type": "runner_identity",
      "action": "Rilevare selectionId duplicate nel payload API e fail-closed sull'identità ambigua; coordinare `TECH-SAMPLE-002`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "GRAPH-URL-003",
      "report_id": "TDUI-DOC-REPORT-027",
      "document_path": "docs/tennis-decision-ui/modules/python/04-betfair-graph-url-validation.md",
      "priority": "medium",
      "type": "url_canonicalization",
      "action": "Definire canonical Graph URL: reject query/fragment oppure canonical navigation URL usata dal browser.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "GRAPH-URL-004",
      "report_id": "TDUI-DOC-REPORT-027",
      "document_path": "docs/tennis-decision-ui/modules/python/04-betfair-graph-url-validation.md",
      "priority": "high",
      "type": "verification_contract",
      "action": "Aggiungere test integration del Graph loop per page skip, contatori, assignment, empty/error, duplicate reservation e mixed list.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "GRAPH-URL-005",
      "report_id": "TDUI-DOC-REPORT-027",
      "document_path": "docs/tennis-decision-ui/modules/python/04-betfair-graph-url-validation.md",
      "priority": "medium",
      "type": "validation_semantics",
      "action": "Separare verification deterministica da live observation: parser/mapping offline, live solo browser/source-dependent.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "GRAPH-URL-006",
      "report_id": "TDUI-DOC-REPORT-027",
      "document_path": "docs/tennis-decision-ui/modules/python/04-betfair-graph-url-validation.md",
      "priority": "medium",
      "type": "validation_provenance",
      "action": "Linkare l'artifact storico effettivo e non dichiarare `mode=cdp reale` senza evidenza archiviata.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "GRAPH-URL-007",
      "report_id": "TDUI-DOC-REPORT-027",
      "document_path": "docs/tennis-decision-ui/modules/python/04-betfair-graph-url-validation.md",
      "priority": "medium",
      "type": "documentation_authority_alignment",
      "action": "Aggiornare insieme a `PREFLIGHT-API-004`: grammatica condivisa; market/runner/ladder mapping resta runtime Python.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }