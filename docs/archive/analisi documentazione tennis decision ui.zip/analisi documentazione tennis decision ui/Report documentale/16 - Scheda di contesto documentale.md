# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/modules/evidence/01-match-evidence-snapshot.md`

Tipo di documento:  
owner tecnico / composer-facade del Match Evidence Snapshot.

Ruolo documentale:  
descrivere come le evidenze già persistite vengono composte in uno snapshot Evidence read-only, mantenendo il confine tra composizione dello snapshot e responsabilità specialistiche esterne. Il documento è il punto di raccordo della composizione Evidence, non l'owner degli algoritmi specialistici, della persistenza/recovery o del gate live.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `16 - Report 01-match-evidence-snapshot.md` — report documentale `TDUI-DOC-REPORT-016`, relativo alla precedente baseline documentale.
- `16 - TODO e Json.md` — registro Markdown e JSON delle task associate al documento.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260812-204234).txt` — regole di preparazione della presente scheda.

## Task storicamente associate

- `EVID-SNAPSHOT-001` — stato: completata  
  Argomento coinvolto: boundary canonico degli input SofaScore e Betfair usati dallo snapshot.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `EVID-SNAPSHOT-002` — stato: completata  
  Argomento coinvolto: comportamento dello snapshot quando è disponibile soltanto Betfair.  
  Uso consentito: verificare nel CODE AUTHORITY il contratto corrente pertinente.

- `EVID-SNAPSHOT-003` — stato: completata  
  Argomento coinvolto: semantica di caricamento delle timeline e significato dei campi `*TimelineFound`.  
  Uso consentito: verificare nel CODE AUTHORITY il comportamento corrente e documentare soltanto ciò che appartiene allo snapshot.

- `EVID-SNAPSHOT-004` — stato: completata  
  Argomento coinvolto: lettura del Source Identity confirmation store e osservabilità bounded dei relativi esiti.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `EVID-SNAPSHOT-005` — stato: completata  
  Argomento coinvolto: rapporto fra confirmation persistita, bootstrap live e applicabilità della Source Identity nello snapshot.  
  Uso consentito: verificare nel CODE AUTHORITY il comportamento corrente senza assumere il report storico come authority tecnica.

- `EVID-SNAPSHOT-006` — stato: completata  
  Argomento coinvolto: semantica temporale di `metadata.updatedAt` rispetto alla freshness delle fonti.  
  Uso consentito: verificare nel CODE AUTHORITY la semantica corrente del campo.

- `EVID-SNAPSHOT-007` — stato: completata  
  Argomento coinvolto: riferimenti ai test e coverage della composizione Evidence.  
  Uso consentito: verificare nel CODE AUTHORITY quali suite esistono e quali sono pertinenti al documento.

- `EVID-SNAPSHOT-008` — stato: completata  
  Argomento coinvolto: separazione fra domain snapshot ed envelope HTTP pubblico e relativo boundary di errore.  
  Uso consentito: verificare nel CODE AUTHORITY il comportamento corrente della route e mantenere nel documento soltanto il confine pertinente.

- `EVID-SNAPSHOT-009` — stato: completata  
  Argomento coinvolto: ownership documentale del composer Evidence e riduzione delle duplicazioni con owner specialistici.  
  Uso consentito: verificare nel CODE AUTHORITY e nella struttura documentale corrente quali dettagli appartengono ancora a questo documento.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata ma non risulta necessaria.
- Il documento è stato mantenuto come unico composer/facade del Match Evidence Snapshot.
- Non risultano nuovi documenti canonici creati per effetto delle task associate.
- Le fonti storiche indicano un progressivo rinvio dei dettagli specialistici ai rispettivi owner, mantenendo qui composizione, gating, boundary read-only e limiti pertinenti allo snapshot.

## Struttura precedente da considerare

- scopo e natura read-only del Match Evidence Snapshot;
- implementazione e flusso di composizione;
- input provenienti dalle timeline persistite;
- blocchi principali dello snapshot Evidence;
- Source Identity e regole di gating cross-source viste dal composer;
- persistence integrity vista dal composer;
- comportamento degradato in presenza di fonti parziali;
- active Betfair market epoch;
- metadata e semantica temporale;
- placeholder non operativi e assenza di causalità/segnali;
- sezione di verifica.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/matchEvidence.js`
- `backend/src/sofa/matchEvidence/latestMatchEvidence.js`
- `backend/src/sofa/matchEvidence/evidenceBuilder.js`
- `backend/src/sofa/matchEvidence/dataQuality.js`
- `backend/src/sofa/matchEvidence/noTradeReasons.js`
- `backend/src/sofa/matchEvidence/sourceIdentity.js` e moduli direttamente collegati alla Source Identity usata dal composer
- `backend/src/routes/evidence.js`
- test correnti direttamente associati a composer, builder, Source Identity/market epoch, confirmation e route Evidence

## Owner/documenti collegati

- Source Identity — owner delle regole specialistiche di identità e del relativo contesto di confirmation; qui interessa soltanto il modo in cui il risultato entra nello snapshot.
- Data Quality — owner delle regole di qualità/freshness; qui interessa il blocco composto nello snapshot.
- Market Reactions — owner della logica specialistica di market reaction; qui interessa soltanto la sua inclusione o sospensione nel composer.
- Storage integrity / Data Lifecycle — owner di persistenza, journal e recovery; Evidence resta consumer read-only dei relativi esiti.
- API Evidence — owner del contratto HTTP; il documento snapshot deve distinguere il domain payload dal boundary della route senza duplicare l'intero contratto API.
- Graph/Money Flow — owner dei dettagli specialistici di affidabilità e interpretazione; non devono essere ridefiniti integralmente nel facade Evidence.

## Guardrail specifici per questo documento

- Mantenere il documento come facade/composer del Match Evidence Snapshot, senza trasformarlo in owner degli algoritmi specialistici.
- Descrivere il comportamento effettivo del CODE AUTHORITY, non le proposte dell'audit storico.
- Preservare il boundary read-only: il documento non deve attribuire a Evidence ownership di recovery, scrittura delle timeline/history/journal, avvio scraper, browser o fetch live se il codice corrente non lo fa.
- Distinguere chiaramente il risultato Source Identity usato nello snapshot dal gate live, senza trattarli come la stessa authority se il CODE AUTHORITY mantiene questa separazione.
- Non trasformare placeholder o blocchi descrittivi in segnali operativi, fair odds, probabilità, value attivo o causalità se tali funzioni non appartengono al comportamento corrente.
- Evitare di duplicare nel dettaglio Source Identity, Data Quality, Market Reactions, storage/recovery e contratto HTTP quando esistono owner specialistici.
- Mantenere la terminologia corrente del codice e verificare i nomi dei campi prima di riportarli.

## Informazioni storiche da NON assumere come correnti

- I finding, le priorità e l'ordine consigliato contenuti nel report `TDUI-DOC-REPORT-016`.
- Le proposte di implementazione e i target descritti nel report prima del completamento storico delle task.
- I dettagli di codice, i fallback, i limiti e i path di test osservati sul commit auditato `4c5f43b007149f3210c27d7565357a447a3a6ef4`.
- La presenza o assenza di specifici test indicata dal report storico.
- Qualunque comportamento tecnico dedotto esclusivamente dal report o dal testo delle task senza verifica sul CODE AUTHORITY `12b344ea96e71b2bdaa6931c98419ce925b5c228`.
- Lo stato `[x]` delle task come prova sufficiente della forma esatta dell'implementazione corrente: indica soltanto che le fonti storiche le registrano come completate.

## Discrepanze o limiti delle fonti

- Il report documentale fotografa una fase di audit precedente; il TODO/JSON registra successivamente tutte le task `EVID-SNAPSHOT-001`–`009` come completate. Le due fonti appartengono quindi a momenti diversi e non devono essere fuse come se descrivessero lo stesso stato tecnico.
- Markdown e JSON del registro fornito risultano coerenti sullo stato completato delle nove task.
- Non è stato fornito un report separato di applicazione/verifica con il dettaglio completo delle modifiche effettivamente introdotte; il technical writer deve ricostruire il comportamento corrente dal CODE AUTHORITY.
- Nessuna fonte storica fornita sostituisce la verifica sul CODE AUTHORITY.
