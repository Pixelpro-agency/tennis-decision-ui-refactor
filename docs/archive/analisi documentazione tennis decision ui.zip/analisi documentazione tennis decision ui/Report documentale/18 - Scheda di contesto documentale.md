# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/modules/evidence/03-quality-flow-and-alignment.md`

Tipo di documento:  
Owner tecnico-documentale del dominio Evidence.

Ruolo documentale:  
Descrivere congiuntamente qualità tecnica, Money Flow e allineamento temporale dei dati Evidence, mantenendo distinguibili i concetti di dato disponibile, fresco, affidabile, allineato e utilizzabile cross-source. Il documento conserva inoltre il confine fra prossimità temporale e causalità.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `18 - 03-quality-flow-and-alignment.md` — report `TDUI-DOC-REPORT-018`.
- `18 - TODO e Json.md` — mappa delle task e relativi metadata JSON.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-000444).txt`.

## Task storicamente associate

- `QUALITY-FLOW-001` — stato: completata  
  Argomento coinvolto: distinzione fra freshness, età massima delle fonti e gap temporale pairwise; gestione dell’assenza di una fonte.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `QUALITY-FLOW-002` — stato: completata  
  Argomento coinvolto: policy comune per clock skew e trattamento dei timestamp futuri.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `QUALITY-FLOW-003` — stato: completata  
  Argomento coinvolto: reliability del Money Flow basata sul contratto del producer e distinzione fra flow `confirmed` e `suppressed`.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `QUALITY-FLOW-004` — stato: completata  
  Argomento coinvolto: predicate condiviso per affidabilità di ladder e flow, inclusa la disponibilità effettiva della ladder.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `QUALITY-FLOW-005` — stato: completata  
  Argomento coinvolto: confine fra qualità tecnica raw e costruzione di `marketEvidence` quando l’uso cross-source è bloccato.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `QUALITY-FLOW-006` — stato: completata  
  Argomento coinvolto: distinzione fra snapshot order con finestra di 10 secondi e temporal lookback con finestra di 30 secondi.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `QUALITY-FLOW-007` — stato: completata  
  Argomento coinvolto: distinzione fra disponibilità diagnostica e affidabilità del temporal alignment, con relative reason tecniche.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `QUALITY-FLOW-008` — stato: completata  
  Argomento coinvolto: ownership condivisa di predicate e reason di persistence; firma di `buildNoTradeReasons`.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `QUALITY-FLOW-009` — stato: completata  
  Argomento coinvolto: predicate comune per un book valido e two-sided nei diversi layer Evidence.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `QUALITY-FLOW-010` — stato: completata  
  Argomento coinvolto: test canonico del temporal alignment e copertura dei contratti condivisi di quality, flow, ladder, book e finestre temporali.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata e dichiarata non necessaria.
- Il documento è rimasto un owner unico per qualità, flow e alignment.
- Le fonti storiche registrano la distinzione esplicita fra due contratti temporali: snapshot order a 10 secondi e temporal lookback a 30 secondi.
- Risultano storicamente introdotti predicate condivisi per Money Flow, ladder, book e persistence.
- Risulta storicamente creata una validation canonica dedicata al temporal alignment.
- Non risultano nuovi documenti canonici derivati da questo documento.

## Struttura precedente da considerare

- Distinzione fra dato disponibile, fresco, affidabile, confrontabile e temporalmente descrivibile.
- Sezioni dedicate a data quality, flow, marker SofaScore, alignment e `noTradeReasons`.
- Separazione fra qualità tecnica, Source Identity e persistence integrity.
- Descrizione distinta dei due contratti temporali e delle relative finestre.
- Regola esplicita secondo cui prossimità temporale non equivale a causalità.
- Sezione di verification riferita alle suite pertinenti.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/matchEvidence/dataQuality.js`
- `backend/src/sofa/matchEvidence/alignment.js`
- `backend/src/sofa/matchEvidence/alignmentExtension.js`
- `backend/src/sofa/matchEvidence/evidenceBuilder.js`
- `backend/src/sofa/matchEvidence/noTradeReasons.js`
- `backend/src/sofa/marketFlowEvidence/runnerFlow.js`
- `backend/src/sofa/temporalAlignmentEvidence.js`
- `backend/src/sofa/temporalAlignment/`
- `backend/src/sofa/betfair/moneyFlow.js`
- Test direttamente associati a data quality, alignment, runner flow e temporal alignment.

## Owner/documenti collegati

- Owner Match Evidence Snapshot — confine relativo a composizione Evidence, gating cross-source e active Betfair epoch.
- Owner Persistence/Data Lifecycle — confine relativo allo stato di integrità della persistenza; questo documento ne descrive soltanto l’effetto sulla qualità e sull’utilizzabilità Evidence.
- Owner Source Identity — autorizza attribuzione e uso cross-source senza ridefinire la freschezza tecnica dei tick.
- Owner Betfair/Money Flow — possiede produzione, confidence e suppression del Money Flow.
- Owner Technical Sample Validity — collegato alla validità dell’identità runner usata dai predicate di flow.

I percorsi esatti dei documenti collegati non sono sufficientemente determinati dalle fonti consultate e non devono essere dedotti.

## Guardrail specifici per questo documento

- Conservare insieme quality, flow e alignment: la loro relazione costituisce il ruolo principale del documento.
- Non trasformare il documento in una descrizione generale dell’intero composer Evidence.
- Tenere separate qualità tecnica raw, autorizzazione Source Identity e completezza della persistenza.
- Distinguere `available`, `fresh`, `reliable`, `aligned` e utilizzabile cross-source secondo il comportamento verificato.
- Non descrivere volume matched o flow ambiguo come intenzione certa.
- Non trasformare una relazione temporale in una dichiarazione causale.
- Rinviare i dettagli algoritmici agli owner specialistici quando non servono a definire il contratto documentale.
- Riportare soltanto validation e comandi effettivamente presenti nel CODE AUTHORITY.

## Informazioni storiche da NON assumere come correnti

- Finding, priorità e proposte contenuti nel report `TDUI-DOC-REPORT-018`.
- Predicate, signature, reason string e soglie osservati nel commit storico del report.
- Divergenze fra documento e codice descritte durante l’audit.
- Path di test indicati come mancanti o fixture indicate come non allineate nel report storico.
- Formulazioni operative presenti nelle proprietà `action` del JSON.
- Qualsiasi comportamento associato alle task completate prima della verifica nel CODE AUTHORITY.
- L’ordine di applicazione e la matrice di verifica proposti dal report di audit.

## Discrepanze o limiti delle fonti

- Nessuna divergenza individuata fra checkbox Markdown e metadata JSON: tutte le task `QUALITY-FLOW-001..010` risultano completate.
- Il report documentale descrive lo stato del commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`, precedente al CODE AUTHORITY indicato per il technical writer.
- Il report dichiara che mappa Markdown e JSON incrementale non furono modificati durante l’audit; il file TODO/JSON consultato registra invece il successivo completamento delle dieci task.
- Non sono stati forniti report separati di applicazione o verifica; gli effetti correnti delle task devono quindi essere ricavati esclusivamente dal CODE AUTHORITY.
