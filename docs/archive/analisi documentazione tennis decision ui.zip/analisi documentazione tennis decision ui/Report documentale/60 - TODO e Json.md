TODO:

Report: [`Report documentale/60 - 01-rilievi-iniziali-e-api.md`](../Report%20documentale/60%20-%2001-rilievi-iniziali-e-api.md) — `TDUI-DOC-REPORT-060`.

Modularizzazione: **completata**.

Struttura risultante:

```text
implementazioni/audit-documentazione/01-rilievi-iniziali-e-api/01-rilievi-iniziali.md
implementazioni/audit-documentazione/01-rilievi-iniziali-e-api/02-api.md
```

Il file `implementazioni/audit-documentazione/01-rilievi-iniziali-e-api.md` resta come facade stabile.

- [x] **`DOC-AUDIT-P12-001`** — **HIGH** — Riconciliare il checkpoint storico B1/B2 con lo stato corrente post-migrazione: aggiungere un banner storico/current, preservare gli owner originali e registrare come risolti o assorbiti `DOC-001`, `DOC-003`, `DOC-004`, `DOC-005`, `DOC-007`, `DOC-008`, `DOC-010`, `DOC-012`; per `DOC-013` distinguere documentazione sostanzialmente risolta da `CODE-002` ancora aperto; mantenere attivi `DOC-002`, `DOC-006`, `DOC-009`, `DOC-011` e `WORKFLOW-001` e aggiornare la coda API che dice ancora che la correzione canonica non è stata eseguita.
- [x] **`DOC-AUDIT-P12-002`** — **MEDIUM-HIGH** — Modularizzazione completata: `01-rilievi-iniziali-e-api.md` è stato trasformato in facade breve e stabile e le due responsabilità sono state separate in `01-rilievi-iniziali.md` e `02-api.md`, preservando tutti gli owner ID, la checklist iniziale, il checkpoint API `b277...`, il qualifier test-letti/non-eseguiti, la navigazione e la reconciliation introdotta da `DOC-AUDIT-P12-001`. Non risultano da inventare esiti di gate full-repository privi di evidenza.

JSON:

    {
      "change_id": "DOC-AUDIT-P12-001",
      "report_id": "TDUI-DOC-REPORT-060",
      "document_path": "implementazioni/audit-documentazione/01-rilievi-iniziali-e-api.md",
      "priority": "high",
      "type": "owner_lifecycle_post_migration_reconciliation",
      "action": "Aggiungere una reconciliation storico/current per B1/B2, distinguendo finding assorbiti dalla migrazione, finding ancora attivi, finding parzialmente migliorati e finding documentali risolti con bug code ancora aperti; correggere anche la coda API ancora pre-migrazione.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "DOC-AUDIT-P12-002",
      "report_id": "TDUI-DOC-REPORT-060",
      "document_path": "implementazioni/audit-documentazione/01-rilievi-iniziali-e-api.md",
      "priority": "medium-high",
      "type": "modularization_context_boundary",
      "action": "Mantenere il path corrente come facade e separare i rilievi iniziali B1 e l’audit API B2 nei due child proposti, preservando owner ID, checkpoint, test-not-executed qualifier e navigazione.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }