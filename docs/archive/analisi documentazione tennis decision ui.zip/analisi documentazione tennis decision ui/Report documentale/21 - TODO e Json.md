TODO:

Report: [`../Report documentale/21 - 02-live-polling-and-view-model.md`](../Report%20documentale/21%20-%2002-live-polling-and-view-model.md) — `TDUI-DOC-REPORT-021`.

Modularizzazione: **valutata, non necessaria**. Match, Betfair, Evidence e Source Identity devono restare nello stesso facade comparativo per verificare session safety, freshness e current-vs-last-known.

- [x] **`FRONT-POLL-001`** — priorità `critical` — Match e Betfair usano AbortController, poll generation, request ID, ownership e stale-response guard distinti dal trackingSessionId backend.
- [x] **`FRONT-POLL-002`** — priorità `high` — Timer e richieste vengono cancellati su Stop/cleanup; nessun reschedule residuo e Resume idempotente.
- [x] **`FRONT-POLL-003`** — priorità `critical` — Dati current azzerati su waiting/degraded/error e ultimi valori conservati soltanto come lastKnownData esplicito.
- [x] **`FRONT-POLL-004`** — priorità `critical` — `dashboardData` viene azzerato con `backendData` null; il mapping precedente resta separato come last-known.
- [x] **`FRONT-POLL-005`** — priorità `high` — Evidence preserva latest, integrity, sources e persistenceComplete anche nei 404 e li propaga al view state e a Market Reactions.
- [x] **`FRONT-POLL-006`** — priorità `high` — Separati `sourceUpdatedAt` e `fetchedAt`; `lastUpdate` è soltanto alias compatibile del source time.
- [x] **`FRONT-POLL-007`** — priorità `high` — Fallback Betfair reso atomico senza riuso di health/history precedenti e coperto da test.
- [x] **`FRONT-POLL-008`** — priorità `high` — Connessioni basate su read status corrente; payload stale non produce connected o ok.
- [x] **`FRONT-POLL-009`** — priorità `high` — Contatori locali rinominati `pollGeneration` e distinti formalmente dall'autorità backend.
- [x] **`FRONT-POLL-010`** — priorità `critical` — Aggiunti test lifecycle React e StrictMode per abort, stale response, Stop/Resume, evento vuoto, fallback Betfair, Evidence e Gate.

JSON:

    {
      "change_id": "FRONT-POLL-001",
      "report_id": "TDUI-DOC-REPORT-021",
      "document_path": "docs/tennis-decision-ui/modules/frontend/02-live-polling-and-view-model.md",
      "priority": "critical",
      "type": "stale_response_session_safety",
      "action": "Match e Betfair usano AbortController, poll generation, request ID, ownership e stale-response guard distinti dal trackingSessionId backend.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-POLL-002",
      "report_id": "TDUI-DOC-REPORT-021",
      "document_path": "docs/tennis-decision-ui/modules/frontend/02-live-polling-and-view-model.md",
      "priority": "high",
      "type": "polling_scheduler_lifecycle",
      "action": "Timer e richieste vengono cancellati su Stop/cleanup; nessun reschedule residuo e Resume idempotente.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-POLL-003",
      "report_id": "TDUI-DOC-REPORT-021",
      "document_path": "docs/tennis-decision-ui/modules/frontend/02-live-polling-and-view-model.md",
      "priority": "critical",
      "type": "stale_data_presentation",
      "action": "Dati current azzerati su waiting/degraded/error e ultimi valori conservati soltanto come lastKnownData esplicito.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-POLL-004",
      "report_id": "TDUI-DOC-REPORT-021",
      "document_path": "docs/tennis-decision-ui/modules/frontend/02-live-polling-and-view-model.md",
      "priority": "critical",
      "type": "view_model_integrity",
      "action": "dashboardData viene azzerato con backendData null; il mapping precedente resta separato come last-known.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-POLL-005",
      "report_id": "TDUI-DOC-REPORT-021",
      "document_path": "docs/tennis-decision-ui/modules/frontend/02-live-polling-and-view-model.md",
      "priority": "high",
      "type": "persistence_integrity_propagation",
      "action": "Evidence preserva latest, integrity, sources e persistenceComplete anche nei 404 e li propaga al view state e a Market Reactions.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-POLL-006",
      "report_id": "TDUI-DOC-REPORT-021",
      "document_path": "docs/tennis-decision-ui/modules/frontend/02-live-polling-and-view-model.md",
      "priority": "high",
      "type": "frontend_time_semantics",
      "action": "Separati sourceUpdatedAt e fetchedAt; lastUpdate è soltanto alias compatibile del source time.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-POLL-007",
      "report_id": "TDUI-DOC-REPORT-021",
      "document_path": "docs/tennis-decision-ui/modules/frontend/02-live-polling-and-view-model.md",
      "priority": "high",
      "type": "betfair_read_model_consistency",
      "action": "Fallback Betfair reso atomico senza riuso di health/history precedenti e coperto da test.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-POLL-008",
      "report_id": "TDUI-DOC-REPORT-021",
      "document_path": "docs/tennis-decision-ui/modules/frontend/02-live-polling-and-view-model.md",
      "priority": "high",
      "type": "dashboard_connection_semantics",
      "action": "Connessioni basate su read status corrente; payload stale non produce connected o ok.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-POLL-009",
      "report_id": "TDUI-DOC-REPORT-021",
      "document_path": "docs/tennis-decision-ui/modules/frontend/02-live-polling-and-view-model.md",
      "priority": "high",
      "type": "session_authority_terminology",
      "action": "Contatori locali rinominati pollGeneration e distinti formalmente dall'autorità backend.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-POLL-010",
      "report_id": "TDUI-DOC-REPORT-021",
      "document_path": "docs/tennis-decision-ui/modules/frontend/02-live-polling-and-view-model.md",
      "priority": "critical",
      "type": "verification_contract",
      "action": "Aggiunti test lifecycle React e StrictMode per abort, stale response, Stop/Resume, evento vuoto, fallback Betfair, Evidence e Gate.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }