# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/implementazioni-proposte/05-frontend-session-polling.md`

Tipo di documento:  
registro owner tecnico frontend.

Ruolo documentale:  
documentare il perimetro relativo a live-session frontend, polling runtime e Market Reactions view model, mantenendo come ambito principale `IMPL-025…027`. Il report storico identifica esplicitamente il documento come registro owner di queste responsabilità.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

Queste baseline sono quelle assegnate dal Prompt 0 rispettivamente alla verifica tecnica successiva e al recupero della forma documentale precedente.

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing` — definisce perimetro, baseline, criteri di neutralizzazione e struttura della presente Scheda.
- `68 - Report 05-frontend-session-polling.md` — report documentale storico `TDUI-DOC-REPORT-068` relativo al documento target.
- `68 - TODO e Json.md` — registrazione storica di `IMPL-FRONTEND-001`, con checkbox non completata e stato `pending`.

## Task storicamente associate

- `IMPL-025` — stato: non completata.  
  Argomento coinvolto: frontend live-session controller; distinzione fra configurazione richiesta/confermata e identità della sessione accettata dal backend. Il report registra primitive frontend già esistenti, senza considerare completato il contratto complessivo.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `IMPL-026` — stato: non completata.  
  Argomento coinvolto: polling runtime frontend e isolamento delle richieste rispetto alla sessione. Il report registra primitive di polling e protezioni asincrone distribuite fra gli hook, senza considerare completato un runtime condiviso.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `IMPL-027` — stato: non completata.  
  Argomento coinvolto: presentazione frontend di Market Reactions e relativo view model. Il report registra hook, pagina e card già esistenti, senza considerare completato il contratto documentato per il view model.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `IMPL-FRONTEND-001` — stato: non completata.  
  Argomento coinvolto: granularità con cui il registro descrive le primitive frontend già presenti rispetto ai contratti non ancora presenti al momento dell'audit. La fonte TODO la registra con checkbox `[ ]` e stato `pending`.
  Uso consentito: non assumerla come modifica già applicata; usarla soltanto come contesto storico durante il confronto fra struttura precedente e CODE AUTHORITY.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata nel report 068 e risultava non necessaria; non risultavano file aggiuntivi proposti.
- Il report storico non richiedeva una riscrittura completa del documento, ma indicava una revisione circoscritta della rappresentazione dello stato delle tre IMPL.
- Mappa Markdown e ledger JSON non risultavano modificati al termine del report 068.

## Struttura precedente da considerare

- Perimetro unitario composto da tre owner strettamente collegati: `IMPL-025`, `IMPL-026`, `IMPL-027`.
- Relazione concettuale storicamente descritta come: sessione live accettata → abilitazione/disabilitazione dei poller → dati session-scoped → Market Reactions view model.
- La precedente valutazione considerava elevata la dipendenza di `IMPL-026` dal contesto di `IMPL-025` e di `IMPL-027` da session state, integrity state e polling state.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `frontend/src/App.jsx`
- `frontend/src/hooks/useAnalysisSessionState.js`
- `frontend/src/hooks/useLiveTrackingActions.js`
- `frontend/src/hooks/useMatchPolling.js`
- `frontend/src/hooks/useBetfairJson.js`
- `frontend/src/hooks/useMarketReactionEvidence.js`
- `frontend/src/hooks/useSourceIdentityGateStatus.js`
- `frontend/src/components/MarketReactionsPage.jsx`
- `frontend/src/components/marketReactions/MarketLedObservationCard.jsx`
- `frontend/src/components/marketReactions/FieldLedReactionCard.jsx`

Queste sono le principali sorgenti frontend utilizzate dal report storico per verificare il documento.

## Owner/documenti collegati

Il report coordina storicamente il documento con `IMPL-006`, `IMPL-009`, `IMPL-023`, `IMPL-024`, oltre a registri `FRONTEND-*`, `DOC-*` e relativi test, ma non fornisce nella fonte consultata percorsi documentali owner sufficientemente precisi da riportare qui come documenti collegati canonici.

Le dipendenze storicamente dichiarate sono:

- `IMPL-025` collegata a `IMPL-006`;
- `IMPL-026` collegata a `IMPL-006` e `IMPL-025`;
- `IMPL-027` collegata a `IMPL-023`, `IMPL-024` e `IMPL-009`.

Queste relazioni servono soltanto a comprendere i confini del documento target e non implicano modifiche agli altri owner.

## Guardrail specifici per questo documento

- Mantenere il ruolo di registro owner per sessione frontend, polling e Market Reactions, senza trasformarlo in un documento di strategia o di calcolo Evidence.
- Conservare la distinzione concettuale fra stato richiesto dal frontend e stato accettato dalla sessione backend, se ancora confermata dal CODE AUTHORITY.
- Trattare polling lifecycle e semantica specifica dei singoli endpoint come aspetti distinti quando il codice corrente mantiene tale separazione.
- Non assimilare automaticamente presenza di UI Market Reactions e completamento di un eventuale view model dedicato.
- Non assumere che la precedente decisione di non modularizzare costituisca un vincolo tecnico corrente: è soltanto una decisione storica sulla forma del documento.
- Non trasformare le descrizioni di contratti mancanti del report 068 in istruzioni di implementazione.

Il Prompt 0 richiede espressamente che la Scheda orienti il technical writer senza trasferire finding, prescrizioni, refactoring o ordini di implementazione.

## Informazioni storiche da NON assumere come correnti

- Le liste di primitive frontend dichiarate presenti nel report 068.
- Le liste di contratti dichiarati mancanti per `IMPL-025`, `IMPL-026` e `IMPL-027`.
- La descrizione dello stato di implementazione osservato durante l'audit.
- La classificazione storica secondo cui le tre IMPL erano aperte/non completate.
- La mancata esecuzione dei test `TEST-044…059` registrata nel report.
- La necessità della revisione descritta da `IMPL-FRONTEND-001`, che nella fonte TODO risulta ancora non completata.
- Qualunque finding, priorità o azione proposta dal report 068: il materiale storico non costituisce authority tecnica e deve essere verificato contro il CODE AUTHORITY prima di entrare nel documento finale.

## Discrepanze o limiti delle fonti

- Non emerge una discrepanza tra TODO e JSON per `IMPL-FRONTEND-001`: entrambi la rappresentano come non completata/pending.
- Il report 068 dichiara esplicitamente che, al momento della sua chiusura, mappa Markdown e ledger JSON non erano stati aggiornati; la fonte TODO/JSON allegata rappresenta quindi una registrazione successiva o separata del Change ID e non va usata per dedurre automaticamente l'avvenuta modifica del documento target.
- Non è stato fornito in questa fase il documento target corrente né la sua versione alla documentation structure baseline; forma e contenuto finali dovranno quindi essere recuperati e confrontati dalla successiva chat technical writer.