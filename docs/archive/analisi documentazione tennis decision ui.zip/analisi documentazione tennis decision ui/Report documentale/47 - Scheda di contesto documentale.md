# Scheda di contesto documentale

## Documento target

Percorso:
`implementazioni/03-audit-codice.md`

Tipo di documento:
facade / indice di un registro storico di audit tecnico.

Ruolo documentale:
orientare verso i sette moduli dell’audit del codice e offrire una mappa sintetica per area, mantenendo separato il registro storico dalla documentazione tecnica canonica sotto `docs/tennis-decision-ui/`.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-201757).txt`
- `Report documentale/47 - 03-audit-codice.md` — `TDUI-DOC-REPORT-047`
- estratto Todo e intestazione JSON forniti in `47 - TODO e Json.md`

## Task storicamente associate

- Nessuna nuova task risulta direttamente associata al documento target nel report e nella Todo forniti. `PLAN-AUDIT-003` è richiamata soltanto come ownership storica già esistente del tema della completion dell’audit; non va trattata come task propria del facade né come istruzione da rieseguire.

## Cambiamenti strutturali storicamente rilevanti

- Il documento risulta già configurato come facade breve di sette moduli collocati in `implementazioni/audit-codice/`.
- La modularizzazione risulta storicamente valutata e non ulteriormente richiesta.
- Non risultano nuovi documenti canonici proposti né nuove schede owner collocate nel facade.

## Struttura precedente da considerare

- titolo e frase di ruolo;
- tabella cronologica dei sette moduli;
- mappa rapida per area tematica;
- regole sintetiche di manutenzione;
- stato conclusivo dell’attività di audit.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente, mantenendo la forma leggera propria di un indice.

## Aree da verificare nel CODE AUTHORITY

- `implementazioni/03-audit-codice.md`
- `implementazioni/audit-codice/` e presenza dei sette moduli numerati `01`–`07`
- destinazioni dei collegamenti e navigazione tra indice e moduli
- separazione dichiarata rispetto a `docs/tennis-decision-ui/`
- riferimenti sintetici a Todo e registro globale, soltanto per verificare i confini documentali correnti

## Owner/documenti collegati

- `implementazioni/audit-codice/01-rilievi-iniziali.md` — rilievi iniziali, entry point, launcher e writer authority.
- `implementazioni/audit-codice/02-runtime-sessioni-betfair.md` — runtime, sessioni, Betfair, Graph, diagnostica e cleanup.
- `implementazioni/audit-codice/03-storage-recovery.md` — storage, journal e recovery.
- `implementazioni/audit-codice/04-evidence-market-reactions.md` — Evidence, alignment e Market Reactions.
- `implementazioni/audit-codice/05-frontend-session-shell.md` — frontend, session shell, polling e presentazione.
- `implementazioni/audit-codice/06-validazione-e-test.md` — validazione, runner, fixture e test.
- `implementazioni/audit-codice/07-post-audit-e-migrazione.md` — chiusura dell’attività di audit e riallineamenti storici successivi.
- `docs/tennis-decision-ui/` — owner della documentazione tecnica corrente; il facade non ne duplica i contratti.
- `todo-list-tennis-decision-ui.md` e registro globale — viste sintetiche dello stato, non contenuto da replicare nell’indice.

## Guardrail specifici per questo documento

- Mantenere il documento come indice leggero, senza trasformarlo in un audit monolitico, una seconda Todo o un owner tecnico.
- Conservare entrambe le funzioni di navigazione: sequenza dei moduli e mappa per area.
- Non trasferire nel facade schede complete, stati dettagliati, priorità, pass count, matrici di validazione o contratti tecnici appartenenti ai moduli e agli owner canonici.
- Interpretare la conclusione dei Punti 1–7 come completamento storico dell’attività di audit, non come chiusura automatica delle attività tecniche, dei test o delle verifiche live.
- Trattare percorsi e baseline presenti nei moduli come riferimenti ai rispettivi checkpoint storici; evitare normalizzazioni globali non supportate dal CODE AUTHORITY.

## Informazioni storiche da NON assumere come correnti

- stati tecnici, finding e priorità registrati nei sette moduli;
- esecuzione o mancata esecuzione di suite e verifiche live nei checkpoint storici;
- percorsi `.mdx`, policy di archivio e altre convenzioni legate a versioni precedenti del repository;
- baseline tecniche differenti conservate nei singoli moduli;
- formulazioni storiche su implementazioni completate, che non attestano da sole la copertura complessiva corrente;
- valutazioni del report documentale sulla correttezza del facade, da riconfermare sulla baseline corrente soltanto per quanto pertinente alla riscrittura documentale.

## Discrepanze o limiti delle fonti

- La fonte `47 - TODO e Json.md` contiene la voce Todo ma, dopo l’intestazione `JSON:`, non include dati JSON. Non è quindi possibile effettuare una conferma strutturata indipendente di associazioni e stati.
- Non emerge una discrepanza tra il report e la Todo disponibile: entrambi indicano assenza di nuove task e modularizzazione valutata come non necessaria.
