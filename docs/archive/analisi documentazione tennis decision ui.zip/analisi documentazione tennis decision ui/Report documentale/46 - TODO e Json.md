TODO:

Report: [`Report documentale/46 - 02-audit-documentazione.md`](../Report%20documentale/46%20-%2002-audit-documentazione.md) — `TDUI-DOC-REPORT-046`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`DOC-AUDIT-IDX-001`** — priorità `high` — Delimitare il facade ai moduli storici B1–B6 (`DOC-001…023`, `WORKFLOW-001…003`), indicare che i prefissi continuano nei registri tecnici successivi e chiarire che il prefisso non determina automaticamente la directory owner; Todo resta la vista sintetica globale.

JSON:

    {
      "change_id": "DOC-AUDIT-IDX-001",
      "report_id": "TDUI-DOC-REPORT-046",
      "document_path": "implementazioni/02-audit-documentazione.md",
      "priority": "high",
      "type": "registry_prefix_scope_owner_navigation",
      "action": "Delimitare il facade ai moduli storici B1–B6 (`DOC-001…023`, `WORKFLOW-001…003`), indicare che i prefissi continuano nei registri tecnici successivi e chiarire che il prefisso non determina automaticamente la directory owner; Todo resta la vista sintetica globale.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }