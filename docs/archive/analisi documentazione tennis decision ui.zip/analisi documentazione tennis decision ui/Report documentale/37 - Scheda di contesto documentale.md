# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/reference/01-repository-map.md`

Tipo di documento:  
Reference/map trasversale del repository.

Ruolo documentale:  
Orientare una task verso entrypoint, area responsabile, file minimi e documento owner pertinente. Non costituisce un inventario completo né sostituisce i documenti tecnici di dettaglio.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `Report documentale/37 - 01-repository-map.md` — `TDUI-DOC-REPORT-037`
- `37 - TODO e Json.md`
- Prompt di preparazione della Scheda neutra

## Task storicamente associate

- `REPO-MAP-001` — stato: completata  
  Argomento coinvolto: presenza di `launcher/session.py` nella superficie minima del launcher e distinzione sintetica delle responsabilità relative a lock, manifest e identità della sessione.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `REPO-MAP-002` — stato: completata  
  Argomento coinvolto: classificazione di `backend/source_identity_confirmations.json` come stato locale persistito, distinto da cache, dump e log, con rinvio agli owner Source Identity e Retention.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `REPO-MAP-003` — stato: completata  
  Argomento coinvolto: significato del riferimento `IMPL-003` come matrice test ↔ modulo ↔ documento, distinta dalla repository map.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- La superficie launcher risulta storicamente estesa a `launcher/session.py`.
- La classificazione dei dati locali risulta storicamente estesa al confirmation store di Source Identity.
- Il riferimento a `IMPL-003` risulta storicamente precisato come matrice di copertura e non come seconda repository map.
- La modularizzazione è stata valutata ma non ritenuta necessaria; non risultano nuovi documenti canonici derivati dal documento target.

## Struttura precedente da considerare

- Percorso di orientamento: root → runtime locale → data flow → backend → storage → Python/scraper → frontend → dati generati → controlli → validation → documentazione → orientamento per task.
- Separazione tra wrapper root, launcher, backend, storage, frontend e validation.
- Distinzione tra documenti owner, validazioni storiche e archivio non canonico.
- Tabella finale di orientamento per tipo di task.
- Clausola secondo cui la repository map orienta verso gli owner senza sostituirne i contratti.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `avvio.py`
- `launcher/app.py`
- `launcher/session.py`
- `launcher/services.py`
- `launcher/config.py`
- `backend/src/server.js`
- `backend/src/sofa/matchEvidence/sourceIdentityConfirmationStore.js`
- `scripts/validation/test-manifest.json`
- `scripts/validation/run.mjs`
- `.gitignore`

## Owner/documenti collegati

- `docs/tennis-decision-ui/index.md` — possiede la navigazione completa della documentazione canonica.
- `docs/tennis-decision-ui/operations/01-local-runtime.md` — owner collegato per lifecycle e comportamento operativo del launcher.
- `docs/tennis-decision-ui/modules/evidence/02-source-identity.md` — owner collegato per il contratto Source Identity.
- `docs/tennis-decision-ui/operations/05-retention-and-cleanup.md` — owner collegato per classificazione e trattamento dello stato locale persistito.
- `docs/validations/README.md` — delimita le validazioni storiche rispetto agli owner correnti.

## Guardrail specifici per questo documento

- Mantenere la funzione di orientamento trasversale senza trasformare il documento in un inventario completo.
- Conservare la distinzione tra file owner, documenti owner e contesto minimo necessario per una task.
- Non duplicare contratti dettagliati già posseduti dai documenti tecnici.
- Non creare mappe separate per backend, frontend, launcher o storage.
- Non presentare `IMPL-003` come una seconda repository map.
- Non trattare dati persistiti, sidecar di recovery o authority come cache eliminabili.
- Evitare conteggi puntuali dei test o stati di validation soggetti a rapida obsolescenza.

## Informazioni storiche da NON assumere come correnti

- Elenchi esatti dei file e dettagli dei flussi descritti dal report sul commit storico.
- Porte, responsabilità runtime e sequenze di bootstrap senza verifica nel CODE AUTHORITY.
- Stato, profili e conteggi del validation runner osservati durante l’audit.
- Semantica corrente del confirmation store dedotta esclusivamente dal report storico.
- Dettagli lifecycle, recovery, shutdown e ownership riportati come evidenza dell’audit.
- Qualsiasi finding o proposta del report non rappresentata dalle tre task storicamente completate.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza individuata tra checkbox Markdown e metadata JSON per `REPO-MAP-001…003`.
- Il completamento risulta determinato sul contenuto allora corrente e sugli owner collegati; gli snapshot storici non furono aggiornati retroattivamente.
- Il report documentale riguarda la documentation structure baseline, non il CODE AUTHORITY successivo.
