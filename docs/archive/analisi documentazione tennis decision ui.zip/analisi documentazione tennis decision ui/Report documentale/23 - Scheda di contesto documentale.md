# Scheda di contesto documentale

## Documento target

Percorso:
`docs/tennis-decision-ui/modules/frontend/04-match-context-ui.md`

Tipo di documento:
owner tecnico frontend.

Ruolo documentale:
descrivere la presentazione frontend del `localContext` SofaScore: ricezione del read model, validazione e formattazione nel view model, rendering nella `MatchContextCard` e relativi stati disponibili o non disponibili. Il calcolo sportivo resta di competenza backend.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `23 - Report 04-match-context-ui.md` — report `TDUI-DOC-REPORT-023`.
- `23 - TODO e Json.md` — registro Markdown e JSON delle task associate.

## Task storicamente associate

- `MATCH-CONTEXT-001` — stato: completata  
  Argomento coinvolto: provenienza backend dei valori e ruolo frontend di validazione e formattazione.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `MATCH-CONTEXT-002` — stato: completata  
  Argomento coinvolto: coerenza del contratto per percentuali, punti, `totalPoints`, finestra recent e comparison; degradazione a unavailable senza valori sostitutivi.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `MATCH-CONTEXT-003` — stato: completata  
  Argomento coinvolto: propagazione della reason canonica `unsupported_or_ambiguous_score_transition`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `MATCH-CONTEXT-004` — stato: completata  
  Argomento coinvolto: availability indipendente delle sezioni match, recent e comparison e significato di `dataQuality.level`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `MATCH-CONTEXT-005` — stato: completata  
  Argomento coinvolto: significato di `observedShift` come cambio del lato leader, distinto dai delta percentuali e da un trend.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `MATCH-CONTEXT-006` — stato: completata  
  Argomento coinvolto: compatibilità del contratto canonico tramite `version`, `source` e `purpose`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `MATCH-CONTEXT-007` — stato: completata  
  Argomento coinvolto: verifiche component-level della card e propagazione backend della reason recent.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- Modularizzazione valutata ma non eseguita: il documento è rimasto unico.
- Nessun nuovo documento canonico risulta creato.
- Il perimetro storico continua a comprendere insieme contratto frontend, view model di presentazione e rendering della card.

## Struttura precedente da considerare

- Flusso `localContext` dal polling al mapping dashboard, quindi al view model e alla card.
- Contratto dei blocchi match, recent e comparison.
- Stati unavailable e relative reason.
- Confini, responsabilità e sezione di verifica.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `frontend/src/components/MatchContextCard.jsx`
- `frontend/src/components/matchContextViewModel.js`
- `frontend/src/hooks/useDashboardViewModel.js`
- `frontend/src/hooks/useMatchPolling.js`
- `frontend/src/types/dashboard.js`
- test direttamente associati alla card, al view model e al contratto dashboard
- `backend/src/sofa/localContext.js` e `backend/src/sofa/pointByPoint.js`, limitatamente al contratto consumato dal frontend e alle reason esposte

## Owner/documenti collegati

- `docs/tennis-decision-ui/modules/sofa/02-local-context-and-point-by-point.md` — owner backend del calcolo di `localContext` e della derivazione point-by-point; il documento target deve limitarsi al consumo e alla presentazione frontend.
- Owner frontend di polling/view model — collegati alla consegna del read model e alla sua freschezza; non appartiene a questo documento la gestione generale della sessione o del polling.

## Guardrail specifici per questo documento

- Mantenere distinta l'authority numerica backend dalla validazione e formattazione frontend.
- Descrivere la card come contesto informativo e descrittivo, senza attribuirle strategia, previsione, fair odds, edge, momentum o indicazioni di betting.
- Non attribuire al frontend ricostruzioni point-by-point, ricalcoli sportivi, clamp, fallback `50/50` o valori sintetici.
- Trattare match, recent e comparison come sezioni con disponibilità verificabili separatamente, se confermato dal CODE AUTHORITY.
- Mantenere fuori dal perimetro diretto scraper, browser, filesystem, timeline store, Source Identity e Match Evidence.
- Conservare il documento unico salvo evidenza strutturale diversa nella baseline corrente.

## Informazioni storiche da NON assumere come correnti

- Gli esiti tecnici e le descrizioni del report derivano dal commit storico `4c5f43b007149f3210c27d7565357a447a3a6ef4`, non dal CODE AUTHORITY corrente.
- Il completamento delle task indica uno stato storico registrato, ma non sostituisce la verifica del comportamento presente.
- Copy UI, reason, invarianti numeriche, gate di compatibilità e copertura dei test citati nelle fonti devono essere confermati nel CODE AUTHORITY.
- Le dipendenze storiche `FRONT-POLL-003`, `FRONT-POLL-004` e `FRONT-SESSION-004` non devono essere assunte come responsabilità di questo documento né come task da rieseguire.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza individuata tra il registro Markdown e il JSON forniti.
- Non sono stati forniti il documento corrente né un report applicativo separato; lo stato storico finale delle task deriva dal report e dal registro allegati.
