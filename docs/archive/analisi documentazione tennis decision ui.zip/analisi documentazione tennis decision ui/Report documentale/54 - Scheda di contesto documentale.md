# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/audit-codice/02-runtime-sessioni-betfair.md`

Tipo di documento:  
Facade stabile della Parte 2 dell’audit codice, con due moduli child owner dedicati rispettivamente a Session Authority/Start-Stop e Betfair Lifecycle/Control Plane.

Ruolo documentale:  
Mantenere la navigazione della Parte 2, la mappa delle responsabilità e la distinzione delle baseline. I due audit snapshot completi vivono nei rispettivi moduli child.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `Report documentale/54 - 02-runtime-sessioni-betfair.md` — `TDUI-DOC-REPORT-054`
- Sezione Markdown e JSON relativa alle task `AUDIT-CODE-P23-001` e `AUDIT-CODE-P23-002`

## Task storicamente associate

- `AUDIT-CODE-P23-001` — stato: completata  
  Argomento coinvolto: distinzione tra audit snapshot, target approvati e stato corrente; riferimenti alle evidenze successive; qualificazione dell’ordine tecnico storico e dei metadata di priorità.  
  Uso consentito: verificare nel CODE AUTHORITY e nel documento corrente quale effetto documentale sia effettivamente presente e ancora pertinente.

- `AUDIT-CODE-P23-002` — stato: completata  
  Argomento coinvolto: separazione completata del Punto 2 e del Punto 3 nei due child dedicati, mantenendo `02-runtime-sessioni-betfair.md` come facade stabile e preservando baseline, owner ID, sintesi IMPL, navigazione e contenuto senza duplicazioni.  
  Uso consentito: assumere la modularizzazione come struttura documentale corrente già realizzata; usare il facade per la navigazione e i child per il contenuto owner dei rispettivi audit snapshot.

## Cambiamenti strutturali storicamente rilevanti

- È storicamente registrato un chiarimento della temporal authority del modulo e del significato di `COMPLETATO E APPROVATO`.
- Il documento contiene due audit eseguiti su baseline differenti.
- La modularizzazione in due child è stata completata mantenendo stabile il percorso principale come facade.
- Il percorso principale è rimasto stabile come facade della Parte 2.

## Struttura precedente da considerare

- Facade: `implementazioni/audit-codice/02-runtime-sessioni-betfair.md`.
- Child Session Authority: `implementazioni/audit-codice/02-runtime-sessioni-betfair/01-session-authority-start-stop.md`.
- Il child Session Authority contiene il Punto 2, la baseline `dda406c4a07ae4a1debfcab39db346e47c33c419`, Start/Stop, generation, callback tardive, no-gate semantics, gli owner `RUNTIME`, `FRONTEND`, `DOC` e `TEST` pertinenti, oltre alle decisioni e ai target del Punto 2.
- Child Betfair Lifecycle/Control Plane: `implementazioni/audit-codice/02-runtime-sessioni-betfair/02-betfair-lifecycle-control-plane.md`.
- Il child Betfair contiene il Punto 3, la baseline `cf249ad669347fb06dc69d876d68af591a7f5639`, Graph, diagnostica, concorrenza, cache, capture, retention, cleanup, gli owner `RUNTIME`, `SECURITY`, `CODE`, `DATA`, `PYTHON`, `CLEANUP` e `TEST` pertinenti, le sintesi `IMPL-016…018`, le decisioni e l’ordine tecnico storico del Punto 3.
- Il facade non duplica le owner card dei child.
- La navigazione resta stabile fra Parte 1, facade della Parte 2 e Parte 3.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/routes/match/trackingResponses.js`
- `backend/src/sofa/matchTracker.js`
- Route e lifecycle Betfair direttamente richiamati dal documento
- Source Identity Gate e polling frontend per i confini della Session Authority
- Parser Graph, processor, scraper e diagnostica Betfair
- Test direttamente associati ai comportamenti documentati

## Owner/documenti collegati

- `implementazioni/03-audit-codice.md` — indice e contesto dell’audit codice.
- `todo-list-tennis-decision-ui.md` — fonte storicamente indicata per lo stato corrente degli owner.
- `implementazioni/99-decisioni-utente.md` — decisioni approvate pertinenti.
- `implementazioni/audit-codice/01-rilievi-iniziali.md` — navigazione precedente.
- `implementazioni/audit-codice/02-runtime-sessioni-betfair/01-session-authority-start-stop.md` — owner del Punto 2, Session Authority e Start/Stop.
- `implementazioni/audit-codice/02-runtime-sessioni-betfair/02-betfair-lifecycle-control-plane.md` — owner del Punto 3, Betfair Lifecycle e Control Plane.
- `implementazioni/audit-codice/03-storage-recovery.md` — navigazione successiva e confine con storage/recovery.
- `implementazioni/audit-codice/05-frontend-session-shell.md` — ownership frontend collegata.
- `implementazioni/audit-codice/06-validazione-e-test.md` — confine relativo alle validation.
- `implementazioni/audit-codice/07-post-audit-e-migrazione.md` — contesto successivo all’audit.

## Guardrail specifici per questo documento

- Conservare la natura di audit storico del modulo.
- Non presentare `COMPLETATO E APPROVATO` come conferma dell’implementazione dei target.
- Trattare la modularizzazione come già completata.
- Mantenere il facade privo di owner card duplicate.
- Mantenere Punto 2 e Punto 3 nei rispettivi child.
- Non spostare owner ID da un child all’altro senza evidence.
- Distinguere baseline del Punto 2 e del Punto 3.
- Non rinumerare né duplicare gli owner ID.
- Non trasformare le sintesi `IMPL-016…018` in owner card.
- Preservare la navigazione stabile Parte 1 / facade Parte 2 / Parte 3.
- Non trasformare finding, test gap o ordine storico in istruzioni operative correnti.

## Informazioni storiche da NON assumere come correnti

- Le baseline tecniche interne dei due audit snapshot.
- Lo stato dei finding e dei target registrato al momento dei checkpoint.
- Le priorità storiche degli owner, incluse quelle di `FRONTEND-003` e `FRONTEND-007`.
- Le parti definite “solide”, successivamente raffinate da evidenze con owner distinti.
- L’ordine tecnico riportato nel Punto 3.
- La corrispondenza tra target approvato e comportamento effettivamente implementato.

## Discrepanze o limiti delle fonti

- Markdown e JSON concordano sullo stato completato di `AUDIT-CODE-P23-001` e `AUDIT-CODE-P23-002`.
- Le fonti consultate sono storiche e non costituiscono authority tecnica corrente.
- Il documento target e il CODE AUTHORITY non sono stati verificati in questa preparazione.
- La modularizzazione risulta completata e il percorso principale resta il facade stabile della Parte 2.
