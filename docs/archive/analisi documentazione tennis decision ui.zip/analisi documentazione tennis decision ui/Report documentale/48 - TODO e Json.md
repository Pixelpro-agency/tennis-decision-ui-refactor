TODO:

Report: [`Report documentale/48 - 04-task-completate.md`](../Report%20documentale/48%20-%2004-task-completate.md) — `TDUI-DOC-REPORT-048`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`TASK-RECHECK-001`** — **HIGH** — Rendere esplicito che il ricontrollo D1–D18 è uno snapshot storico sulla baseline `b277bd9`; preservare gli esiti storici, aggiungere un pointer allo stato corrente/overlay e impedire che `Esito reale @ b277bd9` venga letto come stato corrente a HEAD.
- [x] **`TASK-RECHECK-002`** — **CRITICAL** — Riconciliare lo stato corrente D1–D18 con le evidenze degli audit successivi senza riscrivere il checkpoint storico: riesaminare almeno D5, D6, D9, D10, D11, D12, D13, D16 e D18, mantenere D14/D17 riaperte, collegare gli owner tecnici esistenti e aggiornare Todo/current counts con una overlay esplicita.

JSON:

    {
      "change_id": "TASK-RECHECK-001",
      "report_id": "TDUI-DOC-REPORT-048",
      "document_path": "implementazioni/04-task-completate.md",
      "priority": "high",
      "type": "historical_recertification_authority",
      "action": "Rendere esplicito che il ricontrollo D1–D18 è uno snapshot storico sulla baseline `b277bd9`; preservare gli esiti storici, aggiungere un pointer allo stato corrente/overlay e impedire che `Esito reale @ b277bd9` venga letto come stato corrente a HEAD.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "TASK-RECHECK-002",
      "report_id": "TDUI-DOC-REPORT-048",
      "document_path": "implementazioni/04-task-completate.md",
      "priority": "critical",
      "type": "completed_task_status_supersession",
      "action": "Riconciliare lo stato corrente D1–D18 con le evidenze degli audit successivi senza riscrivere il checkpoint storico: riesaminare almeno D5, D6, D9, D10, D11, D12, D13, D16 e D18, mantenere D14/D17 riaperte, collegare gli owner tecnici esistenti e aggiornare Todo/current counts con una overlay esplicita.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }