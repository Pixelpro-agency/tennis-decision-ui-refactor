# Scheda di contesto documentale

## Documento target

Percorso:
`docs/tennis-decision-ui/modules/storage/02-commit-journal-and-recovery.md`

Tipo di documento:
owner tecnico specialistico.

Ruolo documentale:
descrivere il commit journal e la recovery deterministica, inclusi commit intent, marker dei documenti, repair, verifica dei target, stato di integrity e sicurezza del payload journalizzato. La writer authority a livello di processo è separata nel documento `05-writer-authority.md`.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-154507).txt`
- `31 - Report 02-commit-journal-and-recovery.md` — report `TDUI-DOC-REPORT-031`, dichiarato applicato e verificato.
- `31 - TODO e Json.md` — registro Markdown e JSON delle task associate.

## Task storicamente associate

- `JOURNAL-REC-001` — stato: completata
  Argomento coinvolto: ciclo di vita e verifica dei completed residual prima della rimozione del journal.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `JOURNAL-REC-002` — stato: completata
  Argomento coinvolto: verifica dei target completati rispetto a identità, forma e documento journalizzato.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `JOURNAL-REC-003` — stato: completata
  Argomento coinvolto: validazione del payload di repair e binding con event, source e target canonico.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `JOURNAL-REC-004` — stato: completata
  Argomento coinvolto: comportamento integrity quando la scansione o lettura del journal non è disponibile.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `JOURNAL-REC-005` — stato: completata
  Argomento coinvolto: semantica degli stati di recovery, inclusi retry operativi, failure e record invalidi identificabili.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `JOURNAL-REC-006` — stato: completata
  Argomento coinvolto: osservabilità bounded del riepilogo di recovery al bootstrap.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `JOURNAL-REC-007` — stato: completata
  Argomento coinvolto: sicurezza strutturale delle stringhe e degli URL nei payload e nelle informazioni diagnostiche journalizzate.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `JOURNAL-REC-008` — stato: completata
  Argomento coinvolto: distinzione tra commit ID canonico di nuova generazione e formati eventualmente accettati in recovery o per compatibilità.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `JOURNAL-REC-009` — stato: completata
  Argomento coinvolto: copertura di verifica e provenienza degli esiti di validation.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `JOURNAL-REC-010` — stato: completata
  Argomento coinvolto: separazione documentale tra journal/recovery e writer authority process-level.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- Modularizzazione dichiarata eseguita: creato `docs/tennis-decision-ui/modules/storage/05-writer-authority.md`.
- `02-commit-journal-and-recovery.md` è rimasto owner del journal e della recovery; process identity, acquire/reclaim, bootstrap relativo all'authority e shutdown release sono stati assegnati al nuovo owner.
- È dichiarata la creazione dell'artifact `docs/validations/commit-journal-hardening-2026-08-10.md`.

## Struttura precedente da considerare

- lifecycle del commit journal: intent, scrittura dei documenti, marker e cleanup;
- recovery deterministica basata sul payload journalizzato;
- verifica dei target e dei risultati dei writer;
- distinzione fra record, record invalidi ed entry non identificabili;
- stato di persistence integrity e relativa lettura senza side effect;
- payload safety, commit identity e riferimenti alla validation;
- collegamento alla writer authority come precondizione, senza riassorbirne il protocollo.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/matchHistory/commitId.js`
- `backend/src/sofa/matchHistory/commitJournal.js` e `backend/src/sofa/matchHistory/commitJournal/`
- `backend/src/sofa/matchHistory/recovery.js`
- `backend/src/sofa/matchHistory/sofaUpdates/journalWorkflow.js`
- `backend/src/sofa/betfair/processor/journalRecovery.js` e `backend/src/sofa/betfair/processor/persistenceCommitWorkflow.js`
- test di commit journal, integrity, payload safety, residual recovery e recovery integration direttamente associati.

## Owner/documenti collegati

- `docs/tennis-decision-ui/modules/storage/05-writer-authority.md` — owner separato di process identity, repository/storage identity, acquire/reclaim, single-writer, bootstrap authority e shutdown drain/release.
- `docs/validations/commit-journal-hardening-2026-08-10.md` — artifact storico dichiarato per gli esiti di validation collegati alle task.
- Owner della persistenza canonica history/timeline — definiscono i contratti dei documenti su cui journal e recovery operano; il loro contenuto non va duplicato nel documento target.
- Owner API ed Evidence — consumano lo stato di integrity; non ne ridefiniscono l'authority storage nel documento target.

## Guardrail specifici per questo documento

- Mantenere il focus su commit journal, recovery, target verification, repair, integrity, payload safety e commit identity.
- Non riunire nel documento il protocollo completo di writer authority process-level.
- Presentare la recovery come deterministica e fondata su dati journalizzati, verificando nel CODE AUTHORITY i contratti effettivi.
- Distinguere sicurezza/serializzabilità del payload, validità semantica dei documenti e verificabilità dei target.
- Descrivere gli stati e i confini pubblici di integrity soltanto nella misura posseduta dall'owner storage, senza duplicare i contratti dei consumer.
- Non trasformare conteggi di test storici o task completate in garanzie correnti senza riscontro nella baseline tecnica.

## Informazioni storiche da NON assumere come correnti

- Le descrizioni tecniche, gli scenari e gli esiti dell'audit precedente alla sezione di applicazione.
- Le soluzioni proposte nel report, considerate separatamente dalla loro effettiva presenza nel CODE AUTHORITY.
- I conteggi di test riportati inline nel report storico.
- I nomi esatti di stati, risultati, validator e primitive, finché non confermati nella baseline tecnica.
- Le dipendenze e i contratti downstream citati nel report, salvo quanto risulta ancora pertinente al ruolo del documento.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza individuata tra il registro Markdown e il JSON: entrambi indicano `JOURNAL-REC-001`…`JOURNAL-REC-010` come completate.
- Il report è riferito alla documentation structure baseline, mentre l'applicazione delle task è registrata successivamente in una nota storica sintetica; i comportamenti correnti devono quindi essere ricavati dal CODE AUTHORITY.
- Il documento target corrente e il nuovo `05-writer-authority.md` non erano tra gli allegati consultati; forma finale, link e ripartizione effettiva dei contenuti restano da verificare nelle baseline indicate.
