TODO:

Report: [`../Report documentale/10 - 06-runtime-health.md`](../Report%20documentale/10%20-%2006-runtime-health.md) — `TDUI-DOC-REPORT-010`.

Modularizzazione: **valutata, non necessaria**. Il documento ha un solo endpoint, un solo owner e una shape compatta; richiede una revisione mirata senza nuovi documenti.

- [x] **`RUNTIME-HEALTH-001`** — priorità `high` — Applicato `IMPL-017`: bind backend su loopback e policy positiva Host/Origin locale, con richieste senza Origin preservate e test HTTP reali.
- [x] **`RUNTIME-HEALTH-002`** — priorità `high` — Introdotto response builder puro con allow-list HTTP positiva, normalizzazione e test con campi privati iniettati.
- [x] **`RUNTIME-HEALTH-003`** — priorità `high` — Definito `ok:true` come reachability del backend e allineato il consumer Preflight a `service` e `project`, con messaggi bounded.
- [x] **`RUNTIME-HEALTH-004`** — priorità `medium` — Precisato che `instanceId` è l’ID effimero del processo backend e non tracking session, writer authority o launcher ownership; chiarito che `startedAt` precede recovery e listener readiness.
- [x] **`RUNTIME-HEALTH-005`** — priorità `medium` — Documentata la semantica completa di `pythonProcesses`: conteggio delle entry registrate, `pid` nullable e status come lifecycle del registry, non health funzionale.
- [x] **`RUNTIME-HEALTH-006`** — priorità `medium` — Aggiunto e testato `Cache-Control: no-store` sulla response Health.
- [x] **`RUNTIME-HEALTH-007`** — priorità `medium` — Coordinata `PREFLIGHT-API-006`: rimosso `/api/test/health` e mantenuto `/api/health` come authority canonica.
- [x] **`RUNTIME-HEALTH-008`** — priorità `medium` — Completata la verifica con test di server, registry, response builder, local boundary, `pid:null`, lifecycle, identità frontend e suite launcher.

JSON:

    {
      "change_id": "RUNTIME-HEALTH-001",
      "report_id": "TDUI-DOC-REPORT-010",
      "document_path": "docs/tennis-decision-ui/api/05-runtime-health.md",
      "priority": "high",
      "type": "local_control_plane_boundary",
      "action": "Applicare IMPL-017: bind loopback, Host/Origin locali e documentazione di Health come data plane read-only locale.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "RUNTIME-HEALTH-002",
      "report_id": "TDUI-DOC-REPORT-010",
      "document_path": "docs/tennis-decision-ui/api/05-runtime-health.md",
      "priority": "high",
      "type": "public_snapshot_allowlist",
      "action": "Introdurre una allow-list HTTP positiva per pythonProcesses tramite response builder puro e testare campi privati iniettati.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "RUNTIME-HEALTH-003",
      "report_id": "TDUI-DOC-REPORT-010",
      "document_path": "docs/tennis-decision-ui/api/05-runtime-health.md",
      "priority": "high",
      "type": "health_ok_semantics",
      "action": "Definire ok:true come liveness/reachability del backend, non come salute complessiva, e allineare il consumer Preflight all'identità project.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "RUNTIME-HEALTH-004",
      "report_id": "TDUI-DOC-REPORT-010",
      "document_path": "docs/tennis-decision-ui/api/05-runtime-health.md",
      "priority": "medium",
      "type": "backend_identity_semantics",
      "action": "Precisare instanceId e startedAt distinguendoli da tracking session, writer authority, launcher ownership e listener readiness.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "RUNTIME-HEALTH-005",
      "report_id": "TDUI-DOC-REPORT-010",
      "document_path": "docs/tennis-decision-ui/api/05-runtime-health.md",
      "priority": "medium",
      "type": "python_snapshot_semantics",
      "action": "Documentare active/byRole come entry registrate, pid nullable e status come lifecycle del registry, non health funzionale.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "RUNTIME-HEALTH-006",
      "report_id": "TDUI-DOC-REPORT-010",
      "document_path": "docs/tennis-decision-ui/api/05-runtime-health.md",
      "priority": "medium",
      "type": "health_cache_policy",
      "action": "Aggiungere Cache-Control: no-store alla response Health e testare l'header.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "RUNTIME-HEALTH-007",
      "report_id": "TDUI-DOC-REPORT-010",
      "document_path": "docs/tennis-decision-ui/api/05-runtime-health.md",
      "priority": "medium",
      "type": "health_endpoint_authority",
      "action": "Coordinare con PREFLIGHT-API-006, inventariare /api/test/health e rimuoverla se inutilizzata mantenendo /api/health come authority canonica.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "RUNTIME-HEALTH-008",
      "report_id": "TDUI-DOC-REPORT-010",
      "document_path": "docs/tennis-decision-ui/api/05-runtime-health.md",
      "priority": "medium",
      "type": "health_verification_coverage",
      "action": "Aggiornare la verifica con server.test.mjs, pythonProcessRegistry.test.mjs e test per allow-list, no-store, local boundary, pid null e lifecycle.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }