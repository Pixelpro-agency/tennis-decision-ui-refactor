TODO:

Report: [`Report documentale/41 - documentation-migration-finalization-2026-08-03.md`](../Report%20documentale/41%20-%20documentation-migration-finalization-2026-08-03.md) — `TDUI-DOC-REPORT-041`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`MIGRATION-VAL-001`** — priorità `high` — Allineare il claim di content preservation alla prova: un dimension ratio `0,998–1,001` supporta `no substantial truncation`, non exact body identity; ridurre il wording oppure produrre un normalized diff per file con zero differenze non classificate.

JSON:

    {
      "change_id": "MIGRATION-VAL-001",
      "report_id": "TDUI-DOC-REPORT-041",
      "document_path": "docs/validations/documentation-migration-finalization-2026-08-03.md",
      "priority": "high",
      "type": "migration_fidelity_evidence_strength",
      "action": "Allineare il claim di content preservation alla prova: un dimension ratio `0,998–1,001` supporta `no substantial truncation`, non exact body identity; ridurre il wording oppure produrre un normalized diff per file con zero differenze non classificate.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }