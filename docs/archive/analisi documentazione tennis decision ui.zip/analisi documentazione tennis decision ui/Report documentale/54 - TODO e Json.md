Report: [`Report documentale/54 - 02-runtime-sessioni-betfair.md`](../Report%20documentale/54%20-%2002-runtime-sessioni-betfair.md) — `TDUI-DOC-REPORT-054`.

Modularizzazione: **valutata, necessaria e completata**.

File creati:

```text
implementazioni/audit-codice/02-runtime-sessioni-betfair/01-session-authority-start-stop.md
implementazioni/audit-codice/02-runtime-sessioni-betfair/02-betfair-lifecycle-control-plane.md
```

Il file `implementazioni/audit-codice/02-runtime-sessioni-betfair.md` resta come facade stabile.

- [x] **`AUDIT-CODE-P23-001`** — **HIGH** — Riallineare temporal authority, supersession e metadata del modulo: chiarire che Punto 2 e Punto 3 sono audit snapshot sulle rispettive baseline e che `COMPLETATO E APPROVATO` non significa implementazione completata; collegare le evidenze successive già owned (`SOFA-LIVE-*`, `LIVE-CTRL-*`, `GRAPH-URL-*`, `BETFAIR-SCRAPER-*`, `BETFAIR-DIAG-*`, `RETENTION-*`), qualificare l’ordine tecnico come storico e riconciliare `FRONTEND-003` e `FRONTEND-007` con la priorità corrente **critica** della Todo oppure separare `priority_at_checkpoint` da `current_priority`.
- [x] **`AUDIT-CODE-P23-002`** — **MEDIUM-HIGH** — Mantenuto `02-runtime-sessioni-betfair.md` come facade stabile e separati Punto 2 Session Authority e Punto 3 Betfair Lifecycle/Control Plane nei due child previsti, preservando le due baseline, tutti gli owner ID, le sintesi IMPL, la navigazione Parte 1/Parte 3 e l’intero contenuto senza duplicazioni.

```json
{
  "change_id": "AUDIT-CODE-P23-001",
  "report_id": "TDUI-DOC-REPORT-054",
  "document_path": "implementazioni/audit-codice/02-runtime-sessioni-betfair.md",
  "priority": "high",
  "type": "historical_audit_authority_registry_metadata_drift",
  "action": "Riallineare temporal authority, supersession e metadata del modulo: chiarire che Punto 2 e Punto 3 sono snapshot sulle rispettive baseline, collegare le evidenze successive già owned e riconciliare il priority drift di FRONTEND-003 e FRONTEND-007 con la Todo corrente.",
  "checkbox": "[x]",
  "completed": true,
  "status": "completed"
},
{
  "change_id": "AUDIT-CODE-P23-002",
  "report_id": "TDUI-DOC-REPORT-054",
  "document_path": "implementazioni/audit-codice/02-runtime-sessioni-betfair.md",
  "priority": "medium-high",
  "type": "modularization_context_boundary",
  "action": "Mantenere `02-runtime-sessioni-betfair.md` come facade stabile e separare Session Authority/Start-Stop e Betfair Lifecycle/Control Plane nei due child previsti, preservando baseline, owner ID, sintesi IMPL, navigazione e contenuto senza duplicazioni.",
  "checkbox": "[x]",
  "completed": true,
  "status": "completed"
}
```
