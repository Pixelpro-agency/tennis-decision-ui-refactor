# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/modules/python/01-entrypoints-and-runtime.md`

Tipo di documento:  
Owner tecnico / facade tecnico Python e launcher locale.

Ruolo documentale:  
Owner dei wrapper Python compatibili e dell'implementazione launcher locale. Il report identifica come responsabilità primaria gli entrypoint Python e la facade implementativa del launcher.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-022949).txt`
- `24 - Report 01-entrypoints-and-runtime.md` — `TDUI-DOC-REPORT-024`
- `24 - TODO e Json.md`

## Task storicamente associate

Le fonti TODO/JSON registrano tutte le task `PY-RUNTIME-001–010` come completate.

- `PY-RUNTIME-001` — stato: completata  
  Argomento coinvolto: contratti distinti delle modalità CLI Sofa scrape, Betfair scrape e Betfair login-only.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PY-RUNTIME-002` — stato: completata  
  Argomento coinvolto: diagnostica SofaScore bounded/redacted e separazione del canale stderr.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PY-RUNTIME-003` — stato: completata  
  Argomento coinvolto: boundedness dello stdout SofaScore e gestione dell'overflow del subprocess.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PY-RUNTIME-004` — stato: completata  
  Argomento coinvolto: coordinamento temporale dello shutdown tra launcher e backend.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PY-RUNTIME-005` — stato: completata  
  Argomento coinvolto: propagazione e osservabilità delle failure I/O del manifest.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PY-RUNTIME-006` — stato: completata  
  Argomento coinvolto: semantica CDP `starting/ready/unavailable` e verifica bounded post-helper.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PY-RUNTIME-007` — stato: completata  
  Argomento coinvolto: distinzione tra probe loopback e bind backend locale.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PY-RUNTIME-008` — stato: completata  
  Argomento coinvolto: direct Node start come authority launcher e classificazione dello script PowerShell backend come helper manuale.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PY-RUNTIME-009` — stato: completata  
  Argomento coinvolto: confini documentali tra owner tecnico Python/launcher, runbook operativo ed evidenze live.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `PY-RUNTIME-010` — stato: completata  
  Argomento coinvolto: matrice di verifica dei contratti runtime/entrypoint.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

Il report registra successivamente `PY-RUNTIME-001–010` come completate e verificate.

## Cambiamenti strutturali storicamente rilevanti

- Modularizzazione valutata ma non necessaria; non risultano nuovi documenti canonici derivati da uno split.
- Il documento è stato mantenuto come singola facade tecnica Python/launcher.
- È stato esplicitato il confine documentale tra questo owner tecnico, il runbook operativo e le evidenze live; l'aggiornamento applicativo registra questo riallineamento senza modifiche a launcher, scraper o test.

## Struttura precedente da considerare

- wrapper root;
- contratti CLI;
- moduli launcher;
- lock e manifest;
- service resolution e ownership dei processi;
- shutdown;
- collegamenti con backend Python process registry e writer authority;
- matrice di verification.

Il report descrive questi sottotemi all'interno della responsabilità primaria del documento e non richiede uno split fisico.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `avvio.py`, `scraper.py`, `betfair_scraper.py`;
- `launcher/app.py`, `launcher/config.py`, `launcher/services.py`, `launcher/session.py`, `launcher/system.py`;
- `launcher/tests/test_launcher.py`;
- `scrapers/sofa/cli.py`, `scrapers/sofa/config.py`, `scrapers/sofa/browser.py`;
- `scrapers/betfair/cli.py`, `scrapers/betfair/config.py`;
- `backend/src/sofa/directFetch.js` e relativi test;
- `backend/src/runtime/pythonProcessRegistry.js`;
- `backend/src/server.js` e relativi test.

Queste aree sono tra le sorgenti direttamente confrontate dal report per il documento target.

## Owner/documenti collegati

- `docs/tennis-decision-ui/operations/01-local-runtime.md` — owner del runbook e del comportamento operativo locale; questo documento mantiene il lato tecnico Python/launcher.
- storage owner / writer authority — l'implementazione dettagliata della writer authority resta fuori dal ruolo di questo documento.
- validation owner — sede delle evidenze e della storia di validazione live, distinta dall'owner tecnico.
- Betfair lifecycle owner — owner specialistico del lifecycle scraper Betfair, da non duplicare in questo documento.

## Guardrail specifici per questo documento

- Mantenere il documento centrato su wrapper compatibili, entrypoint Python, struttura e contratti del launcher.
- Non trasformarlo nel runbook operativo del runtime locale.
- Non assorbire l'implementazione dettagliata della writer authority, le evidenze live o il lifecycle Betfair posseduto da owner specialistici.
- Conservare la distinzione concettuale tra launcher process ownership e backend Python process registry.
- Conservare la natura sottile dei wrapper root e verificare nel CODE AUTHORITY i comportamenti concreti prima di descriverli come correnti. Il report storico descrive `avvio.py`, `scraper.py` e `betfair_scraper.py` come wrapper sottili.

## Informazioni storiche da NON assumere come correnti

- Le osservazioni tecniche contenute nella parte iniziale dell'audit precedono l'applicazione delle task `PY-RUNTIME-001–010` e non devono essere riproposte come stato corrente.
- Le priorità e le proposte operative del report sono metadata storici e non definiscono il contenuto corrente del documento.
- Gli effetti delle task risultano storicamente applicati e verificati, ma il comportamento tecnico corrente deve essere ricavato dal CODE AUTHORITY, non dal report storico.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza individuata tra TODO e JSON allegati: entrambi associano `PY-RUNTIME-001–010` al documento target e le registrano come completate.
- La mappa Markdown cumulativa non è inclusa tra gli allegati di questa Scheda; non è quindi possibile verificarne qui l'allineamento con TODO/JSON.
- Il materiale consultato è storico e non costituisce authority tecnica corrente.