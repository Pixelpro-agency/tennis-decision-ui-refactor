# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/modules/evidence/02-source-identity.md`

Tipo di documento:  
owner tecnico del dominio Source Identity.

Ruolo documentale:  
documentare il **Source Identity Gate live** e il **contratto di identità effective** usato nell’area Evidence. Le fonti storiche trattano nello stesso owner matching, lifecycle del gate, confirmation, market epoch/fingerprint e superficie di status.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

La prima è la baseline tecnica da verificare successivamente; la seconda serve come riferimento per forma e struttura precedente del documento.

## Fonti storiche consultate

- `17 - Report 02-source-identity.md` — report `TDUI-DOC-REPORT-017`, relativo a `02-source-identity.md`.
- `17 - TODO e Json.md` — registro Markdown e JSON delle task associate; le nove voci risultano completate.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing` — criterio metodologico usato per separare contesto storico e authority tecnica.

## Task storicamente associate

- `SOURCE-ID-001` — stato: completata  
  Argomento coinvolto: identità della sessione di tracking e associazione delle callback alla sessione corrente.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOURCE-ID-002` — stato: completata  
  Argomento coinvolto: comportamento del tracking in assenza di gate e percorso Sofa-only `not-applicable`.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOURCE-ID-003` — stato: completata  
  Argomento coinvolto: relazione tra conferma manuale, bootstrap e passaggio a recording.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOURCE-ID-004` — stato: completata  
  Argomento coinvolto: semantica del POST di confirmation quando non esiste un gate live.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOURCE-ID-005` — stato: completata  
  Argomento coinvolto: comportamento e retry dopo un bootstrap non riuscito e cambio di contesto.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOURCE-ID-006` — stato: completata  
  Argomento coinvolto: distinzione fra errori di input/context ed errori infrastrutturali della confirmation.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOURCE-ID-007` — stato: completata  
  Argomento coinvolto: lifecycle di terminazione dei processi Betfair tracking in caso di mismatch.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOURCE-ID-008` — stato: completata  
  Argomento coinvolto: separazione fra documento owner e validation live storica.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOURCE-ID-009` — stato: completata  
  Argomento coinvolto: copertura di verifica relativa a session authority, gate assente, Sofa-only, callback stale e confirmation.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

Il registro Markdown indica `[x]` per tutte le nove task e il JSON conferma `completed: true` / `status: "completed"`.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata ma non ritenuta necessaria: matching, gate, confirmation ed effective identity sono rimasti nello stesso dominio documentale.
- Non risultano nuovi documenti canonici derivati dalla suddivisione del documento.
- La validation live storica è stata separata dall’owner come contenuto di verifica dedicato; il registro storico indica che nel documento owner è rimasto il relativo collegamento.

## Struttura precedente da considerare

- distinzione tra `phase` del gate e `sourceIdentity.status`;
- lifecycle `collecting`, `pending`, `recording`, `mismatch`, `not-applicable`;
- buffering e bootstrap prima della registrazione;
- matching tra identità SofaScore e runner Betfair;
- gestione di market epoch e confirmation fingerprint;
- confirmation manuale;
- distinzione concettuale fra gate live ed effective identity Evidence;
- status endpoint;
- sezione di verification/test.

Questi elementi risultavano parte dello stesso dominio Source Identity.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/sourceIdentityGate.js`
- `backend/src/sofa/sourceIdentityGate/` — in particolare session factory, evaluator, manual confirmation, sample validation e status
- `backend/src/sofa/matchTracker.js` e `backend/src/sofa/trackerUpdate.js`
- `backend/src/sofa/betfair/trackerUpdate.js`
- `backend/src/routes/match.js` e `backend/src/routes/match/sourceIdentityStatusResponse.js`
- `backend/src/routes/evidence.js` e `backend/src/routes/evidence/evidenceResponses.js`
- `backend/src/sofa/matchEvidence/sourceIdentity/`
- `backend/src/sofa/matchEvidence/sourceIdentityConfirmation.js` e `sourceIdentityConfirmationStore.js`
- relativi test di gate, matching, epoch, confirmation e status endpoint

Queste sono le principali sorgenti direttamente associate dal report al documento target.

## Owner/documenti collegati

- `docs/validations/source-identity-live-verification.md` — owner della validation live storica; non sostituisce il contratto tecnico del documento Source Identity.
- area Evidence — collegata per l’uso dell’**effective identity** sui dati persistiti; il gate live e l’effective identity rappresentano due viste dello stesso dominio ma con responsabilità differenti.
- owner Betfair — il classifier tecnico generale Betfair resta fuori dal perimetro Source Identity; la fonte storica non specifica qui il relativo percorso documentale canonico.

## Guardrail specifici per questo documento

- Conservare il documento come owner unico del dominio Source Identity salvo evidenza diversa nel CODE AUTHORITY.
- Non trasformarlo in un documento generale sul lifecycle Betfair, sulla persistenza o sull’intera API Evidence.
- Mantenere distinta la responsabilità del gate live dalla responsabilità dell’effective identity sui dati già persistiti.
- Non assorbire nel documento il dettaglio storico della validation live: la fonte dedicata è `docs/validations/source-identity-live-verification.md`.
- Non generalizzare le regole di matching o normalizzazione oltre ciò che il CODE AUTHORITY corrente dimostra.
- Non assumere che descrizioni, pseudo-flussi o comportamenti presenti nel report di audit rappresentino ancora il codice corrente.

## Informazioni storiche da NON assumere come correnti

- Le condizioni tecniche descritte dal report `TDUI-DOC-REPORT-017` appartengono al commit auditato `4c5f43b007149f3210c27d7565357a447a3a6ef4`, non al CODE AUTHORITY successivo.
- Finding, valutazioni e comportamenti osservati nel report prima dell’applicazione delle task non devono essere trasferiti automaticamente nel documento corrente.
- Le nove task risultano storicamente completate, ma il loro effetto documentabile deve essere ricostruito dal CODE AUTHORITY e non dalle formulazioni progettuali contenute nel vecchio report.
- Gli esiti della validation live storica non equivalgono automaticamente a una verifica del CODE AUTHORITY corrente.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza individuata tra il TODO Markdown e il JSON sullo stato delle nove task: entrambi le registrano come completate.
- Esiste una differenza temporale da preservare: il report documentale descrive lo stato al commit di audit, mentre TODO/JSON registrano successivamente il completamento delle task. Non costituisce una contraddizione da risolvere usando il report come authority tecnica.
- Il materiale fornito non contiene il documento target aggiornato al CODE AUTHORITY; il comportamento corrente dovrà quindi essere verificato direttamente nel repository alla baseline indicata.
