# Scheda di contesto documentale

## Documento target

Percorso:
`docs/validations/documentation-migration-finalization-2026-08-03.md`

Tipo di documento:
record storico di finalizzazione e verifica di una migrazione documentale.

Ruolo documentale:
conservare la cronologia e gli esiti dichiarati della campagna di migrazione documentale del 3–4 agosto 2026, inclusi finalizzazione, cleanup immediato, verifiche sulla working tree e pubblicazione. Non è un owner dello stato tecnico corrente del prodotto.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `41 - Report documentation-migration-finalization-2026-08-03.md` — report `TDUI-DOC-REPORT-041`.
- `41 - TODO e Json.md` — voce TODO e record JSON associati al documento target.

## Task storicamente associate

- `MIGRATION-VAL-001` — stato: completata  
  Argomento coinvolto: formulazione del livello di preservazione dei contenuti sostenuto dal confronto dimensionale dei 28 owner convertiti.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente e documentarlo soltanto entro il ruolo probatorio e storico del documento.

## Cambiamenti strutturali storicamente rilevanti

- Migrazione documentale dichiarata da 40 file `.mdx` residui a 0, con 28 owner convertiti, 8 owner già preparati, 2 validation storiche e 2 specifiche future trattate separatamente.
- Creazione dell'area `docs/validations/` e rimozione del workspace temporaneo di migrazione e dei report temporanei di consegna.
- Cleanup immediatamente successivo di 10 fonti consolidate in `docs/archive/`, con una mappa fonte → destinazione presente al relativo checkpoint storico.
- Aggiunta, nella stessa campagna, delle sezioni di verifica sulla repository reale e di pubblicazione remota.
- Modularizzazione valutata storicamente e ritenuta non necessaria; non risultano nuovi documenti canonici derivati dal documento target.

## Struttura precedente da considerare

- Sequenza della singola campagna: preparazione/finalizzazione → cleanup immediato → gate sulla working tree → verifica di pubblicazione.
- Distinzione tra verifica della copia/pacchetto documentale e verifica della repository applicativa reale.
- Sezioni datate di follow-up del 4 agosto, appartenenti alla stessa campagna avviata il 3 agosto.
- Conteggi della migrazione, riferimenti ai commit storici, risultati dei checker e limiti dichiarati del pacchetto.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `docs/validations/documentation-migration-finalization-2026-08-03.md`
- `docs/validations/README.md`
- `scripts/check_documentation_links.py`
- checker di coerenza dei registri documentali e relativo validation runner `full-offline`
- registri correnti delle task `MIGRATION-VAL-001`, `IMPL-032` e `TEST-076`–`TEST-079`
- storia Git dei checkpoint `2697f66ea8e17a9e35481299cb47ec402558df55` e `3de08ca09ac7cf3d64533b2e72b8f61d1d32f196`, soltanto per interpretare le dichiarazioni storiche

## Owner/documenti collegati

- `docs/validations/README.md` — indice e governance degli artifact di validation; il documento target resta un record di campagna specifico.
- Registri correnti di implementazioni, test e TODO — possiedono lo stato corrente delle task; non va trasferito retroattivamente nel record storico.
- `docs/validations/source-identity-live-verification.md` e `docs/validations/betfair-live-validation-2026-07-04.md` — validation storiche distinte, citate nel contesto della struttura risultante ma non possedute dal documento target.
- Artefatto storico `tennis-decision-ui-documentation-finalization-validation.md` — possibile fonte probatoria della migrazione, da considerare solo se ancora disponibile e identificabile nella baseline.

## Guardrail specifici per questo documento

- Mantenere il documento come record storico della campagna del 3–4 agosto 2026, senza convertirlo in current state, roadmap o owner tecnico.
- Distinguere sempre i fatti validi al checkpoint storico dallo stato corrente della repository.
- Non presentare i risultati di link checker, registry checker o `full-offline` come prova di validazione live o dell'intero prodotto.
- Non equiparare la somiglianza dimensionale dei file alla preservazione esatta del contenuto; riportare soltanto il livello di prova sostenuto dalle evidenze correnti.
- Non dedurre l'identità esatta della working tree dal solo `HEAD` o dall'uguaglianza tra riferimenti locale e remoto.
- Conservare il confine fra pacchetto documentale e repository applicativa completa.
- Non imporre una modularizzazione o una nuova gerarchia di documenti.

## Informazioni storiche da NON assumere come correnti

- L'esistenza di `docs/archive/README.md` oltre il checkpoint del cleanup `3de08ca09ac7cf3d64533b2e72b8f61d1d32f196`.
- La frase secondo cui `IMPL-015` era il lavoro tecnico successivo: descrive il checkpoint storico, non la roadmap corrente.
- Disponibilità corrente del pacchetto ZIP, del relativo hash o dell'artefatto esterno di validazione, se non confermata nella baseline.
- Corrispondenza esatta tra il contenuto verificato della working tree e il commit indicato come `HEAD`.
- Preservazione integrale e semanticamente identica dei 28 corpi migrati sulla sola base del rapporto dimensionale `0,998–1,001`.
- Stato corrente di `docs/archive/`, dei registri o delle task citate nel racconto storico.

## Discrepanze o limiti delle fonti

- Markdown e JSON concordano sull'associazione e sullo stato completato di `MIGRATION-VAL-001`; nessuna discrepanza storica individuata tra le due fonti.
- Il report storico cita artifact esterni e dati di provenance la cui disponibilità corrente deve essere verificata nella baseline prima di documentarli come accessibili.
- Il conteggio storico di quattro validation nel pacchetto non identifica con certezza il quarto artifact; non va completato per deduzione.
- I conteggi dei checker appartengono a scope e checkpoint differenti e non devono essere confrontati senza conservarne il contesto.
