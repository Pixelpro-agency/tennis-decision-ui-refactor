TODO:

Report: [`Report documentale/28 - 01-live-tracking.md`](../Report%20documentale/28%20-%2001-live-tracking.md) — `TDUI-DOC-REPORT-028`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`SOFA-LIVE-001`** — priorità `critical` — Rendere esplicita la differenza fra trackedMatches membership, Python generation, Source Identity bufferGeneration e tracking session authority; applicare IMPL-006 e coprire Stop/new Start same-event ed event switch con callback in-flight.
- [x] **`SOFA-LIVE-002`** — priorità `critical` — Verificare il ritorno di trackMatch nella route Start: nessun HTTP 200 ok:true se il tracker rifiuta l'attivazione; introdurre esito bounded e test terminal barrier.
- [x] **`SOFA-LIVE-003`** — priorità `critical` — Distinguere stop logico da cleanup fisico; remaining process o cleanup failure non devono produrre un falso successo complessivo; preservare betfair_login e coordinare FRONT-SESSION-007.
- [x] **`SOFA-LIVE-004`** — priorità `critical` — Rendere il cleanup mismatch fisicamente completo e osservabile per i child tracking Sofa/Betfair, preservando login e Chrome/CDP; un nuovo Start non deve restare bloccato da un vecchio Sofa child.
- [x] **`SOFA-LIVE-005`** — priorità `high` — Correggere la semantica del technical sample: nessun nuovo sample-derived canonical tick, ma repairOnly di un commit precedente resta consentito; riallineare anche la frase su getBetfairTrackingKey e coordinare TECH-SAMPLE-004.
- [x] **`SOFA-LIVE-006`** — priorità `high` — Rendere bounded e redatta la diagnostica tecnica Betfair end-to-end, usare runtime logger strutturato al posto di detail raw/console.log e verificare che /latest health non esponga URL, path o token.
- [x] **`SOFA-LIVE-007`** — priorità `critical` — Qualificare l'auto-stop Betfair: hasFinished ricevuto non equivale a finished authoritative finché BETFAIR-SCRAPER-006 non irrobustisce il producer; weak hint non deve fermare il tracking.
- [x] **`SOFA-LIVE-008`** — priorità `medium` — Documentare 5s/6s come minimum delay dopo completion e distinguere scheduler completion da scrape attempt, successful scrape, canonical tick e commit timestamp.
- [x] **`SOFA-LIVE-009`** — priorità `high` — Correggere i path test stale, aggiungere coverage per Start/Stop/mismatch/session race/repairOnly/redaction/finished/scheduler e spostare le osservazioni live in artifact di validation con provenance.

JSON:

    {
      "change_id": "SOFA-LIVE-001",
      "report_id": "TDUI-DOC-REPORT-028",
      "document_path": "docs/tennis-decision-ui/modules/sofa/01-live-tracking.md",
      "priority": "critical",
      "type": "tracking_session_authority_alignment",
      "action": "Rendere esplicita la differenza fra trackedMatches membership, Python generation, Source Identity bufferGeneration e tracking session authority; applicare IMPL-006 e coprire Stop/new Start same-event ed event switch con callback in-flight.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-LIVE-002",
      "report_id": "TDUI-DOC-REPORT-028",
      "document_path": "docs/tennis-decision-ui/modules/sofa/01-live-tracking.md",
      "priority": "critical",
      "type": "start_acknowledgement_contract",
      "action": "Verificare il ritorno di trackMatch nella route Start: nessun HTTP 200 ok:true se il tracker rifiuta l'attivazione; introdurre esito bounded e test terminal barrier.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-LIVE-003",
      "report_id": "TDUI-DOC-REPORT-028",
      "document_path": "docs/tennis-decision-ui/modules/sofa/01-live-tracking.md",
      "priority": "critical",
      "type": "stop_completion_contract",
      "action": "Distinguere stop logico da cleanup fisico; remaining process o cleanup failure non devono produrre un falso successo complessivo; preservare betfair_login e coordinare FRONT-SESSION-007.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-LIVE-004",
      "report_id": "TDUI-DOC-REPORT-028",
      "document_path": "docs/tennis-decision-ui/modules/sofa/01-live-tracking.md",
      "priority": "critical",
      "type": "mismatch_process_lifecycle",
      "action": "Rendere il cleanup mismatch fisicamente completo e osservabile per i child tracking Sofa/Betfair, preservando login e Chrome/CDP; un nuovo Start non deve restare bloccato da un vecchio Sofa child.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-LIVE-005",
      "report_id": "TDUI-DOC-REPORT-028",
      "document_path": "docs/tennis-decision-ui/modules/sofa/01-live-tracking.md",
      "priority": "high",
      "type": "technical_sample_persistence_semantics",
      "action": "Correggere la semantica del technical sample: nessun nuovo sample-derived canonical tick, ma repairOnly di un commit precedente resta consentito; riallineare anche la frase su getBetfairTrackingKey e coordinare TECH-SAMPLE-004.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-LIVE-006",
      "report_id": "TDUI-DOC-REPORT-028",
      "document_path": "docs/tennis-decision-ui/modules/sofa/01-live-tracking.md",
      "priority": "high",
      "type": "runtime_diagnostic_redaction",
      "action": "Rendere bounded e redatta la diagnostica tecnica Betfair end-to-end, usare runtime logger strutturato al posto di detail raw/console.log e verificare che /latest health non esponga URL, path o token.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-LIVE-007",
      "report_id": "TDUI-DOC-REPORT-028",
      "document_path": "docs/tennis-decision-ui/modules/sofa/01-live-tracking.md",
      "priority": "critical",
      "type": "downstream_stop_authority_alignment",
      "action": "Qualificare l'auto-stop Betfair: hasFinished ricevuto non equivale a finished authoritative finché BETFAIR-SCRAPER-006 non irrobustisce il producer; weak hint non deve fermare il tracking.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-LIVE-008",
      "report_id": "TDUI-DOC-REPORT-028",
      "document_path": "docs/tennis-decision-ui/modules/sofa/01-live-tracking.md",
      "priority": "medium",
      "type": "scheduler_time_semantics",
      "action": "Documentare 5s/6s come minimum delay dopo completion e distinguere scheduler completion da scrape attempt, successful scrape, canonical tick e commit timestamp.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOFA-LIVE-009",
      "report_id": "TDUI-DOC-REPORT-028",
      "document_path": "docs/tennis-decision-ui/modules/sofa/01-live-tracking.md",
      "priority": "high",
      "type": "verification_and_validation_provenance",
      "action": "Correggere i path test stale, aggiungere coverage per Start/Stop/mismatch/session race/repairOnly/redaction/finished/scheduler e spostare le osservazioni live in artifact di validation con provenance.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },