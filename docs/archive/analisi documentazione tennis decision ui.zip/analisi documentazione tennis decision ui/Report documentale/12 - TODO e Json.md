TODO:

Report: [`../Report documentale/12 - 02-data-lifecycle.md`](../Report%20documentale/12%20-%2002-data-lifecycle.md) — `TDUI-DOC-REPORT-012`.

Modularizzazione: **valutata, non necessaria**. Il documento deve restare un unico lifecycle end-to-end; richiede una revisione mirata che riduca le duplicazioni con gli owner specialistici e renda espliciti i gap di authority e consistenza, senza creare nuovi file.

- [x] **`DATA-LIFE-001`** — priorità `medium` — Documentato l’ordine esatto bootstrap e il piccolo intervallo tra listener readiness e registrazione degli handler, senza dichiarare hardening inesistente.
- [x] **`DATA-LIFE-002`** — priorità `critical` — Distinti Stop live e shutdown terminale, registrando callback Node in-flight e target `IMPL-006`.
- [x] **`DATA-LIFE-003`** — priorità `high` — Separati scrape success, commit success, canonical tick e semantica di `lastSuccessfulScrapeAt`.
- [x] **`DATA-LIFE-004`** — priorità `critical` — Documentata la persistenza pre-bootstrap e la rollback compensativa ora applicata quando il bootstrap fallisce.
- [x] **`DATA-LIFE-005`** — priorità `high` — Precisato lo status-only Graph come nuovo tick timeline con `seq`/`commitId`, history senza append e dati regressivi non adottati.
- [x] **`DATA-LIFE-006`** — priorità `high` — Distinte letture persistite, in memoria e probe diagnostici bounded verso target ammessi.
- [x] **`DATA-LIFE-007`** — priorità `high` — Registrato il gap di provenance temporale e mantenuto `IMPL-018` come target non implementato.
- [x] **`DATA-LIFE-008`** — priorità `high` — Descritte le protezioni differenti dei poller e l’assenza di uno Stop frontend coordinato, collegando `IMPL-006`.
- [x] **`DATA-LIFE-009`** — priorità `medium` — Mantenuto un solo documento, ridotte duplicazioni e aggiunta la matrice stage/owner/evidenza.

JSON:

    {
      "change_id": "DATA-LIFE-001",
      "report_id": "TDUI-DOC-REPORT-012",
      "document_path": "docs/tennis-decision-ui/architecture/02-data-lifecycle.md",
      "priority": "medium",
      "type": "bootstrap_shutdown_registration_order",
      "action": "Rendere esatto l’ordine bootstrap e valutare il gap fra listener readiness e registrazione degli shutdown handler.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "DATA-LIFE-002",
      "report_id": "TDUI-DOC-REPORT-012",
      "document_path": "docs/tennis-decision-ui/architecture/02-data-lifecycle.md",
      "priority": "critical",
      "type": "stop_vs_terminal_drain",
      "action": "Distinguere Stop live e terminal drain, registrare che lo Stop corrente non drena necessariamente activeTrackerOperations e collegare IMPL-006.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "DATA-LIFE-003",
      "report_id": "TDUI-DOC-REPORT-012",
      "document_path": "docs/tennis-decision-ui/architecture/02-data-lifecycle.md",
      "priority": "high",
      "type": "betfair_runtime_vs_commit_semantics",
      "action": "Correggere la semantica Betfair distinguendo lastSuccessfulScrapeAt, persistence success e canonical tick.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "DATA-LIFE-004",
      "report_id": "TDUI-DOC-REPORT-012",
      "document_path": "docs/tennis-decision-ui/architecture/02-data-lifecycle.md",
      "priority": "critical",
      "type": "manual_confirmation_bootstrap_consistency",
      "action": "Registrare la persistenza della manual confirmation prima del bootstrap e coordinare la soluzione con EVIDENCE-API-008.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "DATA-LIFE-005",
      "report_id": "TDUI-DOC-REPORT-012",
      "document_path": "docs/tennis-decision-ui/architecture/02-data-lifecycle.md",
      "priority": "high",
      "type": "graph_status_only_timeline_semantics",
      "action": "Correggere la semantica Graph status-only: history non append, nuovo tick timeline con seq/commitId e market/runner clonati.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "DATA-LIFE-006",
      "report_id": "TDUI-DOC-REPORT-012",
      "document_path": "docs/tennis-decision-ui/architecture/02-data-lifecycle.md",
      "priority": "high",
      "type": "readonly_diagnostic_network_io",
      "action": "Distinguere persisted read, memory read e diagnostic network read e consentire probe solo verso target validati e bounded.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "DATA-LIFE-007",
      "report_id": "TDUI-DOC-REPORT-012",
      "document_path": "docs/tennis-decision-ui/architecture/02-data-lifecycle.md",
      "priority": "high",
      "type": "betfair_acquisition_provenance",
      "action": "Registrare l’assenza corrente di provenance temporale Betfair completa e collegare IMPL-018 come target approvato non implementato.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "DATA-LIFE-008",
      "report_id": "TDUI-DOC-REPORT-012",
      "document_path": "docs/tennis-decision-ui/architecture/02-data-lifecycle.md",
      "priority": "high",
      "type": "frontend_poller_lifecycle",
      "action": "Documentare le differenze fra i poller frontend e il fatto che lo Stop corrente non li sospende tutti, collegando IMPL-006.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "DATA-LIFE-009",
      "report_id": "TDUI-DOC-REPORT-012",
      "document_path": "docs/tennis-decision-ui/architecture/02-data-lifecycle.md",
      "priority": "medium",
      "type": "data_lifecycle_owner_deduplication",
      "action": "Mantenere un solo lifecycle, ridurre duplicazioni e aggiungere una matrice stage→owner→test senza nuovi documenti.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }