# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/audit-documentazione/03-operations-roadmap-e-controlli.md`

Tipo di documento:  
Facade stabile del modulo/registro storico relativo ai checkpoint B5 Operations/Roadmap e B6 Controlli trasversali.

Ruolo documentale:  
Preservare il confine tra stato storico dei checkpoint e stato successivo alla migrazione, mantenere il current overlay sintetico e fornire la navigazione verso i due documenti child che conservano il contenuto completo di B5 e B6. Il parent non costituisce più il contenitore monolitico dei due checkpoint.

Documenti appartenenti allo stesso modulo:

- `implementazioni/audit-documentazione/03-operations-roadmap-e-controlli/01-operations-roadmap-b5.md`
- `implementazioni/audit-documentazione/03-operations-roadmap-e-controlli/02-controlli-trasversali-b6.md`

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

Baseline storica interna B6:  
`b277bd9b7373dfd8702e65446c88bab7a0f64dcc`

## Fonti storiche consultate

- `Report documentale/62 - 03-operations-roadmap-e-controlli.md` — `TDUI-DOC-REPORT-062`.
- `62 - TODO e Json.md`.
- `Report di handoff — aggiornamento post-esecuzione DOC-AUDIT-B56-002`.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing`.

## Task storicamente associate

- `DOC-AUDIT-B56-001` — stato: **completata**.  
  Argomento coinvolto: riconciliazione tra i checkpoint storici B5/B6 e lo stato documentale successivo alla migrazione, con distinzione tra owner storici e riferimenti correnti.  
  Uso consentito: verificare nel CODE AUTHORITY e nella documentazione corrente quale effetto della riconciliazione sia pertinente al ruolo del documento.

- `DOC-AUDIT-B56-002` — stato: **completata**.  
  Argomento coinvolto: modularizzazione del precedente documento monolitico B5/B6. Il parent è stato trasformato in facade stabile; il contenuto B5 è stato trasferito nel child `01-operations-roadmap-b5.md` e il contenuto B6 nel child `02-controlli-trasversali-b6.md`, preservando provenance storica e current overlay.  
  Uso consentito: considerare la struttura facade + due child come struttura documentale risultante della task.

## Cambiamenti strutturali storicamente rilevanti

- Dopo i checkpoint B5/B6 è avvenuta una migrazione documentale che ha modificato collocazione e stato di diversi contenuti senza invalidare il valore storico dei checkpoint.
- Le validation live di Source Identity e Betfair risultano separate dagli operations e collocate sotto `docs/validations/`.
- I precedenti file canonici `roadmap/02-replay-and-backtesting.md` e `roadmap/03-market-reactions-journal.md` non risultano più parte del tree canonico; le relative specifiche future sono indicate come consolidate nei registri.
- La riconciliazione storico/current di `DOC-AUDIT-B56-001` risulta completata ed è stata preservata durante la modularizzazione.
- La separazione fisica B5/B6 è stata eseguita:
  - `03-operations-roadmap-e-controlli.md` resta facade stabile;
  - `§14` B5 vive nel child `01-operations-roadmap-b5.md`;
  - `§15` B6 vive nel child `02-controlli-trasversali-b6.md`.

## Struttura precedente da considerare

Prima di `DOC-AUDIT-B56-002`:

- `03-operations-roadmap-e-controlli.md`
  - `§14` — Checkpoint B5, Operations e roadmap;
  - `§15` — Checkpoint B6, controlli trasversali e chiusura dell’audit.

Dopo `DOC-AUDIT-B56-002`:

- `03-operations-roadmap-e-controlli.md`
  - facade;
  - current overlay sintetico;
  - navigazione verso i child.

- `03-operations-roadmap-e-controlli/01-operations-roadmap-b5.md`
  - record storico completo di `§14` B5.

- `03-operations-roadmap-e-controlli/02-controlli-trasversali-b6.md`
  - record storico completo di `§15` B6.

Il child B5 conserva, tra gli altri elementi:

- perimetro B5;
- esito sintetico;
- `DOC-020`;
- `DOC-021`;
- `DOC-022`;
- `DOC-023`;
- runbook da preservare;
- roadmap future;
- esito B5;
- provenance secondo cui i test furono letti ma non eseguiti;
- path storici `.mdx`.

Il child B6 conserva, tra gli altri elementi:

- perimetro;
- link e navigazione;
- materiale legacy;
- `WORKFLOW-002`;
- `WORKFLOW-003`;
- test e validazioni;
- §15.5 classificazione finale;
- §15.6 struttura documentale risultante;
- esito B6;
- baseline storica B6;
- distinzione fra presenza del test, esecuzione, collaudo live e prova archiviata.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- persistenza e commit journal, incluso il dominio `backend/match_history/.pending_commits/`;
- runtime, cleanup e retention collegati agli operations;
- frontend relativo alla persistence integrity;
- diagnostica e redazione delle informazioni Betfair;
- Source Identity e distinzione tra comportamento corrente e validation storica;
- infrastruttura del test runner e dei checker richiamati dal checkpoint B6, incluso `scripts/validation/run.mjs`.

Le fonti storiche non forniscono per tutte queste aree un singolo file di codice canonico; dove necessario vanno trattate come domini da localizzare nel CODE AUTHORITY.

## Owner/documenti collegati

### Componenti documentali diretti del modulo

- `implementazioni/audit-documentazione/03-operations-roadmap-e-controlli.md`  
  Owner della facade, della navigazione e del current overlay sintetico.

- `implementazioni/audit-documentazione/03-operations-roadmap-e-controlli/01-operations-roadmap-b5.md`  
  Owner del record storico completo B5 Operations/Roadmap.

- `implementazioni/audit-documentazione/03-operations-roadmap-e-controlli/02-controlli-trasversali-b6.md`  
  Owner del record storico completo B6 Controlli trasversali.

### Documenti e owner collegati

- `docs/tennis-decision-ui/operations/01-local-runtime.md` — contesto runtime operativo.
- `docs/tennis-decision-ui/operations/04-validation-and-rollback.md` — runbook di validazione/rollback.
- `docs/tennis-decision-ui/operations/05-retention-and-cleanup.md` — retention, cleanup e journal.
- `docs/tennis-decision-ui/roadmap/01-current-state.md` — fotografia corrente richiamata nella riconciliazione.
- `docs/validations/README.md` — confine fra validation storica e authority corrente.
- `docs/validations/source-identity-live-verification.md` — evidenza storica Source Identity.
- `docs/validations/betfair-live-validation-2026-07-04.md` — evidenza storica Betfair.
- `DOC-031` — owner corrente più specifico del tema precedentemente rappresentato anche da `DOC-021`; `DOC-021` resta riferimento storico precedente.
- `DOC-022` — riferimento associato alla completezza/accuratezza della fotografia Current State.
- `IMPL-010`, `IMPL-012`, `IMPL-023` — registri indicati come sede delle specifiche future precedentemente presenti nei file roadmap rimossi dal canonico.

La modularizzazione non modifica gli owner tecnici correnti sotto `docs/`.

## Guardrail specifici per questo documento

- Mantenere distinta la verità **al checkpoint B5/B6** dalla situazione successiva alla migrazione.
- Non reinterpretare retroattivamente un esito storico come se fosse stato errato solo perché il repository è cambiato successivamente.
- Preservare la qualificazione B5 “I test sono stati letti ma non eseguiti”.
- Preservare la baseline storica B6.
- Non usare automaticamente la §15.5 di B6 come backlog corrente.
- Non trattare `docs/validations/` come owner del comportamento runtime corrente.
- Non considerare l’assenza dei due vecchi file roadmap come prova di perdita dei requisiti; le fonti indicano che le specifiche future sono state consolidate nei registri.
- La struttura **facade + due child** è la struttura risultante di `DOC-AUDIT-B56-002`.
- Non ricomporre integralmente B5 e B6 nel parent.
- Non duplicare nella facade il contenuto completo dei due checkpoint.

## Informazioni storiche da NON assumere come correnti

- L’inventario di file operations/roadmap presente nel checkpoint B5 è pre-migrazione.
- Le affermazioni B5/B6 secondo cui la documentazione non era stata modificata descrivono l’esito di quei checkpoint, non lo stato successivo.
- Il riferimento storico a `README → index.mdx` appartiene allo stato pre-migrazione.
- I path `.mdx` preservati nei child sono evidenza storica e non vanno trasformati automaticamente in path correnti.
- La §15.5 rappresenta una classificazione effettuata al checkpoint, non il backlog corrente.
- Lo stato storico di `TEST-003` come runner assente è stato successivamente superato dal runner corrente.
- `IMPL-001` e `IMPL-005` risultano successivamente completate.
- `DOC-020` e `DOC-023` risultano successivamente risolti.
- `DOC-021` resta un precursore storico con owner corrente più specifico in `DOC-031`.
- `DOC-022` resta pertinente/parzialmente aggiornato.
- I file canonici futuri di replay/backtesting e Market Reactions Journal citati nel checkpoint non risultano più parte del tree canonico corrente.

Queste informazioni restano invariate dopo la modularizzazione.

## Discrepanze o limiti delle fonti

- `DOC-AUDIT-B56-001` risulta completata.
- `DOC-AUDIT-B56-002` risulta completata **a livello di trasformazione documentale**.
- Il parent è stato trasformato in facade stabile e i due child B5/B6 sono stati materialmente prodotti.
- Le verifiche strutturali sul materiale prodotto risultano positive, incluse preservazione dei link, degli ID, della provenance B5, della baseline B6 e del payload storico trasferito.
- Non risultano invece eseguiti, sulla working tree finale completa del repository, i quattro gate repository-level:
  - `python scripts/check_registry_consistency.py`
  - `python scripts/check_documentation_links.py --forbid-mdx-links`
  - `node scripts/validation/run.mjs fast --no-write`
  - `git diff --check`
- Non assumere né registrare un PASS di questi quattro gate in assenza di un report separato della loro effettiva esecuzione.
