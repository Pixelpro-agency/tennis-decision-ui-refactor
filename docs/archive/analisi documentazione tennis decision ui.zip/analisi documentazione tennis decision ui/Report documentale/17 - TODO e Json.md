TODO:

Report: [`../Report documentale/17 - 02-source-identity.md`](../Report%20documentale/17%20-%2002-source-identity.md) — `TDUI-DOC-REPORT-017`.

Modularizzazione: **valutata, non necessaria**. Matching, gate, confirmation ed effective identity appartengono allo stesso dominio; va aggiunta chiarezza sulle authority e separata la validation live storica.

- [x] **`SOURCE-ID-001`** — priorità `critical` — `trackingSessionId` propagata a tracker, gate, observer, Start API e conferma; callback SofaScore e Betfair stale bloccate prima della persistenza.
- [x] **`SOURCE-ID-002`** — priorità `critical` — Gate assente fail-closed nel tracking canonico; Sofa-only esplicitamente `not-applicable`.
- [x] **`SOURCE-ID-003`** — priorità `critical` — La confirmation viene persistita dopo bootstrap riuscito; bootstrap o upsert falliti lasciano il gate pending senza confirmation stale.
- [x] **`SOURCE-ID-004`** — priorità `high` — Il POST di conferma senza gate è rifiutato; conferme persistite disponibili solo per lettura/revoca diagnostica e non come autorità live.
- [x] **`SOURCE-ID-005`** — priorità `high` — Definita e testata la retry policy: nessun retry automatico nella stessa buffer generation, nuovo tentativo dopo cambio contesto e pending manuale ritentabile.
- [x] **`SOURCE-ID-006`** — priorità `high` — Separati input/context e failure infrastrutturali con status e code HTTP bounded.
- [x] **`SOURCE-ID-007`** — priorità `medium` — Documentata la terminazione mismatch scoped e bounded tramite process registry, con escalation sul solo PID registrato e Chrome/CDP preservati.
- [x] **`SOURCE-ID-008`** — priorità `medium` — Rimossa la duplicazione della validation live dall'owner e mantenuto il link alla validation storica.
- [x] **`SOURCE-ID-009`** — priorità `high` — Aggiunta matrice per session authority, gate assente, Sofa-only, callback stale e conferma stale/senza gate; mantenuti i test store/bootstrap/recovery.

JSON:

    {
      "change_id": "SOURCE-ID-001",
      "report_id": "TDUI-DOC-REPORT-017",
      "document_path": "docs/tennis-decision-ui/modules/evidence/02-source-identity.md",
      "priority": "critical",
      "type": "source_identity_session_authority",
      "action": "Applicare una trackingSessionId end-to-end: il gate eventId-based e bufferGeneration non sono session authority e le callback stale devono essere rifiutate.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOURCE-ID-002",
      "report_id": "TDUI-DOC-REPORT-017",
      "document_path": "docs/tennis-decision-ui/modules/evidence/02-source-identity.md",
      "priority": "critical",
      "type": "no_gate_fail_closed",
      "action": "Trasformare no-gate da fail-open a fail-closed nel tracking canonico e usare not-applicable per Sofa-only.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOURCE-ID-003",
      "report_id": "TDUI-DOC-REPORT-017",
      "document_path": "docs/tennis-decision-ui/modules/evidence/02-source-identity.md",
      "priority": "critical",
      "type": "confirmation_bootstrap_atomicity",
      "action": "Rendere coerente/atomico confirmation→bootstrap→recording senza lasciare confirmation attive dopo bootstrap fallito.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOURCE-ID-004",
      "report_id": "TDUI-DOC-REPORT-017",
      "document_path": "docs/tennis-decision-ui/modules/evidence/02-source-identity.md",
      "priority": "high",
      "type": "confirmation_api_without_gate",
      "action": "Decidere se il fallback confirmation senza gate è supportato; se sì distinguere confirmation persisted da gate recording, altrimenti rimuoverlo.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOURCE-ID-005",
      "report_id": "TDUI-DOC-REPORT-017",
      "document_path": "docs/tennis-decision-ui/modules/evidence/02-source-identity.md",
      "priority": "high",
      "type": "bootstrap_failure_recovery",
      "action": "Definire la retry policy dopo bootstrap failure e testare il cambio contesto, senza confondere bufferGeneration con session generation.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOURCE-ID-006",
      "report_id": "TDUI-DOC-REPORT-017",
      "document_path": "docs/tennis-decision-ui/modules/evidence/02-source-identity.md",
      "priority": "high",
      "type": "confirmation_error_mapping",
      "action": "Correggere l’error mapping confirmation distinguendo input/context da store/persistence/bootstrap failures con code HTTP bounded.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOURCE-ID-007",
      "report_id": "TDUI-DOC-REPORT-017",
      "document_path": "docs/tennis-decision-ui/modules/evidence/02-source-identity.md",
      "priority": "medium",
      "type": "mismatch_cleanup_contract",
      "action": "Descrivere il cleanup mismatch tramite Python process registry scoped/bounded, includendo eventuale escalation e preservando Chrome/CDP.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOURCE-ID-008",
      "report_id": "TDUI-DOC-REPORT-017",
      "document_path": "docs/tennis-decision-ui/modules/evidence/02-source-identity.md",
      "priority": "medium",
      "type": "live_validation_ownership",
      "action": "Rimuovere la duplicazione della validazione live dall’owner Source Identity e rinviare alla validation storica con stato parziale.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOURCE-ID-009",
      "report_id": "TDUI-DOC-REPORT-017",
      "document_path": "docs/tennis-decision-ui/modules/evidence/02-source-identity.md",
      "priority": "high",
      "type": "source_identity_authority_tests",
      "action": "Aggiungere test di session authority, no-gate, stale callbacks, confirmation fallback/store failures e bootstrap recovery.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }