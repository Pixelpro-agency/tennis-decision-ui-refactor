# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/implementazioni-proposte/01-utility-e-autorita-base.md`

Tipo di documento:  
facade stabile di un registro owner modularizzato relativo alle implementazioni `IMPL-001…015`.

Ruolo documentale:  
fornire il livello di orientamento del registro `IMPL-001…015`, mantenendo perimetro, nota sui checkpoint storici, riepilogo corrente, collegamenti ai tre child owner e navigazione precedente/successiva. Le schede owner complete risiedono nei tre child e non sono duplicate nella facade.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`
- `Report documentale — implementazioni/implementazioni-proposte/01-utility-e-autorita-base.md`, report `TDUI-DOC-REPORT-064`
- `64 - TODO e Json.md`, stato precedente all'esecuzione
- `Report di handoff — esecuzione IMPL-BASE-001 / IMPL-BASE-002`

## Task storicamente associate

- `IMPL-001` — stato: completata  
  Argomento coinvolto: utility e controlli documentali; controllo ripetibile dei link.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente. Il problema originario registrato al checkpoint B6 è ora distinto dallo stato corrente.

- `IMPL-002` — stato: non completata  
  Argomento coinvolto: utility e controlli documentali.  
  Uso consentito: non assumerla come comportamento implementato; verificare soltanto il contesto corrente pertinente.

- `IMPL-003` — stato: non completata  
  Argomento coinvolto: mappa/matrice delle superfici di test e validation.  
  Uso consentito: non assimilare l'esistenza di un validation runner al completamento della task.

- `IMPL-004` — stato: completata  
  Argomento coinvolto: struttura delle validation documentali.  
  Uso consentito: verificarne nel CODE AUTHORITY la forma ancora pertinente.

- `IMPL-005` — stato: completata  
  Argomento coinvolto: coerenza del registro e checker dedicato.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `IMPL-006` — stato: non completata  
  Argomento coinvolto: session authority e identificazione delle sessioni/comandi.  
  Uso consentito: non assumere come implementato il target descritto storicamente. Eventuali materializzazioni parziali non equivalgono al completamento della task.

- `IMPL-007` — stato: non completata  
  Argomento coinvolto: boundary dei dati diagnostici pubblici.  
  Uso consentito: verificare esclusivamente il comportamento corrente pertinente.

- `IMPL-008` — stato: non completata  
  Argomento coinvolto: profilo/harness di validation per persistence e recovery.  
  Uso consentito: non assumere che test isolati equivalgano alla task completata.

- `IMPL-009` — stato: non completata  
  Argomento coinvolto: rappresentazione frontend dello stato di persistence integrity.  
  Uso consentito: verificare nel CODE AUTHORITY l'eventuale comportamento corrente. Eventuali materializzazioni parziali non equivalgono al completamento della task.

- `IMPL-010` — stato: non completata  
  Argomento coinvolto: toolkit/ambiente strategie offline; registrata storicamente come futura.  
  Uso consentito: non descriverla come capacità corrente senza verifica.

- `IMPL-011` — stato: non completata  
  Argomento coinvolto: maintenance authority e cleanup runtime.  
  Uso consentito: distinguere la primitiva di retention già esistente dal completamento della task.

- `IMPL-012` — stato: non completata  
  Argomento coinvolto: fixture e replay offline deterministico.  
  Uso consentito: non assumere l'esistenza di un replay canonico senza verifica.

- `IMPL-013` — stato: non completata  
  Argomento coinvolto: benchmark e baseline prestazionali.  
  Uso consentito: non assumere metriche correnti sulla base del solo materiale storico.

- `IMPL-014` — stato: non completata  
  Argomento coinvolto: evoluzione futura dipendente da altre aree; registrata storicamente come futura e condizionata.  
  Uso consentito: non descriverla come comportamento implementato.

- `IMPL-015` — stato: completata  
  Argomento coinvolto: writer authority per la match history.  
  Uso consentito: verificare nel CODE AUTHORITY il comportamento corrente pertinente preservando il significato del closeout e della provenance storica.

- `IMPL-BASE-001` — stato: completata  
  Argomento coinvolto: temporal authority del registro `IMPL-001…015`.  
  Impatto documentale registrato: problema originario, checkpoint storico, decisioni successive, stato corrente e closeout sono ora distinti; §13.1 e §14.1 sono qualificati come sequencing storici e l'introduzione di §14 è separata temporalmente dalle decisioni successive.  
  Uso consentito: considerare questo riallineamento come struttura documentale già applicata, senza riaprire l'audit tecnico.

- `IMPL-BASE-002` — stato: completata  
  Argomento coinvolto: modularizzazione del registro in tre responsibility boundary.  
  Impatto documentale registrato: il file target è ora una facade stabile e le schede owner `IMPL-001…015` sono distribuite una sola volta nei tre child.  
  Uso consentito: considerare la modularizzazione come struttura documentale già esistente.

## Cambiamenti strutturali storicamente rilevanti

- La temporal authority del registro è stata riallineata senza modificare gli stati tecnici delle `IMPL-001…015`.
- Il problema originario di `IMPL-001` è ora esplicitamente riferito al checkpoint B6 e separato dallo stato corrente.
- §13.1 è qualificato come ordine consigliato appartenente a un checkpoint storico.
- L'introduzione di §14 distingue il momento iniziale di registrazione delle voci dalle decisioni successive delle singole schede.
- §14.1 è qualificato come sequencing storico e non come priorità operativa corrente.
- `01-utility-e-autorita-base.md` è stato trasformato in facade stabile.
- Sono stati creati tre child owner:
  - `implementazioni/implementazioni-proposte/01-utility-e-autorita-base/01-utility-e-controlli.md`
  - `implementazioni/implementazioni-proposte/01-utility-e-autorita-base/02-autorita-boundary-e-supporto.md`
  - `implementazioni/implementazioni-proposte/01-utility-e-autorita-base/03-offline-replay-strategy-performance.md`
- Ogni scheda owner `IMPL-001…015` compare una sola volta nei tre child.
- Il closeout e la provenance storica di `IMPL-015` sono preservati nel child authority/boundary/supporto.
- L'estensione di `IMPL-009`, la pipeline cross-source e la navigazione verso `02-runtime-betfair.md` risultano preservate.

## Struttura precedente da considerare

Prima della modularizzazione il documento target conteneva nello stesso file:

- perimetro completo `IMPL-001…015`;
- schede owner complete;
- checkpoint B1–B6 e D1–D18;
- problemi originari;
- decisioni successive;
- sezioni §13.1, §14 e §14.1;
- stati correnti;
- closeout e provenance.

Questa struttura è contesto storico. La forma corrente è invece composta dalla facade stabile e dai tre child owner.

Da confrontare con il CODE AUTHORITY soltanto per gli aspetti tecnici pertinenti, senza ricostruire il precedente monolite documentale.

## Aree da verificare nel CODE AUTHORITY

- `scripts/check_documentation_links.py`
- `scripts/check_registry_consistency.py`
- `scripts/validation/test-manifest.json`
- `scripts/cleanup_runtime_cache.py`
- `backend/src/routes/match/trackingResponses.js`
- `backend/src/routes/betfair/oddsResponse.js`
- `backend/src/runtime/matchHistoryWriterAuthority.js`
- `frontend/src/App.jsx`

Queste restano le principali superfici tecniche storicamente associate al perimetro del registro. La verifica futura deve servire soltanto a determinare il comportamento corrente pertinente alla documentazione.

## Owner/documenti collegati

- `implementazioni/implementazioni-proposte/01-utility-e-autorita-base/01-utility-e-controlli.md`  
  Owner di `IMPL-001…005`; conserva checkpoint B1–B6, problema originario di `IMPL-001`, §13.1 come ordine storico, stato corrente pertinente e closeout del gruppo.

- `implementazioni/implementazioni-proposte/01-utility-e-autorita-base/02-autorita-boundary-e-supporto.md`  
  Owner di `IMPL-006/007/008/009/011/015`; conserva checkpoint D1–D18, §14.1 come sequencing storico, estensione di `IMPL-009`, stato corrente pertinente e closeout/provenance completa di `IMPL-015`.

- `implementazioni/implementazioni-proposte/01-utility-e-autorita-base/03-offline-replay-strategy-performance.md`  
  Owner di `IMPL-010/012/013/014`; raccoglie Strategy Lab, fixture/replay offline, pipeline e dataset cross-source, baseline prestazionale e ottimizzazione Betfair futura e condizionata.

- `todo-list-tennis-decision-ui.md`  
  Riferimento storico sintetico degli stati; non sostituisce il CODE AUTHORITY per determinare il comportamento tecnico corrente.

- `docs/validations/`  
  Struttura collegata storicamente a `IMPL-004` e alle validation documentali.

- `implementazioni/implementazioni-proposte/02-runtime-betfair.md`  
  Documento successivo nella navigazione del registro; la modularizzazione ha preservato il collegamento verso questo owner.

## Guardrail specifici per questo documento

- mantenere `01-utility-e-autorita-base.md` come facade stabile;
- non riportare nella facade le schede owner complete già presenti nei child;
- mantenere ogni `IMPL-001…015` in un solo child owner;
- non trasformare §13.1 o §14.1 in execution queue correnti;
- mantenere separati problema originario, checkpoint, decisione successiva, stato corrente e closeout;
- non riaprire le `IMPL` storicamente completate;
- non promuovere come completate le `IMPL` aperte o future;
- non usare il completamento di `IMPL-BASE-001` o `IMPL-BASE-002` per modificare automaticamente gli stati tecnici di `IMPL-001…015`;
- preservare il closeout e la provenance di `IMPL-015`;
- non aprire nuovi finding o un nuovo audit tecnico durante il technical writing;
- non dichiarare test o PASS che non risultino effettivamente eseguiti.

## Informazioni storiche da NON assumere come correnti

- Le verifiche tecniche del report `TDUI-DOC-REPORT-064` appartengono alla baseline storica utilizzata da quel report; il technical writer deve usare il CODE AUTHORITY assegnato per stabilire il comportamento tecnico corrente.
- Gli stati aperti o futuri registrati storicamente per `IMPL-002/003/006/007/008/009/010/011/012/013/014` non sostituiscono una verifica del CODE AUTHORITY quando occorre descrivere comportamento corrente.
- Le descrizioni dei problemi originari e gli ordini dei checkpoint non costituiscono backlog corrente.
- La descrizione della modularizzazione come proposta, pending o non ancora eseguita appartiene allo stato precedente a `IMPL-BASE-002` e non è più valida.
- La descrizione di `IMPL-BASE-001` e `IMPL-BASE-002` come non completate appartiene allo stato precedente all'esecuzione e non è più valida.
- Non devono essere assunti come PASS già eseguiti:
  - `python scripts/check_registry_consistency.py`
  - `python scripts/check_documentation_links.py --forbid-mdx-links`
  - `node scripts/validation/run.mjs fast`

## Discrepanze o limiti delle fonti

- Il report documentale 064 precede l'esecuzione di `IMPL-BASE-001` e `IMPL-BASE-002`; per lo stato successivo all'esecuzione prevale il relativo report di handoff documentale.
- Il precedente `64 - TODO e Json.md` rappresentava correttamente lo stato pre-esecuzione e registrava entrambe le task come pending; tale stato deve ora essere considerato storico.
- La lavorazione di handoff ha verificato gli invarianti della struttura modularizzata, ma non autorizza a dichiarare come eseguiti i tre controlli repository-level indicati sopra.
- Non risulta dal materiale fornito che la mappa Markdown globale o altri registri esterni al presente `64 - TODO e Json.md` siano stati aggiornati durante questa esecuzione.