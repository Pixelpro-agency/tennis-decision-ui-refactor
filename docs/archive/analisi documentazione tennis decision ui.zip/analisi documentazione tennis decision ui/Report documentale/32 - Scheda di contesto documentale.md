# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/operations/01-local-runtime.md`

Tipo di documento:  
runbook operativo / facade locale.

Ruolo documentale:  
owner operativo dell'avvio, del riuso e dello shutdown dello stack locale. Il documento tiene insieme, a livello operativo, la sequenza di startup, risoluzione dei servizi, ownership, stato ready e shutdown, senza sostituire gli owner tecnici specialistici dei sottosistemi coinvolti.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`
- `Report documentale/32 - 01-local-runtime.md` — `TDUI-DOC-REPORT-032`
- `32 - TODO e Json.md`, comprendente mappa TODO e JSON incrementale associati al report

## Task storicamente associate

- `LOCAL-RUNTIME-001` — stato: completata  
  Argomento coinvolto: identità del backend riusato rispetto a working copy e storage.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `LOCAL-RUNTIME-002` — stato: completata  
  Argomento coinvolto: ordine di discovery/reuse e avvio del backend locale.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `LOCAL-RUNTIME-003` — stato: completata  
  Argomento coinvolto: esiti e contratto CLI del launcher `avvio.py`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `LOCAL-RUNTIME-004` — stato: completata  
  Argomento coinvolto: provenienza e propagazione della configurazione CDP tra launcher, frontend, richieste backend e scraper.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `LOCAL-RUNTIME-005` — stato: completata  
  Argomento coinvolto: distinzione tra readiness dei servizi e apertura browser come handoff operativo.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `LOCAL-RUNTIME-006` — stato: completata  
  Argomento coinvolto: separazione tra contratto operativo corrente e provenance delle validation runtime storiche.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `LOCAL-RUNTIME-007` — stato: completata  
  Argomento coinvolto: verification matrix del launcher e copertura dei principali scenari di riuso, startup e outcome.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione del documento è stata valutata e risulta storicamente non necessaria.
- Non risultano suddivisioni del documento né nuovi file canonici creati come conseguenza della revisione.
- Il ruolo principale è rimasto quello di runbook operativo unico per il lifecycle locale dello stack.
- Il report registra, nella successiva nota di applicazione del 2026-08-10, la creazione dell'artifact `docs/validations/local-runtime-hardening-2026-08-10.md`.

## Struttura precedente da considerare

- flusso operativo complessivo: Start → service resolution → ownership → ready → Ctrl+C;
- avvio e riuso dei servizi locali;
- distinzione fra processi owned e servizi riusati/esterni;
- distinzione fra launcher lock e writer authority;
- shutdown e responsabilità di terminazione;
- failure mode e verification matrix operativa;
- riferimenti agli owner specialistici senza duplicarne i dettagli tecnici.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `avvio.py`
- `launcher/app.py`
- `launcher/config.py`
- `launcher/session.py`
- `launcher/services.py`
- `launcher/system.py`
- `backend/src/server.js`
- `backend/src/runtime/matchHistoryWriterAuthority.js`
- `frontend/vite.config.js` e `frontend/src/hooks/useAnalysisSessionState.js`
- `launcher/tests/test_launcher.py` e `scripts/validation/test-manifest.json`

## Owner/documenti collegati

- `modules/python/01-entrypoints-and-runtime.md` — owner tecnico dei dettagli Python/launcher; il runbook mantiene la vista operativa.
- `modules/storage/02-commit-journal-and-recovery.md` — owner specialistico della recovery/persistenza; il runbook non ne replica la logica interna.
- `modules/sofa/01-live-tracking.md` — owner del lifecycle del tracking; il runbook considera soltanto il confine operativo necessario allo shutdown.
- `api/06-runtime-health.md` — owner collegato alla health/runtime boundary; il runbook usa la health come parte dell'orchestrazione senza diventarne l'owner tecnico.
- `docs/validations/local-runtime-hardening-2026-08-10.md` — artifact storico di validation registrato dalla nota di applicazione del report; non costituisce da solo authority sul comportamento corrente.

## Guardrail specifici per questo documento

- Mantenere la natura di runbook operativo dell'avvio, riuso e shutdown dello stack locale.
- Non trasformarlo nel secondo owner tecnico di writer authority, tracking drain, persistence recovery, Python registry o scraper lifecycle.
- Descrivere come i sottosistemi si coordinano a livello operativo, rimandando agli owner specialistici per i dettagli interni.
- Trattare gli stati delle task come informazione storica e verificare nel CODE AUTHORITY il comportamento corrente prima di documentarlo.
- Mantenere distinta la descrizione del contratto corrente dalla provenance di singole validation storiche.
- Non introdurre una nuova suddivisione documentale solo sulla base del precedente audit: la modularizzazione risultava storicamente valutata e non necessaria.

## Informazioni storiche da NON assumere come correnti

- I comportamenti associati a `LOCAL-RUNTIME-001`…`007`, pur risultando storicamente applicati e verificati, devono essere riconfermati sulla CODE AUTHORITY indicata.
- Le descrizioni tecniche del report sono riferite alla baseline documentale/audit precedente e non sostituiscono il codice corrente.
- I conteggi di test o gli esiti di singole validation storiche non costituiscono prova permanente dello stato attuale.
- La struttura e il testo della versione precedente del runbook devono essere recuperati dalla documentation structure baseline soltanto come riferimento di forma.
- Le dipendenze storiche `PY-RUNTIME-*`, `RUNTIME-HEALTH-*`, `ARCH-BOUND-*`, `DATA-LIFE-*` e `JOURNAL-REC-*` citate nel report non devono essere trattate automaticamente come task correnti del documento target.
- Il riferimento storico a un possibile `modules/storage/05-writer-authority.md` non deve essere assunto come documento esistente senza verifica separata.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza individuata tra mappa TODO e JSON sullo stato di `LOCAL-RUNTIME-001`…`007`: tutte risultano completate.
- Il report nasce dall'analisi della documentation structure baseline `4c5f43b007149f3210c27d7565357a447a3a6ef4`, mentre la futura verifica tecnica deve usare la CODE AUTHORITY `12b344ea96e71b2bdaa6931c98419ce925b5c228`.
- Nella parte iniziale del report non risultava individuato un artifact dedicato al “collaudo runtime finale”; la successiva nota di applicazione del 2026-08-10 registra invece la creazione di `docs/validations/local-runtime-hardening-2026-08-10.md`. È un aggiornamento storico successivo, non una divergenza da risolvere.
- Il documento target corrente non è stato fornito tra gli allegati di questa preparazione; la struttura precedente qui riassunta deriva dal report storico e dovrà essere confrontata con la documentation structure baseline dalla chat technical writer.
