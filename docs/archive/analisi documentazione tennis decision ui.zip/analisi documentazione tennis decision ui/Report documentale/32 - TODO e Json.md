TODO:

Report: [`Report documentale/32 - 01-local-runtime.md`](../Report%20documentale/32%20-%2001-local-runtime.md) — `TDUI-DOC-REPORT-032`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`LOCAL-RUNTIME-001`** — priorità `critical` — Rendere il riuso backend working-copy aware usando repository/storage identity opache e bounded condivise con la writer authority; same project ma working copy o storage diversa non deve essere riusato e nessun path raw deve essere esposto.
- [x] **`LOCAL-RUNTIME-002`** — priorità `high` — Separare bounded discovery/reuse da spawn: cercare prima un backend riusabile su tutte le candidate, avviare un child solo se necessario e interrompere la readiness appena il child owned è già terminato.
- [x] **`LOCAL-RUNTIME-003`** — priorità `high` — Definire un contratto CLI stabile per startup, reuse, blocked, backend/frontend failure e shutdown partial; i bootstrap failure reali non devono terminare implicitamente con exit code 0 e il caso launcher già attivo va deciso/testato separatamente.
- [x] **`LOCAL-RUNTIME-004`** — priorità `medium` — Documentare la catena reale della CDP URL: launcher → VITE_CDP_URL → frontend session state → request backend → scraper; non presentarla come configurazione backend globale e coordinare session reuse/provisional con PY-RUNTIME-006.
- [x] **`LOCAL-RUNTIME-005`** — priorità `medium` — Separare service readiness da browser convenience: webbrowser.open è best-effort, un failure deve essere osservabile senza teardown automatico e l'URL frontend effettivo deve restare disponibile.
- [x] **`LOCAL-RUNTIME-006`** — priorità `medium` — Separare contratto corrente e 'collaudo runtime finale': spostare risultati/pass-count in artifact docs/validations con metadata reali, usando 'non registrato' per dati storici mancanti e mantenendo nel runbook solo verification matrix e live-required.
- [x] **`LOCAL-RUNTIME-007`** — priorità `high` — Completare i test launcher con cross-working-copy identity, fallback reusable prima dello spawn, owned child early exit, CLI outcome e browser failure; coordinare i finding PY-RUNTIME esistenti e correggere la docstring app.py stale sull'ordine lock/reuse.

JSON:

    {
      "change_id": "LOCAL-RUNTIME-001",
      "report_id": "TDUI-DOC-REPORT-032",
      "document_path": "docs/tennis-decision-ui/operations/01-local-runtime.md",
      "priority": "critical",
      "type": "local_runtime_service_identity",
      "action": "Rendere il riuso backend working-copy aware usando repository/storage identity opache e bounded condivise con la writer authority; same project ma working copy o storage diversa non deve essere riusato e nessun path raw deve essere esposto.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LOCAL-RUNTIME-002",
      "report_id": "TDUI-DOC-REPORT-032",
      "document_path": "docs/tennis-decision-ui/operations/01-local-runtime.md",
      "priority": "high",
      "type": "launcher_backend_resolution",
      "action": "Separare bounded discovery/reuse da spawn: cercare prima un backend riusabile su tutte le candidate, avviare un child solo se necessario e interrompere la readiness appena il child owned è già terminato.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LOCAL-RUNTIME-003",
      "report_id": "TDUI-DOC-REPORT-032",
      "document_path": "docs/tennis-decision-ui/operations/01-local-runtime.md",
      "priority": "high",
      "type": "launcher_cli_outcome",
      "action": "Definire un contratto CLI stabile per startup, reuse, blocked, backend/frontend failure e shutdown partial; i bootstrap failure reali non devono terminare implicitamente con exit code 0 e il caso launcher già attivo va deciso/testato separatamente.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LOCAL-RUNTIME-004",
      "report_id": "TDUI-DOC-REPORT-032",
      "document_path": "docs/tennis-decision-ui/operations/01-local-runtime.md",
      "priority": "medium",
      "type": "runtime_configuration_provenance",
      "action": "Documentare la catena reale della CDP URL: launcher → VITE_CDP_URL → frontend session state → request backend → scraper; non presentarla come configurazione backend globale e coordinare session reuse/provisional con PY-RUNTIME-006.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LOCAL-RUNTIME-005",
      "report_id": "TDUI-DOC-REPORT-032",
      "document_path": "docs/tennis-decision-ui/operations/01-local-runtime.md",
      "priority": "medium",
      "type": "launcher_user_interface_handoff",
      "action": "Separare service readiness da browser convenience: webbrowser.open è best-effort, un failure deve essere osservabile senza teardown automatico e l'URL frontend effettivo deve restare disponibile.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LOCAL-RUNTIME-006",
      "report_id": "TDUI-DOC-REPORT-032",
      "document_path": "docs/tennis-decision-ui/operations/01-local-runtime.md",
      "priority": "medium",
      "type": "validation_provenance",
      "action": "Separare contratto corrente e 'collaudo runtime finale': spostare risultati/pass-count in artifact docs/validations con metadata reali, usando 'non registrato' per dati storici mancanti e mantenendo nel runbook solo verification matrix e live-required.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LOCAL-RUNTIME-007",
      "report_id": "TDUI-DOC-REPORT-032",
      "document_path": "docs/tennis-decision-ui/operations/01-local-runtime.md",
      "priority": "high",
      "type": "verification_contract",
      "action": "Completare i test launcher con cross-working-copy identity, fallback reusable prima dello spawn, owned child early exit, CLI outcome e browser failure; coordinare i finding PY-RUNTIME esistenti e correggere la docstring app.py stale sull'ordine lock/reuse.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }