TODO:

Report: [`../Report documentale/01 - Readme.md`](../Report%20documentale/01%20-%20Readme.md) — `TDUI-DOC-REPORT-001`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`README-001`** — priorità `low` — Sostituire il requisito generico «versione LTS recente» con una formulazione allineata ai manifest backend e frontend.
- [x] **`README-002`** — priorità `low` — Indicare che `.pending_commits/` e `.writer_authority/` sono sidecar interni a `backend/match_history/`.
- [x] **`README-STYLE-001`** — priorità `editorial` — Sostituire «JSON bounded» con «JSON con output limitato».


JSON:

{
      "change_id": "README-001",
      "document_path": "README.md",
      "report_id": "TDUI-DOC-REPORT-001",
      "report_path": "../Report documentale/01 - Readme.md",
      "priority": "low",
      "type": "documentation_precision",
      "action": "Sostituire il requisito generico «versione LTS recente» con una formulazione allineata ai manifest backend e frontend.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "README-002",
      "document_path": "README.md",
      "report_id": "TDUI-DOC-REPORT-001",
      "report_path": "../Report documentale/01 - Readme.md",
      "priority": "low",
      "type": "path_precision",
      "action": "Indicare che `.pending_commits/` e `.writer_authority/` sono sidecar interni a `backend/match_history/`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "README-STYLE-001",
      "document_path": "README.md",
      "report_id": "TDUI-DOC-REPORT-001",
      "report_path": "../Report documentale/01 - Readme.md",
      "priority": "editorial",
      "type": "language_consistency",
      "action": "Sostituire «JSON bounded» con «JSON con output limitato».",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }