TODO:

Report: [`Report documentale/70 - 07-documentazione-e-normalizzazione.md`](../Report%20documentale/70%20-%2007-documentazione-e-normalizzazione.md) — `TDUI-DOC-REPORT-070`.

Modularizzazione: **valutata, non necessaria**.

- [ ] **`IMPL-DOCNORM-001`** — **HIGH** — Preservare la matrice owner della §24 come checkpoint pre-modularizzazione e aggiungere una overlay dei current owner path dopo lo split dei registri. I facade `02-audit-documentazione.md`, `03-audit-codice.md` e `06-implementazioni-proposte.md` non devono essere presentati come owner current quando le schede vivono nei child; risolvere ogni ID tramite la card owner reale, senza promuovere addenda, rinumerare ID, rifare il dedupe o riaprire `IMPL-032`/`TEST-076…079`.

JSON:

    {
      "change_id": "IMPL-DOCNORM-001",
      "report_id": "TDUI-DOC-REPORT-070",
      "document_path": "implementazioni/implementazioni-proposte/07-documentazione-e-normalizzazione.md",
      "priority": "high",
      "type": "registry_provenance_post_modularization_owner_path_reconciliation",
      "action": "Preservare la matrice owner della §24 come checkpoint pre-modularizzazione e aggiungere una overlay dei current owner path dopo lo split dei registri. I facade `02-audit-documentazione.md`, `03-audit-codice.md` e `06-implementazioni-proposte.md` non devono essere presentati come owner current quando le schede vivono nei child; risolvere ogni ID tramite la card owner reale, senza promuovere addenda, rinumerare ID, rifare il dedupe o riaprire IMPL-032/TEST-076…079.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    }