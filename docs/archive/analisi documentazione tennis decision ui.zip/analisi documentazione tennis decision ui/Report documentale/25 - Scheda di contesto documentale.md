# Scheda di contesto documentale

## Documento target

Percorso:
`docs/tennis-decision-ui/modules/python/02-sofascore-scraper.md`

Tipo di documento:
owner tecnico di modulo Python.

Ruolo documentale:
descrivere l'acquisizione Python dei dati SofaScore, dalla normalizzazione dell'input alla cache breve, al browser persistente e all'emissione del risultato JSON, mantenendo distinti gli owner downstream di tracking, normalizzazione e persistenza.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-040945).txt`
- `25 - Report 02-sofascore-scraper.md` (`TDUI-DOC-REPORT-025`)
- `25 - TODO e Json.md`

## Task storicamente associate

- `SOFA-SCRAPER-001` — stato: completata  
  Argomento coinvolto: authority degli URL HTTPS SofaScore e validazione di host, percorso ed eventId.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `SOFA-SCRAPER-002` — stato: completata  
  Argomento coinvolto: contratto single-event per match URL ed endpoint API.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `SOFA-SCRAPER-003` — stato: completata  
  Argomento coinvolto: identità deterministica della cache tramite SHA-256 delle URL canoniche.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `SOFA-SCRAPER-004` — stato: completata  
  Argomento coinvolto: eleggibilità della cache limitata ai successi completi e trattamento delle entry non utilizzabili.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `SOFA-SCRAPER-005` — stato: completata  
  Argomento coinvolto: gerarchia dei timeout di navigazione, challenge, endpoint, processo Python e parent Node.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `SOFA-SCRAPER-006` — stato: completata  
  Argomento coinvolto: allineamento con il runtime condiviso per stdout, stderr, redazione, limiti di dimensione e lifecycle del child process.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `SOFA-SCRAPER-007` — stato: completata  
  Argomento coinvolto: lifecycle, persistenza, concorrenza e privacy del profilo browser, distinto dalla cache.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `SOFA-SCRAPER-008` — stato: completata  
  Argomento coinvolto: stato machine-readable `challenge_unresolved` alla scadenza del relativo budget.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `SOFA-SCRAPER-009` — stato: completata  
  Argomento coinvolto: contratto uniforme e bounded degli errori Python.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `SOFA-SCRAPER-010` — stato: completata  
  Argomento coinvolto: matrice di verifica Python per URL, cache, output e timeout, con verifiche Node sul lifecycle del subprocess.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata e dichiarata non necessaria: il documento è rimasto owner unitario della pipeline `input → cache → browser → output`.
- Non risultano nuovi documenti canonici creati per separare CLI, cache o browser.
- Il report registra un successivo riallineamento del documento canonico e il completamento delle task `SOFA-SCRAPER-001–010`; il comportamento corrente resta da ricavare dal CODE AUTHORITY.

## Struttura precedente da considerare

- pipeline e responsabilità del package;
- input CLI e URL canoniche;
- cache runtime breve;
- browser persistente e fallback headless/headed;
- timeout e gestione della challenge;
- contratti di stdout, stderr e degli errori;
- confini con il backend downstream;
- verifiche owner Python e Node collegate.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `scraper.py`
- `scrapers/sofa/cli.py`
- `scrapers/sofa/urls.py`
- `scrapers/sofa/browser.py`
- `scrapers/sofa/cache.py`
- `scrapers/sofa/config.py`
- `backend/src/sofa/directFetch.js` e relativi test
- `backend/src/sofa/loadSofaAnalysis.js`
- `backend/src/sofa/trackerUpdate.js`
- test Python del package SofaScore relativi a URL, cache, output e timeout

## Owner/documenti collegati

- `docs/tennis-decision-ui/modules/python/01-entrypoints-and-runtime.md` — owner del runtime Python condiviso, compresi i contratti trasversali di redazione, bounded output e lifecycle del subprocess.
- `docs/tennis-decision-ui/modules/sofa/01-live-tracking.md` — owner del consumo backend dei payload SofaScore e del flusso live downstream.

## Guardrail specifici per questo documento

- Mantenere il focus sull'acquisizione Python SofaScore e sulla pipeline locale `input → cache → browser → output`.
- Non attribuire allo scraper la costruzione di snapshot finale, `localContext`, Source Identity, history, timeline o Evidence.
- Distinguere `backend/scraper_profile/`, profilo browser persistente, da `backend/scraper_cache/`, cache runtime breve.
- Distinguere la convenience CLI basata su match URL dagli endpoint API costruiti dal backend canonico.
- Descrivere timeout, formati di risultato e verifiche soltanto nella forma confermata dal CODE AUTHORITY.
- Conservare il documento unitario, salvo evidenze diverse nella baseline documentale o nel codice corrente.

## Informazioni storiche da NON assumere come correnti

- I finding e le descrizioni del comportamento precedente contenuti nell'audit al commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`.
- Le modifiche proposte, l'ordine di applicazione e la matrice di verifica prevista nel report originario.
- I valori numerici di timeout, dimensione massima dell'output, TTL e percorsi runtime senza riscontro nel CODE AUTHORITY.
- Il solo stato `[x]` delle task come prova sufficiente della forma esatta dell'implementazione corrente.
- Le dipendenze storiche `PY-RUNTIME-002`, `PY-RUNTIME-003`, `IMPL-006` e `SOURCE-ID-001` come istruzioni da rieseguire o come contenuto appartenente automaticamente a questo documento.

## Discrepanze o limiti delle fonti

- Il report documentale fotografa inizialmente il commit della documentation structure baseline e contiene anche un aggiornamento applicativo successivo; non costituisce authority tecnica sul codice corrente.
- La mappa/TODO e il JSON concordano sul completamento di `SOFA-SCRAPER-001–010`; non sono state individuate discrepanze storiche tra i relativi stati.
- Il documento target corrente e il CODE AUTHORITY non sono stati verificati in questa preparazione, come richiesto dal prompt.
