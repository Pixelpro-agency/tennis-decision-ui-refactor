TODO:

Report: [`../Report documentale/18 - 03-quality-flow-and-alignment.md`](../Report%20documentale/18%20-%2003-quality-flow-and-alignment.md) — `TDUI-DOC-REPORT-018`.

Modularizzazione: **valutata, non necessaria**. Qualità, flow e alignment devono restare leggibili insieme per rendere visibili le differenze fra `available`, `fresh`, `reliable`, `aligned` e utilizzabilità cross-source.

- [x] **`QUALITY-FLOW-001`** — priorità `high` — Separati freshness, massima età delle fonti e gap pairwise; fonte mancante non produce più alignment medio.
- [x] **`QUALITY-FLOW-002`** — priorità `high` — Policy clock skew comune a 5 secondi; timestamp futuri oltre tolleranza degradati con reason bounded e test.
- [x] **`QUALITY-FLOW-003`** — priorità `critical` — Predicate Money Flow condiviso basato su `confidence:confirmed`; output suppressed mai reliable e blacklist locale rimossa.
- [x] **`QUALITY-FLOW-004`** — priorità `high` — Predicate ladder condiviso con origine affidabile e ladder non vuota per quality, runner corrente e lookback.
- [x] **`QUALITY-FLOW-005`** — priorità `high` — Documentato il contratto corrente: sotto blocco cross-source resta la quality tecnica raw, mentre `marketEvidence` flow non viene costruito né promosso come diagnostica separata.
- [x] **`QUALITY-FLOW-006`** — priorità `high` — Contratti distinti e nominati: snapshot order 10s e temporal lookback window 30s, con input e semantiche separate.
- [x] **`QUALITY-FLOW-007`** — priorità `high` — Temporal alignment espone `available`, `reliable` e reason basate su freshness, Graph, ladder e book.
- [x] **`QUALITY-FLOW-008`** — priorità `medium` — Centralizzati reason e predicate persistence; rimosso il parametro `integrity` inutilizzato da `buildNoTradeReasons`.
- [x] **`QUALITY-FLOW-009`** — priorità `high` — Predicate book condiviso tra quality, runner flow, runner Evidence e temporal; matrice zero/negativi/crossed/one-sided.
- [x] **`QUALITY-FLOW-010`** — priorità `high` — Creato il test temporal canonico, corretti fixture/signature runnerFlow e aggiunta la matrice completa di regressione.

JSON:

    {
      "change_id": "QUALITY-FLOW-001",
      "report_id": "TDUI-DOC-REPORT-018",
      "document_path": "docs/tennis-decision-ui/modules/evidence/03-quality-flow-and-alignment.md",
      "priority": "high",
      "type": "temporal_semantics",
      "action": "Separare age/freshness da pairwise temporal gap; Correggere `maxTickGapSec`; Non classificare come `medium` un cross-source alignment senza Betfair; Evitare duplicazioni con il temporal alignment vero.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "QUALITY-FLOW-002",
      "report_id": "TDUI-DOC-REPORT-018",
      "document_path": "docs/tennis-decision-ui/modules/evidence/03-quality-flow-and-alignment.md",
      "priority": "high",
      "type": "freshness_validation",
      "action": "Definire clock-skew policy; Non trasformare automaticamente timestamp futuri in age 0; Degradare freshness/alignment oltre la tolleranza approvata; Aggiungere reason e test.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "QUALITY-FLOW-003",
      "report_id": "TDUI-DOC-REPORT-018",
      "document_path": "docs/tennis-decision-ui/modules/evidence/03-quality-flow-and-alignment.md",
      "priority": "critical",
      "type": "data_quality_integrity",
      "action": "Usare `confidence`/predicate del producer; `suppressed` non deve diventare reliable; Eliminare blacklist reason stale; Centralizzare il contratto Money Flow; Testare tutte le suppression reason correnti.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "QUALITY-FLOW-004",
      "report_id": "TDUI-DOC-REPORT-018",
      "document_path": "docs/tennis-decision-ui/modules/evidence/03-quality-flow-and-alignment.md",
      "priority": "high",
      "type": "reliability_contract",
      "action": "Unificare i predicate fra dataQuality e runnerFlow; Decidere esplicitamente il requisito ladder non vuota; Evitare marketFlowSummary reliable mentre ladderReliable è false; Coordinare runner identity con `TECH-SAMPLE-002`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "QUALITY-FLOW-005",
      "report_id": "TDUI-DOC-REPORT-018",
      "document_path": "docs/tennis-decision-ui/modules/evidence/03-quality-flow-and-alignment.md",
      "priority": "high",
      "type": "evidence_scoping",
      "action": "Riallineare testo e composer; Scegliere se marketEvidence flow deve sparire o restare in un blocco diagnostico Betfair-only; Non promuovere diagnostica raw a cross-source Evidence.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "QUALITY-FLOW-006",
      "report_id": "TDUI-DOC-REPORT-018",
      "document_path": "docs/tennis-decision-ui/modules/evidence/03-quality-flow-and-alignment.md",
      "priority": "high",
      "type": "temporal_alignment_contract",
      "action": "Gestire 10s vs 30s; Gestire input marker/move differenti; Consolidare oppure rinominare i due contratti; Documentare una sola authority per ciascuna semantica.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "QUALITY-FLOW-007",
      "report_id": "TDUI-DOC-REPORT-018",
      "document_path": "docs/tennis-decision-ui/modules/evidence/03-quality-flow-and-alignment.md",
      "priority": "high",
      "type": "temporal_quality_gating",
      "action": "Distinguere `available` da `reliable`; Decidere il ruolo di freshness/Graph/ladder/book; Non usare relation stale/degradata come Evidence favorevole; Aggiungere reason quality-specific.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "QUALITY-FLOW-008",
      "report_id": "TDUI-DOC-REPORT-018",
      "document_path": "docs/tennis-decision-ui/modules/evidence/03-quality-flow-and-alignment.md",
      "priority": "medium",
      "type": "reason_ownership",
      "action": "Eliminare o usare davvero il parametro `integrity` di `buildNoTradeReasons`; Centralizzare reason/code persistence; Mantenere deduplica deterministica.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "QUALITY-FLOW-009",
      "report_id": "TDUI-DOC-REPORT-018",
      "document_path": "docs/tennis-decision-ui/modules/evidence/03-quality-flow-and-alignment.md",
      "priority": "high",
      "type": "market_quality_consistency",
      "action": "Condividere `bestBack > 0 && bestLay > 0 && bestLay > bestBack`; Riallineare runnerFlow, runnerEvidence e temporal alignment; Testare zero/negativi/crossed/one-sided.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "QUALITY-FLOW-010",
      "report_id": "TDUI-DOC-REPORT-018",
      "document_path": "docs/tennis-decision-ui/modules/evidence/03-quality-flow-and-alignment.md",
      "priority": "high",
      "type": "test_contract",
      "action": "Correggere il path test temporal inesistente; Correggere la signature nel runnerFlow test; Usare trend producer-compatible; Coprire future timestamps, suppressed flow, empty ladder, dual windows e book predicate.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }