# Scheda di contesto documentale

## Documento target

Percorso:
`implementazioni/06-implementazioni-proposte.md`

Tipo di documento:
facade / indice corrente delle schede `IMPL-001…032`.

Ruolo documentale:
fornire navigazione verso i moduli tematici e una sintesi dello stato, senza duplicare le schede owner, i contratti tecnici, i test o la cronologia estesa.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `Report documentale/50 - 06-implementazioni-proposte.md` — `TDUI-DOC-REPORT-050`.
- Sezione TODO e JSON associata al documento target.

## Task storicamente associate

- `IMPL-IDX-001` — stato: completata.
  Argomento coinvolto: allineamento storico delle sintesi delle implementazioni concluse nel facade e nel registro root, con riferimento a `IMPL-004`.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente e documentarlo soltanto entro il ruolo di indice/sintesi del documento.

## Cambiamenti strutturali storicamente rilevanti

- Il precedente contenuto monolitico è stato distribuito in sette moduli tematici; il documento target è rimasto come facade leggero.
- Un successivo riallineamento ha ridotto il facade alla forma corrente: titolo, descrizione del ruolo, tabella dei moduli, stato sintetico e regole minime.
- Il range storico delle schede indicizzate copre `IMPL-001…032` senza rinumerazioni; i checkpoint successivi citati nel modulo 07 non costituiscono un ulteriore range owner.
- La fonte storica indica che non è stata ritenuta necessaria un'ulteriore modularizzazione.

## Struttura precedente da considerare

- Tabella di navigazione verso i sette moduli tematici.
- Sintesi distinta tra implementazioni completate e implementazioni future o condizionate.
- Regole minime sul rapporto tra facade, schede owner e stato sintetico.
- Assenza di schede owner complete, contratti tecnici, test, payload e cronologia estesa nel facade.
- I dettagli tecnici della migrazione del precedente monolite risultano storici e non parte della forma corrente.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `implementazioni/06-implementazioni-proposte.md`.
- `implementazioni/implementazioni-proposte/01-utility-e-autorita-base.md`.
- `implementazioni/implementazioni-proposte/02-runtime-betfair.md`.
- `implementazioni/implementazioni-proposte/03-storage-recovery.md`.
- `implementazioni/implementazioni-proposte/04-evidence-provenance.md`.
- `implementazioni/implementazioni-proposte/05-frontend-session-polling.md`.
- `implementazioni/implementazioni-proposte/06-validazione-e-fixture.md`.
- `implementazioni/implementazioni-proposte/07-documentazione-e-normalizzazione.md`.
- `implementazioni-tennis-decision-ui.md` e `todo-list-tennis-decision-ui.md`, limitatamente alla sintesi dello stato e ai confini di authority.

## Owner/documenti collegati

- I sette moduli in `implementazioni/implementazioni-proposte/` contengono le schede owner; il documento target ne offre soltanto la navigazione e la sintesi.
- `todo-list-tennis-decision-ui.md` rappresenta la fonte storicamente indicata per lo stato sintetico globale.
- `implementazioni-tennis-decision-ui.md` è il registro root collegato alla sintesi delle implementazioni concluse.
- `implementazioni/99-decisioni-utente.md` contiene le decisioni utente richiamate dalle schede; non è sostituito dal facade.
- `docs/validations/README.md` delimita le evidenze di validazione rispetto ai documenti owner.

## Guardrail specifici per questo documento

- Conservare la natura di facade/indice leggero.
- Non trasformare il documento in un secondo owner delle schede `IMPL-*`.
- Non duplicare dettagli tecnici, test, payload o cronologie già appartenenti ai moduli.
- Trattare classificazioni e approvazioni separatamente dallo stato di implementazione verificato.
- Preservare gli ID e i range delle schede senza rinumerazioni.
- Verificare le sintesi nel CODE AUTHORITY senza assumere che gli elenchi storici siano ancora correnti.

## Informazioni storiche da NON assumere come correnti

- Il contenuto delle liste storiche delle implementazioni completate, future o condizionate.
- Gli stati delle singole schede `IMPL-*` descritti nel report di audit.
- La permanenza di `DEC-013` o di qualsiasi altra decisione nel medesimo stato.
- La presenza e la struttura corrente di `docs/validations/`.
- I conteggi di righe, byte, blob e gli altri dettagli della modularizzazione originaria.
- Le valutazioni, le priorità e i finding del report storico.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza tra la sezione TODO e il JSON forniti: entrambi associano `IMPL-IDX-001` al documento target e la indicano come completata.
- Il report è riferito alla documentation structure baseline e non costituisce authority sul contenuto corrente del CODE AUTHORITY.
- Le fonti fornite non includono il documento target corrente né i moduli alla baseline tecnica; forma e stato effettivi devono quindi essere verificati successivamente nel CODE AUTHORITY.
