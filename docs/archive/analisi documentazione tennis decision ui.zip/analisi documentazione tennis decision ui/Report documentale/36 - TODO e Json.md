TODO:

Report: [`Report documentale/36 - 05-retention-and-cleanup.md`](../Report%20documentale/36%20-%2005-retention-and-cleanup.md) — `TDUI-DOC-REPORT-036`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`RETENTION-001`** — priorità `medium` — Documentare che `max-files` e `max-total-bytes` sono valutati per ciascuna cache selezionata; non trasformare la CLI in un global-cap senza decisione e migrazione esplicita.
- [x] **`RETENTION-002`** — priorità `high` — Documentare il best-effort per-file dell'apply: `exit 1` può coesistere con removals già eseguite; obbligare la lettura di `removed/errors/recoveredBytes` e valutare uno stato strutturato `partial`.
- [ ] **`RETENTION-003`** — priorità `high` — Definire una procedura project-owned per backup restore/audit con snapshot boundary coerente fra più artefatti; `IMPL-011` può essere un building block solo dopo decisione esplicita sullo scope.

JSON:

    {
      "change_id": "RETENTION-001",
      "report_id": "TDUI-DOC-REPORT-036",
      "document_path": "docs/tennis-decision-ui/operations/05-retention-and-cleanup.md",
      "priority": "medium",
      "type": "retention_cap_scope",
      "action": "Documentare che `max-files` e `max-total-bytes` sono valutati per ciascuna cache selezionata; non trasformare la CLI in un global-cap senza decisione e migrazione esplicita.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "RETENTION-002",
      "report_id": "TDUI-DOC-REPORT-036",
      "document_path": "docs/tennis-decision-ui/operations/05-retention-and-cleanup.md",
      "priority": "high",
      "type": "partial_apply_outcome",
      "action": "Documentare il best-effort per-file dell'apply: `exit 1` può coesistere con removals già eseguite; obbligare la lettura di `removed/errors/recoveredBytes` e valutare uno stato strutturato `partial`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "RETENTION-003",
      "report_id": "TDUI-DOC-REPORT-036",
      "document_path": "docs/tennis-decision-ui/operations/05-retention-and-cleanup.md",
      "priority": "high",
      "type": "backup_snapshot_consistency",
      "action": "Definire una procedura project-owned per backup restore/audit con snapshot boundary coerente fra più artefatti; IMPL-011 può essere un building block solo dopo decisione esplicita sullo scope.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    }