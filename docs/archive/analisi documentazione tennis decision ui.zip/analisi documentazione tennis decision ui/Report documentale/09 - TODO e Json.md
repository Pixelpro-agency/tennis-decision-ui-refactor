TODO:

Report: [`../Report documentale/09 - 05-preflight.md`](../Report%20documentale/09%20-%2005-preflight.md) — `TDUI-DOC-REPORT-009`.

Modularizzazione: **valutata, non necessaria**. I cinque endpoint appartengono alla stessa responsabilità di preflight locale e diagnostico; il documento deve essere accorciato e riallineato agli owner esistenti, senza creare nuovi file.

- [x] **`PREFLIGHT-API-001`** — priorità `high` — Probe CDP bounded con utility condivisa, timeout, abort e reason code distinti per timeout e unreachable; test dedicati aggiunti.
- [x] **`PREFLIGHT-API-002`** — priorità `high` — Introdotto validator SofaScore canonico con HTTPS, host consentiti, event ID e reason bounded; rimosso il logging dell’input raw.
- [x] **`PREFLIGHT-API-003`** — priorità `critical` — Applicato `DEC-020`: validator Betfair unico usato da Preflight, Start, login e `/odds`, con protocollo, host, credenziali, porta, normalizzazione ed event ID coerenti.
- [x] **`PREFLIGHT-API-004`** — priorità `critical` — Applicato `DEC-020`: preflight Graph allineato al parser Python per HTTPS, host, credenziali, porta, path `/0`, `sameMarket` e duplicati.
- [x] **`PREFLIGHT-API-005`** — priorità `high` — Dichiarato esplicitamente che i check Preflight frontend sono advisory e non costituiscono un gate obbligatorio di `Link Accounts & Start`; un gate futuro richiede una decisione dedicata.
- [x] **`PREFLIGHT-API-006`** — priorità `medium` — Inventariati i consumer, rimosso `/api/test/health` e aggiornati i riferimenti correnti a `/api/health`, unica authority Health.
- [x] **`PREFLIGHT-API-007`** — priorità `high` — Completata la contract coverage per CDP, SofaScore, Betfair, Graph, consumer Betfair e comportamento frontend Persistent/CDP advisory.
- [x] **`PREFLIGHT-API-008`** — priorità `medium` — Corretto il mojibake Preflight e sostituita l’esposizione di errori, URL e snippet raw con messaggi bounded.
- [x] **`PREFLIGHT-API-009`** — priorità `medium` — Riscritto e rinominato `04-preflight.md` in forma più compatta, mantenendolo unico owner API, riducendo duplicazioni Graph/Health e documentando authority, limiti correnti, boundedness, stato advisory e verifica effettiva.

JSON:

    {
      "change_id": "PREFLIGHT-API-001",
      "report_id": "TDUI-DOC-REPORT-009",
      "document_path": "docs/tennis-decision-ui/api/04-preflight.md",
      "priority": "high",
      "type": "cdp_probe_boundedness",
      "action": "Rendere bounded il probe CDP con timeout e abort tramite utility condivisa, mantenendo la validazione loopback e aggiungendo test timeout/unreachable.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PREFLIGHT-API-002",
      "report_id": "TDUI-DOC-REPORT-009",
      "document_path": "docs/tennis-decision-ui/api/04-preflight.md",
      "priority": "high",
      "type": "sofascore_url_authority",
      "action": "Distinguere estrazione event ID da validazione SofaScore, valutare un validator canonico condiviso e rimuovere logging raw e authority duplicate.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PREFLIGHT-API-003",
      "report_id": "TDUI-DOC-REPORT-009",
      "document_path": "docs/tennis-decision-ui/api/04-preflight.md",
      "priority": "critical",
      "type": "betfair_url_validator_authority",
      "action": "Applicare DEC-020 introducendo un validator Betfair unico per preflight, Start, login e future diagnostiche.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PREFLIGHT-API-004",
      "report_id": "TDUI-DOC-REPORT-009",
      "document_path": "docs/tennis-decision-ui/api/04-preflight.md",
      "priority": "critical",
      "type": "graph_preflight_runtime_parity",
      "action": "Applicare DEC-020 rendendo la grammatica e la semantica del preflight Graph coerenti con il parser runtime Python.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PREFLIGHT-API-005",
      "report_id": "TDUI-DOC-REPORT-009",
      "document_path": "docs/tennis-decision-ui/api/04-preflight.md",
      "priority": "high",
      "type": "preflight_advisory_semantics",
      "action": "Dichiarare esplicitamente che i check Preflight frontend sono advisory e non costituiscono oggi un gate obbligatorio di Start.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PREFLIGHT-API-006",
      "report_id": "TDUI-DOC-REPORT-009",
      "document_path": "docs/tennis-decision-ui/api/04-preflight.md",
      "priority": "medium",
      "type": "duplicate_health_surface",
      "action": "Inventariare i consumer di /api/test/health e rimuoverlo se inutilizzato, mantenendo /api/health come authority.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PREFLIGHT-API-007",
      "report_id": "TDUI-DOC-REPORT-009",
      "document_path": "docs/tennis-decision-ui/api/04-preflight.md",
      "priority": "high",
      "type": "preflight_contract_test_coverage",
      "action": "Completare la coverage automatica per health, CDP, SofaScore, Betfair, Graph e comportamento frontend advisory.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PREFLIGHT-API-008",
      "report_id": "TDUI-DOC-REPORT-009",
      "document_path": "docs/tennis-decision-ui/api/04-preflight.md",
      "priority": "medium",
      "type": "frontend_message_boundedness",
      "action": "Correggere il mojibake e impedire che snippet o messaggi tecnici raw siano mostrati direttamente nella UI Preflight.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PREFLIGHT-API-009",
      "report_id": "TDUI-DOC-REPORT-009",
      "document_path": "docs/tennis-decision-ui/api/04-preflight.md",
      "priority": "medium",
      "type": "document_rewrite_without_split",
      "action": "Riscrivere e rinominare 04-preflight.md in forma più compatta senza modularizzarlo, riducendo duplicazioni e aggiungendo authority, boundedness e verifica.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }