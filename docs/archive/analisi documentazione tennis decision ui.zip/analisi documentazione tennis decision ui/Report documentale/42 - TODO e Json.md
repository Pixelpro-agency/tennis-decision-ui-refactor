TODO:

Report: [`Report documentale/42 - source-identity-live-verification.md`](../Report%20documentale/42%20-%20source-identity-live-verification.md) — `TDUI-DOC-REPORT-042`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`SOURCE-ID-VAL-001`** — priorità `high` — Correggere `Sorgente migrata` self-reference usando la fonte storica `docs/tennis-decision-ui/operations/06-source-identity-live-verification.mdx`, senza inventare SHA o ambiente.
- [x] **`SOURCE-ID-VAL-002`** — priorità `high` — Ripristinare la fidelity storica: `Sofa: In attesa` era soltanto historically reported; `no polling error` e il `404` erano unchecked; rendere inoltre esplicita la route osservata `/api/match/:eventId/json → 200` per `Sofa: Connected`.
- [x] **`SOURCE-ID-VAL-003`** — priorità `medium` — Completare `Interpretazione` con gli scenari live non eseguiti del body, inclusi plausible pending, mismatch/no-modal, modal privacy, single-toast e bootstrap failure, senza promuovere i test offline a live evidence.

JSON:

    {
      "change_id": "SOURCE-ID-VAL-001",
      "report_id": "TDUI-DOC-REPORT-042",
      "document_path": "docs/validations/source-identity-live-verification.md",
      "priority": "high",
      "type": "historical_source_provenance",
      "action": "Correggere `Sorgente migrata` self-reference usando la fonte storica `docs/tennis-decision-ui/operations/06-source-identity-live-verification.mdx`, senza inventare SHA o ambiente.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOURCE-ID-VAL-002",
      "report_id": "TDUI-DOC-REPORT-042",
      "document_path": "docs/validations/source-identity-live-verification.md",
      "priority": "high",
      "type": "historical_migration_fidelity",
      "action": "Ripristinare la fidelity storica: `Sofa: In attesa` era soltanto historically reported; `no polling error` e il `404` erano unchecked; rendere inoltre esplicita la route osservata `/api/match/:eventId/json → 200` per `Sofa: Connected`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "SOURCE-ID-VAL-003",
      "report_id": "TDUI-DOC-REPORT-042",
      "document_path": "docs/validations/source-identity-live-verification.md",
      "priority": "medium",
      "type": "historical_scenario_summary_completeness",
      "action": "Completare `Interpretazione` con gli scenari live non eseguiti del body, inclusi plausible pending, mismatch/no-modal, modal privacy, single-toast e bootstrap failure, senza promuovere i test offline a live evidence.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }