# Scheda di contesto documentale

## Documento target

Percorso:
`docs/tennis-decision-ui/api/01-match.md`

Tipo di documento:
API / facade del router Match.

Ruolo documentale:
Contratto HTTP del router Match montato sotto `/api/match`. Il report storico lo identifica esplicitamente come «contratto HTTP del router Match» e registra nove endpoint appartenenti alle aree di lettura/integrity, tracking/Source Identity e analisi/snapshot.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

Queste baseline sono quelle assegnate alla successiva attività di technical writing; il materiale storico allegato non sostituisce il CODE AUTHORITY.

## Fonti storiche consultate

* `05 - TODO e Json.md` — associa il documento al report `TDUI-DOC-REPORT-005`, registra otto task `MATCH-API-*` e il relativo stato storico.
* `05 - Report 01-match.md` — report documentale `TDUI-DOC-REPORT-005`, riferito alla documentation structure baseline `4c5f43b007149f3210c27d7565357a447a3a6ef4`.

## Task storicamente associate

* `MATCH-API-001` — stato: completata.
  Argomento coinvolto: superficie `GET /api/match/debug-last` e relativo contratto/deprecazione.
  Uso consentito: verificare nel CODE AUTHORITY quale superficie e comportamento risultino correnti.

* `MATCH-API-002` — stato: completata.
  Argomento coinvolto: contratto pubblico di `integrity.reason`, in particolare stato di persistenza parziale e recovery.
  Uso consentito: verificare i valori correnti prodotti dall'authority prima di documentarli.

* `MATCH-API-003` — stato: completata.
  Argomento coinvolto: shape HTTP della history e relazione fra `metadata`, dati history e `integrity`.
  Uso consentito: verificare la shape pubblica corrente.

* `MATCH-API-004` — stato: completata.
  Argomento coinvolto: shape HTTP della timeline, normalizzazione in lettura, campo derivato `latest` e distinzione dalla forma persistita.
  Uso consentito: verificare la vista HTTP corrente e il relativo confine con la persistenza.

* `MATCH-API-005` — stato: completata.
  Argomento coinvolto: semantica delle letture non riuscite e distinzione o eventuale collasso fra risorsa assente, errore di lettura e JSON non valido.
  Uso consentito: verificare quale contratto sia effettivamente presente nel CODE AUTHORITY.

* `MATCH-API-006` — stato: completata.
  Argomento coinvolto: contratto `track/untrack`, validazione degli input, `betfairMode` e comportamento di Untrack.
  Uso consentito: verificare input, errori, fallback e no-op effettivamente correnti.

* `MATCH-API-007` — stato: completata.
  Argomento coinvolto: contratto pubblico degli errori di `POST /analyze` e relativo confine di redazione.
  Uso consentito: verificare il mapping degli errori corrente.

* `MATCH-API-008` — stato: completata.
  Argomento coinvolto: ruolo di `01-match.md` come facade, possibile separazione in owner specifici, indice/link e sezione di verifica.
  Uso consentito: verificare la struttura documentale realmente presente prima di assumere che la modularizzazione sia stata materialmente applicata.

Markdown e JSON concordano sullo stato `completed` delle otto task.

## Cambiamenti strutturali storicamente rilevanti

Il materiale storico associa a `MATCH-API-008` una separazione per responsabilità mantenendo `01-match.md` come facade e individuando tre possibili owner:

* `docs/tennis-decision-ui/api/match/01-read-and-integrity.md`
* `docs/tennis-decision-ui/api/match/02-tracking-and-source-identity.md`
* `docs/tennis-decision-ui/api/match/03-analysis-and-snapshot.md`

Le tre responsabilità individuate erano: letture/integrity, tracking/Source Identity e analisi/snapshot.

Le fonti allegate **non sono sufficienti per attestare autonomamente che i tre file siano stati realmente creati nello stato corrente**: il TODO definisce la modularizzazione come “richiesta” e i file come “proposti”, mentre `MATCH-API-008` risulta storicamente completata.

## Struttura precedente da considerare

La versione analizzata dal report era un singolo documento di 583 righe contenente il contratto complessivo del router, con nove endpoint e tre responsabilità principali.
Elementi strutturali storicamente rilevanti:

* scopo e mount del router;
* struttura dei relativi helper;
* tabella completa degli endpoint;
* contratti di lettura e integrity;
* tracking e Source Identity;
* analisi e snapshot;
* riferimenti/verifica dei test;
* collegamenti ai documenti owner del progetto.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente. La forma corrente non deve essere ricostruita automaticamente dal report storico.

## Aree da verificare nel CODE AUTHORITY

* `backend/src/server.js`
* `backend/src/routes/match.js`
* `backend/src/routes/match/readResponses.js`
* `backend/src/routes/match/trackingResponses.js`
* `backend/src/routes/match/analysisResponse.js`
* `backend/src/routes/match/sourceIdentityStatusResponse.js`
* `backend/src/sofa/matchHistory.js` e area persistence/integrity direttamente usata dalle letture
* `backend/src/sofa/matchTracker.js` e Source Identity Gate
* `backend/src/sofa/buildSofaAnalysis.js`, `normalizeSnapshot.js` e `localContext.js`
* relativi test route/persistence effettivamente presenti nella baseline

Queste sono le principali aree che il report storico aveva usato per confrontare il contratto documentale con il runtime.

## Owner/documenti collegati

Possibili owner specifici da verificare nella documentation structure corrente:

* `docs/tennis-decision-ui/api/match/01-read-and-integrity.md` — area letture HTTP e integrity;
* `docs/tennis-decision-ui/api/match/02-tracking-and-source-identity.md` — area tracking, Source Identity e stop;
* `docs/tennis-decision-ui/api/match/03-analysis-and-snapshot.md` — area analisi SofaScore e snapshot.

Nel disegno storico, `01-match.md` avrebbe dovuto conservare la visione complessiva del router e delegare i dettagli ai tre owner.

Il report segnala inoltre collegamenti documentali verso architettura, lifecycle dati, tracking live, local context/point-by-point, storage, recovery, Source Identity, polling frontend e validazione; i percorsi correnti vanno recuperati dalla struttura documentale effettiva, non dedotti dal report.

## Guardrail specifici per questo documento

* Conservare il ruolo di contratto/facade HTTP del router Match; non trasformarlo in documento di implementazione interna.
* Verificare gli endpoint e i payload nel CODE AUTHORITY prima di riportare comportamenti tecnici.
* Se esistono i tre owner modulari, evitare duplicazione dettagliata dei loro contratti nella facade.
* Distinguere, dove ancora pertinente, risposta HTTP, dati derivati in lettura e documento persistito.
* Le task `MATCH-API-*` servono come indice storico degli argomenti da controllare, non come istruzioni da rieseguire.
* Non reintrodurre finding, priorità, decisioni progettuali o proposte di refactoring contenute nel report storico.
* Verificare l'esistenza effettiva dei test e dei percorsi prima di mantenere comandi di verifica; il report storico aveva già rilevato che non tutti i path precedentemente documentati esistevano.

## Informazioni storiche da NON assumere come correnti

Non assumere dalla sola fonte storica:

* che `debug-last` esista ancora o conservi il comportamento analizzato;
* quali siano oggi i valori ammessi o prodotti da `integrity.reason`;
* quale sia la shape corrente di history e timeline;
* se `latest` sia ancora derivato in lettura;
* se missing, read failure e JSON invalido siano ancora collassati nello stesso risultato;
* quale sia oggi la validazione di `track`, `untrack` e `betfairMode`;
* quale mapping pubblico degli errori utilizzi oggi `/analyze`;
* che i test indicati dal vecchio documento esistano ancora agli stessi path;
* che la modularizzazione nei tre documenti owner sia realmente presente soltanto perché `MATCH-API-008` risulta completata.

Il report descriveva uno stato precedente e le relative modifiche proposte; alcune riguardavano soltanto la documentazione, altre potevano coinvolgere il runtime.

## Discrepanze o limiti delle fonti

`DISCREPANZA STORICA DA NON RISOLVERE AUTOMATICAMENTE`

* `MATCH-API-008` risulta `[x]` / `completed`, ma la stessa fonte descrive la modularizzazione come **richiesta** e i tre nuovi documenti come **file proposti**. Le fonti allegate non includono un report di applicazione/verifica che dimostri direttamente la creazione dei tre owner.
* Il report di audit stesso presentava la suddivisione come struttura proposta e dichiarava che le mappe non erano state aggiornate durante quell'analisi.
* Non è stato fornito in questo blocco il documento `01-match.md` corrente né un report successivo di applicazione; pertanto nessun dettaglio tecnico del report storico deve essere trattato come authority dello stato attuale.
