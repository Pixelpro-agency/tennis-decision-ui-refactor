# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/ai/02-documentation-conventions.md`

Tipo di documento:  
documento metodologico / owner delle convenzioni della documentazione tecnica.

Ruolo documentale:  
definire le convenzioni per scrivere, collocare, aggiornare e verificare la documentazione tecnica del progetto, mantenendo separati ownership, stato reale, validazioni storiche, materiale non canonico e procedure documentali.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`
- `03 - TODO e Json.md`
- `03 - Report 02-documentation-conventions.md`
- report associato: `TDUI-DOC-REPORT-003`

## Task storicamente associate

- `DOC-CONV-001` — stato: completata  
  Argomento coinvolto: ruolo documentale di `docs/archive/` come area non canonica preservata, non owner e non prova di implementazione.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `DOC-CONV-002` — stato: completata  
  Argomento coinvolto: terminologia relativa al caso in cui non esiste un documento owner canonico e superamento della precedente formulazione legata alla migrazione.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `DOC-CONV-003` — stato: completata  
  Argomento coinvolto: policy corrente di conservazione di `docs/archive/` ed esclusione dalle pulizie automatiche o generiche.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `DOC-CONV-004` — stato: completata  
  Argomento coinvolto: conclusione della migrazione MDX → Markdown, procedura corrente per le modifiche documentali e collegamento con il workflow esecutivo.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- Modularizzazione valutata e non ritenuta necessaria.
- Il documento è rimasto un unico owner delle convenzioni documentali.
- Non risultano nuovi documenti canonici creati come conseguenza delle task associate.
- La precedente sezione dedicata alla migrazione MDX è stata storicamente ricondotta a una procedura generale per le modifiche documentali.
- Il collegamento con `03-workflow-esecutivo.md` è storicamente associato all'aggiornamento della procedura documentale.

## Struttura precedente da considerare

La struttura precedente comprendeva nello stesso documento:

- scopo e responsabilità;
- radici documentali;
- formato dei documenti canonici;
- aree canoniche;
- regola di un owner per responsabilità;
- dimensione e criteri di suddivisione;
- stati documentali consentiti;
- fatti tecnici;
- rapporto tra modifiche al codice e documentazione;
- link;
- validazioni storiche;
- materiale non canonico e archivio;
- segreti e dati locali;
- coerenza dei registri;
- procedura per modifiche documentali;
- checklist di chiusura;
- documenti collegati.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `README.md`
- `docs/tennis-decision-ui/index.md`
- `docs/tennis-decision-ui/ai/01-context-selection.md`
- `docs/tennis-decision-ui/ai/03-workflow-esecutivo.md`
- `docs/tennis-decision-ui/reference/01-repository-map.md`
- `docs/tennis-decision-ui/operations/05-retention-and-cleanup.md`
- `scripts/check_documentation_links.py`
- `scripts/check_registry_consistency.py`
- policy e stato corrente di `docs/archive/`

## Owner/documenti collegati

- `docs/tennis-decision-ui/index.md` — indice canonico e confini generali della documentazione tecnica.
- `docs/tennis-decision-ui/ai/01-context-selection.md` — selezione del contesto documentale per le attività AI.
- `docs/tennis-decision-ui/ai/03-workflow-esecutivo.md` — workflow esecutivo e criteri di chiusura collegati alle modifiche documentali.
- `docs/tennis-decision-ui/reference/01-repository-map.md` — riferimento alla struttura del repository.
- `docs/tennis-decision-ui/operations/05-retention-and-cleanup.md` — confine con le procedure di cleanup runtime e con il materiale documentale da preservare.
- `docs/validations/` — sede delle verifiche e dei collaudi storici, distinta dalla documentazione tecnica canonica.

## Guardrail specifici per questo documento

- Mantenere il documento nel ruolo di owner delle convenzioni documentali.
- Non trasformarlo in un audit, backlog, registro di finding o piano di implementazione.
- Non trattare `docs/archive/` come documentazione tecnica canonica, owner tecnico o prova di implementazione.
- Distinguere sempre la policy documentale corrente dalle validazioni e dai record storici.
- Non descrivere proposte o decisioni future come comportamento già implementato.
- Conservare il principio di un solo documento owner per responsabilità.
- Non imporre una suddivisione del documento soltanto per la sua lunghezza.
- Mantenere distinti checker documentali, validazioni storiche, materiale non canonico e codice/runtime.
- Non introdurre una seconda radice canonica o una nuova fase di migrazione MDX salvo evidenza corrente nel CODE AUTHORITY.

## Informazioni storiche da NON assumere come correnti

- La precedente policy secondo cui `docs/archive/` doveva essere svuotato o rimosso dopo il consolidamento.
- La formula relativa a un “owner non ancora migrato”.
- L'esistenza di una fase attiva di migrazione MDX → Markdown.
- Le priorità assegnate ai finding nel report storico.
- Le sostituzioni testuali e le formulazioni proposte dal report come se fossero automaticamente il testo corrente.
- I controlli elencati nel report come “previsti” non devono essere considerati eseguiti soltanto perché compaiono nel report.
- Le osservazioni su altri documenti o decisioni storiche non autorizzano modifiche fuori dal documento target.

## Discrepanze o limiti delle fonti

- Il report documentale descrive lo stato analizzato al commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`, mentre il technical writer successivo dovrà verificare il comportamento e la struttura correnti rispetto al CODE AUTHORITY `12b344ea96e71b2bdaa6931c98419ce925b5c228`.
- Il report contiene finding, priorità, testi sostitutivi e controlli proposti che costituiscono materiale storico di audit e non authority tecnica corrente.
- TODO e JSON concordano sullo stato completato di `DOC-CONV-001`, `DOC-CONV-002`, `DOC-CONV-003` e `DOC-CONV-004`.
- Nessuna discrepanza storica rilevante tra TODO e JSON è stata individuata per stato e associazione delle quattro task.
