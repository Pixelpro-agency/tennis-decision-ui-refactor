TODO:

Report: [`Report documentale/65 - 02-runtime-betfair.md`](../Report%20documentale/65%20-%2002-runtime-betfair.md) — `TDUI-DOC-REPORT-065`.

Modularizzazione: **valutata, non necessaria**.

- [ ] **`IMPL-BETFAIR-001`** — **HIGH** — Normalizzare il dependency graph di `IMPL-016…018` distinguendo hard prerequisites, supporting tools, validation/test dependencies, downstream consumers e future dependencies; chiarire in particolare che `IMPL-002` non è implicitamente bloccante per `IMPL-017` salvo decisione esplicita e definire il verso delle relazioni `IMPL-018↔IMPL-012/013` senza introdurre cicli.

JSON:

    {
      "change_id": "IMPL-BETFAIR-001",
      "report_id": "TDUI-DOC-REPORT-065",
      "document_path": "implementazioni/implementazioni-proposte/02-runtime-betfair.md",
      "priority": "high",
      "type": "dependency_metadata_implementation_sequencing",
      "action": "Normalizzare il dependency graph di IMPL-016…018 distinguendo hard prerequisites, supporting tools, validation/test dependencies, downstream consumers e future dependencies; chiarire in particolare che IMPL-002 non è implicitamente bloccante per IMPL-017 salvo decisione esplicita e definire il verso delle relazioni IMPL-018↔IMPL-012/013 senza introdurre cicli.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    }