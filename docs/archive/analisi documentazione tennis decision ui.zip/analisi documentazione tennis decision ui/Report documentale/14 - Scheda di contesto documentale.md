# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/modules/betfair/01-scraper-lifecycle.md`

Tipo di documento:  
owner tecnico del lifecycle Node/Python dello scraper Betfair.

Ruolo documentale:  
descrivere il lifecycle dello scraper Betfair e i suoi confini applicativi principali, con particolare riferimento a spawn, deduplica, runtime identity, terminazione, login, restore e confine di persistenza differita. Il documento deve restare focalizzato sul contratto del lifecycle, evitando di assorbire responsabilità proprie di owner specialistici, runbook o validation storiche.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`
- `14 - Report 01-scraper-lifecycle.md` — `TDUI-DOC-REPORT-014`
- `14 - TODO e Json.md`

## Task storicamente associate

- `BETFAIR-LIFE-001` — stato: completata  
  Argomento coinvolto: deduplica per scraper key URL e runtime identity, distinta dalla market authority.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-LIFE-002` — stato: completata  
  Argomento coinvolto: tracking session authority, riuso della Promise e callback stale tra sessioni.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-LIFE-003` — stato: completata  
  Argomento coinvolto: semantica di `profileDir` nella runtime identity Persistent.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-LIFE-004` — stato: completata  
  Argomento coinvolto: distinzione tra `executionToken`, Python generation e tracking session authority.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-LIFE-005` — stato: completata  
  Argomento coinvolto: lifecycle su Source Identity mismatch e gestione di callback SofaScore già in volo.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-LIFE-006` — stato: completata  
  Argomento coinvolto: rimozione del consumer legacy `/api/betfair/odds` e dei relativi helper/test dedicati.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-LIFE-007` — stato: completata  
  Argomento coinvolto: separazione tra normalizzazione di `scraperKey()` e validazione backend-owned di protocollo/host Betfair.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-LIFE-008` — stato: completata  
  Argomento coinvolto: confine read-only e probe diagnostico CDP di `/latest`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-LIFE-009` — stato: completata  
  Argomento coinvolto: policy cache del tracking canonico e uso di `noCache` / `--no-cache`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-LIFE-010` — stato: completata  
  Argomento coinvolto: boundedness dell'output del child process, gestione stdout/stderr e overflow.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-LIFE-011` — stato: completata  
  Argomento coinvolto: contratto di verifica del lifecycle e riallineamento dei test al runner corrente.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `BETFAIR-LIFE-012` — stato: completata  
  Argomento coinvolto: separazione del collaudo storico dal documento owner.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata e non ritenuta necessaria: il documento resta un singolo owner del lifecycle Betfair.
- Non risultano nuovi owner canonici creati a seguito del report.
- Il blocco storico `Stato Task 2` risulta rimosso dall'owner, mantenendo separata l'evidenza di collaudo storico.
- Il consumer legacy `/api/betfair/odds` risulta rimosso insieme agli helper e ai test dedicati.
- Le modifiche storicamente registrate hanno interessato anche session authority, cache del tracking, bounded output del child process e verifica del runner.

## Struttura precedente da considerare

- lifecycle fisico dei processi Python;
- spawn e ownership del child process;
- deduplica e runtime identity;
- timeout e terminazione;
- separazione tra lifecycle tracking e login;
- restore dei runner;
- confine di persistenza differita;
- network capture e cache come temi confinanti;
- verification del lifecycle.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

Il documento non deve essere trasformato in owner di storage, retention/cache generale, validità tecnica dei campioni o risultati storici di collaudo.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/betfairFetch.js`
- `backend/src/sofa/betfair/url.js`
- `backend/src/sofa/betfair/scraperLifecycle.js`
- `backend/src/sofa/betfair/scraperLifecycle/runner.js`
- `backend/src/sofa/betfair/scraperLifecycle.test.mjs`
- `backend/src/sofa/betfair/trackerUpdate.js`
- `backend/src/sofa/matchTracker.js`
- `backend/src/runtime/pythonProcessRegistry.js`
- `backend/src/routes/betfair.js`
- `backend/src/routes/betfair/loginWindowLifecycle.js`
- `backend/src/utils/cdpUrl.js`
- `scrapers/betfair/cli.py`
- `scrapers/betfair/cache.py`

## Owner/documenti collegati

- `02-technical-sample-validity.md` — owner collegato per la validità tecnica dei campioni; il percorso completo va confermato nella struttura documentale corrente.
- owner storage — relazione esplicita nel report per i dettagli di persistenza/storage; il report non fornisce qui un percorso univoco.
- runbook relativo a cache/retention — relazione esplicita nel report; il percorso va confermato nella struttura documentale corrente.
- `docs/validations/betfair-live-validation-2026-07-04.md` — validation storica citata dal report; non costituisce prova di PASS corrente.
- `docs/tennis-decision-ui/ai/02-documentation-conventions.md` — convenzioni documentali usate come riferimento storico.
- owner API Betfair — collegato storicamente alla rimozione di `/api/betfair/odds` e al confine delle route; il percorso va verificato nella struttura documentale corrente.

## Guardrail specifici per questo documento

- Mantenere il file come owner del lifecycle Betfair, senza introdurre una nuova suddivisione solo per separare spawn, deduplica, runtime identity, terminazione, login o restore.
- Non trasferire nel documento risultati di collaudo storico come prova di stato corrente.
- Non duplicare dettagli già posseduti dagli owner storage o dal runbook cache/retention.
- Non trasformare il documento in owner della validità tecnica dei campioni.
- Tenere distinti lifecycle tracking, lifecycle login e altre eventuali authority applicative, documentando soltanto quanto risulta dal CODE AUTHORITY.
- Usare le task completate come indice delle aree da ricontrollare, non come descrizione automatica del comportamento corrente.

## Informazioni storiche da NON assumere come correnti

- Le descrizioni tecniche del report `TDUI-DOC-REPORT-014` derivano dalla precedente baseline documentale/codice analizzata e non sono authority per il commit corrente.
- Finding, priorità, target, ordine di applicazione e test proposti nel report non devono essere trasferiti come istruzioni.
- I comportamenti descritti nel report prima del completamento di `BETFAIR-LIFE-001..012` non devono essere considerati ancora presenti senza verifica nel CODE AUTHORITY.
- Il collaudo storico citato nel vecchio blocco `Stato Task 2` non prova un PASS corrente.
- I riferimenti storici a `IMPL-006`, `IMPL-016`, `RUNTIME-*`, `BETFAIR-API-*`, `DOC-025`, `PREFLIGHT-API-003`, `DEC-020` e altri ID collegati servono solo a ricostruire il contesto storico; il loro stato corrente non va dedotto da questa scheda.

## Discrepanze o limiti delle fonti

- Il report è stato prodotto sulla baseline `4c5f43b007149f3210c27d7565357a447a3a6ef4`, mentre la successiva verifica tecnica dovrà usare il CODE AUTHORITY `12b344ea96e71b2bdaa6931c98419ce925b5c228`.
- Il report contiene un riepilogo che indica `Modifiche proposte: 10`, ma registra esplicitamente i Change ID `BETFAIR-LIFE-001..012`; il TODO/JSON riporta dodici task, tutte completate. Questa incongruenza storica non va usata per dedurre task mancanti.
- Il TODO/JSON registra lo stato storico di completamento, ma non sostituisce la verifica del comportamento corrente nel CODE AUTHORITY.
- Alcuni owner collegati sono indicati dal report per ruolo ma senza percorso documentale completo; tali percorsi vanno confermati nella struttura corrente.
