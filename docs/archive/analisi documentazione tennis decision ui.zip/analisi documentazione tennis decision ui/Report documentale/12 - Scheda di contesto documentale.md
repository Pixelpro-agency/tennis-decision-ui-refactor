# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/architecture/02-data-lifecycle.md`

Tipo di documento:  
architettura / lifecycle end-to-end.

Ruolo documentale:  
owner del ciclo di vita end-to-end dei dati. Il documento rappresenta il percorso complessivo attraverso acquisizione, autorizzazione, persistenza, lettura, Evidence e frontend, mantenendo i dettagli algoritmici negli owner specialistici.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `Report documentale/12 - 02-data-lifecycle.md` — `TDUI-DOC-REPORT-012`, relativo alla precedente baseline documentale.
- `12 - TODO e Json.md` — registro successivo delle task `DATA-LIFE-001..009`, tutte marcate storicamente completate.

## Task storicamente associate

- `DATA-LIFE-001` — stato: completata  
  Argomento coinvolto: ordine bootstrap, listener readiness e registrazione degli shutdown handler.  
  Uso consentito: verificare nel CODE AUTHORITY l'ordine corrente pertinente.

- `DATA-LIFE-002` — stato: completata  
  Argomento coinvolto: distinzione tra Stop live, shutdown terminale e operazioni Node già in-flight; relazione storica con `IMPL-006`.  
  Uso consentito: verificare nel CODE AUTHORITY il lifecycle corrente di Stop/Start e drain.

- `DATA-LIFE-003` — stato: completata  
  Argomento coinvolto: separazione tra scrape success, commit success, canonical tick e significato di `lastSuccessfulScrapeAt`.  
  Uso consentito: verificare nel CODE AUTHORITY la semantica runtime Betfair corrente.

- `DATA-LIFE-004` — stato: completata  
  Argomento coinvolto: manual confirmation, bootstrap e consistenza del record persistito; la fonte storica più recente registra una rollback compensativa in caso di bootstrap fallito.  
  Uso consentito: verificare nel CODE AUTHORITY il comportamento effettivamente corrente.

- `DATA-LIFE-005` — stato: completata  
  Argomento coinvolto: semantica Graph status-only, timeline, history, `seq` e `commitId`.  
  Uso consentito: verificare nel CODE AUTHORITY il comportamento corrente del tick status-only.

- `DATA-LIFE-006` — stato: completata  
  Argomento coinvolto: distinzione tra letture persistite, letture in memoria e probe diagnostici bounded.  
  Uso consentito: verificare nel CODE AUTHORITY quali letture possono ancora produrre I/O diagnostico.

- `DATA-LIFE-007` — stato: completata  
  Argomento coinvolto: provenance temporale dell'acquisizione Betfair.  
  Uso consentito: verificare lo stato corrente senza assumere `IMPL-018` come implementata; la fonte storica la mantiene come target non implementato.

- `DATA-LIFE-008` — stato: completata  
  Argomento coinvolto: lifecycle dei poller frontend, protezioni locali e coordinamento con Stop.  
  Uso consentito: verificare nel CODE AUTHORITY le protezioni e il coordinamento correnti; il riferimento storico a `IMPL-006` non prova da solo lo stato attuale dell'implementazione.

- `DATA-LIFE-009` — stato: completata  
  Argomento coinvolto: ownership documentale, riduzione delle duplicazioni e matrice stage/owner/evidenza.  
  Uso consentito: verificare nel documento e nel CODE AUTHORITY quali owner ed evidenze siano ancora correnti.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata e non ritenuta necessaria; il documento deve restare un unico lifecycle end-to-end, senza nuovi file dedicati ai singoli stage.
- Storicamente sono state ridotte duplicazioni con gli owner specialistici ed è stata aggiunta una matrice `stage → owner → evidenza`.

## Struttura precedente da considerare

- percorso unico end-to-end attraverso i principali layer del dato;
- distinzione tra bootstrap, acquisizione/tracking, Source Identity, persistenza, letture/Evidence, frontend e shutdown;
- collegamento agli owner specialistici invece della duplicazione dei loro algoritmi;
- matrice sintetica `stage → owner → evidenza`, storicamente introdotta con `DATA-LIFE-009`.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/server.js`
- `backend/src/sofa/matchTracker.js`
- `backend/src/sofa/trackerUpdate.js`
- `backend/src/sofa/betfair/trackerUpdate.js`
- `backend/src/sofa/betfair/processor.js` e relativi moduli di persistenza/timeline
- `backend/src/sofa/sourceIdentityGate.js`
- `backend/src/sofa/sourceIdentityGate/manualConfirmation.js`
- `backend/src/sofa/matchEvidence/latestMatchEvidence.js`
- `backend/src/sofa/betfairHealth.js` e `backend/src/routes/betfair/cdpStatus.js`
- `frontend/src/hooks/useMatchPolling.js`, `useBetfairJson.js`, `useMarketReactionEvidence.js`, `useSourceIdentityGateStatus.js`

## Owner/documenti collegati

- `docs/tennis-decision-ui/architecture/01-system-boundaries.md` — collegato ai confini architetturali richiamati nel report.
- Owner specialistici di writer authority/recovery, Source Identity, persistenza, API Match/Betfair/Evidence, frontend polling e shutdown — il lifecycle deve descrivere soprattutto ordine, handoff e relazioni tra questi domini, senza diventarne un secondo owner.

## Guardrail specifici per questo documento

- Mantenere la natura di lifecycle end-to-end e non trasformare il file in una raccolta di algoritmi specialistici.
- Non creare documenti separati per bootstrap, tracking, persistence o read lifecycle sulla sola base del materiale storico.
- Distinguere chiaramente concetti appartenenti a layer diversi, in particolare acquisition/runtime, persistenza, integrity, Source Identity, Evidence e frontend.
- Conservare il confine fra descrizione del comportamento corrente e target/proposte storiche.
- Usare gli owner specialistici come riferimento per i dettagli, riportando nel lifecycle principalmente ordine, handoff, invarianti e punti di degradazione.

## Informazioni storiche da NON assumere come correnti

- `IMPL-006` non deve essere assunta come implementata soltanto perché collegata storicamente a `DATA-LIFE-002` e `DATA-LIFE-008`.
- `IMPL-018` risultava esplicitamente un target approvato ma non implementato nella fonte storica; il suo stato deve essere verificato nel CODE AUTHORITY.
- Il comportamento della manual confirmation descritto nel report originario precede il completamento di `DATA-LIFE-004`: il report registrava persistenza prima del bootstrap senza rollback, mentre il registro successivo dichiara applicata una rollback compensativa. Lo stato corrente deve quindi essere ricavato dal CODE AUTHORITY.
- Finding, priorità, ordine di applicazione, proposte tecniche e test elencati nel report sono materiale storico di audit e non istruzioni per il technical writer.

## Discrepanze o limiti delle fonti

- Il report documentale fotografa la precedente baseline `4c5f43b007149f3210c27d7565357a447a3a6ef4`, mentre il technical writer dovrà usare come authority tecnica `12b344ea96e71b2bdaa6931c98419ce925b5c228`; il report non dimostra quindi lo stato corrente del codice.
- Il registro TODO/JSON conferma storicamente tutte le task `DATA-LIFE-001..009` come completate, ma non sostituisce la verifica del comportamento corrente nel CODE AUTHORITY.
- Il documento corrente `02-data-lifecycle.md` e il codice della CODE AUTHORITY non fanno parte delle fonti fornite in questa fase; struttura e semantica correnti non devono essere dedotte automaticamente dal materiale storico.
