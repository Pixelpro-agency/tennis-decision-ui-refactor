# Scheda di contesto documentale

## Documento target

Percorso:
`implementazioni/04-task-completate.md`

Tipo di documento:
registro storico di ricontrollo e ricertificazione delle task D1–D18.

Ruolo documentale:
conservare gli esiti del ricontrollo svolto sulla baseline storica `b277bd9b7373dfd8702e65446c88bab7a0f64dcc`, distinguendoli dallo stato corrente eventualmente determinato da verifiche successive. Il documento non è owner delle implementazioni tecniche richiamate.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `Report documentale/48 - 04-task-completate.md` — `TDUI-DOC-REPORT-048`.
- `48 - TODO e Json.md` — mappa sintetica e record JSON delle task associate.

## Task storicamente associate

- `TASK-RECHECK-001` — stato: completata  
  Argomento coinvolto: distinzione tra il ricontrollo storico D1–D18 sulla baseline `b277bd9` e lo stato corrente delle task.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `TASK-RECHECK-002` — stato: completata  
  Argomento coinvolto: rappresentazione dello stato corrente D1–D18 mediante un livello distinto dagli esiti storici, con riferimenti agli owner tecnici già esistenti.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- È stata resa esplicita la separazione semantica tra checkpoint storico e stato corrente.
- È stato previsto un collegamento o livello di stato corrente senza riscrivere retroattivamente gli esiti del checkpoint.
- La modularizzazione è stata valutata e non ritenuta necessaria: il documento conserva una responsabilità unitaria come snapshot della campagna D1–D18.
- Non risultano nuovi documenti canonici creati per questa revisione.

## Struttura precedente da considerare

- Baseline storica dichiarata in apertura.
- Distinzione tra test presenti e suite non rieseguite.
- Analisi delle task D1–D18 come unica campagna di ricontrollo.
- Classificazione degli esiti storici e conteggi associati.
- Separazione tra risultato storico, limiti osservati e owner tecnici esterni.
- Ordine tecnico e strutture mancanti presentati come elementi del checkpoint, non come coda operativa corrente.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `implementazioni/04-task-completate.md` e la relativa rappresentazione di historical result, current status e baseline.
- `todo-list-tennis-decision-ui.md`, limitatamente al collegamento con lo stato corrente D1–D18.
- `implementazioni/README.md`, limitatamente ai riferimenti al registro e alla sua natura storica.
- `frontend/src/App.jsx`, per gli aspetti D2 e D14 richiamati dal registro.
- `backend/src/routes/match/trackingResponses.js`, per gli aspetti D10 richiamati dal registro.
- `backend/src/sofa/betfair/processor/runnerProcessing.js`, per gli aspetti D5 richiamati dal registro.
- Domini direttamente richiamati per D6, D9, D11–D13, D16 e D18: Graph URL, runtime locale, timeline/history, commit journal/recovery, local context/PBP e retention; i percorsi esatti sono da ricavare dagli owner correnti.

## Owner/documenti collegati

- `implementazioni/03-audit-codice.md` — fonte di collegamento agli owner tecnici, senza trasferirne la responsabilità nel registro storico.
- `implementazioni/audit-codice/02-runtime-sessioni-betfair.md` — owner collegato agli aspetti runtime, sessione e controllo live.
- `implementazioni/audit-codice/03-storage-recovery.md` — owner collegato a timeline/history, journal, integrità e recovery.
- `implementazioni/audit-codice/07-post-audit-e-migrazione.md` — contesto successivo utile a distinguere checkpoint e stato corrente.
- `todo-list-tennis-decision-ui.md` — rappresentazione operativa dello stato corrente, distinta dagli esiti storici conservati nel documento target.

## Guardrail specifici per questo documento

- Conservare la natura di registro storico unitario D1–D18; non trasformarlo in owner tecnico dei singoli domini.
- Tenere separati il risultato del ricontrollo sulla baseline `b277bd9` e lo stato corrente verificato sul CODE AUTHORITY.
- Non interpretare la presenza di file di test come prova di una nuova esecuzione delle suite.
- Non presentare conteggi, ordine tecnico o strutture mancanti del checkpoint come fotografia automatica dello stato corrente.
- Non duplicare finding o responsabilità appartenenti ai documenti owner collegati.
- Non imporre una suddivisione per dominio: la valutazione storica della modularizzazione ha mantenuto un solo documento.

## Informazioni storiche da NON assumere come correnti

- Gli esiti e i conteggi D1–D18 derivati dal checkpoint `b277bd9`.
- La qualificazione storica secondo cui soltanto D14 e D17 risultavano da riaprire.
- L'elenco delle strutture mancanti registrate durante quel ricontrollo.
- L'ordine tecnico emerso nella campagna storica.
- Qualsiasi stato delle task ricavato esclusivamente dagli audit successivi citati nel report, senza riscontro nel CODE AUTHORITY.
- Qualsiasi affermazione di test superati: nel ricontrollo storico le suite non risultavano rieseguite.

## Discrepanze o limiti delle fonti

- Markdown e JSON concordano su associazione, stato completato e report delle task `TASK-RECHECK-001` e `TASK-RECHECK-002`; nessuna discrepanza storica individuata.
- Il report è materiale storico e non costituisce authority tecnica sul comportamento corrente.
- Il documento target corrente non è tra le fonti fornite; forma e struttura precedenti dovranno essere recuperate dalla Documentation structure baseline.
