TODO:

Report: [`Report documentale/38 - 01-current-state.md`](../Report%20documentale/38%20-%2001-current-state.md) — `TDUI-DOC-REPORT-038`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`CURRENT-STATE-001`** — priorità `high` — Separare code/runtime baseline da document/repository baseline e dichiarare quale SHA/content state supporta ogni claim del Current State.
- [x] **`CURRENT-STATE-002`** — priorità `medium` — Rimuovere o aggiornare il riferimento a `docs/archive/README.md` assente; identificare l’authority corrente della provenance senza ricreare automaticamente il file.
- [x] **`CURRENT-STATE-003`** — priorità `high` — Rendere artifact-backed l’inventario delle historical validations; launcher/Stop/lifecycle non vanno attribuiti a `docs/validations/` senza artifact o link verificabile.

JSON:

    {
      "change_id": "CURRENT-STATE-001",
      "report_id": "TDUI-DOC-REPORT-038",
      "document_path": "docs/tennis-decision-ui/roadmap/01-current-state.md",
      "priority": "high",
      "type": "current_state_provenance",
      "action": "Separare code/runtime baseline da document/repository baseline e dichiarare quale SHA/content state supporta ogni claim del Current State.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "CURRENT-STATE-002",
      "report_id": "TDUI-DOC-REPORT-038",
      "document_path": "docs/tennis-decision-ui/roadmap/01-current-state.md",
      "priority": "medium",
      "type": "stale_reference_provenance_owner",
      "action": "Rimuovere o aggiornare il riferimento a `docs/archive/README.md` assente e identificare l’authority corrente della provenance senza ricreare automaticamente il file.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "CURRENT-STATE-003",
      "report_id": "TDUI-DOC-REPORT-038",
      "document_path": "docs/tennis-decision-ui/roadmap/01-current-state.md",
      "priority": "high",
      "type": "validation_provenance_aggregation",
      "action": "Rendere artifact-backed l’inventario delle historical validations; launcher/Stop/lifecycle non vanno attribuiti a `docs/validations/` senza artifact o link verificabile.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }