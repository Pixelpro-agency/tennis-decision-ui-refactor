TODO:

Report: [`Report documentale/50 - 06-implementazioni-proposte.md`](../Report%20documentale/50%20-%2006-implementazioni-proposte.md) — `TDUI-DOC-REPORT-050`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`IMPL-IDX-001`** — **HIGH** — Riallineare le summary delle implementazioni concluse a owner e Todo aggiungendo `IMPL-004` nel facade e nel root registry; mantenere invariati owner, Todo e `DEC-013`, non promuovere le IMPL ancora aperte e preservare il next step `DA SELEZIONARE`.

JSON:

    {
      "change_id": "IMPL-IDX-001",
      "report_id": "TDUI-DOC-REPORT-050",
      "document_path": "implementazioni/06-implementazioni-proposte.md",
      "priority": "high",
      "type": "implementation_registry_summary_divergence",
      "action": "Riallineare le summary delle implementazioni concluse a owner e Todo aggiungendo `IMPL-004` nel facade e nel root registry; mantenere invariati owner, Todo e `DEC-013`, non promuovere le IMPL ancora aperte e preservare il next step `DA SELEZIONARE`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }