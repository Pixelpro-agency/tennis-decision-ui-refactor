# Scheda di contesto documentale

## Documento target

Percorso:
`implementazioni/99-decisioni-utente.md`

Tipo di documento:
registro delle decisioni strutturali dell'utente.

Ruolo documentale:
conservare le decisioni che incidono su più aree, task o documenti, registrandone scelta, confini ed eventuale supersession. Non è una Todo, un registro di implementazione o validazione, né un changelog Git.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-231739).txt`
- `51 - Report 99-decisioni-utente.md` — `TDUI-DOC-REPORT-051`
- `51 - TODO e Json.md` — estratto della mappa; la sezione JSON non contiene dati nel materiale fornito

## Task storicamente associate

- `IMPL-004` — stato: completata. Argomento coinvolto: separazione dei collaudi approfonditi dagli owner tecnici e collocazione delle evidenze in `docs/validations/`. Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `IMPL-015` — stato: completata. Argomento coinvolto: singola authority di scrittura backend. Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente, senza trasformare lo stato della decisione collegata in stato d'implementazione.
- `IMPL-029`, `IMPL-030`, `IMPL-031` — stato: non completata. Argomento coinvolto: sistema di validazione, fixture e baseline approvato da `DEC-024`. Uso consentito: non assumerne come corrente l'implementazione; verificare nel CODE AUTHORITY soltanto ciò che risulta realmente presente.
- `IMPL-032` — stato: completata. Argomento coinvolto: migrazione dei nuovi documenti al formato Markdown. Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `ROOT-REG-001` — stato: ambiguo. Argomento coinvolto: relazione tra la policy corrente di conservazione di `docs/archive/` e la decisione storica `DEC-026`. Uso consentito: verificare lo stato corrente nelle fonti autorevoli senza assumere applicata una supersession.
- `METHOD-SCHEMA-001` — stato: ambiguo. Argomento coinvolto: separazione tra stato della decisione e stato della sua applicazione, inclusi i riferimenti di supersession. Uso consentito: verificare l'eventuale schema corrente senza uniformare retroattivamente le decisioni storiche.
- `METHOD-EVIDENCE-001` — stato: ambiguo. Argomento coinvolto: distinzione tra implementazione, verifica offline, verifica live e provenienza. Uso consentito: preservare il confine del registro rispetto alle evidenze di validazione.
- `METHOD-REG-001` — stato: ambiguo. Argomento coinvolto: contratto del registry checker. Uso consentito: verificare soltanto le relazioni documentali correnti pertinenti al registro.

## Cambiamenti strutturali storicamente rilevanti

- Il registro comprende una sequenza continua `DEC-001…DEC-026` e mantiene una sola responsabilità documentale; la modularizzazione è stata valutata e non ritenuta necessaria.
- `DEC-015` è conservata come decisione storica ed è indicata come superata da `DEC-026`.
- Le decisioni più recenti, in particolare `DEC-019…DEC-025`, adottano una forma ricorrente con stato, regole, confini, strutture e relazioni.
- La migrazione collegata a `IMPL-032` ha consolidato l'uso di Markdown per i nuovi documenti.

## Struttura precedente da considerare

- Sequenza identificativa continua delle decisioni.
- Per ogni decisione: scelta, confini, relazioni pertinenti ed eventuale supersession.
- Distinzione tra approvazione della decisione e completamento dell'implementazione.
- Conservazione delle decisioni superate come record storico esplicitamente collegato alla decisione successiva.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `implementazioni/99-decisioni-utente.md`, per contenuto corrente, intervallo degli ID e catene di supersession.
- `implementazioni/00-metodo-e-stati.md`, per lo schema corrente degli stati e i confini tra decisione, applicazione ed evidenza.
- `implementazioni/04-task-completate.md` e `implementazioni/06-implementazioni-proposte.md`, per distinguere le decisioni dagli stati esecutivi collegati.
- `todo-list-tennis-decision-ui.md` e `implementazioni-tennis-decision-ui.md`, per gli owner e gli stati correnti richiamati dal registro.
- `docs/validations/README.md`, per confermare il confine tra decision log ed evidenze di collaudo.
- `docs/archive/` e relativi riferimenti canonici, limitatamente alla policy corrente richiamata in relazione a `DEC-026`.

## Owner/documenti collegati

- `implementazioni/00-metodo-e-stati.md` — owner metodologico degli stati e delle categorie documentali.
- `implementazioni/04-task-completate.md` — registra attività completate senza trasferirne lo stato alle decisioni.
- `implementazioni/06-implementazioni-proposte.md` — registra proposte e stati applicativi separatamente dal decision log.
- `todo-list-tennis-decision-ui.md` — conserva task e relativi stati; una decisione approvata non equivale a una task completata.
- `docs/validations/README.md` — delimita l'area delle evidenze di validazione, che non appartengono al registro delle decisioni.

## Guardrail specifici per questo documento

- Mantenere il documento come unica decision authority dell'utente, senza convertirlo in Todo, implementation ledger, validation ledger o changelog Git.
- Documentare una decisione come scelta approvata senza inferirne l'avvenuta implementazione.
- Preservare le decisioni storiche e rappresentare le sostituzioni mediante supersession esplicita, senza riscrittura retroattiva.
- Non attribuire date, provenienza o stati non registrati nelle fonti autorevoli.
- Mantenere i confini dichiarati su assenza di strategie, segnali operativi, fair odds, suggerimenti di trade, intenzioni attribuite ai trader e causalità dichiarata.
- Evitare una normalizzazione puramente estetica dell'intero intervallo `DEC-001…DEC-026`.

## Informazioni storiche da NON assumere come correnti

- L'approvazione di una DEC non prova che la relativa implementazione sia presente o completata.
- Gli ordini e i “next step” contenuti nelle decisioni descrivono il checkpoint storico in cui furono registrati.
- La policy di cleanup descritta da `DEC-026` non rappresenta automaticamente l'attuale trattamento di `docs/archive/`.
- I diversi status testuali presenti nelle decisioni storiche non costituiscono automaticamente uno schema corrente uniforme.
- Le soglie, i target e le strutture approvate nelle decisioni future o rinviate non devono essere descritti come comportamento operativo senza riscontro nel CODE AUTHORITY.
- Il momento del commit Git non equivale al momento in cui l'utente ha preso una decisione.

## Discrepanze o limiti delle fonti

- Il report storico segnala che una policy successiva consente la conservazione intenzionale di materiali non canonici in `docs/archive/`, mentre `DEC-026` riflette il precedente checkpoint di cleanup. La divergenza non va risolta automaticamente.
- `DISCREPANZA STORICA DA NON RISOLVERE AUTOMATICAMENTE`: nel materiale fornito, la sezione Markdown dichiara che non vi sono nuove task e richiama owner già esistenti, mentre la sezione JSON è vuota; non è quindi possibile svolgere un confronto Markdown–JSON né confermare da JSON gli stati delle task associate.
- Gli stati di `ROOT-REG-001`, `METHOD-SCHEMA-001`, `METHOD-EVIDENCE-001` e `METHOD-REG-001` non sono determinati in modo sufficiente dalle fonti fornite.
