TODO:

Report: [`Report documentale/40 - betfair-live-validation-2026-07-04.md`](../Report%20documentale/40%20-%20betfair-live-validation-2026-07-04.md) — `TDUI-DOC-REPORT-040`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`BETFAIR-VAL-001`** — priorità `high` — Correggere `Sorgente migrata` self-reference usando il path storico `docs/tennis-decision-ui/operations/07-betfair-live-validation.mdx`, senza inventare SHA o ambiente.
- [x] **`BETFAIR-VAL-002`** — priorità `high` — Confrontare source e artifact migrato; ripristinare o classificare l’osservazione unica `/api/match/:eventId/json = 200 → Sofa: Connected`, distinguendo safe wording/privacy da material evidence omission.
- [x] **`BETFAIR-VAL-003`** — priorità `medium` — Aggiungere `Mismatch marketId → non eseguito` alla tabella `Interpretazione` per non perdere uno scenario aperto già dichiarato nel body.

JSON:

    {
      "change_id": "BETFAIR-VAL-001",
      "report_id": "TDUI-DOC-REPORT-040",
      "document_path": "docs/validations/betfair-live-validation-2026-07-04.md",
      "priority": "high",
      "type": "historical_source_provenance",
      "action": "Correggere `Sorgente migrata` self-reference usando il path storico `docs/tennis-decision-ui/operations/07-betfair-live-validation.mdx`, senza inventare SHA o ambiente.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-VAL-002",
      "report_id": "TDUI-DOC-REPORT-040",
      "document_path": "docs/validations/betfair-live-validation-2026-07-04.md",
      "priority": "high",
      "type": "historical_migration_fidelity",
      "action": "Confrontare source e artifact migrato; ripristinare o classificare l’osservazione unica `/api/match/:eventId/json = 200 → Sofa: Connected`, distinguendo safe wording/privacy da material evidence omission.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-VAL-003",
      "report_id": "TDUI-DOC-REPORT-040",
      "document_path": "docs/validations/betfair-live-validation-2026-07-04.md",
      "priority": "medium",
      "type": "historical_scenario_summary_completeness",
      "action": "Aggiungere `Mismatch marketId → non eseguito` alla tabella `Interpretazione` per non perdere uno scenario aperto già dichiarato nel body.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }