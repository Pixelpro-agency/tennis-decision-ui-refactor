# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/00-metodo-e-stati.md`

Tipo di documento:  
Documento metodologico / registro operativo non canonico.

Ruolo documentale:  
Descrivere il metodo operativo della revisione: workflow, stati, evidenze, ownership dei registri e criteri di verifica. La documentazione tecnica corrente in `docs/` resta owner dei comportamenti runtime, delle API e dei contratti applicativi.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `Report documentale/44 - 00-metodo-e-stati.md` — `TDUI-DOC-REPORT-044`
- Sezione TODO e ledger JSON associati al report 044

## Task storicamente associate

- `METHOD-EVIDENCE-001` — stato: completata  
  Argomento coinvolto: distinzione fra lifecycle del workflow, stato dell’implementazione, verifica offline, verifica live e provenienza dell’evidenza.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `METHOD-REG-001` — stato: completata  
  Argomento coinvolto: contratto documentato del registry checker, scope degli owner, parità dei registri, vocabolario degli stati e limiti delle verifiche automatiche.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `METHOD-LIFECYCLE-001` — stato: completata  
  Argomento coinvolto: distinzione fra regole operative permanenti e procedure storiche di migrazione o planning.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `METHOD-SCHEMA-001` — stato: completata  
  Argomento coinvolto: schema minimo delle owner card per tipo di record e trattamento delle schede storiche.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- Modularizzazione valutata e dichiarata non necessaria.
- Nessun nuovo documento canonico associato alle quattro task.
- Le modifiche risultano applicate nello stesso documento target.
- Le fonti indicano il passaggio da istruzioni transitorie di migrazione a un metodo operativo stabile.
- Gli snapshot storici non risultano riscritti retroattivamente.

## Struttura precedente da considerare

- Dichiarazione del documento come registro operativo non canonico.
- Separazione fra Todo sintetico e metodo esteso.
- Baseline storica della revisione.
- Gerarchia generale delle fonti e delle prove.
- Lifecycle degli stati.
- Regole operative: una task verificabile per volta, massimo tre tentativi, test mirati e report finale.
- Confine Git sotto controllo dell’utente.
- Regole su owner unici, registri e checker.
- Distinzione fra fonti correnti e materiale storico.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `implementazioni/00-metodo-e-stati.md`
- `scripts/check_registry_consistency.py`
- `scripts/tests/test_check_registry_consistency.py`
- Struttura corrente delle owner card sotto `implementazioni/**/*.md`
- Righe sintetiche correnti dei registri Todo collegate al checker

## Owner/documenti collegati

- `implementazioni-tennis-decision-ui.md` — registro radice e quadro sintetico.
- `todo-list-tennis-decision-ui.md` — stato sintetico delle attività.
- `implementazioni/README.md` — struttura e confini dell’area `implementazioni`.
- `implementazioni/01-piano-generale-audit.md` — pianificazione dell’audit, distinta dal metodo operativo.
- `implementazioni/05-audit-docs-planning.md` — riferimento storico sul ciclo di planning.
- `implementazioni/06-implementazioni-proposte.md` — owner delle schede IMPL.
- `implementazioni/99-decisioni-utente.md` — owner delle decisioni dell’utente.
- `implementazioni/audit-documentazione/01-rilievi-iniziali-e-api.md` — esempio di owner card documentale.
- `implementazioni/implementazioni-proposte/01-utility-e-autorita-base.md` — contesto storico del registry checker.

## Guardrail specifici per questo documento

- Mantenere il carattere metodologico e non canonico.
- Non trasformarlo in documentazione tecnica di runtime, API, storage o frontend.
- Non confondere stato del workflow, stato dell’implementazione ed evidenza di verifica.
- Non presentare un report storico come prova automatica del comportamento corrente.
- Non attribuire al registry checker controlli ulteriori rispetto a quelli verificati nel CODE AUTHORITY.
- Conservare la distinzione fra regole correnti e procedure storiche concluse.
- Mantenere la forma unitaria del documento, salvo diversa evidenza nella baseline corrente.

## Informazioni storiche da NON assumere come correnti

- Commit e baseline tecniche citati nel report 044.
- Finding, giudizi, priorità e proposte formulati durante l’audit.
- Descrizioni del registry checker precedenti al completamento di `METHOD-REG-001`.
- Formulazioni sulla migrazione MDX o sull’analisi del planning come attività future.
- Schemi, pseudo-strutture e matrici presentati nel report come soluzioni proposte.
- La presenza di un test o di un report storico come prova di una verifica corrente.
- L’esito storico delle task come descrizione sufficiente del contenuto attuale.

## Discrepanze o limiti delle fonti

- Markdown e JSON concordano su associazione, stato completato e metadata delle quattro task.
- Il materiale fornito conferma il completamento storico, ma non sostituisce la verifica del contenuto corrente nella CODE AUTHORITY.
- Non è stato fornito un report applicativo dettagliato separato; l’esito di applicazione è registrato sinteticamente in chiusura del report 044.
