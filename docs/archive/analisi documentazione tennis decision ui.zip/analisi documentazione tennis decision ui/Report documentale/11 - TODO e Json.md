TODO:

Report: [`../Report documentale/11 - 01-system-boundaries.md`](../Report%20documentale/11%20-%2001-system-boundaries.md) — `TDUI-DOC-REPORT-011`.

Modularizzazione: **valutata, non necessaria**. Il documento è già l’owner corretto della mappa dei confini; richiede una revisione mirata per distinguere stato corrente, target approvati e legacy, senza creare nuovi documenti.

- [x] **`ARCH-BOUND-001`** — priorità `high` — Ripristinato l’invariante frontend `/api`: rimosso con `CODE-001` il consumer Strategy con URL backend hard-coded e aggiornata la mappa dei confini allo stato corrente.
- [x] **`ARCH-BOUND-002`** — priorità `critical` — Applicato e documentato `IMPL-017`: bind loopback, Host e Origin locali, richieste diagnostiche senza Origin e rifiuto bounded dei target remoti.
- [x] **`ARCH-BOUND-003`** — priorità `high` — Separate le authority Betfair scraper e login con key/runtime identity, portata e limiti; `IMPL-016` resta approvata ma non implementata.
- [x] **`ARCH-BOUND-004`** — priorità `high` — Aggiunta la matrice corrente/approvato per launcher, writer authority, Source Identity, tracking session, Betfair command authority e confine HTTP locale.
- [x] **`ARCH-BOUND-005`** — priorità `medium` — Separati gli owner Tracking e Source Identity, mantenendo `matchTracker.js` come integratore del gate nel lifecycle live.
- [x] **`ARCH-BOUND-006`** — priorità `high` — Definito il guardrail per probe diagnostici read-only e documentato Betfair latest come probe CDP loopback validato e bounded.
- [x] **`ARCH-BOUND-007`** — priorità `medium` — Ridotte le sequenze operative duplicate a invarianti, con rinvii agli owner Data Lifecycle, Runtime locale e Storage.
- [x] **`ARCH-BOUND-008`** — priorità `medium` — Aggiunta la matrice confine/evidenza automatica con test owner e checker documentali, senza certificare esiti storici.

JSON:

    {
      "change_id": "ARCH-BOUND-001",
      "report_id": "TDUI-DOC-REPORT-011",
      "document_path": "docs/tennis-decision-ui/architecture/01-system-boundaries.md",
      "priority": "high",
      "type": "frontend_api_boundary",
      "action": "Qualificare l’invariante frontend /api registrando la Strategy hardcoded come eccezione legacy destinata alla rimozione.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "ARCH-BOUND-002",
      "report_id": "TDUI-DOC-REPORT-011",
      "document_path": "docs/tennis-decision-ui/architecture/01-system-boundaries.md",
      "priority": "critical",
      "type": "local_http_boundary",
      "action": "Aggiungere stato corrente vs target IMPL-017 per bind loopback, Host locale e Origin locale, coordinando Runtime Health.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "ARCH-BOUND-003",
      "report_id": "TDUI-DOC-REPORT-011",
      "document_path": "docs/tennis-decision-ui/architecture/01-system-boundaries.md",
      "priority": "high",
      "type": "betfair_runtime_authority",
      "action": "Separare scraper lifecycle e login lifecycle e chiarire che la command authority globale IMPL-016 è approvata ma non implementata.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "ARCH-BOUND-004",
      "report_id": "TDUI-DOC-REPORT-011",
      "document_path": "docs/tennis-decision-ui/architecture/01-system-boundaries.md",
      "priority": "high",
      "type": "current_vs_approved_authorities",
      "action": "Aggiungere una matrice corrente vs approvato per launcher lock, writer authority, Source Identity, IMPL-006, IMPL-016 e IMPL-017.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "ARCH-BOUND-005",
      "report_id": "TDUI-DOC-REPORT-011",
      "document_path": "docs/tennis-decision-ui/architecture/01-system-boundaries.md",
      "priority": "medium",
      "type": "source_identity_ownership",
      "action": "Correggere l’ownership Source Identity separando tracker scheduler/stop/drain dal lifecycle del gate e mantenendo matchTracker come integratore live.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "ARCH-BOUND-006",
      "report_id": "TDUI-DOC-REPORT-011",
      "document_path": "docs/tennis-decision-ui/architecture/01-system-boundaries.md",
      "priority": "high",
      "type": "readonly_network_io_guardrail",
      "action": "Definire il guardrail per network I/O nelle route read-only e collegare l’eccezione Betfair latest a BETFAIR-API-001.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "ARCH-BOUND-007",
      "report_id": "TDUI-DOC-REPORT-011",
      "document_path": "docs/tennis-decision-ui/architecture/01-system-boundaries.md",
      "priority": "medium",
      "type": "document_owner_deduplication",
      "action": "Ridurre duplicazioni operative di bootstrap/recovery/shutdown e rinviare ai documenti owner già esistenti.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "ARCH-BOUND-008",
      "report_id": "TDUI-DOC-REPORT-011",
      "document_path": "docs/tennis-decision-ui/architecture/01-system-boundaries.md",
      "priority": "medium",
      "type": "architecture_boundary_verification",
      "action": "Aggiungere una matrice confine→test per authority, registry, Source Identity, drain, API relative, local boundary e probe read-only.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }