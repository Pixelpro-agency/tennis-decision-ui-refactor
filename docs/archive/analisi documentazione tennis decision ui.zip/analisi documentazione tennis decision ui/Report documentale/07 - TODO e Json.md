TODO:

Report: [`../Report documentale/07 - 03-evidence.md`](../Report%20documentale/07%20-%2003-evidence.md) — `TDUI-DOC-REPORT-007`.

Modularizzazione: **richiesta**. File proposti: `docs/tennis-decision-ui/api/evidence/01-latest-snapshot.md`, `docs/tennis-decision-ui/api/evidence/02-source-identity-confirmation.md`.

- [ ] **`EVIDENCE-API-001`** — priorità `high` — Definire un validator `eventId` canonico e condiviso, rifiutando separatori, traversal, caratteri di controllo e lunghezze non ammesse; coordinare API, storage e test. **Riaperta:** API e writer principali usano `backend/src/utils/eventId.js`, ma recovery, `sofaUpdates/commitResult.js` e `commitJournal/recordSchema.js` mantengono validator locali più permissivi.
- [x] **`EVIDENCE-API-002`** — priorità `high` — Sostituire negli esempi `integrity.reason: commit_incomplete` con `pending_commit`, distinguendo la reason aggregata dalle reason specifiche delle due fonti.
- [x] **`EVIDENCE-API-003`** — priorità `medium` — Correggere la semantica di `sofaTimelineFound` e `betfairTimelineFound`: indicano almeno una entry leggibile, non la semplice esistenza del file; valutare una rinomina pubblica.
- [x] **`EVIDENCE-API-004`** — priorità `high` — Distinguere o documentare missing, discovery failure, read failure e JSON invalido; coordinare l’eventuale read result strutturato con `MATCH-API-005` e `BETFAIR-API-004`.
- [x] **`EVIDENCE-API-005`** — priorità `high` — Rimuovere `details: err.message` dal `500` latest, introdurre un code pubblico bounded e mantenere path, URL, token e stack soltanto nei log redatti.
- [x] **`EVIDENCE-API-006`** — priorità `medium` — Decidere come rendere osservabile un confirmation store corrotto o illeggibile nel latest, senza confonderlo silenziosamente con l’assenza di una conferma e senza esporre dettagli interni.
- [x] **`EVIDENCE-API-007`** — priorità `high` — Correggere il mapping degli errori gate: distinguere input, conflitto, race e failure server; mappare persistence e bootstrap failure a `500` con code bounded.
- [x] **`EVIDENCE-API-008`** — priorità `high` — Rendere coerenti conferma e bootstrap scegliendo transazione logica, rollback compensativo o stato esplicito; impedire che una conferma resti applicabile dopo bootstrap fallito.
- [x] **`EVIDENCE-API-009`** — priorità `high` — Rimuovere i percorsi test monolitici assenti, usare i test modulari reali e coprire tutti gli status delle tre route, inclusi latest, fallback, revoke e failure del gate.
- [x] **`EVIDENCE-API-010`** — priorità `high` — Mantenere `03-evidence.md` come facade, creare due owner API per latest e conferma/revoca, lasciare algoritmi e lifecycle ai moduli Evidence esistenti e aggiornare indice e link.

JSON:

    {
      "change_id": "EVIDENCE-API-001",
      "document_path": "docs/tennis-decision-ui/api/03-evidence.md",
      "report_id": "TDUI-DOC-REPORT-007",
      "report_path": "../Report documentale/07 - 03-evidence.md",
      "priority": "high",
      "type": "event_id_validation",
      "action": "Definire un validator `eventId` canonico e condiviso, rifiutando separatori, traversal, caratteri di controllo e lunghezze non ammesse; coordinare API, storage e test. Riaperta: API e writer principali usano backend/src/utils/eventId.js, ma recovery, sofaUpdates/commitResult.js e commitJournal/recordSchema.js mantengono validator locali più permissivi.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    },
    {
      "change_id": "EVIDENCE-API-002",
      "document_path": "docs/tennis-decision-ui/api/03-evidence.md",
      "report_id": "TDUI-DOC-REPORT-007",
      "report_path": "../Report documentale/07 - 03-evidence.md",
      "priority": "high",
      "type": "integrity_contract",
      "action": "Sostituire negli esempi `integrity.reason: commit_incomplete` con `pending_commit`, distinguendo la reason aggregata dalle reason specifiche delle due fonti.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVIDENCE-API-003",
      "document_path": "docs/tennis-decision-ui/api/03-evidence.md",
      "report_id": "TDUI-DOC-REPORT-007",
      "report_path": "../Report documentale/07 - 03-evidence.md",
      "priority": "medium",
      "type": "timeline_found_semantics",
      "action": "Correggere la semantica di `sofaTimelineFound` e `betfairTimelineFound`: indicano almeno una entry leggibile, non la semplice esistenza del file; valutare una rinomina pubblica.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVIDENCE-API-004",
      "document_path": "docs/tennis-decision-ui/api/03-evidence.md",
      "report_id": "TDUI-DOC-REPORT-007",
      "report_path": "../Report documentale/07 - 03-evidence.md",
      "priority": "high",
      "type": "read_error_semantics",
      "action": "Distinguere o documentare missing, discovery failure, read failure e JSON invalido; coordinare l’eventuale read result strutturato con `MATCH-API-005` e `BETFAIR-API-004`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVIDENCE-API-005",
      "document_path": "docs/tennis-decision-ui/api/03-evidence.md",
      "report_id": "TDUI-DOC-REPORT-007",
      "report_path": "../Report documentale/07 - 03-evidence.md",
      "priority": "high",
      "type": "public_error_redaction",
      "action": "Rimuovere `details: err.message` dal `500` latest, introdurre un code pubblico bounded e mantenere path, URL, token e stack soltanto nei log redatti.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVIDENCE-API-006",
      "document_path": "docs/tennis-decision-ui/api/03-evidence.md",
      "report_id": "TDUI-DOC-REPORT-007",
      "report_path": "../Report documentale/07 - 03-evidence.md",
      "priority": "medium",
      "type": "confirmation_store_observability",
      "action": "Decidere come rendere osservabile un confirmation store corrotto o illeggibile nel latest, senza confonderlo silenziosamente con l’assenza di una conferma e senza esporre dettagli interni.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVIDENCE-API-007",
      "document_path": "docs/tennis-decision-ui/api/03-evidence.md",
      "report_id": "TDUI-DOC-REPORT-007",
      "report_path": "../Report documentale/07 - 03-evidence.md",
      "priority": "high",
      "type": "gate_error_mapping",
      "action": "Correggere il mapping degli errori gate: distinguere input, conflitto, race e failure server; mappare persistence e bootstrap failure a `500` con code bounded.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVIDENCE-API-008",
      "document_path": "docs/tennis-decision-ui/api/03-evidence.md",
      "report_id": "TDUI-DOC-REPORT-007",
      "report_path": "../Report documentale/07 - 03-evidence.md",
      "priority": "high",
      "type": "confirmation_bootstrap_consistency",
      "action": "Rendere coerenti conferma e bootstrap scegliendo transazione logica, rollback compensativo o stato esplicito; impedire che una conferma resti applicabile dopo bootstrap fallito.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVIDENCE-API-009",
      "document_path": "docs/tennis-decision-ui/api/03-evidence.md",
      "report_id": "TDUI-DOC-REPORT-007",
      "report_path": "../Report documentale/07 - 03-evidence.md",
      "priority": "high",
      "type": "verification_coverage",
      "action": "Rimuovere i percorsi test monolitici assenti, usare i test modulari reali e coprire tutti gli status delle tre route, inclusi latest, fallback, revoke e failure del gate.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "EVIDENCE-API-010",
      "document_path": "docs/tennis-decision-ui/api/03-evidence.md",
      "report_id": "TDUI-DOC-REPORT-007",
      "report_path": "../Report documentale/07 - 03-evidence.md",
      "priority": "high",
      "type": "document_modularization",
      "action": "Mantenere `03-evidence.md` come facade, creare due owner API per latest e conferma/revoca, lasciare algoritmi e lifecycle ai moduli Evidence esistenti e aggiornare indice e link.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }
  ]