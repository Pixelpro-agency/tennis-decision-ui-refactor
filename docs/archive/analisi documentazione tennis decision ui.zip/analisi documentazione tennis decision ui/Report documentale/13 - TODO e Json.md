TODO:

Report: [`../Report documentale/13 - index.md`](../Report%20documentale/13%20-%20index.md) — `TDUI-DOC-REPORT-013`.

Modularizzazione: **valutata, non necessaria**. L’indice deve restare un unico punto di ingresso della documentazione canonica; la revisione deve correggere authority e manutenzione senza frammentarlo.

- [x] **`INDEX-001`** — priorità `high` — Separate authority dei fatti correnti e authority dei target approvati, richiedendo codice e verifiche per dichiarare implementazione.
- [x] **`INDEX-002`** — priorità `high` — Riallineata `docs/archive/` come radice non canonica, facoltativa, preservata esplicitamente e non soggetta a cleanup generici.
- [x] **`INDEX-003`** — priorità `medium` — Rimosse le note ad hoc sui gap e introdotta una regola unica per owner correnti, finding e registri.
- [x] **`INDEX-004`** — priorità `medium` — Qualificata la roadmap come snapshot legato alla baseline dichiarata internamente.
- [x] **`INDEX-005`** — priorità `low` — Rinominato l’heading permanente in `Fondazione e architettura`, lasciando la migrazione alla validation storica.
- [x] **`INDEX-006`** — priorità `medium` — Aggiunto il contratto di manutenzione dell’indice e i checker obbligatori dopo modifiche strutturali.

JSON:

    {
      "change_id": "INDEX-001",
      "report_id": "TDUI-DOC-REPORT-013",
      "document_path": "docs/tennis-decision-ui/index.md",
      "priority": "high",
      "type": "source_hierarchy_current_vs_target",
      "action": "Separare fatti correnti e target approvati: codice/test come authority dello stato implementato e decisioni utente come authority del target, senza promuovere decisioni non implementate a stato corrente.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "INDEX-002",
      "report_id": "TDUI-DOC-REPORT-013",
      "document_path": "docs/tennis-decision-ui/index.md",
      "priority": "high",
      "type": "archive_policy_alignment",
      "action": "Riallineare la policy archive con DOC-CONV-001/003, descrivendo una radice non canonica eventualmente vuota/assente e preservata senza cleanup automatici.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "INDEX-003",
      "report_id": "TDUI-DOC-REPORT-013",
      "document_path": "docs/tennis-decision-ui/index.md",
      "priority": "medium",
      "type": "index_findings_ownership",
      "action": "Rimuovere lo stato ad hoc dei finding dall’indice e mantenere soltanto ownership e stati strutturali, rinviando limiti e finding a roadmap/registri.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "INDEX-004",
      "report_id": "TDUI-DOC-REPORT-013",
      "document_path": "docs/tennis-decision-ui/index.md",
      "priority": "medium",
      "type": "snapshot_baseline_semantics",
      "action": "Esplicitare che il Current State è uno snapshot legato alla propria baseline e non una certificazione automatica del checkpoint corrente.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "INDEX-005",
      "report_id": "TDUI-DOC-REPORT-013",
      "document_path": "docs/tennis-decision-ui/index.md",
      "priority": "low",
      "type": "migration_heading_cleanup",
      "action": "Rimuovere il framing migration-era dall’heading dell’indice, lasciando la storia della migrazione alla validation storica.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "INDEX-006",
      "report_id": "TDUI-DOC-REPORT-013",
      "document_path": "docs/tennis-decision-ui/index.md",
      "priority": "medium",
      "type": "index_maintenance_contract",
      "action": "Definire i trigger di manutenzione dell’indice e vietare link a owner soltanto proposti, con link checker dopo modifiche strutturali.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }