# Scheda di contesto documentale

## Documento target

Percorso:
`implementazioni/audit-codice/01-rilievi-iniziali.md`

Tipo di documento:
facade stabile della Parte 1 dell’audit codice e punto di accesso a due moduli storici specialistici.

Ruolo documentale:
orientare la consultazione della Parte 1, mantenere la navigazione generale e l’overlay di autorità temporale, e distinguere i checkpoint storici B3–B6 dal successivo audit del Punto 1 e dall’esito storico di `IMPL-015`. Le schede owner appartengono ai due moduli figli e non alla facade.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-231822).txt`
- `53 - Report 01-rilievi-iniziali.md` — report `TDUI-DOC-REPORT-053`
- `53 - TODO e Json.md` — sezione Markdown e record JSON associati al documento target
- report di applicazione e verifica di `AUDIT-CODE-P1-002` contenuto in `Pasted markdown(20260813-234152).md`

## Task storicamente associate

- `AUDIT-CODE-P1-001` — stato: completata  
  Argomento coinvolto: distinzione temporale fra checkpoint B3–B6, secondo audit Punto 1, aggiornamento `IMPL-015` e stato corrente degli owner; riferimenti di successione per decisioni e stati storici.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `AUDIT-CODE-P1-002` — stato: completata  
  Argomento coinvolto: trasformazione di `implementazioni/audit-codice/01-rilievi-iniziali.md` in facade stabile e separazione dei contenuti storici nei moduli `01-checkpoint-b3-b6.md` e `02-punto-1-runtime-writer-authority.md`, con preservazione di ID, stati, testo storico, navigazione e unicità degli owner.  
  Uso consentito: considerare la struttura modularizzata come struttura documentale corrente e verificare nel CODE AUTHORITY o nel risultato esecutivo disponibile i contenuti tecnici pertinenti.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione prevista da `AUDIT-CODE-P1-002` risulta completata.
- `implementazioni/audit-codice/01-rilievi-iniziali.md` è la facade stabile della Parte 1 e non contiene schede owner.
- I moduli correnti sono `implementazioni/audit-codice/01-rilievi-iniziali/01-checkpoint-b3-b6.md` e `implementazioni/audit-codice/01-rilievi-iniziali/02-punto-1-runtime-writer-authority.md`.
- Il primo modulo possiede i rilievi iniziali e i checkpoint B3–B6; il secondo possiede il secondo audit Punto 1 e l’esito storico di `IMPL-015`.
- La modularizzazione non introduce nuovi documenti canonici.

## Struttura corrente e continuità storica

- facade Parte 1 con identità «Parte 1 di 7 — Rilievi iniziali e Punto 1», navigazione generale, indice dei moduli figli e overlay temporale;
- `01-checkpoint-b3-b6.md` con rilievi tecnici iniziali, mappa di controllo, checkpoint B3–B6, decisioni e priorità appartenenti a quei checkpoint e relativi owner ID;
- `02-punto-1-runtime-writer-authority.md` con secondo audit Punto 1, entry point, launcher, writer authority, `RUNTIME-003`, `DOC-024`, `TEST-004` ed esito storico di `IMPL-015`;
- Todo e owner collegati come autorità dello stato operativo corrente;
- distinzione preservata fra contenuto storico, implementazione verificata, test offline e collaudo live non eseguito.

## Aree da verificare nel CODE AUTHORITY

- facade `implementazioni/audit-codice/01-rilievi-iniziali.md` e navigazione verso i due moduli figli;
- entry point e launcher runtime;
- bootstrap del server, recovery e avvio dell’ascolto;
- writer authority e relativo ciclo di acquisizione/rilascio;
- arresto e drain di `matchTracker`;
- test relativi a writer authority, server e concorrenza fra backend;
- stato corrente degli ID e delle decisioni richiamate dai moduli storici.

## Owner/documenti collegati

- `implementazioni/audit-codice/01-rilievi-iniziali/01-checkpoint-b3-b6.md` — owner dei rilievi iniziali e dei checkpoint storici B3–B6.
- `implementazioni/audit-codice/01-rilievi-iniziali/02-punto-1-runtime-writer-authority.md` — owner del secondo audit Punto 1 e dell’esito storico di `IMPL-015`.
- `implementazioni/03-audit-codice.md` — facade e perimetro complessivo dell’audit codice.
- `todo-list-tennis-decision-ui.md` — vista sintetica dello stato corrente degli ID; non coincide con gli snapshot B3–B6.
- `implementazioni/99-decisioni-utente.md` — owner delle decisioni richiamate storicamente dai moduli.
- `implementazioni/audit-codice/02-runtime-sessioni-betfair.md` — prosecuzione dell’audit per sessioni e runtime Betfair.
- `implementazioni/audit-codice/03-storage-recovery.md` — owner collegato per storage e recovery emersi negli audit successivi.
- `implementazioni/audit-codice/06-validazione-e-test.md` e `implementazioni/audit-codice/07-post-audit-e-migrazione.md` — confine documentale per validazioni, test ed esiti successivi.

## Guardrail specifici per questo documento

- Conservare il carattere storico dei checkpoint senza convertirli in backlog o stato tecnico corrente.
- Distinguere sempre B3–B6, secondo audit Punto 1 e aggiornamento `IMPL-015`.
- Considerare la facade e i due moduli figli come struttura corrente completata da `AUDIT-CODE-P1-002`.
- Non riportare schede owner nella facade e non duplicare gli ID fra i due moduli figli.
- Non duplicare decisioni o stati correnti già appartenenti alla Todo o ai documenti collegati.
- Non trasformare la facade in una Todo, in un decision log completo o in un changelog Git.
- Preservare la provenienza delle evidenze e la distinzione fra implementazione, test offline e validazione live.

## Informazioni storiche da NON assumere come correnti

- Le sintesi, le priorità e le domande decisionali contenute nei checkpoint B3–B6.
- Le valutazioni su storage/recovery, Graph URL, test, frontend, security e altre aree formulate durante i primi checkpoint.
- La conclusione del secondo audit Punto 1 sulla baseline allora dichiarata, se interpretata come validità permanente.
- Gli stati tecnici dei singoli finding e delle decisioni citate nel report storico.
- Il collaudo manuale con due backend reali concorrenti: la fonte di verifica lo indica come non eseguito.

## Discrepanze o limiti delle fonti

- La Scheda e il record TODO/JSON originari precedevano l’esecuzione di `AUDIT-CODE-P1-002`; il presente contenuto incorpora il successivo esito di applicazione e verifica.
- La verifica conclusiva riporta facade e moduli figli coerenti, 23 owner ID univoci, registry checker senza errori o warning e `git diff --check` superato.
- Il comando `fast` ha registrato un esito non pienamente positivo soltanto per tre riferimenti mancanti preesistenti nella cartella `analisi documentazione tennis decision ui/`, fuori dal perimetro documentale indicato; nessun errore di collegamento riguarda la facade, i moduli figli o i Markdown della cartella `implementazioni/` coinvolti nella task.
- Le fonti storiche non sostituiscono la verifica tecnica sulla Code Authority.
