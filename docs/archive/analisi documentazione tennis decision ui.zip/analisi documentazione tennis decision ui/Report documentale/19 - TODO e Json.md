TODO:

Report: [`../Report documentale/19 - 04-market-reactions.md`](../Report%20documentale/19%20-%2004-market-reactions.md) — `TDUI-DOC-REPORT-019`.

Modularizzazione: **valutata, non necessaria**. Significant Flow, Market → Field e Field → Market appartengono allo stesso owner Market Reactions e devono restare confrontabili nello stesso documento.

- [x] **`MARKET-REACT-001`** — priorità `high` — Distinte attività Exchange isolata e osservazione temporale; documentati i livelli che possiedono `causalityClaimed:false` e ripristinato il disclaimer Market → Field.
- [x] **`MARKET-REACT-002`** — priorità `critical` — Significant Flow usa confidence condivisa e tolleranza producer-compatible; rimossa la blacklist locale come authority.
- [x] **`MARKET-REACT-003`** — priorità `critical` — Flow suppressed o senza Graph, ladder reale o selection ID resta invalidato e non diventa sourceMarketEvent.
- [x] **`MARKET-REACT-004`** — priorità `high` — Market → Field applica max age 240s, clock skew 5s e configurazione window normalizzata con reason bounded.
- [x] **`MARKET-REACT-005`** — priorità `high` — Separati `marketResponseObserved`, `marketResponseReliable` e `reliabilityReasons` fino al summary parent.
- [x] **`MARKET-REACT-006`** — priorità `medium` — Chiarito che quality di window e summary sono coverage quality locali e non la Data Quality globale dello snapshot.
- [x] **`MARKET-REACT-007`** — priorità `medium` — Documentate separatamente pipeline available, large flow, disponibilità dei due rami e response observed.
- [x] **`MARKET-REACT-008`** — priorità `high` — Card basate su `evidence.available`; reason parent backend-owned rese visibili senza ricostruzione frontend.
- [x] **`MARKET-REACT-009`** — priorità `high` — Mapping frontend riallineato ai campi backend, marker array-safe e disclaimer causality verificato dal view model.
- [x] **`MARKET-REACT-010`** — priorità `high` — Aggiunte suite Significant Flow e view model, corretti i command path e coperti suppression, tolerance, recency, reliability e UI mapping.

JSON:

    {
      "change_id": "MARKET-REACT-001",
      "report_id": "TDUI-DOC-REPORT-019",
      "document_path": "docs/tennis-decision-ui/modules/evidence/04-market-reactions.md",
      "priority": "high",
      "type": "public_evidence_contract",
      "action": "Distinguere market activity isolata da temporal observation; Rendere coerente `causalityClaimed:false` sui livelli consumati dalla UI; Correggere la dichiarazione `Ogni output`; Ripristinare il disclaimer Market → Field.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MARKET-REACT-002",
      "report_id": "TDUI-DOC-REPORT-019",
      "document_path": "docs/tennis-decision-ui/modules/evidence/04-market-reactions.md",
      "priority": "critical",
      "type": "data_integrity",
      "action": "Eliminare blacklist reason locale stale; Riusare producer confidence/reason; Allineare le tolleranze TotalMatched; Coordinare `QUALITY-FLOW-003/004`; Impedire divergenze producer/consumer.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MARKET-REACT-003",
      "report_id": "TDUI-DOC-REPORT-019",
      "document_path": "docs/tennis-decision-ui/modules/evidence/04-market-reactions.md",
      "priority": "critical",
      "type": "source_event_eligibility",
      "action": "Non promuovere suppressed/incoherent flow a sourceMarketEvent; Richiedere eligibility condivisa; Mantenere eventuale large flow non affidabile come diagnostica; Testare `flow_exceeds_runner_delta` e suppression.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MARKET-REACT-004",
      "report_id": "TDUI-DOC-REPORT-019",
      "document_path": "docs/tennis-decision-ui/modules/evidence/04-market-reactions.md",
      "priority": "high",
      "type": "temporal_source_eligibility",
      "action": "Definire max source age o natura historical diagnostic; Gestire future timestamp/clock skew; Coordinare `QUALITY-FLOW-002/007`; Non usare flow stale come fonte live senza reason.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MARKET-REACT-005",
      "report_id": "TDUI-DOC-REPORT-019",
      "document_path": "docs/tennis-decision-ui/modules/evidence/04-market-reactions.md",
      "priority": "high",
      "type": "market_response_semantics",
      "action": "Distinguere `marketResponseObserved` da risposta affidabile; Documentare cosa usa price/market total; Aggiungere reliability/reasons se necessario; Non confondere observed con causal/reliable.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MARKET-REACT-006",
      "report_id": "TDUI-DOC-REPORT-019",
      "document_path": "docs/tennis-decision-ui/modules/evidence/04-market-reactions.md",
      "priority": "medium",
      "type": "quality_semantics",
      "action": "Distinguere quality delle window da Evidence `dataQuality`; Chiarire che parent `summary.dataQuality` è market-led; Valutare naming `windowDataQuality` / `observationCoverageQuality`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MARKET-REACT-007",
      "report_id": "TDUI-DOC-REPORT-019",
      "document_path": "docs/tennis-decision-ui/modules/evidence/04-market-reactions.md",
      "priority": "medium",
      "type": "public_availability_contract",
      "action": "Distinguere pipeline/data available da reaction observed; Non usare un solo boolean ambiguo; Documentare `largeFlowDetected`, `marketLedAvailable`, `fieldLedAvailable`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MARKET-REACT-008",
      "report_id": "TDUI-DOC-REPORT-019",
      "document_path": "docs/tennis-decision-ui/modules/evidence/04-market-reactions.md",
      "priority": "high",
      "type": "frontend_evidence_contract",
      "action": "Usare `evidence.available`, non `!!evidence`; Mostrare parent blocking reasons; Preservare Source Identity/persistence reason backend-owned; Non ricostruire reason lato frontend.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MARKET-REACT-009",
      "report_id": "TDUI-DOC-REPORT-019",
      "document_path": "docs/tennis-decision-ui/modules/evidence/04-market-reactions.md",
      "priority": "high",
      "type": "frontend_mapping",
      "action": "Riallineare runner/importo/tier ai campi backend reali; Renderizzare marker array correttamente; Mostrare disclaimer causality; Aggiungere fixture frontend.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MARKET-REACT-010",
      "report_id": "TDUI-DOC-REPORT-019",
      "document_path": "docs/tennis-decision-ui/modules/evidence/04-market-reactions.md",
      "priority": "high",
      "type": "test_contract",
      "action": "Correggere i due command path inesistenti; Aggiungere/ristabilire suite Significant Flow; Usare i test modulari reali Evidence; Coprire suppression, tolerance, recency, availability e UI mapping.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }