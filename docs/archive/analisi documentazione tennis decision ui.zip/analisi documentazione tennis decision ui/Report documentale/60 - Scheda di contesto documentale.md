# Scheda di contesto documentale

## Documento target

Percorso:

`implementazioni/audit-documentazione/01-rilievi-iniziali-e-api.md`

Tipo di documento:

facade/entrypoint stabile del modulo storico di audit documentale B1/B2.

Ruolo documentale:

mantenere il path storico stabile, sintetizzare il perimetro del modulo e fornire la navigazione verso i due child nei quali sono ora materialmente separati i contenuti B1 e B2. La facade non possiede copie delle schede owner.

I contenuti dettagliati sono distribuiti in:

- `implementazioni/audit-documentazione/01-rilievi-iniziali-e-api/01-rilievi-iniziali.md` — checkpoint storico B1, §9, §10, `DOC-001…008`, `WORKFLOW-001`;
- `implementazioni/audit-documentazione/01-rilievi-iniziali-e-api/02-api.md` — checkpoint storico B2, §11, `DOC-009…013`, Runtime Health e riepilogo API.

## Baseline

Code authority:

`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:

`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `Report documentale/60 - 01-rilievi-iniziali-e-api.md` — `TDUI-DOC-REPORT-060`.
- `60 - TODO e Json.md`.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing`.
- `Report di aggiornamento retroattivo — DOC-AUDIT-P12-002`.

## Task storicamente associate

- `DOC-AUDIT-P12-001` — stato: completata  
  Argomento coinvolto: distinzione tra checkpoint storico B1/B2 e stato documentale successivo degli owner collegati, con reconciliation storico/current.  
  Uso consentito: verificare nel CODE AUTHORITY quale comportamento corrente sia pertinente al ruolo documentale e descriverlo senza riaprire la task.

- `DOC-AUDIT-P12-002` — stato: completata  
  Argomento coinvolto: modularizzazione del precedente modulo B1/B2 mediante mantenimento del path principale come facade breve e separazione dei contenuti nei child `01-rilievi-iniziali.md` e `02-api.md`.  
  La modularizzazione ha preservato owner ID, checklist B1, checkpoint API, qualifier storico sui test, navigazione e reconciliation di `DOC-AUDIT-P12-001`.

## Cambiamenti strutturali storicamente rilevanti

- La documentazione canonica collegata risulta già migrata da `.mdx` a Markdown ordinario `.md`.
- `DOC-AUDIT-P12-001` ha introdotto la reconciliation storico/current degli owner interessati.
- `DOC-AUDIT-P12-002` ha completato la separazione strutturale B1/B2:
  - facade stabile: `implementazioni/audit-documentazione/01-rilievi-iniziali-e-api.md`;
  - child B1: `implementazioni/audit-documentazione/01-rilievi-iniziali-e-api/01-rilievi-iniziali.md`;
  - child B2: `implementazioni/audit-documentazione/01-rilievi-iniziali-e-api/02-api.md`.
- La modularizzazione è rimasta sotto `implementazioni/audit-documentazione/01-rilievi-iniziali-e-api/`, evitando collisioni con il distinto audit del codice.

## Struttura precedente da considerare

La struttura originariamente raccolta nel singolo modulo era:

- §9 — rilievi strutturali iniziali;
- §10 — checklist generale/iniziale;
- §11 — checkpoint audit API.

Il mapping strutturale risultante è:

```text
§9 + §10 -> 01-rilievi-iniziali.md
§11      -> 02-api.md
```

La facade principale resta l'entrypoint del modulo.

Nel child B2 restano rilevanti:

- checkpoint API completo `b277bd9b7373dfd8702e65446c88bab7a0f64dcc`;
- distinzione storica secondo cui i test del checkpoint furono letti/ispezionati, non eseguiti.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/routes/match.js`
- `backend/src/routes/test.js`
- possibili router e sorgenti direttamente collegati alle API Match, Betfair, Evidence, Strategy, Preflight e Runtime Health, soltanto quando necessari a disambiguare il comportamento corrente.

Non usare il materiale storico come sostituto della verifica del CODE AUTHORITY.

## Owner/documenti collegati

Struttura diretta del modulo:

- `implementazioni/audit-documentazione/01-rilievi-iniziali-e-api.md` — facade;
- `implementazioni/audit-documentazione/01-rilievi-iniziali-e-api/01-rilievi-iniziali.md` — child B1;
- `implementazioni/audit-documentazione/01-rilievi-iniziali-e-api/02-api.md` — child B2;
- `implementazioni/02-audit-documentazione.md` — parent dell'audit documentale.

Documenti di contesto collegati:

- `README.md`
- `docs/tennis-decision-ui/roadmap/01-current-state.md`
- `docs/tennis-decision-ui/reference/01-repository-map.md`
- `docs/tennis-decision-ui/ai/01-context-selection.md`
- `docs/tennis-decision-ui/ai/02-documentation-conventions.md`
- `docs/tennis-decision-ui/api/01-match.md`
- `docs/tennis-decision-ui/api/02-betfair.md`
- `docs/tennis-decision-ui/api/03-evidence.md`
- `docs/tennis-decision-ui/api/04-strategy.md`
- `docs/tennis-decision-ui/api/05-preflight.md`

## Guardrail specifici per questo documento

- Considerare B1 e B2 checkpoint storici, non stato corrente assoluto.
- Considerare la struttura a due child come esistente.
- Non ricombinare B1 e B2 nel precedente monolite.
- Non duplicare le schede owner fra facade e child.
- `DOC-001…008` e `WORKFLOW-001` appartengono al child B1.
- `DOC-009…013` appartengono al child B2.
- `DOC-003` può comparire nel contesto API come richiamo storico, ma non come seconda scheda owner.
- Preservare nel child API il qualifier storico secondo cui i test del checkpoint furono letti/ispezionati e non eseguiti.
- Non trasformare la facade in un secondo contenitore completo dei contenuti già posseduti dai child.
- Non inventare esiti di gate o run complete del repository privi di evidenza.

## Informazioni storiche da NON assumere come correnti

- Le formulazioni del checkpoint originale precedenti alla migrazione canonica.
- Gli stati originari degli owner precedenti alla reconciliation di `DOC-AUDIT-P12-001`.
- Proposte, finding o prescrizioni del report storico che non corrispondano a modifiche effettivamente applicate.
- Eventuali vecchi path `.mdx` presenti come testo nei checkpoint: restano riferimenti storici e non equivalgono a link canonici correnti.
- Eventuali risultati di `check_registry_consistency.py`, `check_documentation_links.py`, `run.mjs fast` o `git diff --check` non supportati da evidenza di esecuzione.

## Discrepanze o limiti delle fonti

Dopo l'aggiornamento retroattivo, lo stato storico da rappresentare è:

```text
DOC-AUDIT-P12-001 = completed
DOC-AUDIT-P12-002 = completed
```

e la struttura risultante è:

```text
implementazioni/audit-documentazione/01-rilievi-iniziali-e-api.md
└── facade stabile

implementazioni/audit-documentazione/01-rilievi-iniziali-e-api/
├── 01-rilievi-iniziali.md
│   └── B1 + §9/§10 + DOC-001…008 + WORKFLOW-001
└── 02-api.md
    └── B2 + §11 + DOC-009…013 + checkpoint API
```

Il report retroattivo specifica che non deve essere inventata una run completa dei gate di repository; la chiusura di `DOC-AUDIT-P12-002` deriva dalla verifica strutturale documentata degli artefatti prodotti.
