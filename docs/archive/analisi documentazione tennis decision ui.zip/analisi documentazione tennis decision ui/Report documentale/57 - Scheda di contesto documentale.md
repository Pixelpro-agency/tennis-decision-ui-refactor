# Scheda di contesto documentale

## Documento target

Percorso:
`implementazioni/audit-codice/05-frontend-session-shell.md`

Tipo di documento:
modulo owner dell’audit codice / record tecnico relativo al frontend e alla session shell.

Ruolo documentale:
documento unitario del “Punto 6 — Frontend”, storicamente collocato come “Parte 5 di 7 — Frontend e session shell”. Il perimetro documentale comprende session controller, Start/Stop, polling, integrity UI, Source Identity, Market Reactions UI e stato statico. La fonte storica considera queste aree come consumer della stessa session authority frontend e non richiede una suddivisione del documento.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260814-011759).txt`
- `57 - Report 05-frontend-session-shell.md` — report `TDUI-DOC-REPORT-057`
- `57 - TODO e Json.md`

## Task storicamente associate

- `FRONTEND-001…012` — stato: non completate / ancora aperte nel contesto storico disponibile.
  Argomento coinvolto: lifecycle della sessione frontend, Start/Stop, polling, propagazione dello stato di integrity, indicatori di stato, Market Reactions UI, Source Identity UI, Preflight e responsive.
  Uso consentito: verificare nel CODE AUTHORITY quali aspetti risultano ancora pertinenti e documentare soltanto il comportamento corrente.

- `DOC-028…030` — stato: non completate nel contesto storico; le fonti le mantengono aperte come riferimenti documentali.
  Argomento coinvolto: documentazione canonica della session shell e descrizione dei contratti frontend.
  Uso consentito: verificare nel CODE AUTHORITY e nella struttura documentale corrente quali descrizioni siano ancora applicabili.

- `IMPL-025` — stato: non completata nella fonte storica.
  Argomento coinvolto: frontend live-session controller.
  Uso consentito: non assumere il target storico come comportamento già presente; verificarne l’eventuale effetto corrente nel CODE AUTHORITY.

- `IMPL-026` — stato: non completata nella fonte storica.
  Argomento coinvolto: polling runtime session-scoped.
  Uso consentito: non assumere il target storico come comportamento già presente; verificarne l’eventuale effetto corrente nel CODE AUTHORITY.

- `IMPL-027` — stato: non completata nella fonte storica.
  Argomento coinvolto: Market Reactions frontend view model.
  Uso consentito: non assumere il target storico come comportamento già presente; verificarne l’eventuale effetto corrente nel CODE AUTHORITY.

- `TEST-044…059` — stato: non completate nella fonte storica.
  Argomento coinvolto: verifiche frontend collegate a session authority, polling, Stop, persistence UI, Source Identity, Preflight, Market Reactions, StrictMode e responsive.
  Uso consentito: il loro stato storico serve soltanto a evitare di presentare come già validato ciò che dovrà essere verificato sulla baseline corrente.

- `IMPL-006`, `IMPL-009`, `RUNTIME-009`, `RUNTIME-010`, `CODE-001`, `CODE-004`, `CLEANUP-001`, `SOFA-LIVE-001…009`, `LIVE-CTRL-001…007`, `METHOD-EVIDENCE-001`, `PLAN-AUDIT-003` — stato storico non sufficientemente determinato dalle fonti fornite.
  Argomento coinvolto: owner e dipendenze coordinate con il Punto 6 senza duplicarne l’ownership.
  Uso consentito: considerarli soltanto come riferimenti di confine e verificarne lo stato nelle fonti autoritative prima di citarli come correnti.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione del documento è stata valutata e non ritenuta necessaria.
- Il report registra `split_required: false` e nessun nuovo file proposto.
- Nella provenance storica del Punto 6 compaiono tre documenti separati, indicati come `01-session-shell.mdx`, `02-live-polling-and-view-model.mdx` e `03-betfair-and-market-reactions-ui.mdx`; il report segnala una successiva migrazione `.mdx → .md`. Questi riferimenti descrivono il perimetro letto a una baseline precedente e non vanno assunti come struttura corrente senza verifica.
- Al momento del report 057 non risultavano richieste né una riscrittura completa né una revisione mirata autonoma del documento.

## Struttura precedente da considerare

- Un solo audit point: `Punto 6 — Frontend`.
- Una sola baseline storica dichiarata nel documento: `9205b5a789a40203c48ba19f8e3397fd0cec9707`.
- Dichiarazione esplicita della natura statica dell’analisi storica.
- Perimetro unitario: session controller, Start/Stop, polling, integrity UI, Source Identity, Market Reactions UI e stato statico.
- Separazione concettuale fra Source Identity, Evidence, persistence integrity e Betfair health.
- Ownership Evidence descritta a livello applicativo, senza duplicare un secondo poller nelle singole view/card.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `frontend/src/App.jsx`
- `frontend/src/hooks/useLiveTrackingActions.js`
- `frontend/src/hooks/useMatchPolling.js`
- `frontend/src/hooks/useBetfairJson.js`
- `frontend/src/hooks/useMarketReactionEvidence.js`
- `frontend/src/hooks/useSourceIdentityGateStatus.js`
- `frontend/src/hooks/useSourceIdentityGateUi.js`
- `frontend/src/hooks/useDashboardViewModel.js`
- `frontend/src/hooks/usePreflightChecks.js`
- `frontend/src/hooks/useBetfairHealthAlerts.js`
- `frontend/src/utils/dashboardConnections.js`
- `frontend/src/components/marketReactions/`
- `backend/src/routes/match/trackingResponses.js` come sorgente collegata al contratto Start/Stop consumato dal frontend.

## Owner/documenti collegati

- `todo-list-tennis-decision-ui.md` — indice storico degli owner e degli stati associati al Punto 6.
- `implementazioni/03-audit-codice.md` — contesto documentale superiore dell’audit codice.
- `implementazioni/implementazioni-proposte/05-frontend-session-polling.md` — riferimento storico alle proposte relative a sessione e polling; non è CODE AUTHORITY.
- `implementazioni/99-decisioni-utente.md` — fonte storica delle decisioni coordinate con il documento.
- `01-session-shell.mdx`, `02-live-polling-and-view-model.mdx`, `03-betfair-and-market-reactions-ui.mdx` — riferimenti di provenance della baseline storica; la fonte segnala una successiva migrazione a `.md`.

## Guardrail specifici per questo documento

- Mantenere il ruolo del file come documento unitario della frontend live session shell, salvo evidenza contraria nella struttura documentale corrente.
- Non interpretare lo stato storico dell’audit come prova che le implementazioni o i test associati siano stati completati.
- Non assumere build, test o validazione responsive sulla base del report 057: il report dichiara che non furono eseguiti.
- Mantenere distinti, nella documentazione, i domini Source Identity, Evidence, persistence integrity e Betfair health quando il CODE AUTHORITY conferma ancora questa separazione.
- Non introdurre una seconda ownership del polling Evidence nelle singole view se il CODE AUTHORITY conserva l’ownership applicativa descritta storicamente.
- Non trasformare i riferimenti `.mdx` storici in errori o path correnti senza prima verificare la struttura attuale.
- Non usare task, finding o proposte storiche come istruzioni di implementazione.
- Non usare il documento frontend per descrivere recovery backend o scritture canoniche delle timeline, salvo semplice confine di ownership se confermato dal CODE AUTHORITY.

## Informazioni storiche da NON assumere come correnti

- Lo stato del codice osservato dal report 057, perché il technical writer dovrà usare il CODE AUTHORITY `12b344ea96e71b2bdaa6931c98419ce925b5c228`.
- L’assenza storica delle strutture associate a `IMPL-025…027`.
- Lo stato storico “mancante” di `TEST-044…059`.
- I singoli gap tecnici elencati nel report, compresi quelli relativi a Start/Stop, polling, integrity propagation, Market Reactions, Source Identity, Preflight e responsive.
- Le priorità storiche assegnate alle task.
- L’ordine storico delle dipendenze fra implementazioni e test.
- La baseline interna `9205b5a789a40203c48ba19f8e3397fd0cec9707` come descrizione del codice corrente.
- I path `.mdx` come struttura documentale corrente.

## Discrepanze o limiti delle fonti

- Il file `57 - TODO e Json.md` contiene la nota TODO relativa al report 057, ma la sezione `JSON:` non contiene dati strutturati utilizzabili; non è quindi possibile confermare da JSON gli stati delle task.
- Il report 057 dichiara che, al momento della sua produzione, mappa Markdown e ledger JSON non erano stati aggiornati con il blocco dei report 053–057. La scheda non tenta di ricostruire o risolvere questo consolidamento storico.
- Per gli owner coordinati ma non descritti con uno stato esplicito nel materiale fornito (`IMPL-006`, `IMPL-009`, `RUNTIME-009`, `RUNTIME-010`, `CODE-001`, `CODE-004`, `CLEANUP-001`, `SOFA-LIVE-001…009`, `LIVE-CTRL-001…007`, `METHOD-EVIDENCE-001`, `PLAN-AUDIT-003`), lo stato resta storicamente non sufficientemente determinato.
- Il documento target corrente non è stato fornito come allegato separato; la forma precedente è quindi ricostruita soltanto dal report documentale e dovrà essere confrontata con la Documentation Structure Baseline.
