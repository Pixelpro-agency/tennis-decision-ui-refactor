# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/ai/01-context-selection.md`

Tipo di documento:  
documento metodologico/operativo per la selezione del contesto destinato ai prompt AI.

Ruolo documentale:  
definire il contesto minimo da fornire ai prompt AI e le regole di orientamento necessarie per selezionarlo, senza sostituire codice, test, documentazione tecnica owner, decisioni dell’utente o workflow esecutivo completo. Il report storico identifica come responsabilità centrale la selezione minima del contesto.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

Le baseline sono quelle prescritte per la successiva fase di technical writing; il materiale storico non costituisce authority tecnica.

## Fonti storiche consultate

- `Report documentale/02 - 01-context-selection.md` — `TDUI-DOC-REPORT-002`, relativo al documento target e al commit della documentation structure baseline.
- `02 - TODO e Json.md` — registro storico delle task `CTX-001`–`CTX-004` e dei relativi stati.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing` — regole di preparazione della presente scheda; richiede di trasformare audit, finding e task in contesto storico neutro senza trasferire prescrizioni alla fase successiva.

## Task storicamente associate

- `CTX-001` — stato: completata  
  Argomento coinvolto: delimitazione di `01-context-selection.md` alla selezione del contesto e rapporto di ownership con `03-workflow-esecutivo.md`.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `CTX-002` — stato: completata  
  Argomento coinvolto: distinzione fra campi comuni e requisiti condizionali legati alle modalità che modificano file, con particolare riferimento a `fileModificati.md`, consegna e report.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `CTX-003` — stato: completata  
  Argomento coinvolto: separazione della diagnosi/modularizzazione in `docs/tennis-decision-ui/ai/04-diagnosi-e-modularizzazione.md` e aggiornamento dei collegamenti documentali.  
  Uso consentito: verificare nel CODE AUTHORITY se questa struttura è effettivamente quella corrente.

- `CTX-004` — stato: completata  
  Argomento coinvolto: trattamento dei guardrail tecnici come riferimenti condizionali ai rispettivi owner anziché come contratti autonomi del documento.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- Il materiale storico registra una modularizzazione associata a `CTX-003`, con `04-diagnosi-e-modularizzazione.md` come documento separato proposto dalla revisione e successivamente marcato come task completata.
- Il report distingueva tre responsabilità documentali: selezione del contesto in `01-context-selection.md`, ciclo esecutivo in `03-workflow-esecutivo.md`, diagnosi tecnica/modularizzazione nel nuovo owner dedicato.
- Le task storiche registrano inoltre una riduzione delle duplicazioni del workflow e una trasformazione dei requisiti universali in requisiti dipendenti dalla modalità.

## Struttura precedente da considerare

La versione analizzata storicamente comprendeva, fra gli elementi pertinenti al ruolo del documento:

- scopo e precondizioni iniziali;
- gerarchia sintetica delle fonti;
- selezione minima del contesto e materiali da escludere;
- criteri per le decisioni mancanti;
- navigazione mirata del codice;
- template e checklist;
- riferimenti ai documenti collegati.

Conteneva inoltre sezioni estese sui ruoli, sugli artefatti del workflow e sulla diagnosi/modularizzazione, che il report storico attribuiva ad altri owner.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `docs/tennis-decision-ui/ai/01-context-selection.md`
- `docs/tennis-decision-ui/ai/03-workflow-esecutivo.md`
- `docs/tennis-decision-ui/ai/04-diagnosi-e-modularizzazione.md`
- `docs/tennis-decision-ui/ai/02-documentation-conventions.md`
- `docs/tennis-decision-ui/reference/01-repository-map.md`

Il report storico indica esplicitamente `03-workflow-esecutivo.md`, `02-documentation-conventions.md` e `01-repository-map.md` fra i documenti usati per determinare confini e relazioni del target.

## Owner/documenti collegati

- `docs/tennis-decision-ui/ai/03-workflow-esecutivo.md` — owner storico indicato per contratti completi dei ruoli, artefatti, esecuzione, collaudo, report e criteri di chiusura.
- `docs/tennis-decision-ui/ai/04-diagnosi-e-modularizzazione.md` — storicamente associato alla separazione della diagnosi tecnica e dei criteri di modularizzazione; esistenza e contenuto corrente da verificare.
- `docs/tennis-decision-ui/ai/02-documentation-conventions.md` — riferimento alle convenzioni documentali.
- `docs/tennis-decision-ui/reference/01-repository-map.md` — riferimento per orientamento e navigazione della repository.
- `docs/tennis-decision-ui/index.md` — collegamento strutturale citato nel materiale storico.

## Guardrail specifici per questo documento

- Mantenere come responsabilità primaria la **selezione del contesto minimo** per i prompt AI.
- Trattare la gerarchia delle fonti presente nel documento come orientamento sintetico, verificando l’owner corrente per il contratto operativo completo.
- Preservare la distinzione fra file modificabili, consultabili ed esclusi quando ancora presente nel CODE AUTHORITY.
- Mantenere la navigazione mirata del codice come tema proprio del documento: owner, file target, dipendenze indispensabili, consumer pertinenti e test più vicino, senza estendere automaticamente il contesto all’intera repository.
- I dettagli completi del workflow, della diagnosi tecnica o dei contratti trasversali vanno considerati secondo l’ownership effettivamente presente nel CODE AUTHORITY, non sulla sola base del report storico.

## Informazioni storiche da NON assumere come correnti

- Le formulazioni tecniche e i guardrail elencati nel report del commit `4c5f43b...` non devono essere assunti automaticamente come contratti correnti.
- Il contenuto dettagliato della vecchia sezione di diagnosi e modularizzazione non deve essere assunto come ancora presente nel documento target.
- La creazione di `04-diagnosi-e-modularizzazione.md` risulta **storicamente completata**, ma la sua esistenza, forma e ownership correnti devono essere verificate nel CODE AUTHORITY.
- Le proposte testuali, gli esempi di riscrittura, l’ordine di applicazione e i controlli suggeriti dal report appartengono alla fase storica di audit e non costituiscono istruzioni per il technical writer.
- Le valutazioni di gravità, priorità e qualità presenti nel report non devono essere trasferite nel documento finale; il prompt di preparazione le qualifica come metadata storici dell’audit.

## Discrepanze o limiti delle fonti

- Il report documentale fotografa il documento al commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`, mentre la successiva technical writing dovrà usare `12b344ea96e71b2bdaa6931c98419ce925b5c228` come CODE AUTHORITY.
- Il report presenta `04-diagnosi-e-modularizzazione.md` come nuovo file **proposto**, mentre il registro TODO/JSON marca successivamente `CTX-003`, che ne prevedeva la creazione, come completata. Non è una discrepanza da risolvere tramite il materiale storico: lo stato effettivo va verificato nel CODE AUTHORITY.
- Non è stato fornito un report separato di applicazione/verifica delle quattro task; il loro stato storico deriva dal registro TODO/JSON, che le marca tutte come completate.
