TODO:

Report: [`../Report documentale/03 - 02-documentation-conventions.md`](../Report%20documentale/03%20-%2002-documentation-conventions.md) — `TDUI-DOC-REPORT-003`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`DOC-CONV-001`** — priorità `high` — Aggiornare nella tabella delle radici il ruolo di `docs/archive/`, dichiarandolo non canonico, preservato, non owner e non prova di implementazione.
- [x] **`DOC-CONV-002`** — priorità `medium` — Eliminare la formula «owner non ancora migrato» e descrivere il caso corrente in cui non esiste ancora un owner canonico.
- [x] **`DOC-CONV-003`** — priorità `high` — Sostituire integralmente la precedente politica di rimozione dell’archive con la policy corrente di conservazione ed esclusione dalle pulizie automatiche o generiche.
- [x] **`DOC-CONV-004`** — priorità `medium` — Rinominare `Migrazione MDX → Markdown` in `Procedura per modifiche documentali`, dichiarare conclusa la migrazione e aggiungere il collegamento al workflow esecutivo.

JSON:

    {
      "change_id": "DOC-CONV-001",
      "document_path": "docs/tennis-decision-ui/ai/02-documentation-conventions.md",
      "report_id": "TDUI-DOC-REPORT-003",
      "report_path": "../Report documentale/03 - 02-documentation-conventions.md",
      "priority": "high",
      "type": "archive_policy",
      "action": "Aggiornare nella tabella delle radici il ruolo di `docs/archive/`, dichiarandolo non canonico, preservato, non owner e non prova di implementazione.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "DOC-CONV-002",
      "document_path": "docs/tennis-decision-ui/ai/02-documentation-conventions.md",
      "report_id": "TDUI-DOC-REPORT-003",
      "report_path": "../Report documentale/03 - 02-documentation-conventions.md",
      "priority": "medium",
      "type": "migration_terminology",
      "action": "Eliminare la formula «owner non ancora migrato» e descrivere il caso corrente in cui non esiste ancora un owner canonico.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "DOC-CONV-003",
      "document_path": "docs/tennis-decision-ui/ai/02-documentation-conventions.md",
      "report_id": "TDUI-DOC-REPORT-003",
      "report_path": "../Report documentale/03 - 02-documentation-conventions.md",
      "priority": "high",
      "type": "archive_policy",
      "action": "Sostituire integralmente la precedente politica di rimozione dell’archive con la policy corrente di conservazione ed esclusione dalle pulizie automatiche o generiche.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "DOC-CONV-004",
      "document_path": "docs/tennis-decision-ui/ai/02-documentation-conventions.md",
      "report_id": "TDUI-DOC-REPORT-003",
      "report_path": "../Report documentale/03 - 02-documentation-conventions.md",
      "priority": "medium",
      "type": "documentation_state",
      "action": "Rinominare `Migrazione MDX → Markdown` in `Procedura per modifiche documentali`, dichiarare conclusa la migrazione e aggiungere il collegamento al workflow esecutivo.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }