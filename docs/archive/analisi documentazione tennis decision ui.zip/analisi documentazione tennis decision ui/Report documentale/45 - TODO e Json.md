TODO:

Report: [`Report documentale/45 - 01-piano-generale-audit.md`](../Report%20documentale/45%20-%2001-piano-generale-audit.md) — `TDUI-DOC-REPORT-045`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`PLAN-AUDIT-001`** — priorità `high` — Dichiarare in testa che il file conserva piano originario e snapshot storici dell’audit; indirizzare lo stato operativo corrente verso Todo, audit tecnico e root registry, evitando che sezioni future/differite ormai completate sembrino ancora il piano attivo.
- [x] **`PLAN-AUDIT-002`** — priorità `medium-high` — Aggiungere provenance agli snapshot 8.3–8.4 solo quando dimostrabile: data, SHA realmente verificato, commit di registrazione e fonte locale/non-repository; se la baseline della verifica non è ricostruibile usare `non registrato` senza trasformare il commit che aggiunge il testo nello SHA verificato.
- [x] **`PLAN-AUDIT-003`** — priorità `medium-high` — Definire esplicitamente `activity completion` vs `exhaustive coverage`: “audit/Punto completato” deve significare attività eseguita nel perimetro dichiarato, non checklist tutte verdi, finding chiusi, test tutti eseguiti o collaudi live conclusi.

JSON:

    {
      "change_id": "PLAN-AUDIT-001",
      "report_id": "TDUI-DOC-REPORT-045",
      "document_path": "implementazioni/01-piano-generale-audit.md",
      "priority": "high",
      "type": "audit_plan_temporal_authority",
      "action": "Dichiarare in testa che il file conserva piano originario e snapshot storici dell’audit; indirizzare lo stato operativo corrente verso Todo, audit tecnico e root registry, evitando che sezioni future/differite ormai completate sembrino ancora il piano attivo.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PLAN-AUDIT-002",
      "report_id": "TDUI-DOC-REPORT-045",
      "document_path": "implementazioni/01-piano-generale-audit.md",
      "priority": "medium-high",
      "type": "historical_checkpoint_provenance",
      "action": "Aggiungere provenance agli snapshot 8.3–8.4 solo quando dimostrabile: data, SHA realmente verificato, commit di registrazione e fonte locale/non-repository; se la baseline della verifica non è ricostruibile usare `non registrato` senza trasformare il commit che aggiunge il testo nello SHA verificato.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PLAN-AUDIT-003",
      "report_id": "TDUI-DOC-REPORT-045",
      "document_path": "implementazioni/01-piano-generale-audit.md",
      "priority": "medium-high",
      "type": "audit_completion_semantics",
      "action": "Definire esplicitamente `activity completion` vs `exhaustive coverage`: “audit/Punto completato” deve significare attività eseguita nel perimetro dichiarato, non checklist tutte verdi, finding chiusi, test tutti eseguiti o collaudi live conclusi.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }