# Scheda di contesto documentale

## Documento target

Percorso:
`docs/tennis-decision-ui/modules/storage/01-timelines-and-history.md`

Tipo di documento:
owner tecnico e facade della persistenza canonica timeline/history.

Ruolo documentale:
descrivere gli artefatti canonici timeline e history, la loro identità e i contratti storage comuni. Le responsabilità specifiche dei writer Sofa e Betfair risultano separate nei documenti `03-sofa-persistence.md` e `04-betfair-persistence.md`.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-154943).txt`
- `30 - Report 01-timelines-and-history(3).md` — report `TDUI-DOC-REPORT-030`
- `30 - TODO e Json(3).md` — mappa task e metadata JSON associati al report

## Task storicamente associate

- `STORAGE-TH-001` — stato: completata  
  Argomento coinvolto: risultati di lettura strutturati per timeline/history e distinzione tra documento mancante, non leggibile o non valido.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `STORAGE-TH-002` — stato: completata  
  Argomento coinvolto: identità e discovery univoca dei file canonici.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `STORAGE-TH-003` — stato: completata  
  Argomento coinvolto: distinzione tra stato osservato/preparato e stato committed nelle proiezioni cross-source.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `STORAGE-TH-004` — stato: completata  
  Argomento coinvolto: materialità distinta degli aggiornamenti history e timeline Sofa, inclusi `pointByPoint` e `localContext`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `STORAGE-TH-005` — stato: completata  
  Argomento coinvolto: proiezione Betfair per la history, identità tramite `selectionId`, valori mancanti e confronto indipendente dall'ordine dei runner.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `STORAGE-TH-006` — stato: completata  
  Argomento coinvolto: `latest` come view derivata e semantica degli aggiornamenti metadata su tick duplicato.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `STORAGE-TH-007` — stato: completata  
  Argomento coinvolto: facade storage, contratti di `loadHistoryResult` e `saveHistory`, ruolo compatibility prepare-only di `addBetfairUpdate` e ownership del commit Betfair.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `STORAGE-TH-008` — stato: completata  
  Argomento coinvolto: verification matrix relativa ai principali contratti storage, Sofa, Betfair, recovery e timeline.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.
- `STORAGE-TH-009` — stato: completata  
  Argomento coinvolto: modularizzazione della documentazione storage e relativa mappa di ownership.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- Modularizzazione eseguita: `01-timelines-and-history.md` è rimasto facade/core storage.
- Creato `docs/tennis-decision-ui/modules/storage/03-sofa-persistence.md` per le responsabilità specifiche della persistenza Sofa.
- Creato `docs/tennis-decision-ui/modules/storage/04-betfair-persistence.md` per le responsabilità specifiche della persistenza Betfair.
- `02-commit-journal-and-recovery.md` è rimasto owner separato di journal e recovery.
- Il report di applicazione del 2026-08-10 registra la revisione della facade e l'esito positivo delle suite interessate.

## Struttura precedente da considerare

- distinzione fra artefatti timeline e history;
- identità e shape dei documenti canonici;
- contratti di discovery, lettura e scrittura;
- scrittura atomica per singolo file;
- precondizione di writer authority;
- Source Identity come precondizione esterna allo storage;
- ownership map e collegamenti agli owner specifici;
- sezione di verifica dei contratti documentati.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/timelineStore.js`
- `backend/src/sofa/matchHistory/storage.js`
- `backend/src/sofa/matchHistory/sofaUpdates/`
- `backend/src/sofa/betfair/processor/persistence*`
- `backend/src/sofa/betfair/timeline/`
- `backend/src/runtime/matchHistoryWriterAuthority.js`
- suite storage/writer contract, Sofa, Betfair, recovery e canonical timeline direttamente associate

## Owner/documenti collegati

- `docs/tennis-decision-ui/modules/storage/02-commit-journal-and-recovery.md` — owner del commit journal e della recovery; questi temi non appartengono in dettaglio alla facade core.
- `docs/tennis-decision-ui/modules/storage/03-sofa-persistence.md` — owner delle regole specifiche di history/timeline Sofa, materialità, dedup, `localContext` e stato committed condiviso.
- `docs/tennis-decision-ui/modules/storage/04-betfair-persistence.md` — owner della persistenza Betfair, proiezione history, identità runner, status-only, `marketState` e cleanup legacy.

## Guardrail specifici per questo documento

- Mantenere il documento come facade/core storage, senza riassorbire i dettagli già assegnati agli owner Sofa, Betfair e journal/recovery.
- Descrivere soltanto i contratti confermati dal CODE AUTHORITY, distinguendo stato persistito, stato derivato e precondizioni esterne.
- Conservare la distinzione tra writer authority di processo e controlli interni alle primitive storage.
- Evitare duplicazioni con la documentazione di live tracking, validità del technical sample e Source Identity.
- Trattare le task completate come indici storici di aree da verificare, non come istruzioni da rieseguire.

## Informazioni storiche da NON assumere come correnti

- Le descrizioni tecniche, le firme API e i percorsi di test presenti nel report precedente alla sua applicazione.
- I finding, gli scenari di failure e le proposte contenuti nell'audit originario.
- Le responsabilità Sofa e Betfair precedentemente raccolte integralmente nel documento target prima della modularizzazione.
- L'esito storico PASS delle suite come sostituto della verifica sul CODE AUTHORITY indicato.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza individuata tra checkbox Markdown e metadata JSON: `STORAGE-TH-001`…`STORAGE-TH-009` risultano completate in entrambe le rappresentazioni.
- Le fonti fornite sono materiale storico e non includono il documento corrente né una verifica diretta del CODE AUTHORITY.
