TODO:

Report: [`Report documentale/49 - 05-audit-docs-planning.md`](../Report%20documentale/49%20-%2005-audit-docs-planning.md) — `TDUI-DOC-REPORT-049`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`PLANNING-AUDIT-001`** — **HIGH** — Separare la baseline usata per il confronto finale (`2697f66...`) dal commit che applica e registra la pulizia (`3de08ca...`); non sostituire una provenance con l’altra e registrare eventuale riallineamento archive successivo solo come metadata aggiuntivo dimostrabile.
- [x] **`PLANNING-AUDIT-002`** — **HIGH** — Etichettare il file come closeout storico del checkpoint di cleanup, qualificare `docs/archive/README.md` e `IMPL-015` come stato/next-step del checkpoint e indirizzare policy archive, stato IMPL e prossimo passo correnti verso i relativi owner senza riscrivere la storia.

JSON:

    {
      "change_id": "PLANNING-AUDIT-001",
      "report_id": "TDUI-DOC-REPORT-049",
      "document_path": "implementazioni/05-audit-docs-planning.md",
      "priority": "high",
      "type": "historical_cleanup_provenance",
      "action": "Separare la baseline usata per il confronto finale (`2697f66...`) dal commit che applica e registra la pulizia (`3de08ca...`); non sostituire una provenance con l’altra e registrare eventuale riallineamento archive successivo solo come metadata aggiuntivo dimostrabile.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PLANNING-AUDIT-002",
      "report_id": "TDUI-DOC-REPORT-049",
      "document_path": "implementazioni/05-audit-docs-planning.md",
      "priority": "high",
      "type": "temporal_authority_historical_closeout",
      "action": "Etichettare il file come closeout storico del checkpoint di cleanup, qualificare `docs/archive/README.md` e `IMPL-015` come stato/next-step del checkpoint e indirizzare policy archive, stato IMPL e prossimo passo correnti verso i relativi owner senza riscrivere la storia.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }