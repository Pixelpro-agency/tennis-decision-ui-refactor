# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/modules/betfair/02-technical-sample-validity.md`

Tipo di documento:  
owner tecnico

Ruolo documentale:  
documento owner della validità tecnica dei campioni Betfair, con responsabilità su classificazione del sample, confine di eleggibilità verso il processing canonico, distinzione tra campione non utilizzabile e mercato concluso, comportamento `repairOnly` e semantica dello status-only. La forma storica indica che questi aspetti appartengono a un unico contratto documentale.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `Report documentale/15 - 02-technical-sample-validity.md` — `TDUI-DOC-REPORT-015`
- `15 - TODO e Json.md`
- `PROMPT 0 — Preparazione Scheda neutra per technical writing`

## Task storicamente associate

- `TECH-SAMPLE-001` — stato: completata  
  Argomento coinvolto: shape minima dei runner nella classificazione del sample.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `TECH-SAMPLE-002` — stato: completata  
  Argomento coinvolto: identità canonica dei runner tramite `selectionId`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `TECH-SAMPLE-003` — stato: completata  
  Argomento coinvolto: rappresentazione del volume matched del runner quando il dato non è disponibile e rapporto con Money Flow.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `TECH-SAMPLE-004` — stato: completata  
  Argomento coinvolto: distinzione tra nuovi dati derivati dal sample e completamento fisico di un commit pending tramite repair.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `TECH-SAMPLE-005` — stato: completata  
  Argomento coinvolto: vocabolario dei reason di regressione ai diversi livelli del flusso.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `TECH-SAMPLE-006` — stato: completata  
  Argomento coinvolto: semantica dello status-only tra `marketState`, timeline canonica, history e Money Flow.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `TECH-SAMPLE-007` — stato: completata  
  Argomento coinvolto: distinzione tra baseline runner `marketState` e stato runtime di acquisizione Betfair.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `TECH-SAMPLE-008` — stato: completata  
  Argomento coinvolto: copertura di verifica per classifier, runner identity, volume non disponibile e status-only.  
  Uso consentito: verificare nel CODE AUTHORITY quali test correnti documentare.

- `TECH-SAMPLE-009` — stato: completata  
  Argomento coinvolto: separazione tra contratto corrente dell'owner e storico delle validation.  
  Uso consentito: verificare nel CODE AUTHORITY e nella struttura documentale corrente come viene mantenuto questo confine.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata e non ritenuta necessaria: il documento è rimasto un owner unico.
- Lo storico dettagliato dei collaudi è stato separato dal contratto permanente dell'owner e rinviato alle validation.
- Non risultano nuovi documenti canonici creati come effetto di questo report.

## Struttura precedente da considerare

- distinzione tra errore tecnico, mercato concluso e persistenza canonica;
- classifier del sample tecnico e confine verso il processing;
- confine `repairOnly`;
- semantica dello status-only;
- distinzione tra baseline runtime `marketState` e stato di acquisizione Betfair;
- sezione di verifica/test e rinvio alle validation storiche.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/betfair/processor/technicalSample.js`
- `backend/src/sofa/betfair/processor/runnerProcessing.js`
- `backend/src/sofa/betfair/processor/persistenceDecision.js`
- `backend/src/sofa/betfair/processor/persistence.js`
- `backend/src/sofa/betfair/processor/canonicalTimeline.js`
- `backend/src/sofa/betfair/timeline/state.js`
- `backend/src/sofa/betfair/timeline/statusOnlySnapshot.js`
- `backend/src/sofa/betfair/trackerUpdate.js`
- relativi test del processor, timeline e technical recovery

## Owner/documenti collegati

- `docs/validations/betfair-live-validation-2026-07-04.md` — validation storica richiamata dal report; non sostituisce il contratto corrente dell'owner.
- Le aree storage/persistence, Money Flow e runtime Betfair sono dipendenze tecniche citate dal report; il technical writer deve usarle soltanto per definire correttamente i confini dell'owner, senza ampliare lo scope ad altri documenti.

## Guardrail specifici per questo documento

- Mantenere il documento come owner unico della validità tecnica del sample Betfair, salvo evidenza contraria nella baseline corrente.
- Non trasformare lo storico delle task in una lista di lavori da rieseguire.
- Distinguere sempre ciò che riguarda il sample corrente da eventuale repair di un commit già journalizzato.
- Tenere separati `marketState`, timeline canonica e stato runtime/acquisition quando il CODE AUTHORITY conferma che hanno semantiche differenti.
- Non assumere equivalenza tra validità del totale mercato, validità dei dati runner, disponibilità del matched runner e successo della persistenza canonica.
- Conservare nell'owner il contratto corrente e rinviare le evidenze storiche di collaudo alle validation pertinenti.

## Informazioni storiche da NON assumere come correnti

- Le descrizioni tecniche, gli esempi e gli edge case del report derivano dalla baseline di audit `4c5f43b007149f3210c27d7565357a447a3a6ef4` e non sono authority sul codice corrente.
- I reason, le sequenze di processing, le regole su `selectionId`, matched volume, status-only e repair devono essere riletti nel CODE AUTHORITY prima di essere documentati come comportamento attuale.
- Le task risultano storicamente completate nel TODO/JSON, ma il loro effetto corrente deve essere verificato nel codice.
- Le validazioni live storiche non costituiscono automaticamente prova sul CODE AUTHORITY corrente.
- L'ordine di applicazione e le priorità presenti nel report appartengono all'audit storico e non devono guidare il technical writing.

## Discrepanze o limiti delle fonti

Nessuna discrepanza storica individuata tra il TODO Markdown e il JSON forniti: entrambe le fonti associano al documento le task `TECH-SAMPLE-001`–`TECH-SAMPLE-009` come completate.

Il report documentale è precedente al CODE AUTHORITY indicato per il technical writing; pertanto va usato come contesto storico e non come descrizione tecnica corrente.
