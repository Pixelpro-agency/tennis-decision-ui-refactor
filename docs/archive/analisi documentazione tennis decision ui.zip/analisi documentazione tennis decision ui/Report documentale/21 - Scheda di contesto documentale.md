# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/modules/frontend/02-live-polling-and-view-model.md`

Tipo di documento:  
Owner tecnico frontend.

Ruolo documentale:  
Descrivere congiuntamente il polling frontend e la costruzione del view model della dashboard, mantenendo confrontabili Match, Betfair, Evidence e Source Identity rispetto a session safety, freshness, distinzione current/last-known, integrity e stato delle connessioni.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`
- `21 - Report 02-live-polling-and-view-model.md` — `TDUI-DOC-REPORT-021`
- `21 - TODO e Json.md` — mappa Markdown e registrazioni JSON associate

## Task storicamente associate

- `FRONT-POLL-001` — stato: completata  
  Argomento coinvolto: session safety delle richieste Match e Betfair, con generation locale, request ownership, abort e stale-response guard.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `FRONT-POLL-002` — stato: completata  
  Argomento coinvolto: lifecycle di timer, richieste, Stop, cleanup e Resume.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `FRONT-POLL-003` — stato: completata  
  Argomento coinvolto: separazione tra dati correnti e last-known durante stati waiting, degraded o error.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `FRONT-POLL-004` — stato: completata  
  Argomento coinvolto: coerenza del view model quando il dato backend corrente diventa nullo.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `FRONT-POLL-005` — stato: completata  
  Argomento coinvolto: propagazione del read model Evidence, inclusi integrity, sources e persistence completeness.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `FRONT-POLL-006` — stato: completata  
  Argomento coinvolto: distinzione fra timestamp della sorgente e momento della lettura frontend.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `FRONT-POLL-007` — stato: completata  
  Argomento coinvolto: atomicità del fallback Betfair e coerenza fra data, health e history.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `FRONT-POLL-008` — stato: completata  
  Argomento coinvolto: derivazione delle connessioni dallo stato di lettura corrente.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `FRONT-POLL-009` — stato: completata  
  Argomento coinvolto: distinzione terminologica e funzionale fra `pollGeneration` frontend e autorità di sessione backend.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `FRONT-POLL-010` — stato: completata  
  Argomento coinvolto: verifiche lifecycle React e StrictMode per poller, fallback, Evidence e Gate.  
  Uso consentito: verificare nel CODE AUTHORITY i test correnti pertinenti.

## Cambiamenti strutturali storicamente rilevanti

- Modularizzazione valutata ma non ritenuta necessaria.
- Il documento è rimasto un facade comparativo unico per i poller e il view model frontend.
- Non risultano nuovi documenti canonici derivati.
- La fonte storica conclusiva dichiara una riscrittura del documento canonico successiva al report iniziale; contenuto e forma correnti devono essere verificati nella baseline tecnica.

## Struttura precedente da considerare

- Confronto separato fra polling Match, Betfair, Evidence e Source Identity.
- Catena polling → stato di lettura → view model → presentazione.
- Distinzione fra dato corrente e last-known.
- Separazione fra source time e fetch time.
- Separazione fra persistence integrity, runtime/Graph health e Source Identity.
- Confine fra frontend request generation e tracking session backend.
- Sezione di verifica del lifecycle dei poller.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `frontend/src/App.jsx`
- `frontend/src/hooks/useMatchPolling.js`
- `frontend/src/hooks/useBetfairJson.js`
- `frontend/src/hooks/useMarketReactionEvidence.js`
- `frontend/src/hooks/useSourceIdentityGateStatus.js`
- `frontend/src/hooks/useDashboardViewModel.js`
- `frontend/src/utils/dashboardConnections.js`
- `frontend/src/components/MarketReactionsPage.jsx`
- test lifecycle e helper direttamente associati ai poller e alle connessioni

## Owner/documenti collegati

- Documento Session Shell — confine relativo all’attivazione e all’identità della sessione frontend.
- Documento Source Identity — owner del gate e del relativo stato, consumato dal polling frontend.
- Documento Evidence Snapshot — owner del read model Evidence e dei suoi metadata di integrity.
- Documento Market Reactions — consumer del read model Evidence.
- Documento Data Lifecycle — riferimento per le semantiche temporali e di freshness.

Questi collegamenti servono a mantenere i confini di ownership; la Scheda non richiede modifiche agli altri documenti.

## Guardrail specifici per questo documento

- Conservare il ruolo di owner comparativo del polling e del view model frontend.
- Non trasformarlo nell’owner di journal, recovery o persistenza backend.
- Non attribuire alla generation locale del poller l’autorità della tracking session backend.
- Mantenere distinti dato corrente, last-known, stato della lettura, integrity, health e Source Identity.
- Documentare timestamp e freshness secondo la semantica verificata nel codice.
- Non dividere automaticamente il documento per singolo hook.
- Descrivere soltanto contratti presenti nel CODE AUTHORITY.

## Informazioni storiche da NON assumere come correnti

- Finding, giudizi di gravità e priorità del report originario.
- Gap e comportamenti osservati nel commit documentale storico.
- Soluzioni proposte, pseudo-codice, ordine di applicazione e test allora richiesti.
- Affermazioni sul lifecycle o sulla copertura dei test non riconfermate nel CODE AUTHORITY.
- Dichiarazione conclusiva di avvenuta implementazione delle dieci task senza riscontro nella baseline tecnica.
- Numeri storici relativi a file di test, build e controlli superati.

## Discrepanze o limiti delle fonti

- Markdown e JSON concordano su associazione, ID e completamento di `FRONT-POLL-001`–`FRONT-POLL-010`.
- Il report nasce come audit di una baseline documentale precedente e contiene un aggiornamento conclusivo successivo: descrive quindi più momenti storici.
- Non sono stati forniti il documento canonico corrente né il codice della CODE AUTHORITY; i comportamenti correnti restano da verificare nella fase di technical writing.
