# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/validations/source-identity-live-verification.md`

Tipo di documento:  
Validation storica basata su osservazione live manuale.

Ruolo documentale:  
Registrare una campagna storica relativa a Source Identity e alla relativa UI, distinguendo gli scenari osservati live, quelli soltanto riferiti e quelli non eseguiti. Non costituisce l’owner tecnico del gate, una specifica del comportamento corrente o una suite di validazione automatica.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `Report documentale/42 - source-identity-live-verification.md` — `TDUI-DOC-REPORT-042`.
- Sezione TODO e JSON relativa a `SOURCE-ID-VAL-001…003`.
- Fonte storica originale citata dal report: `docs/tennis-decision-ui/operations/06-source-identity-live-verification.mdx`.
- Versione del documento esaminata nella documentation structure baseline.

## Task storicamente associate

- `SOURCE-ID-VAL-001` — stato: completata  
  Argomento coinvolto: provenienza della migrazione e distinzione fra fonte storica e documento di destinazione.  
  Uso consentito: verificare nel CODE AUTHORITY e nella baseline documentale l’effetto corrente pertinente.

- `SOURCE-ID-VAL-002` — stato: completata  
  Argomento coinvolto: fedeltà della classificazione storica degli scenari di buffering, mismatch e TopBar Connected; riferimento alla route `/api/match/:eventId/json`.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente, senza modificare retroattivamente lo stato probatorio delle osservazioni storiche.

- `SOURCE-ID-VAL-003` — stato: completata  
  Argomento coinvolto: rappresentazione nel riepilogo degli scenari live osservati, soltanto riferiti o non eseguiti.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente, mantenendo separati test offline e osservazioni live.

## Cambiamenti strutturali storicamente rilevanti

- Il documento deriva dalla migrazione di una precedente pagina operativa verso l’area `docs/validations/`.
- La modularizzazione è stata valutata ma non ritenuta necessaria.
- Non risultano nuovi documenti canonici creati per separare i singoli scenari Source Identity.
- Le tre task associate risultano applicate come revisione documentale mirata, senza modifiche runtime.

## Struttura precedente da considerare

- Metadati della campagna: tipo, periodo, SHA e stato complessivo.
- Separazione degli scenari collecting, mismatch, restart, TopBar, pending, decline e limite cross-source.
- Distinzione esplicita fra `live_observed`, `historically_reported` e `not_executed`.
- Tabella finale di interpretazione.
- Separazione fra osservazione storica e owner tecnici correnti.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `frontend/src/App.jsx`
- `frontend/src/hooks/useSourceIdentityGateStatus.js`
- `frontend/src/hooks/useSourceIdentityGateUi.js`
- `frontend/src/hooks/useLiveTrackingActions.js`
- `frontend/src/components/marketReactions/SourceIdentityConfirmationModal.jsx`
- `backend/src/routes/match/sourceIdentityStatusResponse.js`
- `backend/src/sofa/sourceIdentityGate/manualConfirmation.js`
- Test del lifecycle, dei bootstrap failure, del mismatch e della presentazione Source Identity direttamente collegati.

## Owner/documenti collegati

- `docs/tennis-decision-ui/modules/evidence/02-source-identity.md` — owner del contratto corrente Source Identity.
- `docs/tennis-decision-ui/modules/frontend/01-session-shell.md` — owner del comportamento corrente della session shell e della presentazione frontend.
- `docs/validations/README.md` — contesto generale e classificazione degli artifact di validation.

Questi documenti definiscono ownership o contesto corrente; il documento target conserva invece una campagna storica e non deve sostituirli.

## Guardrail specifici per questo documento

- Conservare la natura di osservazione live manuale storica e lo stato complessivo parziale.
- Non presentare il documento come current PASS, owner tecnico o specifica futura.
- Mantenere separati fatti osservati live, informazioni soltanto riferite e scenari non eseguiti.
- Non promuovere test automatici o verifiche statiche correnti a evidenza live storica.
- Conservare `SHA non registrato` senza ricostruzioni retroattive.
- Non presentare il limite cross-source come evento riprodotto durante la stessa sessione live.
- Mantenere il documento unitario; eventuali future campagne live appartengono ad artifact separati.

## Informazioni storiche da NON assumere come correnti

- Il comportamento osservato nella sessione consolidata fino al 4 luglio 2026.
- Lo stato live di pending, conferma manuale, decline e bootstrap failure, indicati come non eseguiti nella campagna storica.
- L’assenza live di campi sensibili nella modale, pur in presenza di verifiche statiche successive.
- Il comportamento del toast verde nel restart o come singola transizione, quando non osservato nello scenario storico specifico.
- La condizione di buffering associata a `Sofa: In attesa`, della quale soltanto lo stato visualizzato risultava storicamente riferito.
- Il codice e i test citati dal report, che precedono il CODE AUTHORITY indicato per il technical writer.

## Discrepanze o limiti delle fonti

- La working tree esatta della sessione live storica non è registrata.
- Alcune osservazioni manuali non disponevano di screenshot, payload o log archiviati.
- Il report distingue verifiche offline correnti da osservazioni live storiche; queste categorie non devono essere sovrapposte.
- Markdown e JSON concordano sul completamento di `SOURCE-ID-VAL-001…003`; nessuna discrepanza storica è stata individuata tra i relativi stati.
