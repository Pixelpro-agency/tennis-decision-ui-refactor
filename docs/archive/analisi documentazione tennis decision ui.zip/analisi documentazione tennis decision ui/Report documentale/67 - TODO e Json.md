TODO:

Report: [`Report documentale/67 - 04-evidence-provenance.md`](../Report%20documentale/67%20-%2004-evidence-provenance.md) — `TDUI-DOC-REPORT-067`.

Modularizzazione: **valutata, non necessaria**.

- [ ] **`IMPL-EVIDENCE-001`** — **HIGH** — Sostituire per `IMPL-022/023/024` la formula `STRUTTURA COMPLETAMENTE ASSENTE` con uno stato bounded `APPROVATA, NON COMPLETATA` che elenchi le primitive legacy/current già presenti e i contratti owner ancora mancanti; preservare temporal alignment, Market Reactions, `causalityClaimed:false` e comparazioni runner esistenti, esplicitando i limiti da sostituire come future timestamp clamp, name fallback e price-source comparability incompleta.

JSON:

    {
      "change_id": "IMPL-EVIDENCE-001",
      "report_id": "TDUI-DOC-REPORT-067",
      "document_path": "implementazioni/implementazioni-proposte/04-evidence-provenance.md",
      "priority": "high",
      "type": "owner_state_granularity_existing_evidence_primitives",
      "action": "Sostituire per IMPL-022/023/024 la formula `STRUTTURA COMPLETAMENTE ASSENTE` con uno stato bounded `APPROVATA, NON COMPLETATA` che elenchi le primitive legacy/current già presenti e i contratti owner ancora mancanti; preservare temporal alignment, Market Reactions, causality false e comparazioni runner esistenti, esplicitando i limiti da sostituire come future timestamp clamp, name fallback e price-source comparability incompleta.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    }