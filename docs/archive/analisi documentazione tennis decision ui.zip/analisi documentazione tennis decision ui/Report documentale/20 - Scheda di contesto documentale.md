# Scheda di contesto documentale

## Documento target

**Percorso:**  
`docs/tennis-decision-ui/modules/frontend/01-session-shell.md`

**Tipo di documento:**  
Owner tecnico / facade documentale del lifecycle della sessione frontend.

**Ruolo documentale:**  
Descrivere come nasce, viene rappresentata e termina una sessione frontend, includendo shell dashboard, Start/Stop/Login, stato della sessione, bootstrap della dashboard, Source Identity UI, navigation e presentation degli stati di persistence, mantenendo visibili i confini fra composizione, lifecycle/state, trasformazioni pure, accesso HTTP e rendering. Il report storico identifica esplicitamente il documento come owner della sessione frontend, della shell dashboard e del lifecycle UI di Start/Stop/Source Identity.

## Baseline

**Code authority:**  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

**Documentation structure baseline:**  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

La seconda baseline corrisponde anche al commit sul quale era stato eseguito l'audit documentale storico; il CODE AUTHORITY indicato sopra è invece la baseline tecnica da usare per determinare il comportamento corrente.

## Fonti storiche consultate

- `Report documentale/20 - 01-session-shell.md` — `TDUI-DOC-REPORT-020`.
- `20 - TODO e Json.md` — registro sintetico delle task associate e relativo JSON.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing` — criteri e baseline per la presente Scheda.

Il report registra inoltre un'applicazione successiva delle modifiche associate a `FRONT-SESSION-002`–`FRONT-SESSION-010`, con suite frontend, build e checker documentali indicati come superati. Il TODO/JSON successivo marca come completate tutte le task `FRONT-SESSION-001`–`FRONT-SESSION-010`.

## Task storicamente associate

- `FRONT-SESSION-001` — stato: **completata**  
  Argomento coinvolto: semantica del Preflight nel lifecycle di Start e distinzione fra diagnostica Preflight e authorization della sessione.  
  Uso consentito: verificare nel CODE AUTHORITY il comportamento corrente del Preflight e documentarlo soltanto nel suo rapporto con Start.

- `FRONT-SESSION-002` — stato: **completata**  
  Argomento coinvolto: momento di promozione della configurazione a sessione active/confirmed e gestione dello Start non riuscito.  
  Uso consentito: verificare nel CODE AUTHORITY l'attuale session activation authority.

- `FRONT-SESSION-003` — stato: **completata**  
  Argomento coinvolto: `sessionActive` e authority comune degli effetti frontend legati alla sessione.  
  Uso consentito: verificare quali consumer dipendono oggi dall'autorità della sessione, lasciando i dettagli interni del polling al relativo owner.

- `FRONT-SESSION-004` — stato: **completata**  
  Argomento coinvolto: bootstrap/readiness della dashboard e associazione alla sessione corrente tramite session identity, storicamente collegata a `trackingSessionId`.  
  Uso consentito: verificare quale criterio corrente distingue i dati della nuova sessione da dati persistiti precedenti.

- `FRONT-SESSION-005` — stato: **completata**  
  Argomento coinvolto: contratto frontend delle azioni Start/Login/Stop e relativa rappresentazione degli esiti.  
  Uso consentito: verificare il contratto corrente di service, hook e UI pertinente alla shell.

- `FRONT-SESSION-006` — stato: **completata**  
  Argomento coinvolto: conferma Source Identity e successiva verifica dello stato live.  
  Uso consentito: verificare nel CODE AUTHORITY quale stato live autorizza oggi il completamento della confirmation UI.

- `FRONT-SESSION-007` — stato: **completata**  
  Argomento coinvolto: relazione fra decline della Source Identity confirmation, Stop e ritorno al form.  
  Uso consentito: verificare l'ordine e gli stati UI correnti senza assumere automaticamente il flusso storico.

- `FRONT-SESSION-008` — stato: **completata**  
  Argomento coinvolto: modello del persistent Chrome profile e stato sessione associato.  
  Uso consentito: verificare quali campi e quale rappresentazione del profile path esistono nel CODE AUTHORITY.

- `FRONT-SESSION-009` — stato: **completata**  
  Argomento coinvolto: presentation frontend read-only della persistence integrity attraverso le diverse superfici della shell.  
  Uso consentito: verificare come gli stati già forniti da hook/API sono aggregati e rappresentati oggi.

- `FRONT-SESSION-010` — stato: **completata**  
  Argomento coinvolto: copertura del lifecycle frontend e separazione fra contratto canonico e storico di validation.  
  Uso consentito: verificare le suite correnti e citare nel documento owner soltanto la verification pertinente al contratto corrente.

Gli stati `[x]` e le associazioni documento/task sono confermati dal TODO e dal JSON storico.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata ma non ritenuta necessaria: Start, stato active/confirmed, attivazione dei consumer, Source Identity, bootstrap, dashboard e Stop sono stati considerati parti dello stesso lifecycle frontend. Non risultano nuovi documenti canonici creati per suddividere questo owner.
- Il report registra successivamente l'applicazione di session activation transazionale, authority `sessionActive`/`trackingSessionId`, bootstrap legato alla sessione, contratti bounded per Start/Login/Stop, verifica live della Source Identity confirmation, gestione del decline subordinata allo Stop, rimozione dello stato legacy `chromeProfileName`, persistence view state read-only e suite lifecycle dedicate. Questi elementi sono contesto storico da verificare nel CODE AUTHORITY prima di documentarli come correnti.
- Il documento canonico risulta essere stato successivamente aggiornato/riscritto rispetto alla versione oggetto dell'audit originario; il report stesso segnala che il contratto successivo è descritto nel documento canonico riscritto.
- La validation manuale storica era stata riconosciuta come responsabilità da tenere distinta dal contratto permanente del modulo frontend, essendo già presente un owner validation dedicato a Source Identity.

## Struttura precedente da considerare

- Facade unico del lifecycle: Start → stato della sessione → attivazione dei consumer → Source Identity → bootstrap → dashboard → Stop/mismatch.
- Separazione dei ruoli interni: `App.jsx` per composizione; hook per lifecycle/state; utils per trasformazioni pure; service per HTTP; componenti per rendering.
- Aree tematiche storiche: current/confirmed session state, Start/Stop/Login, shell readiness e waiting screen, Source Identity UI, navigation, persistence presentation e boundaries.
- Sezione di verification collegata al lifecycle, da distinguere dallo storico dei collaudi manuali.
- Struttura mantenuta come documento unico: la suddivisione in documenti separati per Start/Stop, Source Identity UI e shell navigation era stata valutata e non adottata.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `frontend/src/App.jsx`
- `frontend/src/hooks/useAnalysisSessionState.js`
- `frontend/src/hooks/useLiveTrackingActions.js`
- `frontend/src/hooks/useDashboardBootstrapState.js`
- `frontend/src/hooks/useBetfairLoginAction.js`
- `frontend/src/hooks/useSourceIdentityGateStatus.js` e `frontend/src/hooks/useSourceIdentityGateUi.js`
- `frontend/src/hooks/useMatchPolling.js`, `useBetfairJson.js`, `useMarketReactionEvidence.js` e `useDashboardViewModel.js`, limitatamente ai confini con la session shell
- `frontend/src/services/liveSessionApi.js` e utility session/request collegate
- `frontend/src/components/StartAnalysisPanel.jsx`, `DashboardWorkspace.jsx` e `marketReactions/SourceIdentityConfirmationModal.jsx`
- suite lifecycle e utility test associate a session state, Start/Stop, bootstrap, Source Identity e persistence presentation

Queste aree derivano direttamente dall'insieme di sorgenti utilizzato dal report per analizzare il documento.

## Owner/documenti collegati

- `02-live-polling-and-view-model.md` — owner dei dettagli di polling quali scheduling, stale-response handling e meccanismi equivalenti; `01-session-shell.md` mantiene invece l'authority e il lifecycle della sessione.
- Owner validation Source Identity dedicato — possiede lo storico di collaudo Source Identity; il percorso esatto non è indicato nelle fonti fornite.
- Owner Evidence — la Source Identity riportata da Evidence non costituisce, secondo il confine storico, l'authority del gate UI; i percorsi esatti degli owner Evidence non sono specificati nella fonte.
- Area Preflight/API — relazione storica esplicitata tramite `PREFLIGHT-API-005`; serve a comprendere il confine fra diagnostica Preflight e lifecycle della shell.
- Session authority — relazione storica con `IMPL-006` e con le task Source Identity `SOURCE-ID-001`/`SOURCE-ID-002`; i relativi documenti owner non sono identificati per percorso nelle fonti fornite.
- Persistent/physical Betfair profile — relazione storica con `BETFAIR-LIFE-003`, distinta dall'ownership del session state frontend.

## Guardrail specifici per questo documento

- Mantenere `01-session-shell.md` come facade del lifecycle frontend, senza trasformarlo nell'owner dei dettagli interni già posseduti da hook o documenti specialistici.
- Conservare il confine fra composizione, lifecycle/state, trasformazioni pure, service HTTP e rendering quando tale separazione è confermata dal CODE AUTHORITY.
- Documentare l'autorità reale della sessione e non inferirla soltanto dalla presenza di URL, dati persistiti o visibilità della shell.
- Per Source Identity UI, verificare il live status come fonte del gate; non assumere Evidence come authority della confirmation UI.
- Per persistence integrity, limitare questo owner alla presentation/read state frontend derivata da hook/API. Il report stabilisce come confine storico che la shell non possiede accesso diretto a journal, history/timeline storage o recovery.
- Lasciare a `02-live-polling-and-view-model.md` i dettagli tecnici di polling e stale-response management.
- Non trasformare lo storico di validation in una seconda definizione del contratto corrente.
- Non estendere questo documento alla rimozione o alla progettazione delle view Strategy legacy, già attribuite ad ownership separata.
- Qualunque comportamento descritto nel materiale storico deve essere confermato contro il CODE AUTHORITY prima di essere presentato come corrente.

## Informazioni storiche da NON assumere come correnti

- Le osservazioni tecniche contenute nella parte iniziale di `TDUI-DOC-REPORT-020` descrivono il codice/documento analizzato alla baseline storica `4c5f43b...`, non il CODE AUTHORITY successivo.
- Non assumere come correnti né le condizioni originariamente osservate nell'audit né, senza verifica, i loro esiti successivi.
- In particolare, sono storici gli stati relativi a: semantica Preflight; promozione active/confirmed della sessione; `sessionActive` e `trackingSessionId`; bootstrap session-bound; error contract di Start/Login/Stop; confirmation/decline Source Identity; persistent profile; persistence integrity view state; suite lifecycle. Le fonti dichiarano queste aree successivamente aggiornate, ma l'autorità tecnica resta il commit `12b344ea96e71b2bdaa6931c98419ce925b5c228`.
- Non assumere automaticamente come correnti neppure proprietà che l'audit precedente considerava già coerenti, come semantica CDP, comportamento di Stop, logging runtime o stato delle view Strategy: vanno confermate se rientrano nella riscrittura del documento.
- I risultati storici di 22 suite frontend, production build, documentation links e registry consistency sono evidenza del passaggio di applicazione registrato, non una verifica eseguita sul CODE AUTHORITY durante la preparazione di questa Scheda.

## Discrepanze o limiti delle fonti

- Non è stato fornito il contenuto corrente di `docs/tennis-decision-ui/modules/frontend/01-session-shell.md`; la forma e il testo effettivi al CODE AUTHORITY devono quindi essere recuperati nella fase di technical writing.
- Il report originario è basato sulla documentation structure baseline `4c5f43b...` e contiene anche aggiornamenti successivi di applicazione: le due fasi temporali non devono essere confuse.
- La sezione di applicazione del report nomina esplicitamente `FRONT-SESSION-002`–`FRONT-SESSION-010` come applicate e verificate, mentre il TODO/JSON successivo marca `[x]` anche `FRONT-SESSION-001`. Non emerge una contraddizione sullo stato finale, ma la conferma di `FRONT-SESSION-001` proviene dal registro successivo e non dalla stessa frase di esito implementativo. - I percorsi esatti dell'owner validation Source Identity e degli owner Evidence non sono indicati nel materiale fornito.
- Non risultano discrepanze fra TODO e JSON relativamente agli ID `FRONT-SESSION-001`–`FRONT-SESSION-010`, alla loro associazione con `01-session-shell.md` o al loro stato storico finale di completamento.