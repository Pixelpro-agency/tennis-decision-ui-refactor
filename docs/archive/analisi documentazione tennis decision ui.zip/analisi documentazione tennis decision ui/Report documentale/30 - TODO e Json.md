TODO:

Report: [`Report documentale/30 - 01-timelines-and-history.md`](../Report%20documentale/30%20-%2001-timelines-and-history.md) — `TDUI-DOC-REPORT-030`.

Modularizzazione: **eseguita**. File creati: `docs/tennis-decision-ui/modules/storage/03-sofa-persistence.md`, `docs/tennis-decision-ui/modules/storage/04-betfair-persistence.md`.

- [x] **`STORAGE-TH-001`** — priorità `critical` — Introdurre read result strutturati e fail-closed per timeline/history: missing distinto da discovery/read/invalid_json/invalid_shape; un documento canonico non leggibile non deve essere normalizzato a vuoto né sovrascritto.
- [x] **`STORAGE-TH-002`** — priorità `high` — Rendere univoca la canonical file discovery: zero candidati=missing, uno=found, più di uno=ambiguous_storage_target; nessun sort()[0] o cleanup automatico del candidato extra.
- [x] **`STORAGE-TH-003`** — priorità `critical` — Separare state observed/prepared da committed: la projection usata nella history cross-source deve provenire solo da commit complete/recovered; failure, partial e status-only regressivo non devono contaminare il writer successivo.
- [x] **`STORAGE-TH-004`** — priorità `high` — Separare materialità history e timeline Sofa: pointByPoint/localContext possono richiedere un nuovo tick anche se la projection history è invariata, senza creare righe history artificiali e preservando il journal.
- [x] **`STORAGE-TH-005`** — priorità `high` — Rendere la projection Betfair history identity-safe e missing-preserving: selectionId come identity, missing distinto da zero, confronto runner order-independent e nessun fallback zero-like/mojibake.
- [x] **`STORAGE-TH-006`** — priorità `medium` — Documentare latest come view derivata e non campo persistito; decidere e testare la semantica metadata-only quando il tick è duplicato.
- [x] **`STORAGE-TH-007`** — priorità `medium` — Riallineare la facade storage: documentare loadHistoryResult, firma saveHistory con commitId e addBetfairUpdate come compatibility prepare-only, indicando il vero owner del commit Betfair.
- [x] **`STORAGE-TH-008`** — priorità `high` — Ricostruire la verification matrix storage con corrupt/invalid-shape no-overwrite, ambiguous discovery, cross-source uncommitted leakage, status-only leakage, localContext-only materiality, selection identity e missing semantics.
- [x] **`STORAGE-TH-009`** — priorità `medium` — Mantenere 01-timelines-and-history.md come facade/core e 02-commit-journal-and-recovery.md come owner journal; creare 03-sofa-persistence.md e 04-betfair-persistence.md, aggiornando index, link e owner map senza aggiungere i file all'inventario finché non esistono.

JSON:

    {
      "change_id": "STORAGE-TH-001",
      "report_id": "TDUI-DOC-REPORT-030",
      "document_path": "docs/tennis-decision-ui/modules/storage/01-timelines-and-history.md",
      "priority": "critical",
      "type": "canonical_read_write_safety",
      "action": "Introdurre read result strutturati e fail-closed per timeline/history: missing distinto da discovery/read/invalid_json/invalid_shape; un documento canonico non leggibile non deve essere normalizzato a vuoto né sovrascritto.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STORAGE-TH-002",
      "report_id": "TDUI-DOC-REPORT-030",
      "document_path": "docs/tennis-decision-ui/modules/storage/01-timelines-and-history.md",
      "priority": "high",
      "type": "storage_identity",
      "action": "Rendere univoca la canonical file discovery: zero candidati=missing, uno=found, più di uno=ambiguous_storage_target; nessun sort()[0] o cleanup automatico del candidato extra.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STORAGE-TH-003",
      "report_id": "TDUI-DOC-REPORT-030",
      "document_path": "docs/tennis-decision-ui/modules/storage/01-timelines-and-history.md",
      "priority": "critical",
      "type": "cross_source_commit_consistency",
      "action": "Separare state observed/prepared da committed: la projection usata nella history cross-source deve provenire solo da commit complete/recovered; failure, partial e status-only regressivo non devono contaminare il writer successivo.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STORAGE-TH-004",
      "report_id": "TDUI-DOC-REPORT-030",
      "document_path": "docs/tennis-decision-ui/modules/storage/01-timelines-and-history.md",
      "priority": "high",
      "type": "canonical_change_detection",
      "action": "Separare materialità history e timeline Sofa: pointByPoint/localContext possono richiedere un nuovo tick anche se la projection history è invariata, senza creare righe history artificiali e preservando il journal.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STORAGE-TH-005",
      "report_id": "TDUI-DOC-REPORT-030",
      "document_path": "docs/tennis-decision-ui/modules/storage/01-timelines-and-history.md",
      "priority": "high",
      "type": "history_canonical_representation",
      "action": "Rendere la projection Betfair history identity-safe e missing-preserving: selectionId come identity, missing distinto da zero, confronto runner order-independent e nessun fallback zero-like/mojibake.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STORAGE-TH-006",
      "report_id": "TDUI-DOC-REPORT-030",
      "document_path": "docs/tennis-decision-ui/modules/storage/01-timelines-and-history.md",
      "priority": "medium",
      "type": "timeline_document_contract",
      "action": "Documentare latest come view derivata e non campo persistito; decidere e testare la semantica metadata-only quando il tick è duplicato.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STORAGE-TH-007",
      "report_id": "TDUI-DOC-REPORT-030",
      "document_path": "docs/tennis-decision-ui/modules/storage/01-timelines-and-history.md",
      "priority": "medium",
      "type": "documentation_api_ownership",
      "action": "Riallineare la facade storage: documentare loadHistoryResult, firma saveHistory con commitId e addBetfairUpdate come compatibility prepare-only, indicando il vero owner del commit Betfair.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STORAGE-TH-008",
      "report_id": "TDUI-DOC-REPORT-030",
      "document_path": "docs/tennis-decision-ui/modules/storage/01-timelines-and-history.md",
      "priority": "high",
      "type": "verification_contract",
      "action": "Ricostruire la verification matrix storage con corrupt/invalid-shape no-overwrite, ambiguous discovery, cross-source uncommitted leakage, status-only leakage, localContext-only materiality, selection identity e missing semantics.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STORAGE-TH-009",
      "report_id": "TDUI-DOC-REPORT-030",
      "document_path": "docs/tennis-decision-ui/modules/storage/01-timelines-and-history.md",
      "priority": "medium",
      "type": "documentation_modularization",
      "action": "Mantenere 01-timelines-and-history.md come facade/core e 02-commit-journal-and-recovery.md come owner journal; creare 03-sofa-persistence.md e 04-betfair-persistence.md, aggiornando index, link e owner map senza aggiungere i file all'inventario finché non esistono.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }