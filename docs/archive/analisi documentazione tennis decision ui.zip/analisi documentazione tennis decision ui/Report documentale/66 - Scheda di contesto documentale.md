# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/implementazioni-proposte/03-storage-recovery.md`

Tipo di documento:  
registro owner tecnico relativo a persistence authority, canonical document contract e recovery control plane.

Ruolo documentale:  
mantenere in un unico owner il perimetro di `IMPL-019…021`, che copre in sequenza autorità di commit sull'evento, contratto canonico di storage e gestione dello stato di recovery.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `66 - Report 03-storage-recovery.md` — report `TDUI-DOC-REPORT-066` relativo al documento target.
- `66 - TODO e Json.md` — stato Markdown/JSON delle modifiche documentali `IMPL-STORAGE-001` e `IMPL-STORAGE-002`.

## Task storicamente associate

- `IMPL-019` — stato: non completata  
  Argomento coinvolto: event persistence authority e coordinamento dei commit sul medesimo evento.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `IMPL-020` — stato: non completata  
  Argomento coinvolto: canonical document contract e verified recovery; il report storico registrava anche primitive preesistenti collegate al recovery.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente senza assumere completato l'intero contratto.

- `IMPL-021` — stato: non completata  
  Argomento coinvolto: recovery control plane; il report storico registrava primitive già presenti ma non equivalenti al perimetro completo della task.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `IMPL-STORAGE-001` — stato: non completata  
  Argomento coinvolto: distinzione documentale fra primitive storage/recovery già presenti e contratto residuo di `IMPL-019…021`.  
  Uso consentito: non assumerne l'applicazione; verificare nel CODE AUTHORITY e nel documento corrente quale distinzione sia oggi pertinente.

- `IMPL-STORAGE-002` — stato: non completata  
  Argomento coinvolto: metadata di dipendenza e sequencing fra `IMPL-019…021` e task collegate.  
  Uso consentito: non assumere che la normalizzazione storicamente proposta sia stata eseguita.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata e non ritenuta necessaria; non risultano nuovi file proposti per suddividere il documento.
- Il perimetro storico resta unitario su `IMPL-019`, `IMPL-020` e `IMPL-021`.

## Struttura precedente da considerare

- tre owner distinti nello stesso documento: `IMPL-019`, `IMPL-020`, `IMPL-021`;
- catena concettuale fra event commit authority, canonical storage identity, verified recovery e recovery/operator state;
- presenza di relazioni di dipendenza e sequencing fra gli owner e task collegate.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/matchHistory.js`
- `backend/src/sofa/matchHistory/storage.js`
- `backend/src/sofa/timelineStore.js`
- `backend/src/sofa/matchHistory/commitJournal/`
- `backend/src/sofa/matchHistory/recovery.js`
- `backend/src/server.js`

## Owner/documenti collegati

- `todo-list-tennis-decision-ui.md` — fonte storica di coordinamento degli owner e dei relativi stati.
- `IMPL-015` — relazione storica con la writer authority process-level.
- `IMPL-008`, `IMPL-009` e `IMPL-013` — relazioni storiche di validazione, integrazione o sequencing citate dal report; la loro semantica corrente deve essere verificata senza estendere lo scope documentale.

## Guardrail specifici per questo documento

- Mantenere il documento nel ruolo di owner registry storage/recovery, senza trasformarlo in runbook, audit o registro di bug.
- Conservare la distinzione concettuale fra autorità di scrittura sull'evento, contratto dei documenti persistiti e controllo del recovery.
- La presenza storica di primitive di journal, target verification, recovery bootstrap o integrity state non equivale automaticamente al completamento di `IMPL-019…021`.
- Non introdurre una suddivisione in nuovi documenti sulla sola base del report storico.

## Informazioni storiche da NON assumere come correnti

- Lo stato `OPEN` di `IMPL-019…021` registrato dal report.
- La specifica distinzione fra primitive allora presenti e parti allora mancanti.
- Lo stato dei requirement `TEST-019…030`, che il report storico indicava come non completati.
- Le relazioni di dependency/sequencing descritte dal report prima di un'eventuale successiva normalizzazione.
- `IMPL-STORAGE-001` e `IMPL-STORAGE-002` come modifiche già applicate: Markdown e JSON forniti le registrano ancora come pending/non completate.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza individuata fra Markdown e JSON forniti per `IMPL-STORAGE-001` e `IMPL-STORAGE-002`: entrambi risultano non completati.
- Il report documentale fu prodotto rispetto a un HEAD storico diverso dal CODE AUTHORITY assegnato alla successiva fase di technical writing; le affermazioni sul comportamento runtime devono quindi essere riverificate sulla nuova baseline.
- Il documento target corrente non è tra le fonti fornite; la sua forma precedente è quindi ricostruibile soltanto in modo sintetico dal report storico.
