# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/implementazioni-proposte/04-evidence-provenance.md`

Tipo di documento:  
registro owner tecnico relativo al dominio Evidence.

Ruolo documentale:  
raccogliere e descrivere i contratti proposti relativi a provenance/allineamento temporale, Market Reactions e identità/comparabilità temporale dei runner. Il perimetro storico del documento comprende `IMPL-022`, `IMPL-023` e `IMPL-024`.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `Report documentale/67 - 04-evidence-provenance.md` — `TDUI-DOC-REPORT-067`.
- `67 - TODO e Json.md`.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing`.

Il report storico dichiara che l'audit riguardava il documento target e il perimetro `IMPL-022…024`.

## Task storicamente associate

- `IMPL-022` — stato storico: non completata.  
  Argomento coinvolto: provenance temporale, freshness, source skew, policy di allineamento e provenance delle finestre temporali. Il materiale storico segnala inoltre la presenza di primitive temporali precedenti/correnti.
  Uso consentito: verificare nel CODE AUTHORITY quali strutture siano effettivamente correnti e documentare soltanto quelle pertinenti al ruolo del documento.

- `IMPL-023` — stato storico: non completata.  
  Argomento coinvolto: Market Reactions, eligibility degli input, stato uniforme dei branch, osservazioni di mercato e gestione delle finestre. Il report distingue il contratto proposto dalle primitive Market Reactions già esistenti al momento dell'audit.
  Uso consentito: verificare nel CODE AUTHORITY il comportamento corrente senza assumere che il target storico sia stato realizzato.

- `IMPL-024` — stato storico: non completata.  
  Argomento coinvolto: identità temporale dei runner, uso di `selectionId`, provenienza e comparabilità dei prezzi, baseline temporali e coverage dei runner.
  Uso consentito: verificare nel CODE AUTHORITY quali parti siano oggi effettivamente presenti.

- `IMPL-EVIDENCE-001` — stato storico: non completata.  
  Argomento coinvolto: granularità con cui il documento descrive lo stato di `IMPL-022/023/024` e distinzione fra primitive esistenti e contratti ancora non presenti. Nel TODO storico è registrata con checkbox aperta e `status: pending`.
  Uso consentito: non assumere che la relativa revisione documentale sia già stata applicata; confrontare documento e CODE AUTHORITY prima di stabilire la formulazione corrente.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata ma non risultava necessaria; non erano previsti nuovi file derivati dal documento.
- Il report classificava l'intervento documentale come revisione mirata, non come riscrittura completa.
- Al momento del report, mappa Markdown e ledger JSON generali non erano stati modificati.

## Struttura precedente da considerare

- Documento unitario articolato attorno a tre aree correlate:
  - `IMPL-022` — temporal provenance/alignment;
  - `IMPL-023` — Market Reactions;
  - `IMPL-024` — runner temporal identity/price comparability.
- Le tre aree erano mantenute nello stesso owner document perché temporal provenance, comparabilità dei runner e Market Reaction eligibility condividono un contesto cross-source.
- Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/matchEvidence/latestMatchEvidence.js`
- `backend/src/sofa/matchEvidence/evidenceBuilder.js`
- `backend/src/sofa/matchEvidence/alignment.js`
- `backend/src/sofa/matchEvidence/alignmentExtension.js`
- `backend/src/sofa/temporalAlignmentEvidence.js`
- `backend/src/sofa/temporalAlignment/betfairMove/`
- `backend/src/sofa/marketReactionEvidence.js`
- `backend/src/sofa/significantMarketFlowEvidence.js`
- `backend/src/sofa/marketLedObservationEvidence.js`
- `backend/src/sofa/fieldLedReactionEvidence.js`
- relativi test Evidence/Market Reactions.

Queste sono le principali aree di codice citate dal report storico come fonti del dominio documentato.

## Owner/documenti collegati

- `IMPL-018` — dipendenza storicamente dichiarata per la provenance di acquisizione utilizzata dal dominio temporale; il confine descritto nel report è che `IMPL-018` produce la provenance mentre `IMPL-022` ne interpreta la semantica.
- `IMPL-012` e `IMPL-013` — riferimenti coordinati dal documento storico, da considerare soltanto per comprendere eventuali confini con fixture/replay e baseline/calibrazione.

Non assumere che questi owner debbano essere modificati insieme al documento target.

## Guardrail specifici per questo documento

- Mantenere la natura di registro owner tecnico e il perimetro Evidence, senza trasformarlo in runbook, documento operativo o report di audit.
- Distinguere sempre fra comportamento verificato nel CODE AUTHORITY e contratti descritti come target storico.
- Non dedurre che una primitive esistente equivalga al completamento dell'intero contratto associato.
- Non dedurre lo stato dei nuovi requirement o dei relativi test dalla sola presenza di test legacy; il report storico distingue esplicitamente legacy coverage e completamento dei nuovi TEST-ID.
- Mantenere separati, se ancora presenti nel codice, i confini fra Source Identity/persistence gating e l'eligibility interna al dominio Evidence.
- Eventuali affermazioni su non causalità, assenza di signal/strategy e purezza dei builder devono essere confermate sul CODE AUTHORITY prima di essere presentate come stato corrente.

## Informazioni storiche da NON assumere come correnti

- Le descrizioni tecniche del codice presenti nel report 067 appartengono alla fotografia storica dell'audit e non sostituiscono il CODE AUTHORITY.
- Non assumere automaticamente come corrente la formula storica `STRUTTURA COMPLETAMENTE ASSENTE`, né la formulazione alternativa proposta dal report: entrambe devono essere confrontate con lo stato attuale del codice.
- Non assumere come correnti i dettagli storici relativi a `maxTickGapSec`, future timestamp clamp, fallback per nome runner, price-source handling, branch state, eligibility o threshold/calibration.
- Non assumere come ancora mancanti o ancora presenti `TEST-031…043` sulla sola base del report.
- Non assumere che `IMPL-EVIDENCE-001` sia stata eseguita: nel TODO fornito risulta ancora aperta e `pending`.
- Approval e priorità riportate dall'audit sono metadata storici e non devono guidare la riscrittura tecnica.

## Discrepanze o limiti delle fonti

- Il report documentale fotografa un audit basato sull'HEAD `4c5f43b007149f3210c27d7565357a447a3a6ef4`, mentre la Scheda deve preparare il lavoro rispetto al CODE AUTHORITY successivo `12b344ea96e71b2bdaa6931c98419ce925b5c228`; di conseguenza le affermazioni sul comportamento del codice presenti nel report devono essere riverificate.
- Il TODO/JSON disponibile registra `IMPL-EVIDENCE-001` come non completata; non è presente fra le fonti fornite un successivo report di applicazione che ne dimostri l'esecuzione.
- Non risultano dalle fonti fornite modifiche strutturali effettivamente applicate al documento dopo il report 067.