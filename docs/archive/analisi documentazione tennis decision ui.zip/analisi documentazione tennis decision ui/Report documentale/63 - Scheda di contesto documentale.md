# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/audit-documentazione/04-processo-e-materiali-storici.md`

Tipo di documento:  
record storico di processo e classificazione dei materiali documentali/locali; il report lo descrive anche come `decision log + inventory/classification record`.

Ruolo documentale:  
conservare il checkpoint storico delle decisioni che hanno preparato la migrazione documentale e il trattamento dei materiali precedenti, senza fungere da backlog corrente. Le sezioni 16 e 17 formano una catena unica: decisioni di processo → classificazione dei materiali → migrazione/consolidamento/cleanup. 
## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`
- `Report documentale/63 - 04-processo-e-materiali-storici.md` — `TDUI-DOC-REPORT-063`
- `63 - TODO e Json.md`, contenente la registrazione TODO/JSON di `DOC-AUDIT-PROC-001`.

## Task storicamente associate

- `DOC-AUDIT-PROC-001` — stato: non completata
  Argomento coinvolto: distinzione temporale tra checkpoint storico delle sezioni 16–17 ed esiti successivi della migrazione documentale.
  Uso consentito: non assumere la task come comportamento già applicato; verificare nel CODE AUTHORITY lo stato corrente pertinente prima di descriverlo. Il TODO/JSON fornito la registra come `pending` / `completed: false`.

Gli altri ID citati nel report 063 risultano principalmente authority, owner o task già coordinate con questo documento e non costituiscono una nuova famiglia autonoma del file 063. 
## Cambiamenti strutturali storicamente rilevanti

- La proposta storica di collocare workflow e guida AI in `implementazioni/07-workflow-esecutivo.md` e `implementazioni/08-linee-guida-chat-e-ai.md` risulta successivamente assorbita nei documenti canonici sotto `docs/tennis-decision-ui/ai/`.
- `docs/validations/`, descritta nel checkpoint come struttura futura, risulta successivamente divenuta una struttura effettiva.
- `docs/_work` e `percorsi.txt` risultano storicamente rimossi dopo l'assorbimento delle informazioni utili. - I materiali legacy risultano passati attraverso una fase di archivio temporaneo, consolidamento delle informazioni utili e successiva rimozione delle copie separate.

## Struttura precedente da considerare

- §16: principi e decisioni sul processo documentale, inclusi context selection, formato Markdown, validations e promemoria UI.
- §17: inventario e classificazione di nove materiali storici/locali e relativo trattamento.
- Le due sezioni appartengono alla stessa lifecycle chain e la valutazione storica non richiedeva modularizzazione del documento.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `implementazioni/audit-documentazione/04-processo-e-materiali-storici.md`
- `docs/tennis-decision-ui/ai/01-context-selection.md`
- `docs/tennis-decision-ui/ai/03-workflow-esecutivo.md`
- `docs/validations/`
- `docs/validations/documentation-migration-finalization-2026-08-03.md`
- `todo-list-tennis-decision-ui.md`

Queste sono le superfici direttamente richiamate dal report per distinguere il checkpoint storico dagli owner e dagli esiti successivi.

## Owner/documenti collegati

- `implementazioni/02-audit-documentazione.md` — parent che assegna al file il ruolo di modulo relativo a processo e materiali consolidati.
- `docs/tennis-decision-ui/ai/01-context-selection.md` — owner corrente indicato dal report per le regole di selezione del contesto.
- `docs/tennis-decision-ui/ai/03-workflow-esecutivo.md` — owner corrente indicato per il workflow esecutivo.
- `docs/validations/README.md` e `docs/validations/documentation-migration-finalization-2026-08-03.md` — riferimenti storici per struttura delle validations e outcome della migrazione.

## Guardrail specifici per questo documento

- Preservare la natura di record storico e non trasformarlo in un secondo backlog corrente.
- Conservare la distinzione tra decisione/proposta al checkpoint ed esito successivo.
- Non interpretare l'assenza dei vecchi path `implementazioni/07` e `08` come prova che debbano esistere.
- Non usare la colonna storica “Stato attuale” della §17.6 come authority dello stato corrente delle task.
- Non interpretare “informazione assorbita nei registri” come prova che la relativa funzionalità sia implementata.
- Non inferire SHA assenti dalle fonti storiche.
- Non ripristinare automaticamente materiali legacy, `_work`, `percorsi.txt` o copie d'archivio soltanto perché compaiono nel checkpoint storico. 
## Informazioni storiche da NON assumere come correnti

- I path proposti `implementazioni/07-workflow-esecutivo.md` e `implementazioni/08-linee-guida-chat-e-ai.md`.
- La descrizione di `docs/validations/` come struttura soltanto futura.
- La presenza corrente di `docs/_work`, `percorsi.txt` o delle copie legacy/archive.
- Gli stati delle nove task riportati nella §17.6 al momento della sintesi storica.
- Le classificazioni “da archiviare”, “da deprecare” o equivalenti come azioni ancora da eseguire oggi.
- Qualunque idea/requisito registrato nella §17.7 come prova autonoma di implementazione. 
## Discrepanze o limiti delle fonti

- Il report 063 fotografa il momento dell'audit e dichiara che mappa Markdown e ledger JSON non erano stati aggiornati e che `DOC-AUDIT-PROC-001` non era ancora consolidato.
- Il materiale TODO/JSON fornito successivamente registra invece `DOC-AUDIT-PROC-001` come voce esistente ma ancora `pending`; ciò rappresenta un aggiornamento storico successivo, non prova della sua esecuzione.
- Le fonti storiche non costituiscono authority tecnica corrente; il CODE AUTHORITY deve essere usato dalla successiva chat per verificare gli outcome effettivamente presenti.