TODO:

Report: [`Report documentale/37 - 01-repository-map.md`](../Report%20documentale/37%20-%2001-repository-map.md) — `TDUI-DOC-REPORT-037`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`REPO-MAP-001`** — priorità `high` — Aggiungere `launcher/session.py` alla superficie launcher e distinguerne sinteticamente la responsabilità per lock, manifest e launcher session identity rispetto ad app/services/system/config.
- [x] **`REPO-MAP-002`** — priorità `high` — Aggiungere `backend/source_identity_confirmations.json` alla classificazione dei dati locali persistiti: non cache, non versionare, task-specific only e non cancellare automaticamente; rimandare agli owner Source Identity/Retention.
- [x] **`REPO-MAP-003`** — priorità `medium` — Correggere il riferimento a `IMPL-003`: non è una `mappa completa`, ma la matrice test ↔ modulo ↔ documento; non creare una seconda repository map.

JSON:

    {
      "change_id": "REPO-MAP-001",
      "report_id": "TDUI-DOC-REPORT-037",
      "document_path": "docs/tennis-decision-ui/reference/01-repository-map.md",
      "priority": "high",
      "type": "launcher_repository_orientation",
      "action": "Aggiungere `launcher/session.py` alla superficie launcher e distinguerne sinteticamente la responsabilità per lock, manifest e launcher session identity rispetto ad app/services/system/config.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "REPO-MAP-002",
      "report_id": "TDUI-DOC-REPORT-037",
      "document_path": "docs/tennis-decision-ui/reference/01-repository-map.md",
      "priority": "high",
      "type": "persisted_local_state_context_safety",
      "action": "Aggiungere `backend/source_identity_confirmations.json` alla classificazione dei dati locali persistiti: non cache, non versionare, task-specific only e non cancellare automaticamente; rimandare agli owner Source Identity/Retention.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "REPO-MAP-003",
      "report_id": "TDUI-DOC-REPORT-037",
      "document_path": "docs/tennis-decision-ui/reference/01-repository-map.md",
      "priority": "medium",
      "type": "cross_reference_semantics",
      "action": "Correggere il riferimento a IMPL-003: non è una `mappa completa`, ma la matrice test ↔ modulo ↔ documento; non creare una seconda repository map.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }