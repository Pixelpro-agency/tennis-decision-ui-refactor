TODO:

Report: [`Report documentale/63 - 04-processo-e-materiali-storici.md`](../Report%20documentale/63%20-%2004-processo-e-materiali-storici.md) — `TDUI-DOC-REPORT-063`.

Modularizzazione: **valutata, non necessaria**.

- [ ] **`DOC-AUDIT-PROC-001`** — **HIGH** — Aggiungere una overlay post-migrazione alle sezioni 16–17 senza riscrivere il checkpoint storico: marcare i path `implementazioni/07-workflow-esecutivo.md` e `implementazioni/08-linee-guida-chat-e-ai.md` come proposta superseded dai documenti AI canonici correnti; registrare `docs/validations/` come implementata, `_work` e `percorsi.txt` come rimossi, i materiali legacy come temporaneamente archiviati, consolidati e poi rimossi; qualificare §17.6 come stato al checkpoint e rimandare lo stato corrente a Todo/owner.

JSON:

    {
      "change_id": "DOC-AUDIT-PROC-001",
      "report_id": "TDUI-DOC-REPORT-063",
      "document_path": "implementazioni/audit-documentazione/04-processo-e-materiali-storici.md",
      "priority": "high",
      "type": "historical_process_authority_migration_outcome_reconciliation",
      "action": "Aggiungere una overlay post-migrazione alle sezioni 16–17 senza riscrivere il checkpoint storico: marcare i path `implementazioni/07-workflow-esecutivo.md` e `08-linee-guida-chat-e-ai.md` come proposta superseded dai documenti canonici AI correnti; registrare `docs/validations/` come implementata, `_work` e `percorsi.txt` come rimossi, i materiali legacy come temporaneamente archiviati, consolidati e poi rimossi; qualificare §17.6 come stato al checkpoint e rimandare lo stato corrente a Todo/owner.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    }