TODO:

Report: [`../Report documentale/02 - 01-context-selection.md`](../Report%20documentale/02%20-%2001-context-selection.md) — `TDUI-DOC-REPORT-002`.

Modularizzazione: **richiesta**. File proposti: `docs/tennis-decision-ui/ai/04-diagnosi-e-modularizzazione.md`.

- [x] **`CTX-001`** — priorità `medium` — Ridurre `01-context-selection.md` alla selezione del contesto e sostituire le sezioni che duplicano il workflow con un rinvio a `03-workflow-esecutivo.md`.
- [x] **`CTX-002`** — priorità `high` — Rendere condizionali `fileModificati.md`, metodo di consegna e report finale; dichiarare che i ruoli read-only non creano `fileModificati.md`.
- [x] **`CTX-003`** — priorità `medium` — Creare `docs/tennis-decision-ui/ai/04-diagnosi-e-modularizzazione.md`, spostarvi la sezione di diagnosi e modularizzazione e aggiornare i collegamenti documentali.
- [x] **`CTX-004`** — priorità `medium` — Trasformare i «confini tecnici permanenti» in guardrail condizionali collegati ai rispettivi documenti owner.

JSON:

{
      "change_id": "CTX-001",
      "document_path": "docs/tennis-decision-ui/ai/01-context-selection.md",
      "report_id": "TDUI-DOC-REPORT-002",
      "report_path": "../Report documentale/02 - 01-context-selection.md",
      "priority": "medium",
      "type": "document_ownership",
      "action": "Ridurre `01-context-selection.md` alla selezione del contesto e sostituire le sezioni che duplicano il workflow con un rinvio a `03-workflow-esecutivo.md`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "CTX-002",
      "document_path": "docs/tennis-decision-ui/ai/01-context-selection.md",
      "report_id": "TDUI-DOC-REPORT-002",
      "report_path": "../Report documentale/02 - 01-context-selection.md",
      "priority": "high",
      "type": "operational_consistency",
      "action": "Rendere condizionali `fileModificati.md`, metodo di consegna e report finale; dichiarare che i ruoli read-only non creano `fileModificati.md`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "CTX-003",
      "document_path": "docs/tennis-decision-ui/ai/01-context-selection.md",
      "report_id": "TDUI-DOC-REPORT-002",
      "report_path": "../Report documentale/02 - 01-context-selection.md",
      "priority": "medium",
      "type": "document_split",
      "action": "Creare `docs/tennis-decision-ui/ai/04-diagnosi-e-modularizzazione.md`, spostarvi la sezione di diagnosi e modularizzazione e aggiornare i collegamenti documentali.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "CTX-004",
      "document_path": "docs/tennis-decision-ui/ai/01-context-selection.md",
      "report_id": "TDUI-DOC-REPORT-002",
      "report_path": "../Report documentale/02 - 01-context-selection.md",
      "priority": "medium",
      "type": "owner_references",
      "action": "Trasformare i «confini tecnici permanenti» in guardrail condizionali collegati ai rispettivi documenti owner.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    