# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/audit-codice/03-storage-recovery.md`

Tipo di documento:  
Modulo owner di audit tecnico storico.

Ruolo documentale:  
Documentare il secondo audit del Punto 4 relativo alla persistenza: history condivisa, timeline, commit journal, recovery, integrità, contratti di lettura e autorità dei writer. Il documento conserva il contesto della baseline analizzata e non rappresenta automaticamente lo stato tecnico corrente.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-235001).txt`
- `55 - Report 03-storage-recovery.md` — `TDUI-DOC-REPORT-055`
- `55 - TODO e Json.md`
- Riferimenti interni del report alla Todo, alla proposta implementativa e ai documenti di coordinamento.

## Task storicamente associate

- `IMPL-015` — stato: completata  
  Argomento coinvolto: bootstrap della recovery prima dell’avvio in ascolto del server.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `STORAGE-001` — stato: non completata  
  Argomento coinvolto: autorità event-scoped sulla history condivisa e coordinamento cross-source.  
  Uso consentito: non assumere il target storico come comportamento implementato.

- `STORAGE-002` — stato: non completata  
  Argomento coinvolto: verifica dei target già marcati come completati durante recovery parziali.  
  Uso consentito: non assumere il target storico come comportamento implementato.

- `STORAGE-003` — stato: non completata  
  Argomento coinvolto: validazione canonica dei documenti recuperati, oltre la sola leggibilità JSON.  
  Uso consentito: non assumere il target storico come comportamento implementato.

- `STORAGE-004` — stato: non completata  
  Argomento coinvolto: trattamento dei journal non validi o non attribuibili.  
  Uso consentito: non assumere il target storico come comportamento implementato.

- `STORAGE-005` — stato: non completata  
  Argomento coinvolto: integrità aggregata della history condivisa.  
  Uso consentito: non assumere il target storico come comportamento implementato.

- `STORAGE-006` — stato: non completata  
  Argomento coinvolto: separazione fra stato candidato e stato canonico effettivamente committato.  
  Uso consentito: non assumere il target storico come comportamento implementato.

- `STORAGE-007` — stato: non completata  
  Argomento coinvolto: risultati di lettura strutturati e distinzione fra assenza, invalidità, errore e ambiguità.  
  Uso consentito: non assumere il target storico come comportamento implementato.

- `STORAGE-008` — stato: non completata  
  Argomento coinvolto: gestione di documenti duplicati per lo stesso evento.  
  Uso consentito: non assumere il target storico come comportamento implementato.

- `STORAGE-009` — stato: non completata  
  Argomento coinvolto: metadata e stato persistito dei tentativi di recovery.  
  Uso consentito: non assumere il target storico come comportamento implementato.

- `STORAGE-010` — stato: non completata  
  Argomento coinvolto: costo delle riscritture complete dei documenti e relativa misurazione.  
  Uso consentito: verificare soltanto ciò che il CODE AUTHORITY rende attualmente documentabile.

- `STORAGE-011` — stato: non completata  
  Argomento coinvolto: distinzione fra atomicità del processo e durabilità in caso di power loss.  
  Uso consentito: verificare soltanto ciò che il CODE AUTHORITY rende attualmente documentabile.

- `STORAGE-012` — stato: non completata  
  Argomento coinvolto: superficie dei writer raw e relativa autorità.  
  Uso consentito: non assumere il target storico come comportamento implementato.

- `SECURITY-006` — stato: non completata  
  Argomento coinvolto: validazione dell’event ID e confinamento dei percorsi di persistenza.  
  Uso consentito: non assumere il target storico come comportamento implementato.

- `IMPL-019` — stato: non completata  
  Argomento coinvolto: autorità di persistenza event-scoped e coordinamento dei commit cross-source.  
  Uso consentito: verificare nel CODE AUTHORITY l’eventuale effetto corrente pertinente.

- `IMPL-020` — stato: non completata  
  Argomento coinvolto: contratto canonico dei documenti e recovery verificata.  
  Uso consentito: verificare nel CODE AUTHORITY l’eventuale effetto corrente pertinente.

- `IMPL-021` — stato: non completata  
  Argomento coinvolto: control plane della recovery e stato globale dell’integrità.  
  Uso consentito: verificare nel CODE AUTHORITY l’eventuale effetto corrente pertinente.

- `TEST-019`–`TEST-030` — stato: non completate  
  Argomenti coinvolti: coordinamento cross-source, verifica dei target, identità dei documenti, integrità aggregata, stato committato, risultati di lettura, duplicati, confinamento dei percorsi, writer raw e tentativi di recovery.  
  Uso consentito: non attribuire alla baseline corrente esiti PASS sulla base del solo materiale storico.

## Cambiamenti strutturali storicamente rilevanti

- La recovery prima del `listen` risulta storicamente associata alla chiusura di `IMPL-015`.
- Il documento mantiene `IMPL-019…021` come sintesi; i relativi owner sono esterni al modulo.
- La modularizzazione è stata valutata e dichiarata non necessaria.
- Non risultano nuovi file, nuove task o una riscrittura applicata in conseguenza del report 055.

## Struttura precedente da considerare

- Un solo audit point e una sola baseline storica.
- Catena documentale unitaria: documenti canonici → journal → recovery → integrità → reader → writer authority.
- Sezioni distinte per `STORAGE-001…012`, `SECURITY-006`, Source Identity store, sintesi implementative, test, decisioni e ordine storico.
- Separazione esplicita fra analisi statica, decisioni approvate, test mancanti e limiti da misurare.
- Sequenza journalizzata e relazione fra writer authority, recovery e avvio del server.
- Distinzione fra `no_known_partial` e salute effettiva dei documenti.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/matchHistory/recovery.js`
- `backend/src/sofa/matchHistory/sofaUpdates/recovery.js`
- `backend/src/sofa/matchHistory.js`
- `backend/src/routes/match/readResponses.js`
- Commit journal, writer authority e relativi test di recovery/persistenza.
- Bootstrap del server, limitatamente all’ordine recovery → listen.

## Owner/documenti collegati

- `implementazioni/implementazioni-proposte/03-storage-recovery.md` — owner storico delle sintesi `IMPL-019…021`.
- `implementazioni/03-audit-codice.md` — contesto generale dell’audit codice.
- `todo-list-tennis-decision-ui.md` — registro storico degli stati.
- `implementazioni/99-decisioni-utente.md` — decisioni di progetto pertinenti.
- Famiglia `STORAGE-TH-*` — approfondimenti successivi sui contratti di timeline/history.
- Famiglia `JOURNAL-REC-*` — approfondimenti successivi su journal, recovery e verifica dei target.

## Guardrail specifici per questo documento

- Mantenere il ruolo di audit storico legato alla baseline dichiarata.
- Non trasformare decisioni approvate o target descritti in comportamenti correnti senza verifica.
- Non convertire il documento in runbook, roadmap implementativa o registro dello stato corrente.
- Conservare il confine fra atomicità process-level e durabilità power-loss.
- Conservare la distinzione fra assenza di parzialità nota e salute verificata dei documenti.
- Non duplicare gli owner `IMPL-019…021`, `STORAGE-TH-*` o `JOURNAL-REC-*`.
- Non fondere il Source Identity confirmation store con il journal delle timeline senza evidenza nel CODE AUTHORITY.
- Non interpretare l’ordine storico delle task come coda operativa corrente.

## Informazioni storiche da NON assumere come correnti

- Gli stati e i comportamenti osservati sulla baseline storica `d797d0ee9ec70d4b2f85f6aa51b91af8f71227a1`.
- Le verifiche del codice riportate dal report 055.
- Lo stato aperto delle task come prova che il comportamento sia ancora assente nel CODE AUTHORITY.
- Le suite indicate come non rieseguite e i test `TEST-019…030` indicati come mancanti.
- I target architetturali descritti dalle task approvate ma non completate.
- Qualsiasi valutazione storica su priorità, gravità o qualità tecnica.

## Discrepanze o limiti delle fonti

- Il materiale `55 - TODO e Json.md` contiene la nota Markdown, ma non presenta un payload JSON strutturato dopo l’etichetta `JSON:`; non è quindi disponibile un confronto autonomo Markdown–JSON.
- Il report 055 riguarda una baseline tecnica precedente al CODE AUTHORITY indicato per il technical writer.
- Il report dichiara un’analisi statica e specifica che le suite non furono rieseguite in quel checkpoint.
- Nessuna discrepanza storica esplicita è individuabile nelle fonti disponibili.
