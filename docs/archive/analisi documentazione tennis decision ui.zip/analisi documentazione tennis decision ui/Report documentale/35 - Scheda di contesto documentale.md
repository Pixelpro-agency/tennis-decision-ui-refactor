# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/operations/04-validation-and-rollback.md`

Tipo di documento:  
Runbook operativo.

Ruolo documentale:  
Orientare la scelta e l’interpretazione delle validazioni successive a una modifica, distinguere i diversi livelli di evidenza e descrivere un rollback selettivo che non coinvolga dati runtime o modifiche estranee alla task.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-174524).txt`
- `35 - Report 04-validation-and-rollback.md` — `TDUI-DOC-REPORT-035`
- `35 - TODO e Json.md`

## Task storicamente associate

- `VALID-ROLL-001` — stato: non completata  
  Argomento coinvolto: identificazione della working tree validata, stato pre/post esecuzione e relazione con il rollback selettivo.  
  Uso consentito: non assumere queste garanzie come implementate; verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `VALID-ROLL-002` — stato: non completata  
  Argomento coinvolto: significato dei profili offline, metadata `requires`, ambiente ereditato dai processi e portata di `TEST-073`.  
  Uso consentito: non assumere l’isolamento delle capability come implementato; verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `VALID-ROLL-003` — stato: non completata  
  Argomento coinvolto: completezza del profilo aggregato `full-offline` rispetto alle entry del manifest.  
  Uso consentito: non assumere la completezza automatica del profilo; verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `VALID-ROLL-004` — stato: completata  
  Argomento coinvolto: semantica dei conteggi del runner, natura eterogenea di `perTestResults` e distinzione fra stato del workflow e stato dell’esecuzione.  
  Uso consentito: verificare nel CODE AUTHORITY il comportamento corrente e documentarlo soltanto nella misura pertinente al runbook.

- `VALID-ROLL-005` — stato: non completata  
  Argomento coinvolto: timeout e terminazione dell’albero di processi appartenente al runner.  
  Uso consentito: non assumere il drain completo dei processi discendenti; verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `VALID-ROLL-006` — stato: completata  
  Argomento coinvolto: distinzione fra link checker, registry checker, controlli strutturali e verifiche automatiche, manuali o storiche.  
  Uso consentito: verificare nel CODE AUTHORITY e negli owner collegati la copertura corrente pertinente.

- `VALID-ROLL-007` — stato: completata  
  Argomento coinvolto: confine delle validazioni HTTP e stato del route harness associato a `TEST-072`.  
  Uso consentito: verificare nel CODE AUTHORITY quali harness e test HTTP risultano correnti.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata e ritenuta non necessaria.
- Il documento conserva un unico owner operativo: validazione delle modifiche e rollback sicuro.
- Non risultano nuovi documenti canonici derivati dal report.
- Le modifiche completate hanno interessato soprattutto chiarimenti semantici e delimitazione della copertura, non la separazione del documento.

## Struttura precedente da considerare

- Semantica degli esiti e dei livelli di evidenza.
- Scelta del confine di validazione.
- Runner canonico e relativi profili.
- Eccezioni o verifiche specifiche per dominio.
- Report, provenienza e validazioni storiche.
- Rollback selettivo.
- Limiti correnti dell’infrastruttura.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `scripts/validation/run.mjs`
- `scripts/validation/test-manifest.json`
- `scripts/validation/manifest-schema.json`
- `scripts/validation/result-schema.json`
- `scripts/validation/support/process-runner.mjs`
- `scripts/validation/support/result.mjs`
- `scripts/validation/support/redaction.mjs`
- `scripts/validation/run.test.mjs`
- `scripts/check_documentation_links.py`
- `scripts/check_registry_consistency.py`
- `backend/src/server.test.mjs`
- `frontend/src/App.jsx`

## Owner/documenti collegati

- `scripts/validation/README.md` — owner tecnico del runner e dei suoi contratti.
- `docs/validations/README.md` — owner del formato e dei metadata delle validazioni storiche.
- Registri delle implementazioni e dei `TEST-ID` — owner dello stato delle infrastrutture e delle validazioni pianificate o completate.
- `modules/storage/` — dettagli specialistici di persistence e recovery.
- `modules/frontend/` — dettagli specialistici delle verifiche frontend.
- `operations/02-live-tracking-control.md` — confine operativo delle verifiche live.
- `operations/03-betfair-diagnostics.md` — confine operativo delle verifiche diagnostiche Betfair.

Questi owner forniscono dettagli specialistici che il runbook può richiamare senza assorbirne la responsabilità.

## Guardrail specifici per questo documento

- Mantenere distinta la presenza di un test dalla sua esecuzione e da un PASS corrente.
- Non equiparare build, test automatici, osservazione browser e verifica live.
- Non presentare il manifest come inventario completo senza conferma corrente.
- Non trasformare il documento nell’owner del runner, del ledger, degli algoritmi di recovery o degli harness specialistici.
- Conservare il rollback entro i file e il perimetro della task.
- Non descrivere come procedure ordinarie cancellazioni indiscriminate, reset generali, cleanup dei dati runtime o terminazioni basate su porte e processi non attribuiti.
- Riutilizzare l’authority delle validazioni storiche senza duplicarne il formato.

## Informazioni storiche da NON assumere come correnti

- Le task `VALID-ROLL-001`, `002`, `003` e `005` risultano aperte nelle fonti.
- Un HEAD SHA non va assunto come identificazione completa di una working tree modificata.
- I profili `fast` e `full-offline` non vanno assunti come sandbox di capability.
- `TEST-073` non va assunto come prova tecnica dell’assenza di rete, browser o credenziali.
- La completezza automatica del profilo `full-offline` non risulta storicamente stabilita.
- Il timeout del processo diretto non va assunto come prova della terminazione di tutti i discendenti.
- Lo stato di `TEST-072`, `IMPL-003`, `IMPL-031` e delle altre dipendenze citate deve essere ricavato dal CODE AUTHORITY e dai registri correnti.

## Discrepanze o limiti delle fonti

- Markdown e JSON risultano concordi sullo stato delle sette task.
- Il report è materiale storico riferito alla documentation structure baseline e non costituisce authority tecnica corrente.
- Il documento target corrente non era incluso tra le fonti consultate.
- Gli snapshot storici non risultano aggiornati retroattivamente dopo il completamento di `VALID-ROLL-004`, `006` e `007`.
