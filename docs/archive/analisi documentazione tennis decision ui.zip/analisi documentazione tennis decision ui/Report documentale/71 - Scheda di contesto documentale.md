# Scheda di contesto documentale

## Documento target

Percorso:  
`scripts/validation/README.md`

Tipo di documento:  
README operativo / documento di validation.

Ruolo documentale:  
Guida operativa al validation runner locale: ne descrive uso, comandi e profili, codici di uscita, struttura del manifest, artifact prodotti e limiti della prima versione. Le fonti storiche lo distinguono da una test map completa, da un ledger storico degli esiti, da un catalogo fixture, da un harness DOM/React e da una definizione CI.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `71 - Report validation-README.md` — report documentale `TDUI-DOC-REPORT-071`.
- `71 - TODO e Json.md` — registrazione Markdown/JSON della task associata al documento.

## Task storicamente associate

- `VALID-RUNNER-001` — stato: non completata.
  Argomento coinvolto: boundary live/offline del validation runner a livello di entry/capability selezionata e relativo allineamento documentale.
  Uso consentito: non assumere il target come comportamento già implementato; verificare nel CODE AUTHORITY quale comportamento corrente sia effettivamente presente e documentare soltanto quello pertinente al README.

- `IMPL-028` — stato: storicamente completata secondo il report.
  Argomento coinvolto: prima versione del validation runner, manifest, profili, result artifact e self-test.
  Uso consentito: verificare nel CODE AUTHORITY quali parti della consegna storica siano ancora correnti e pertinenti al README.

- `TEST-073` — stato: storicamente completata secondo il report.
  Argomento coinvolto: protezioni del profilo `fast` rispetto a capacità live-sensitive.
  Uso consentito: usarla soltanto come contesto storico; il technical writer deve verificare nel CODE AUTHORITY il comportamento corrente prima di descriverlo.

- `IMPL-003`, `IMPL-008`, `IMPL-013`, `IMPL-029`, `IMPL-030`, `IMPL-031` — stato storico: non sufficientemente determinato dalle fonti fornite.
  Argomento coinvolto: rispettivamente confini della mappatura test/owner/documento, persistence, benchmark, fixture/sandbox, frontend interaction harness e historical/result ledger.
  Uso consentito: considerarli esclusivamente come riferimenti di ownership o dipendenza storica, senza assumerne lo stato corrente.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata e indicata come non necessaria.
- Non risultano nuovi file documentali proposti per sostituire o suddividere questo README.
- Il documento storico era trattato come un unico README operativo coeso.

## Struttura precedente da considerare

La forma precedente comprendeva in modo unitario:

- scope e ruolo del runner;
- comandi e profili;
- codici di uscita;
- manifest e relativi campi;
- inventario persistence;
- artifact e redaction;
- limiti della prima versione.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `scripts/validation/run.mjs`
- `scripts/validation/run.test.mjs`
- `scripts/validation/test-manifest.json`
- `scripts/validation/support/manifest.mjs`
- `scripts/validation/support/process-runner.mjs`
- `scripts/validation/support/result.mjs`
- `scripts/validation/support/redaction.mjs`
- `scripts/validation/support/paths.mjs`
- `.gitignore`, per il solo confine relativo agli artifact di validation.
- `backend/src/sofa/matchHistory/commitJournal.test.mjs` e `backend/src/sofa/matchHistory/recovery.test.mjs`, soltanto per verificare se l'inventario persistence storicamente riportato dal README sia ancora valido.

## Owner/documenti collegati

- `implementazioni/implementazioni-proposte/06-validazione-e-fixture.md` — fonte storicamente collegata ai confini di validation, fixture e profili pianificati.
- `todo-list-tennis-decision-ui.md` — registro storico richiamato dal report per task e ownership; non va trattato come authority tecnica.
- `IMPL-031` — confine storico del ledger degli esiti: il README del runner non deve essere trasformato automaticamente in un registro storico.
- `IMPL-003` — confine storico della mappatura completa test ↔ owner ↔ documento, distinta dal ruolo operativo del README.

## Guardrail specifici per questo documento

- Mantenere la natura di README operativo del validation runner; non convertirlo in audit, roadmap, test map, ledger storico, catalogo fixture, harness frontend o definizione CI.
- Descrivere solo profili, flag, codici di uscita, vincoli e artifact verificati nel CODE AUTHORITY.
- Non presentare `VALID-RUNNER-001` come comportamento implementato sulla sola base della task storica.
- Non dedurre l'esistenza o il percorso di test persistence dai nomi dei moduli: verificare i path reali nel CODE AUTHORITY.
- Conservare eventuali note di provenance temporale soltanto se servono ancora al ruolo del README e senza trasformarle in affermazioni assolute.
- Distinguere l'artifact della singola esecuzione dal ledger storico degli esiti, se tale confine risulta ancora presente nel CODE AUTHORITY.

## Informazioni storiche da NON assumere come correnti

- Tutte le verifiche tecniche del report 071 erano riferite alla baseline documentale/storica `4c5f43b007149f3210c27d7565357a447a3a6ef4`, non al CODE AUTHORITY indicato per la successiva riscrittura.
- La fonte storica registrava `VALID-RUNNER-001` come pending; non deve quindi essere usata per affermare che il relativo comportamento sia già presente.
- L'assenza storica di `commitJournal.test.mjs`, `recovery.test.mjs` e di `.github/workflows/` deve essere ricontrollata.
- I profili `persistence`, `benchmark` e `live` risultavano storicamente pianificati/disabilitati; il loro stato corrente deve essere verificato.
- Il finding storico relativo al boundary live/offline non deve essere trasferito nel README come giudizio di audit; può servire soltanto a individuare l'area da verificare nel codice corrente.
- Valutazioni di priorità, gravità, hardening proposto, acceptance criteria e self-test richiesti nel report non sono contenuto documentale corrente.

## Discrepanze o limiti delle fonti

- Il report 071 registra che, al momento della chiusura dell'audit, mappa Markdown e ledger JSON non erano stati modificati; il file `71 - TODO e Json.md` fornito successivamente registra invece `VALID-RUNNER-001` come pending. Le fonti sembrano quindi rappresentare momenti diversi della registrazione storica.
- TODO e JSON forniti concordano sullo stato `pending` / non completato di `VALID-RUNNER-001`; non emerge una discrepanza semantica tra le due rappresentazioni.
- Le fonti storiche non determinano in modo sufficiente lo stato corrente di `IMPL-003`, `IMPL-008`, `IMPL-013`, `IMPL-029`, `IMPL-030` e `IMPL-031`.
