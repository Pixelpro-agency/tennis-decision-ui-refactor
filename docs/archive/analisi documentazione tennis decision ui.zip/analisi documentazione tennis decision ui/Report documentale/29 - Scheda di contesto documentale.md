# Scheda di contesto documentale

## Documento target

**Percorso:**  
`docs/tennis-decision-ui/modules/sofa/02-local-context-and-point-by-point.md`

**Tipo di documento:**  
Owner tecnico di modulo / reference tecnica SofaScore.

**Ruolo documentale:**  
Owner del contesto locale SofaScore e del decoder point-by-point. Il contratto documentale storico unisce la trasformazione del PBP verificabile con la costruzione del `localContext`, lungo la pipeline `raw PBP → normalize → decode → recent window → localContext`. 
## Baseline

**Code authority:**  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

**Documentation structure baseline:**  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `Report documentale/29 - 02-local-context-and-point-by-point.md` — `TDUI-DOC-REPORT-029`, audit originariamente riferito al commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`.
- `29 - TODO e Json.md` — registro TODO e JSON associato al report 029; tutte le task `LOCAL-PBP-001..008` risultano marcate `[x]` / `completed:true`.

## Task storicamente associate

- **`LOCAL-PBP-001` — stato: completata**  
  Argomento coinvolto: identificazione evidence-based del game corrente e comportamento fail-closed della finestra recente.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- **`LOCAL-PBP-002` — stato: completata**  
  Argomento coinvolto: identità canonica `set/game`, semantica intera e gestione delle identità duplicate.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- **`LOCAL-PBP-003` — stato: completata**  
  Argomento coinvolto: contratto di `ALL/pointsTotal`, conteggi e gestione di record duplicati.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- **`LOCAL-PBP-004` — stato: completata**  
  Argomento coinvolto: semantica di `localContext.dataQuality`, con distinzione storica fra completezza derivativa e proprietà quali freshness, provenance o temporal alignment.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- **`LOCAL-PBP-005` — stato: completata**  
  Argomento coinvolto: confine delle route `POST /api/match/analyze` e `/snapshot` rispetto alla persistenza canonica. Il report finale registra storicamente entrambe come compute-only.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- **`LOCAL-PBP-006` — stato: completata**  
  Argomento coinvolto: propagazione bootstrap di `localContext` come persistence data separato dal sample usato dal Source Identity matching.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- **`LOCAL-PBP-007` — stato: completata**  
  Argomento coinvolto: provenance e validazione riproducibile del source contract PBP reale.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- **`LOCAL-PBP-008` — stato: completata**  
  Argomento coinvolto: verification matrix e copertura degli invarianti del local context/PBP.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

Lo stato completato di tutte le otto task è concorde fra TODO e JSON; il report finale dichiara inoltre l'applicazione di `LOCAL-PBP-001..008` il 10 agosto 2026. 
## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata ma non ritenuta necessaria: `split_required:false`, senza nuovi file canonici proposti. Il PBP e il `localContext` restano un unico contratto documentale pur avendo owner algoritmici distinti nel codice.
- Il report finale registra storicamente `/analyze` e `/snapshot` come compute-only.
- Il bootstrap viene descritto con `localContext` calcolato prima del gate, mantenuto separato dal sample Source Identity e trasportato come `persistenceData`.
- Il report finale dichiara archiviata una validation riproducibile e riallineata la matrice di test.

## Struttura precedente da considerare

- Pipeline concettuale `raw PBP → normalize → decode → recent window → localContext`.
- Distinzione fra contesto match, finestra recente, comparison e data quality.
- Confine di persistenza fra timeline Sofa, che storicamente contiene `localContext`, e history aggregata, che non lo contiene.
- Confine Source Identity: `localContext` separato dal sample impiegato per il matching.
- Frontend come consumer del `localContext`, non come authority del calcolo.
- Sezione di verifica con suite dedicate a point-by-point, normalizzazione, local context, integrazione Sofa e response API.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/pointByPoint.js`
- `backend/src/sofa/localContext.js`
- `backend/src/sofa/normalizeSnapshot.js`
- `backend/src/sofa/buildSofaAnalysis.js`
- `backend/src/sofa/matchTracker.js`
- `backend/src/routes/match.js` e `backend/src/routes/match/analysisResponse.js`
- test e fixture direttamente associati a questi moduli, in particolare `pointByPoint.test.mjs`, `normalizeSnapshot.test.mjs`, `localContext.test.mjs`, `buildSofaAnalysis.test.mjs`, `analysisResponse.test.mjs` e la fixture PBP verificata.

## Owner/documenti collegati

- `docs/tennis-decision-ui/api/match/03-analysis-and-snapshot.md` — indicato storicamente come owner API collegato al confine di `/analyze` e `/snapshot`, nell'ambito di `MATCH-API-008`.
- Area Match Context frontend — collegata alla presentazione di `localContext`; il report attribuisce al frontend il ruolo di consumer e mantiene il calcolo nell'owner SofaScore. Il percorso documentale esatto di questo owner non è fornito negli allegati.

## Guardrail specifici per questo documento

- Mantenere il documento focalizzato sul contratto tecnico del contesto locale SofaScore e del point-by-point, senza trasformarlo in owner della presentation frontend o dell'intera API match.
- Conservare la distinzione fra dati/calcoli descrittivi e segnali operativi: il report storico non attribuisce al `localContext` logiche betting, pressure, momentum o confidence sintetiche.
- Trattare separatamente availability/completezza derivativa e proprietà ulteriori come freshness, provenance o temporal alignment, documentando soltanto quelle effettivamente presenti nel CODE AUTHORITY.
- Mantenere esplicito il confine fra `localContext` e Source Identity: il primo può appartenere ai dati di persistenza senza partecipare al matching dell'identità.
- Non estendere la descrizione del decoder a semantiche provider che il CODE AUTHORITY o una validation corrente non supportano.

## Informazioni storiche da NON assumere come correnti

- Tutti i comportamenti osservati durante l'audit iniziale al commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`; la baseline tecnica successiva è il CODE AUTHORITY `12b344ea96e71b2bdaa6931c98419ce925b5c228`.
- I finding, le priorità e le proposte originarie di `LOCAL-PBP-001..008`: le fonti successive li marcano come completati e devono servire soltanto a individuare aree da ricontrollare.
- La precedente descrizione di `/analyze` come writer canonico, del bootstrap come wording stale, della mancata uniqueness `set/game` e del domain `pointsTotal` permissivo: compaiono ancora nella parte audit del report, mentre il suo esito finale dichiara applicate le relative task.
- Qualunque proprietà live del provider PBP non direttamente dimostrata dalla baseline corrente. Il report finale segnala storicamente che tie-break e proprietà live non dimostrate restavano `unsupported` o `unknown`.
- I vecchi path di test o la vecchia verification matrix senza confronto con il repository corrente.

## Discrepanze o limiti delle fonti

- Il report contiene una stratificazione storica: dopo aver dichiarato `LOCAL-PBP-001..008` completate, conserva nello stesso blocco finale una sintesi dell'audit precedente che elenca ancora varie condizioni pre-intervento. Questo contenuto non va usato per stabilire il comportamento corrente; va verificato nel CODE AUTHORITY.
- TODO Markdown e JSON non presentano discrepanze sullo stato delle task: tutte risultano completate.
- Il report dichiara una validation riproducibile archiviata, ma gli allegati forniti non ne identificano il filename finale; indicano soltanto `docs/validations/` come area storicamente prevista. - Il documento target corrente e la validation archiviata non fanno parte dei materiali forniti; pertanto la Scheda non assume né la loro struttura attuale né il comportamento tecnico corrente oltre quanto dovrà essere verificato sulla baseline indicata.