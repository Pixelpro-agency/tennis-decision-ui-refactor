TODO:

Report: [`../Report documentale/05 - 01-match.md`](../Report%20documentale/05%20-%2001-match.md) — `TDUI-DOC-REPORT-005`.

Modularizzazione: **richiesta**. File proposti: `docs/tennis-decision-ui/api/match/01-read-and-integrity.md`, `docs/tennis-decision-ui/api/match/02-tracking-and-source-identity.md`, `docs/tennis-decision-ui/api/match/03-analysis-and-snapshot.md`.

- [x] **`MATCH-API-001`** — priorità `high` — Correggere la descrizione di `GET /api/match/debug-last`: documentare che non dispone di un producer corrente e restituisce stabilmente il payload legacy, oppure rimuoverlo con la task dedicata già approvata.
- [x] **`MATCH-API-002`** — priorità `high` — Sostituire negli esempi `integrity.reason: commit_incomplete` con il valore canonico `pending_commit` e descrivere separatamente la reason di `recovery_failed`.
- [x] **`MATCH-API-003`** — priorità `high` — Correggere l’esempio della history usando la shape corrente `metadata + history + integrity`, eliminando lo schema obsoleto `eventId + updates`.
- [x] **`MATCH-API-004`** — priorità `high` — Documentare la vista HTTP reale della timeline: normalizzazione di `timeline`, campo derivato `latest`, aggiunta di `integrity` e distinzione rispetto al documento persistito.
- [x] **`MATCH-API-005`** — priorità `high` — Precisare che il codice corrente collassa missing, read failure e JSON invalido a `null`; valutare in una task separata read result strutturati e status HTTP distinti.
- [x] **`MATCH-API-006`** — priorità `high` — Completare il contratto `track/untrack`: aggiungere i due errori SofaScore, documentare il fallback di `betfairMode` e il no-op Untrack senza `eventId`, decidendo se preservare o validare tali comportamenti.
- [x] **`MATCH-API-007`** — priorità `high` — Sostituire in `POST /analyze` la propagazione del messaggio raw con code e messaggi pubblici bounded, mantenendo i dettagli nei log redatti e aggiungendo i relativi test.
- [x] **`MATCH-API-008`** — priorità `high` — Mantenere `01-match.md` come facade, creare tre owner per letture e integrity, tracking e Source Identity, analisi e snapshot; rimuovere il test path inesistente e aggiornare indice, link e sezione di verifica.

JSON:

    {
      "change_id": "MATCH-API-001",
      "document_path": "docs/tennis-decision-ui/api/01-match.md",
      "report_id": "TDUI-DOC-REPORT-005",
      "report_path": "../Report documentale/05 - 01-match.md",
      "priority": "high",
      "type": "deprecated_debug_contract",
      "action": "Correggere la descrizione di `GET /api/match/debug-last`: documentare che non dispone di un producer corrente e restituisce stabilmente il payload legacy, oppure rimuoverlo con la task dedicata già approvata.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MATCH-API-002",
      "document_path": "docs/tennis-decision-ui/api/01-match.md",
      "report_id": "TDUI-DOC-REPORT-005",
      "report_path": "../Report documentale/05 - 01-match.md",
      "priority": "high",
      "type": "integrity_contract",
      "action": "Sostituire negli esempi `integrity.reason: commit_incomplete` con il valore canonico `pending_commit` e descrivere separatamente la reason di `recovery_failed`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MATCH-API-003",
      "document_path": "docs/tennis-decision-ui/api/01-match.md",
      "report_id": "TDUI-DOC-REPORT-005",
      "report_path": "../Report documentale/05 - 01-match.md",
      "priority": "high",
      "type": "history_payload_shape",
      "action": "Correggere l’esempio della history usando la shape corrente `metadata + history + integrity`, eliminando lo schema obsoleto `eventId + updates`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MATCH-API-004",
      "document_path": "docs/tennis-decision-ui/api/01-match.md",
      "report_id": "TDUI-DOC-REPORT-005",
      "report_path": "../Report documentale/05 - 01-match.md",
      "priority": "high",
      "type": "timeline_payload_shape",
      "action": "Documentare la vista HTTP reale della timeline: normalizzazione di `timeline`, campo derivato `latest`, aggiunta di `integrity` e distinzione rispetto al documento persistito.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MATCH-API-005",
      "document_path": "docs/tennis-decision-ui/api/01-match.md",
      "report_id": "TDUI-DOC-REPORT-005",
      "report_path": "../Report documentale/05 - 01-match.md",
      "priority": "high",
      "type": "read_error_semantics",
      "action": "Precisare che il codice corrente collassa missing, read failure e JSON invalido a `null`; valutare in una task separata read result strutturati e status HTTP distinti.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MATCH-API-006",
      "document_path": "docs/tennis-decision-ui/api/01-match.md",
      "report_id": "TDUI-DOC-REPORT-005",
      "report_path": "../Report documentale/05 - 01-match.md",
      "priority": "high",
      "type": "tracking_input_contract",
      "action": "Completare il contratto `track/untrack`: aggiungere i due errori SofaScore, documentare il fallback di `betfairMode` e il no-op Untrack senza `eventId`, decidendo se preservare o validare tali comportamenti.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MATCH-API-007",
      "document_path": "docs/tennis-decision-ui/api/01-match.md",
      "report_id": "TDUI-DOC-REPORT-005",
      "report_path": "../Report documentale/05 - 01-match.md",
      "priority": "high",
      "type": "public_error_redaction",
      "action": "Sostituire in `POST /analyze` la propagazione del messaggio raw con code e messaggi pubblici bounded, mantenendo i dettagli nei log redatti e aggiungendo i relativi test.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MATCH-API-008",
      "document_path": "docs/tennis-decision-ui/api/01-match.md",
      "report_id": "TDUI-DOC-REPORT-005",
      "report_path": "../Report documentale/05 - 01-match.md",
      "priority": "high",
      "type": "document_modularization",
      "action": "Mantenere `01-match.md` come facade, creare tre owner per letture e integrity, tracking e Source Identity, analisi e snapshot; rimuovere il test path inesistente e aggiornare indice, link e sezione di verifica.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }