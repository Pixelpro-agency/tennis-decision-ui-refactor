TODO:

Report: [`Report documentale/33 - 02-live-tracking-control.md`](../Report%20documentale/33%20-%2002-live-tracking-control.md) — `TDUI-DOC-REPORT-033`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`LIVE-CTRL-001`** — priorità `high` — Distinguere current live, persisted e last-known; non usare timeline/Evidence/dashboard come prova della sessione corrente, dichiarare il limite eventId-based finché manca `IMPL-006` e verificare la session identity quando disponibile.
- [x] **`LIVE-CTRL-002`** — priorità `high` — Distinguere stop logico da cleanup fisico: top-level `ok:true` non basta; per completion processi richiedere `pythonCleanup.ok:true` e `remaining:0`, coordinando `SOFA-LIVE-003` e `FRONT-SESSION-007`.
- [x] **`LIVE-CTRL-003`** — priorità `high` — Chiarire che `pythonProcesses` prova soltanto il lifecycle Python: `sofa_tracking=0` e `betfair_tracking=0` non dimostrano `activeTrackerOperations=0`; ordinary Stop non equivale a tracker drain.
- [ ] **`LIVE-CTRL-004`** — priorità `high` — Definire il recupero di uno Stop con `pythonCleanup.remaining > 0`; correggere la `terminationPromise` riusata che può impedire un nuovo tentativo fisico, scegliere reattempt owned o shutdown esplicito e testare first remaining → second Stop.
- [x] **`LIVE-CTRL-005`** — priorità `medium` — Documentare che Stop manuale rimuove il Source Identity Gate e lo status può 404, mentre Betfair/Evidence possono continuare a mostrare dati persistiti; presentarli come stopped/last-known e coordinare i poller frontend.
- [x] **`LIVE-CTRL-006`** — priorità `high` — Distinguere `new Start API permitted` da restart realmente session-safe, qualificare la promessa sui callback SofaScore in-flight durante mismatch e coordinare `SOFA-LIVE-001/004`, `SOURCE-ID-002` e `IMPL-006` senza delay empirici.
- [ ] **`LIVE-CTRL-007`** — priorità `medium` — Spostare la verifica 9B in un artifact di validation solo con provenance reale; usare `non registrato` per metadata storici mancanti e aggiungere test post-Stop gate 404, partial cleanup, remaining retry, Node in-flight, immediate restart e persisted-vs-current.

JSON:

    {
      "change_id": "LIVE-CTRL-001",
      "report_id": "TDUI-DOC-REPORT-033",
      "document_path": "docs/tennis-decision-ui/operations/02-live-tracking-control.md",
      "priority": "high",
      "type": "current_session_verification_authority",
      "action": "Distinguere current live, persisted e last-known; non usare timeline/Evidence/dashboard come prova della sessione corrente, dichiarare il limite eventId-based finché manca IMPL-006 e verificare la session identity quando disponibile.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LIVE-CTRL-002",
      "report_id": "TDUI-DOC-REPORT-033",
      "document_path": "docs/tennis-decision-ui/operations/02-live-tracking-control.md",
      "priority": "high",
      "type": "stop_completion_semantics",
      "action": "Distinguere stop logico da cleanup fisico: top-level `ok:true` non basta; per completion processi richiedere `pythonCleanup.ok:true` e `remaining:0`, coordinando SOFA-LIVE-003 e FRONT-SESSION-007.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LIVE-CTRL-003",
      "report_id": "TDUI-DOC-REPORT-033",
      "document_path": "docs/tennis-decision-ui/operations/02-live-tracking-control.md",
      "priority": "high",
      "type": "runtime_health_quiescence_semantics",
      "action": "Chiarire che `pythonProcesses` prova soltanto il lifecycle Python: `sofa_tracking=0` e `betfair_tracking=0` non dimostrano `activeTrackerOperations=0`; ordinary Stop non equivale a tracker drain.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LIVE-CTRL-004",
      "report_id": "TDUI-DOC-REPORT-033",
      "document_path": "docs/tennis-decision-ui/operations/02-live-tracking-control.md",
      "priority": "high",
      "type": "stop_cleanup_retry_recovery",
      "action": "Definire il recupero di uno Stop con `pythonCleanup.remaining > 0`; correggere la terminationPromise riusata che può impedire un nuovo tentativo fisico, scegliere reattempt owned o shutdown esplicito e testare first remaining → second Stop.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    },
    {
      "change_id": "LIVE-CTRL-005",
      "report_id": "TDUI-DOC-REPORT-033",
      "document_path": "docs/tennis-decision-ui/operations/02-live-tracking-control.md",
      "priority": "medium",
      "type": "post_stop_source_identity_persisted_reads",
      "action": "Documentare che Stop manuale rimuove il Source Identity Gate e lo status può 404, mentre Betfair/Evidence possono continuare a mostrare dati persistiti; presentarli come stopped/last-known e coordinare i poller frontend.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LIVE-CTRL-006",
      "report_id": "TDUI-DOC-REPORT-033",
      "document_path": "docs/tennis-decision-ui/operations/02-live-tracking-control.md",
      "priority": "high",
      "type": "restart_mismatch_session_semantics",
      "action": "Distinguere `new Start API permitted` da restart realmente session-safe, qualificare la promessa sui callback SofaScore in-flight durante mismatch e coordinare SOFA-LIVE-001/004, SOURCE-ID-002 e IMPL-006 senza delay empirici.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "LIVE-CTRL-007",
      "report_id": "TDUI-DOC-REPORT-033",
      "document_path": "docs/tennis-decision-ui/operations/02-live-tracking-control.md",
      "priority": "medium",
      "type": "validation_provenance_verification_matrix",
      "action": "Spostare la verifica 9B in un artifact di validation solo con provenance reale; usare `non registrato` per metadata storici mancanti e aggiungere test post-Stop gate 404, partial cleanup, remaining retry, Node in-flight, immediate restart e persisted-vs-current.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    }