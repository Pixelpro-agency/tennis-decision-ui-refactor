TODO:

Report: [`../Report documentale/22 - 03-betfair-and-market-reactions-ui.md`](../Report%20documentale/22%20-%2003-betfair-and-market-reactions-ui.md) — `TDUI-DOC-REPORT-022`.

Modularizzazione: **completata**. `03-betfair-and-market-reactions-ui.md` resta la facade; sono stati creati `docs/tennis-decision-ui/modules/frontend/05-betfair-depth-and-health-ui.md` e `docs/tennis-decision-ui/modules/frontend/06-market-reactions-ui.md`; il lifecycle Source Identity resta owner di `01-session-shell.md`.

- [x] **`FRONT-BETFAIR-001`** — priorità `high` — Persistence/read status collegati a BetfairDepthCard e MarketReactionsPage mantenendo health e Source Identity separati e senza storage details.
- [x] **`FRONT-BETFAIR-002`** — priorità `high` — Asse e barre usano lo stesso massimo normalizzato e la scala condivisa tra runner.
- [x] **`FRONT-BETFAIR-003`** — priorità `high` — Tooltip assente per empty/invalid/anomaly e zero reale preservato come osservazione distinta.
- [x] **`FRONT-BETFAIR-004`** — priorità `high` — Price, size e matched mancanti resi come `—`; zero reale non confuso con null.
- [x] **`FRONT-BETFAIR-005`** — priorità `high` — Rimossa la label hard-coded; card collegata a polling, Stop, waiting, error e persistence reali.
- [x] **`FRONT-BETFAIR-006`** — priorità `high` — Read status, last-known data/history e source timestamp inoltrati alla card con label non-current.
- [x] **`FRONT-BETFAIR-007`** — priorità `medium` — Documento allineato ai campi reali; `graphLoginRequiredUrl` mantenuto come diagnostica redatta e vietata l'introduzione di campi raw non approvati.
- [x] **`FRONT-BETFAIR-008`** — priorità `high` — Aggiunta suite JSX per MoneyFlowChart, runner, card, Health Debug e Market Reactions con integrity/current-vs-stale.
- [x] **`FRONT-BETFAIR-009`** — priorità `medium` — Facade mantenuta, creati i due owner derivati e aggiornati index, context selection, repository owner map e link senza duplicare Source Identity.

JSON:

    {
      "change_id": "FRONT-BETFAIR-001",
      "report_id": "TDUI-DOC-REPORT-022",
      "document_path": "docs/tennis-decision-ui/modules/frontend/03-betfair-and-market-reactions-ui.md",
      "priority": "high",
      "type": "persistence_integrity_presentation",
      "action": "Persistence/read status collegati a BetfairDepthCard e MarketReactionsPage mantenendo health e Source Identity separati e senza storage details.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-BETFAIR-002",
      "report_id": "TDUI-DOC-REPORT-022",
      "document_path": "docs/tennis-decision-ui/modules/frontend/03-betfair-and-market-reactions-ui.md",
      "priority": "high",
      "type": "chart_accuracy",
      "action": "Asse e barre usano lo stesso massimo normalizzato e la scala condivisa tra runner.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-BETFAIR-003",
      "report_id": "TDUI-DOC-REPORT-022",
      "document_path": "docs/tennis-decision-ui/modules/frontend/03-betfair-and-market-reactions-ui.md",
      "priority": "high",
      "type": "missing_data_semantics",
      "action": "Tooltip assente per empty/invalid/anomaly e zero reale preservato come osservazione distinta.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-BETFAIR-004",
      "report_id": "TDUI-DOC-REPORT-022",
      "document_path": "docs/tennis-decision-ui/modules/frontend/03-betfair-and-market-reactions-ui.md",
      "priority": "high",
      "type": "raw_value_presentation",
      "action": "Price, size e matched mancanti resi come em dash; zero reale non confuso con null.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-BETFAIR-005",
      "report_id": "TDUI-DOC-REPORT-022",
      "document_path": "docs/tennis-decision-ui/modules/frontend/03-betfair-and-market-reactions-ui.md",
      "priority": "high",
      "type": "ui_runtime_status",
      "action": "Rimossa la label polling hard-coded; card collegata a polling, Stop, waiting, error e persistence reali.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-BETFAIR-006",
      "report_id": "TDUI-DOC-REPORT-022",
      "document_path": "docs/tennis-decision-ui/modules/frontend/03-betfair-and-market-reactions-ui.md",
      "priority": "high",
      "type": "stale_presentation",
      "action": "Read status, last-known data/history e source timestamp inoltrati alla card con label non-current.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-BETFAIR-007",
      "report_id": "TDUI-DOC-REPORT-022",
      "document_path": "docs/tennis-decision-ui/modules/frontend/03-betfair-and-market-reactions-ui.md",
      "priority": "medium",
      "type": "diagnostic_surface_contract",
      "action": "Documento allineato ai campi reali; graphLoginRequiredUrl mantenuto come diagnostica redatta e vietata l'introduzione di campi raw non approvati.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-BETFAIR-008",
      "report_id": "TDUI-DOC-REPORT-022",
      "document_path": "docs/tennis-decision-ui/modules/frontend/03-betfair-and-market-reactions-ui.md",
      "priority": "high",
      "type": "verification_contract",
      "action": "Aggiunta suite JSX per MoneyFlowChart, runner, card, Health Debug e Market Reactions con integrity/current-vs-stale.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-BETFAIR-009",
      "report_id": "TDUI-DOC-REPORT-022",
      "document_path": "docs/tennis-decision-ui/modules/frontend/03-betfair-and-market-reactions-ui.md",
      "priority": "medium",
      "type": "documentation_modularization",
      "action": "Facade mantenuta, creati i due owner derivati e aggiornati index, context selection, repository owner map e link senza duplicare Source Identity.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }