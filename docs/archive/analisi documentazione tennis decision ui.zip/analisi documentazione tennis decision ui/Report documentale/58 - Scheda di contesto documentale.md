# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/audit-codice/06-validazione-e-test.md`

Tipo di documento:  
Modulo owner dell’audit codice dedicato alla validazione e ai test; Parte 6 di 7, Secondo audit — Punto 7.

Ruolo documentale:  
Mantenere il record unitario del Punto 7 relativo all’infrastruttura di validazione/test e ai suoi confini: inventario dei test, runner e manifest, fixture/sandbox, frontend harness, result artifact/ledger, test map, profili offline/live, benchmark e rapporto con la CI. Il documento conserva anche la distinzione temporale fra il checkpoint originario dell’audit e gli sviluppi successivi.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

Baseline storica dichiarata nel documento per il Punto 7:  
`275008a5cd6451f24c6895068639ee3055395986`

## Fonti storiche consultate

- `58 - Report 06-validazione-e-test.md` — `TDUI-DOC-REPORT-058`.
- `58 - TODO e Json.md`.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260814-011820).txt` come regola di trasformazione del materiale storico.

## Task storicamente associate

- `AUDIT-CODE-P7-001` — stato: completata.
  Argomento coinvolto: distinzione documentale fra checkpoint originario del Punto 7 e stato successivo a `IMPL-028`.
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente e documentarlo soltanto se appartiene al ruolo del file.

- `IMPL-028` — stato: completata nella fonte storica, con validazione locale registrata.
  Argomento coinvolto: prima infrastruttura canonica di validazione, comprendente runner, manifest, profili offline, isolamento dei processi, timeout e artifact JSON per esecuzione.
  Uso consentito: verificare nel CODE AUTHORITY quali elementi siano ancora presenti e come vadano descritti.

- `IMPL-003`, `IMPL-029`, `IMPL-030`, `IMPL-031` — stato: non completate nella fonte storica.
  Argomenti coinvolti: test map completa; fixture/sandbox; frontend interaction harness; validation result ledger completo.
  Uso consentito: non assumerne il target come già implementato senza verifica nel CODE AUTHORITY.

- `TEST-003` — stato: non completata integralmente nella fonte storica.
  Argomento coinvolto: runner/manifest già introdotti, mentre la matrice completa test ↔ owner ↔ documento risultava ancora aperta.
  Uso consentito: verificare il perimetro corrente senza confondere la prima infrastruttura con l’inventario totale.

- `TEST-060`, `TEST-061`, `TEST-062`, `TEST-063`, `TEST-064`, `TEST-068`, `TEST-073` — stato: completate nello stato storico registrato.
  Argomento coinvolto: requisiti associati al self-test del validation runner.
  Uso consentito: trattare il PASS come informazione storica finché il CODE AUTHORITY non conferma il comportamento corrente.

- `TEST-069`, `TEST-070` — stato: non completate nella fonte storica.
  Argomento coinvolto: copertura parziale del result artifact e relativi requisiti.
  Uso consentito: non descriverle come chiuse.

- `TEST-065`, `TEST-066`, `TEST-067`, `TEST-071`, `TEST-072`, `TEST-074`, `TEST-075` — stato: non completate nella fonte storica.
  Argomento coinvolto: sandbox/fixture, frontend harness, route HTTP harness, benchmark e lint surface.
  Uso consentito: non assumere la presenza dei relativi target.

## Cambiamenti strutturali storicamente rilevanti

- `IMPL-028` risulta aver introdotto una prima infrastruttura reale sotto `scripts/validation/`, comprendente `run.mjs`, `run.test.mjs`, manifest, schemi, support directory e README.
- La fonte storica registra cinque profili offline implementati: `fast`, `backend`, `frontend`, `python`, `full-offline`.
- I profili `persistence`, `benchmark` e `live` risultavano ancora pianificati nella fotografia storica.
- La modularizzazione del documento è stata valutata e dichiarata non necessaria; non risultano child document creati per questo Punto 7.

## Struttura precedente da considerare

- Header di appartenenza: `Parte 6 di 7 — Validazione e test`.
- Perimetro unitario: runner, manifest, fixture, sandbox, frontend harness, result ledger e `TEST-060…075`.
- Catena tematica storica: test inventory → runner → manifest → sandbox/fixture → frontend harness → result artifact → test map → benchmark/live/CI.
- Distinzione fra test legacy Node/Python, validazione offline e attività live.
- Distinzione fra stato al checkpoint originario e stato successivo a implementazioni documentate.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `scripts/validation/README.md`
- `scripts/validation/test-manifest.json`
- `scripts/validation/manifest-schema.json`
- `scripts/validation/result-schema.json`
- `scripts/validation/run.mjs`
- `scripts/validation/run.test.mjs`
- `scripts/validation/support/`
- `frontend/package.json`, limitatamente alla superficie di test/lint pertinente al Punto 7

## Owner/documenti collegati

- `implementazioni/03-audit-codice.md` — contesto superiore dell’audit codice.
- `implementazioni/implementazioni-proposte/06-validazione-e-fixture.md` — proposta storicamente collegata al dominio validazione/fixture.
- `IMPL-028` — prima infrastruttura validation runner/manifest.
- `IMPL-029` — area fixture/sandbox.
- `IMPL-030` — area frontend interaction harness.
- `IMPL-031` — area validation result ledger.
- `IMPL-003` — inventario/test map completa.
- `VALID-ROLL-001`, `VALID-ROLL-004`, `VALID-ROLL-006`, `VALID-INDEX-001…003`, `METHOD-EVIDENCE-001` — owner collegati alla provenance e alla semantica dei risultati; da usare soltanto per comprendere i confini, senza trasferirne automaticamente il contenuto nel documento target.

## Guardrail specifici per questo documento

- Conservare la natura di record del Punto 7 senza trasformarlo in un runbook generico o in un nuovo piano di implementazione.
- Mantenere distinta la baseline storica del Punto 7 dal CODE AUTHORITY usato dal technical writer.
- Non equiparare la presenza di un manifest o di un runner a una nuova esecuzione corrente dei test.
- Non equiparare `full-offline` all’inventario completo di ogni test legacy se il CODE AUTHORITY non lo dimostra.
- Mantenere distinta la validazione offline da browser/live e dalla CI.
- Non assumere che un artifact JSON per singola esecuzione equivalga al validation result ledger completo.
- Non imporre uno split: dalle fonti storiche non risulta una modularizzazione eseguita.

## Informazioni storiche da NON assumere come correnti

- L’assenza originaria di runner, manifest, profili, comando canonico e result artifact appartiene al checkpoint iniziale e non va trattata automaticamente come stato corrente.
- La presenza storicamente registrata di runner, manifest, cinque profili offline e artifact JSON dopo `IMPL-028` deve essere verificata nel CODE AUTHORITY prima di essere descritta come corrente.
- I PASS associati a `TEST-060/061/062/063/064/068/073` sono stati registrati come validazione locale storica e non costituiscono da soli un PASS corrente.
- Lo stato storico di `IMPL-003`, `IMPL-029…031`, dei profili `persistence/benchmark/live`, della coverage e dei TEST-ID aperti o parziali non deve essere proiettato automaticamente sul repository attuale.
- L’assenza storicamente osservata di workflow/status CI non deve essere assunta senza verifica sulla baseline tecnica corrente.

## Discrepanze o limiti delle fonti

- Il report 058 fotografa e confronta stati storici fino alla documentation structure baseline `4c5f43b...`; non sostituisce il CODE AUTHORITY `12b344e...`.
- La TODO/JSON fornita conferma `AUDIT-CODE-P7-001` come completata e conferma che la modularizzazione è stata valutata ma non necessaria.
- Non risultano discrepanze fra la voce TODO e il JSON forniti per `AUDIT-CODE-P7-001`.
- Le fonti disponibili non includono il documento target corrente né una verifica completa del CODE AUTHORITY; ogni descrizione dello stato tecnico attuale resta quindi da verificare nella fase di technical writing.
