# Scheda di contesto documentale

## Documento target

Percorso:
`todo-list-tennis-decision-ui.md`

Tipo di documento:
vista operativa sintetica centrale / Todo cumulativa.

Ruolo documentale:
fornire una vista operativa unica e sintetica della revisione, mostrando stati, inventari/checklist, collegamenti tra ID e owner, test, implementazioni, workflow e chiusura senza duplicare le motivazioni o le evidenze complete mantenute nei documenti owner.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260814-163140).txt`
- `72 - Report todo-list-tennis-decision-ui.md` — `TDUI-DOC-REPORT-072`
- `72 - TODO e Json.md`

## Task storicamente associate

La fonte storica finale dell'audit dichiara che le task di applicazione completate erano `0`; le seguenti task risultano quindi non completate in quella fonte e non devono essere assunte come comportamento già applicato al repository:

- `TASK-RECHECK-002` — stato: non completata.
  Argomento coinvolto: riconciliazione dello snapshot storico D1–D18 con lo stato corrente.
  Uso consentito: verificare nel CODE AUTHORITY e nei registri correnti l'effetto pertinente.
- `CURRENT-STATE-002` — stato: non completata.
  Argomento coinvolto: stato corrente delle fonti documentali e gestione dell'archive storico.
  Uso consentito: verificare nel CODE AUTHORITY e nella documentazione corrente l'esito pertinente.
- `DOC-AUDIT-P12-001` — stato: non completata.
  Argomento coinvolto: lifecycle sintetico delle righe DOC-001…013.
  Uso consentito: verificare nei registri correnti quali stati appartengano ancora alla Todo.
- `DOC-AUDIT-B34-001` — stato: non completata.
  Argomento coinvolto: lifecycle sintetico delle righe DOC-014…019.
  Uso consentito: verificare nei registri correnti quali stati appartengano ancora alla Todo.
- `DOC-AUDIT-B56-001` — stato: non completata.
  Argomento coinvolto: lifecycle sintetico delle righe DOC-020…023 e relative relazioni di supersession o miglioramento.
  Uso consentito: verificare nei registri correnti quali stati appartengano ancora alla Todo.
- `DOC-AUDIT-PROC-001` — stato: non completata.
  Argomento coinvolto: processo documentale relativo ad archive, consolidamento e cleanup.
  Uso consentito: verificare nella documentazione corrente quale outcome sia ancora pertinente.
- `IMPL-STORAGE-001` — stato: non completata.
  Argomento coinvolto: stato sintetico delle implementazioni storage/recovery e delle primitive eventualmente presenti.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente senza assumere completion.
- `IMPL-EVIDENCE-001` — stato: non completata.
  Argomento coinvolto: stato sintetico delle implementazioni Evidence/provenance e delle primitive eventualmente presenti.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente senza assumere completion.
- `IMPL-FRONTEND-001` — stato: non completata.
  Argomento coinvolto: stato sintetico delle implementazioni frontend/session polling e delle primitive eventualmente presenti.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente senza assumere completion.
- `IMPL-VALIDATION-001` — stato: non completata.
  Argomento coinvolto: stato sintetico delle implementazioni di validazione/fixture e delle primitive eventualmente presenti.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente senza assumere completion.

Il report identifica inoltre `WORKFLOW-002` come infrastruttura storicamente completata per la coerenza Todo ↔ registry; `METHOD-REG-001` è indicato come owner metodologico collegato.

## Cambiamenti strutturali storicamente rilevanti

- La Todo è rimasta un singolo documento: la modularizzazione è stata valutata e non ritenuta necessaria; non risultano nuovi file proposti per questo documento.
- La struttura repository descritta dal report comprendeva 4 moduli `audit-documentazione`, 7 moduli `audit-codice` e 7 moduli `implementazioni-proposte`; ulteriori split citati da report precedenti non risultavano ancora applicati.
- Le copie del precedente `docs/archive/` del ciclo di migrazione risultavano storicamente consolidate e poi rimosse; la relativa provenance rimaneva in Git e nelle validation di migrazione.
- Le validation storiche risultavano separate dai runbook correnti.

## Struttura precedente da considerare

- Vista unica articolata nei blocchi `A`, `B0`, `B`, `C`, `D`, `E`, `F`, `G`, `H`, `I`, `J`.
- `B` e `C` erano esplicitamente usati come checkpoint storici; `D`, `E` e `F` come aree di stato sintetico corrente.
- La legenda delle checkbox distingueva classificazione/decisione da implementazione: `[x]` non significava automaticamente “implementato”.
- Lo stato testuale in grassetto costituiva l'autorità sintetica della singola riga.
- Erano mantenute separate la baseline del codice, la provenance del recupero documentale e le verifiche del recupero pubblicato.
- Il “prossimo passo” non veniva selezionato automaticamente.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- dominio storage/recovery, con particolare attenzione alla semantica del journal `backend/match_history/.pending_commits/`;
- dominio Evidence/provenance — possibile fonte da verificare per gli effetti correnti sintetizzati dalla Todo;
- dominio frontend session/polling — possibile fonte da verificare per gli effetti correnti sintetizzati dalla Todo;
- `scripts/check_registry_consistency.py` per la coerenza tra owner e righe sintetiche della Todo;
- `scripts/validation/` — possibile fonte da verificare per runner, fixture e risultati correnti pertinenti alla Todo.

## Owner/documenti collegati

- `implementazioni/00-metodo-e-stati.md` — metodo e semantica degli stati usati dai registri.
- `implementazioni/audit-documentazione/01-rilievi-iniziali-e-api.md`, `02-moduli-frontend-python.md`, `03-operations-roadmap-e-controlli.md`, `04-processo-e-materiali-storici.md` — owner storici dei gruppi documentali consumati dalla Todo.
- `implementazioni/implementazioni-proposte/03-storage-recovery.md` — owner collegato alle sintesi storage/recovery.
- `implementazioni/implementazioni-proposte/04-evidence-provenance.md` — owner collegato alle sintesi Evidence/provenance.
- `implementazioni/implementazioni-proposte/05-frontend-session-polling.md` — owner collegato alle sintesi frontend/session polling.
- `implementazioni/implementazioni-proposte/06-validazione-e-fixture.md` — owner collegato alle sintesi validation/fixture.
- `docs/tennis-decision-ui/index.md` e `docs/tennis-decision-ui/roadmap/01-current-state.md` — riferimenti per la documentazione tecnica corrente e lo stato corrente.
- `docs/tennis-decision-ui/operations/05-retention-and-cleanup.md` — riferimento collegato alla semantica corrente di retention/journal.
- `docs/validations/README.md` e `docs/validations/documentation-migration-finalization-2026-08-03.md` — confine e provenance delle validation storiche.

## Guardrail specifici per questo documento

- Mantenere il ruolo di vista operativa sintetica centrale; non trasformare la Todo in un duplicato delle schede owner o della documentazione tecnica completa.
- Preservare la distinzione tra checkpoint storici e stato corrente se ancora presente nella baseline documentale.
- Non interpretare una checkbox `[x]` come prova autonoma di implementazione: la semantica dello stato testuale deve essere verificata nei registri correnti.
- Le righe che rappresentano stato corrente devono essere ricavate da authority correnti; gli snapshot storici possono restare tali solo se chiaramente etichettati.
- Non introdurre automaticamente nella Todo ID di audit o proposte non ancora consolidate nei registri correnti.
- Mantenere distinta la provenance storica del recupero documentale dalla baseline tecnica corrente.
- Non introdurre uno split del file soltanto per dimensione: la precedente valutazione di modularizzazione ha mantenuto la vista unica.
- Non selezionare automaticamente una task o un prossimo passo operativo.

## Informazioni storiche da NON assumere come correnti

- L'HEAD `4c5f43b007149f3210c27d7565357a447a3a6ef4` verificato dal report 072 è una fotografia storica del ciclo documentale, non il CODE AUTHORITY assegnato a questa Scheda.
- Lo SHA codice `aefc0ba5894d8fca60e5811088fede3ebbfde98a` citato nella Todo auditata era una baseline storica e non sostituisce il CODE AUTHORITY corrente.
- I riferimenti di recovery `8f936d1` e `2ebe7e8` e la data `2026-08-06` sono provenance storica, non identificazione dell'HEAD corrente.
- I conteggi e i PASS riportati nelle “Verifiche del recupero pubblicato” sono snapshot storici e non devono essere promossi a validation corrente senza verifica.
- L'esistenza di `docs/archive/` non deve essere assunta: nel repository verificato dal report le copie del ciclo di migrazione risultavano già consolidate e rimosse.
- Gli stati DOC, D1–D18 e IMPL descritti dal report 072 non devono essere trasferiti come correnti senza confronto con authority e registri aggiornati.

## Discrepanze o limiti delle fonti

- Il materiale fornito non include direttamente il contenuto corrente di `todo-list-tennis-decision-ui.md`; la struttura precedente è ricavata dal report documentale e deve essere confrontata con la Documentation Structure Baseline.
- `72 - TODO e Json.md` contiene la sezione `JSON:` senza payload: non è quindi disponibile un ledger JSON da confrontare con la mappa o con il report.
- Il report 072 dichiara esplicitamente che mappa Markdown e ledger JSON non furono aggiornati durante quell'audit; l'ultimo consolidamento indicato restava “fino al report 067”.
- Non è stata rilevata, nelle fonti fornite, una discrepanza Markdown ↔ JSON risolvibile: il limite è l'assenza del contenuto JSON stesso.
