# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/architecture/01-system-boundaries.md`

Tipo di documento:  
Architettura.

Ruolo documentale:  
Owner dei confini architetturali del sistema: mantiene una vista unitaria di chi possiede le principali responsabilità e di quali boundary separano frontend, backend, dominio/tracking, persistenza, runtime Python, scraper e fonti esterne. Il report storico conferma che il documento deve restare una singola mappa dei confini, non essere trasformato in runbook operativo né suddiviso in owner separati.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`.
- `Report documentale/11 - 01-system-boundaries.md` — `TDUI-DOC-REPORT-011`, relativo alla versione documentale analizzata al commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`.
- `11 - TODO e Json.md`, comprendente registro Markdown e JSON delle task associate al report.

## Task storicamente associate

- `ARCH-BOUND-001` — stato: completata  
  Argomento coinvolto: boundary frontend/API relative e precedente eccezione Strategy legacy.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `ARCH-BOUND-002` — stato: completata  
  Argomento coinvolto: confine HTTP locale, bind loopback e classificazione Host/Origin.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `ARCH-BOUND-003` — stato: completata  
  Argomento coinvolto: distinzione tra lifecycle Betfair scraper, lifecycle login e relativa runtime identity; il registro storico continuava a distinguere tali authority dalla command authority globale `IMPL-016`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `ARCH-BOUND-004` — stato: completata  
  Argomento coinvolto: matrice tra authority correnti e target approvati, comprendente launcher, writer authority, Source Identity, tracking session, Betfair command authority e HTTP locale.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `ARCH-BOUND-005` — stato: completata  
  Argomento coinvolto: separazione documentale dell'ownership Tracking e Source Identity, con `matchTracker.js` come integratore del gate nel lifecycle live.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `ARCH-BOUND-006` — stato: completata  
  Argomento coinvolto: boundary delle letture read-only che possono effettuare probe diagnostici di rete.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `ARCH-BOUND-007` — stato: completata  
  Argomento coinvolto: riduzione delle sequenze operative duplicate e rinvio agli owner documentali di Data Lifecycle, Runtime locale e Storage.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `ARCH-BOUND-008` — stato: completata  
  Argomento coinvolto: matrice sintetica fra confini architetturali ed evidenze automatiche.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata e registrata come non necessaria; non risultano nuovi documenti creati per suddividere questo owner.
- Risultano storicamente introdotte una distinzione più esplicita fra stato corrente e target approvati, una separazione più precisa delle ownership Tracking/Source Identity e una matrice confine/evidenza automatica.
- Le sequenze operative duplicate di bootstrap/recovery/shutdown risultano storicamente ridotte a invarianti con rinvii verso documenti owner specialistici.

## Struttura precedente da considerare

- Mappa unica dei livelli principali: frontend → router HTTP → dominio/tracking → persistenza → runtime Python → scraper.
- Distinzione fra launcher locale, backend e Chrome/CDP come aree con ownership differenti.
- Tabella/mappa delle ownership e delle responsabilità dei principali domini.
- Invarianti relativi a writer authority, recovery, shutdown e tracker drain; il dettaglio procedurale non appartiene necessariamente a questo owner.
- Sezione storica dedicata alle regole durante un refactor e, successivamente, matrice di verifica dei boundary.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/server.js`
- `backend/src/sofa/matchTracker.js`
- `backend/src/sofa/sourceIdentityGate.js`
- `backend/src/sofa/sourceIdentityGate/`
- `backend/src/runtime/pythonProcessRegistry.js`
- `backend/src/runtime/matchHistoryWriterAuthority.js`
- `backend/src/routes/betfair/loginWindowLifecycle.js`
- `backend/src/sofa/betfair/scraperLifecycle.js` e relativo `scraperLifecycle/runner.js`
- superfici frontend che costruiscono o inviano richieste live/API, in particolare `frontend/src/utils/liveSessionRequests.js`

## Owner/documenti collegati

- `architecture/02-data-lifecycle.md` — owner collegato per lifecycle dei dati, recovery e persistenza.
- `operations/01-local-runtime.md` — owner collegato per bootstrap locale, launcher e sequenze operative.
- `api/06-runtime-health.md` — collegato ai boundary del runtime HTTP/health.
- `modules/storage/02-commit-journal-and-recovery.md` — riferimento specialistico storico per dettagli di journal e recovery.

Il loro rapporto con `01-system-boundaries.md` è di specializzazione: questo documento mantiene i confini e gli invarianti architetturali, mentre i dettagli procedurali appartengono agli owner specifici.

## Guardrail specifici per questo documento

- Mantenere il documento come singolo owner della mappa dei confini architetturali; non trasformarlo in una raccolta di runbook specialistici.
- Distinguere sempre comportamento corrente, target approvati e componenti legacy senza assumere che una proposta approvata sia già implementata.
- Conservare la distinzione fra authority con scope differenti: process/storage-wide, event-scoped e session-scoped.
- Descrivere le responsabilità ad alto livello e rinviare agli owner specialistici per i dettagli operativi.
- Le evidenze/test eventualmente citati servono a identificare il boundary verificabile; esiti storici non costituiscono prova dello stato corrente.

## Informazioni storiche da NON assumere come correnti

- La presenza della Strategy legacy con URL backend assoluto rilevata durante l'audit: `ARCH-BOUND-001` risulta successivamente completata.
- Il precedente stato con CORS globale e listener senza bind loopback esplicito: `ARCH-BOUND-002` risulta successivamente completata.
- Il precedente assetto documentale che aggregava Source Identity sotto Tracking: `ARCH-BOUND-005` risulta successivamente completata.
- Il precedente stato del probe CDP Betfair descritto dal report come non sufficientemente confinato: `ARCH-BOUND-006` risulta successivamente completata.
- Le indicazioni storiche su `IMPL-006` e `IMPL-016` come target approvati ma non implementati devono essere ricontrollate nel CODE AUTHORITY prima di essere descritte come stato corrente. Il registro successivo conferma soltanto, per `ARCH-BOUND-003`, che al momento di quella registrazione `IMPL-016` restava approvata ma non implementata.

## Discrepanze o limiti delle fonti

- Il report `TDUI-DOC-REPORT-011` fotografa il documento prima dell'applicazione delle otto task, mentre TODO e JSON registrano successivamente `ARCH-BOUND-001..008` come completate. Le descrizioni di “stato corrente” presenti nel report non devono quindi essere trasferite automaticamente nella documentazione attuale.
- Markdown TODO e JSON concordano sullo stato completato delle otto task; non emerge una discrepanza fra queste due fonti.
- Non è stato fornito in questo pacchetto il contenuto corrente di `01-system-boundaries.md`; forma finale e comportamento tecnico corrente devono pertanto essere verificati successivamente usando rispettivamente la Documentation Structure Baseline e il CODE AUTHORITY.
