# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/modules/python/03-betfair-scraper.md`

Tipo di documento:  
Owner tecnico del core/facade dello scraper Betfair in Python.

Ruolo documentale:  
Descrivere acquisizione Betfair, modalità browser persistent/CDP, login-only, integrazione Market API e Graph ladder, cache, contratto del risultato JSON e confini con il backend Node. Diagnostica e network capture possiedono un owner documentale separato.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `26 - Report 03-betfair-scraper.md` — report `TDUI-DOC-REPORT-026`.
- `26 - TODO e Json.md` — mappa delle task e relativi record JSON.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing`.

## Task storicamente associate

- `BETFAIR-SCRAPER-001` — stato: completata  
  Argomento coinvolto: identità della richiesta e chiave della cache.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `BETFAIR-SCRAPER-002` — stato: completata  
  Argomento coinvolto: criteri di cache eligibility e contratto tra risultati fresh e cached.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `BETFAIR-SCRAPER-003` — stato: completata  
  Argomento coinvolto: envelope diagnostico pubblico e trattamento dei path locali.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `BETFAIR-SCRAPER-004` — stato: completata  
  Argomento coinvolto: lifecycle asincrono, limiti e drain della network capture.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `BETFAIR-SCRAPER-005` — stato: completata  
  Argomento coinvolto: coordinamento dei timeout tra scraper Python e processo Node.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `BETFAIR-SCRAPER-006` — stato: completata  
  Argomento coinvolto: provenienza dell’evidenza di fine match e semantica di `hasFinished`.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `BETFAIR-SCRAPER-007` — stato: completata  
  Argomento coinvolto: classificazione di autenticazione richiesta, security challenge, ladder vuota ed errore temporaneo.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `BETFAIR-SCRAPER-008` — stato: completata  
  Argomento coinvolto: configurazione e flag del browser Chromium persistent.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `BETFAIR-SCRAPER-009` — stato: completata  
  Argomento coinvolto: matrice di verifica dello scraper Betfair.  
  Uso consentito: verificare nel CODE AUTHORITY test e copertura correnti pertinenti.

- `BETFAIR-SCRAPER-010` — stato: completata  
  Argomento coinvolto: separazione documentale tra core scraper e diagnostica/network capture.  
  Uso consentito: verificare nel CODE AUTHORITY e nella struttura documentale corrente i confini effettivi.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione risulta eseguita.
- È stato creato `docs/tennis-decision-ui/modules/python/05-betfair-diagnostics-and-network-capture.md`.
- `03-betfair-scraper.md` è rimasto owner del core/facade.
- Diagnostica, redazione, dump policy e network capture sono state assegnate al nuovo documento dedicato.
- La Graph URL validation conserva un owner documentale separato.

## Struttura precedente da considerare

- Flusso principale: entrypoint/CLI → browser session → Market API → Graph ladder opzionale → risultato JSON → consumer Node.
- Distinzione tra modalità persistent, CDP e login-only.
- Confini di ownership: lo scraper non possiede scheduler, persistence canonica, Evidence o UI.
- Sezioni relative a cache, lifecycle, stato partita, Graph ladder e verifiche.
- Precedenti contenuti diagnostici ora appartenenti al documento `05-*`.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `scrapers/betfair/cli.py`
- `scrapers/betfair/scrape.py`
- `scrapers/betfair/browser_session.py`
- `scrapers/betfair/cache.py`
- `scrapers/betfair/market_api.py`
- `scrapers/betfair/cdp_url.py`
- `scrapers/betfair/graph_url.py`
- `scrapers/betfair/ladder.py`
- `backend/src/sofa/betfairFetch.js`
- `backend/src/sofa/betfair/scraperLifecycle/runner.js`
- Test Betfair Python e `scraperLifecycle.test.mjs` direttamente pertinenti.

## Owner/documenti collegati

- `modules/python/04-betfair-graph-url-validation.md` — owner della validazione e del mapping delle Graph URL.
- `modules/python/05-betfair-diagnostics-and-network-capture.md` — owner di network capture, redazione, diagnostica e relative policy.
- Documentazione del lifecycle Betfair lato backend — confine Node relativo all’avvio, ai timeout e al consumo del risultato Python.

## Guardrail specifici per questo documento

- Mantenere `03-betfair-scraper.md` centrato sul core/facade dello scraper.
- Non duplicare i dettagli posseduti dai documenti `04-*` e `05-*`; usare riferimenti documentali quando necessari.
- Descrivere soltanto i comportamenti verificati nella CODE AUTHORITY.
- Conservare la distinzione tra proprietà del processo Python, proprietà del browser e lifecycle gestito dal backend Node.
- Non attribuire allo scraper responsabilità di scheduling, persistence canonica, Evidence o interfaccia utente.
- Trattare test e collaudo live come forme di verifica differenti, secondo quanto realmente presente nelle fonti correnti.

## Informazioni storiche da NON assumere come correnti

- Finding, valutazioni di gravità e proposte contenute nella parte di audit precedente alle modifiche.
- Dettagli pre-intervento relativi a cache, timeout, finished detection, classificazione Graph, network capture e flag Chromium.
- Pseudo-codice, ordine consigliato delle attività e verifiche future elencate nel report.
- Dipendenze storiche associate ad altri report o task, salvo riscontro diretto nella CODE AUTHORITY.
- Il collaudo live del browser non risulta sostituito dalla verifica automatica locale.

## Discrepanze o limiti delle fonti

- Markdown e JSON concordano sul completamento di `BETFAIR-SCRAPER-001..010`.
- Il report combina lo stato pre-intervento dell’audit con una decisione finale post-intervento; le descrizioni iniziali non rappresentano automaticamente il comportamento corrente.
- Le fonti storiche dichiarano 56 test Python Betfair e la suite Node superati, ma tali risultati devono essere considerati storici.
- Nessuna discrepanza storica tra mappa e JSON individuata.
