TODO:

Report: [`Report documentale/43 - implementazioni-tennis-decision-ui.md`](../Report%20documentale/43%20-%20implementazioni-tennis-decision-ui.md) — `TDUI-DOC-REPORT-043`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`ROOT-REG-001`** — priorità `high` — Definire una decisione superseding univoca per la policy `docs/archive/`, riallineando `DEC-026`, `ARCHIVE-DEC-001`, metodo, root registry e Todo senza cancellare automaticamente materiali dichiarati utili.
- [ ] **`ROOT-REG-002`** — priorità `high` — Rendere espliciti baseline e provenance dell’ultimo controllo dei registri: distinguere SHA codice, base/commit di recupero documentale, registry baseline realmente validata, scope/comandi e artifact del controllo.
- [x] **`ROOT-REG-003`** — priorità `high` — Separare policy “docs canonici descrivono il reale”, completamento meccanico della migrazione `.mdx → .md` e stato semantico effettivo: i finding documentali ancora aperti devono restare visibili e non essere assorbiti da claim di riallineamento globale.

JSON:

    {
      "change_id": "ROOT-REG-001",
      "report_id": "TDUI-DOC-REPORT-043",
      "document_path": "implementazioni-tennis-decision-ui.md",
      "priority": "high",
      "type": "archive_policy_decision_authority",
      "action": "Definire una decisione superseding univoca per la policy `docs/archive/`, riallineando `DEC-026`, `ARCHIVE-DEC-001`, metodo, root registry e Todo senza cancellare automaticamente materiali dichiarati utili.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "ROOT-REG-002",
      "report_id": "TDUI-DOC-REPORT-043",
      "document_path": "implementazioni-tennis-decision-ui.md",
      "priority": "high",
      "type": "registry_validation_provenance",
      "action": "Rendere espliciti baseline e provenance dell’ultimo controllo dei registri: distinguere SHA codice, base/commit di recupero documentale, registry baseline realmente validata, scope/comandi e artifact del controllo.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    },
    {
      "change_id": "ROOT-REG-003",
      "report_id": "TDUI-DOC-REPORT-043",
      "document_path": "implementazioni-tennis-decision-ui.md",
      "priority": "high",
      "type": "documentation_policy_vs_factual_state",
      "action": "Separare policy “docs canonici descrivono il reale”, completamento meccanico della migrazione `.mdx → .md` e stato semantico effettivo: i finding documentali ancora aperti devono restare visibili e non essere assorbiti da claim di riallineamento globale.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }