TODO:

Report: [`Report documentale/57 - 05-frontend-session-shell.md`](../Report%20documentale/57%20-%2005-frontend-session-shell.md) — `TDUI-DOC-REPORT-057`.

Modularizzazione: **valutata, non necessaria**.

- Nessuna nuova task: `FRONTEND-001…012`, `DOC-028…030`, `IMPL-025…027` e `TEST-044…059` restano coerenti con Todo e codice corrente; le strutture session controller, polling session-scoped e Market Reactions view model risultano ancora aperte e già correttamente owned.

JSON:
