TODO:

Report: [`../Report documentale/08 - 04-strategy.md`](../Report%20documentale/08%20-%2004-strategy.md) — `TDUI-DOC-REPORT-008`.

Modularizzazione: **valutata, non necessaria**. Il documento ha un solo endpoint e una sola feature legacy già approvata per la rimozione; non vengono proposti nuovi file. Destinazione finale: **eliminazione dopo l’applicazione verificata di `CODE-001`**.

- [x] **`STRATEGY-API-001`** — priorità `high` — Riscrivere temporaneamente `04-strategy.md` come contratto di dismissione: superficie ancora attiva, decisione di rimozione, consumer presenti, rischi noti, scope da rimuovere e superfici da preservare; eliminare il documento dopo `CODE-001`.
- [x] **`STRATEGY-API-002`** — priorità `critical` — Dichiarare non canonico il `marketEvidence` della Strategy: il builder bypassa Source Identity, persistence integrity, active market epoch ed eligibility Evidence; non riutilizzarlo e rimuoverlo con la superficie Strategy.
- [x] **`STRATEGY-API-003`** — priorità `high` — Correggere la descrizione semantica: `decision.signal` è disabilitato, ma il payload legacy espone ancora indicatori direzionali come pressure, confidence, money-flow trend, price delta e volume acceleration; non presentarli come Evidence canonica.
- [x] **`STRATEGY-API-004`** — priorità `high` — Registrare i limiti del target context legacy: possibile falso positivo del vincitore del set sul `6-5`, favorito Betfair non necessariamente associato a SofaScore, matching non basato su Source Identity e continuità temporale non garantita da `selectionId`/market epoch.
- [x] **`STRATEGY-API-005`** — priorità `high` — Assorbita da `CODE-001`: la route Strategy e la query `url` sono state rimosse, quindi non esiste più un input Strategy da validare o loggare.
- [x] **`STRATEGY-API-006`** — priorità `high` — Assorbita da `CODE-001`: la route Strategy e la relativa superficie di errori pubblici sono state rimosse.
- [x] **`STRATEGY-API-007`** — priorità `high` — Assorbita da `CODE-001`: eliminato il logging sincrono esclusivo Strategy su `backend_debug.log` insieme alla route.
- [x] **`STRATEGY-API-008`** — priorità `critical` — Applicato `CODE-001`: rimossi route e mount backend, polling e viste Strategy, componenti e moduli esclusivi; preservati Evidence, Market Reactions, Source Identity, Money Flow canonico, tracking e letture Betfair.
- [x] **`STRATEGY-API-009`** — priorità `medium` — Riallineare temporaneamente schema e verifica: tre tab reali, semantica di `header.competition`, disponibilità condizionale di `marketEvidence`, origine mista SofaScore/Betfair, mojibake e test realmente presenti; orientare poi la verifica alla rimozione completa.

JSON:

    {
      "change_id": "STRATEGY-API-001",
      "report_id": "TDUI-DOC-REPORT-008",
      "document_path": "docs/tennis-decision-ui/api/04-strategy.md",
      "priority": "high",
      "type": "decommissioning_contract",
      "action": "Riscrivere temporaneamente 04-strategy.md come contratto di dismissione e rimuoverlo dopo CODE-001.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STRATEGY-API-002",
      "report_id": "TDUI-DOC-REPORT-008",
      "document_path": "docs/tennis-decision-ui/api/04-strategy.md",
      "priority": "critical",
      "type": "legacy_market_evidence_authority",
      "action": "Dichiarare non canonico il marketEvidence Strategy, vietarne il riuso e rimuoverlo con CODE-001.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STRATEGY-API-003",
      "report_id": "TDUI-DOC-REPORT-008",
      "document_path": "docs/tennis-decision-ui/api/04-strategy.md",
      "priority": "high",
      "type": "directional_legacy_output",
      "action": "Distinguere decisione disabilitata dagli indicatori direzionali legacy ancora esposti e non presentarli come Evidence canonica.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STRATEGY-API-004",
      "report_id": "TDUI-DOC-REPORT-008",
      "document_path": "docs/tennis-decision-ui/api/04-strategy.md",
      "priority": "high",
      "type": "legacy_target_context",
      "action": "Registrare i limiti del target context legacy senza avviare un nuovo refactor strategico.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STRATEGY-API-005",
      "report_id": "TDUI-DOC-REPORT-008",
      "document_path": "docs/tennis-decision-ui/api/04-strategy.md",
      "priority": "high",
      "type": "url_validation",
      "action": "Correggere il contratto della query url; se la route resta transitoriamente usare il validator SofaScore canonico e non loggare input raw.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STRATEGY-API-006",
      "report_id": "TDUI-DOC-REPORT-008",
      "document_path": "docs/tennis-decision-ui/api/04-strategy.md",
      "priority": "high",
      "type": "public_error_redaction",
      "action": "Rimuovere errori raw e mapping fragile; usare code e messaggi bounded soltanto se la route resta temporaneamente.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STRATEGY-API-007",
      "report_id": "TDUI-DOC-REPORT-008",
      "document_path": "docs/tennis-decision-ui/api/04-strategy.md",
      "priority": "high",
      "type": "synchronous_logging",
      "action": "Eliminare il logging sincrono esclusivo Strategy o renderlo transitoriamente best-effort, bounded e redatto.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STRATEGY-API-008",
      "report_id": "TDUI-DOC-REPORT-008",
      "document_path": "docs/tennis-decision-ui/api/04-strategy.md",
      "priority": "critical",
      "type": "strategy_runtime_removal",
      "action": "Applicare CODE-001 rimuovendo route, mount, polling e UI Strategy esclusivi, preservando Evidence, Market Reactions, Source Identity e dati canonici.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "STRATEGY-API-009",
      "report_id": "TDUI-DOC-REPORT-008",
      "document_path": "docs/tennis-decision-ui/api/04-strategy.md",
      "priority": "medium",
      "type": "temporary_schema_and_verification_alignment",
      "action": "Riallineare temporaneamente schema e verifica e orientare poi i controlli alla rimozione completa.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }