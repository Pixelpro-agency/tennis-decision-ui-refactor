# Scheda di contesto documentale

## Documento target

Percorso:
`docs/validations/README.md`

Tipo di documento:
policy e indice delle validazioni storiche.

Ruolo documentale:
definire come interpretare e catalogare gli artifact Markdown di validazione storica, mantenendoli distinti dagli owner del comportamento corrente, dai test automatici e dalle prove riferite al commit corrente.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`
- `Report documentale/39 - README-validations.md` — `TDUI-DOC-REPORT-039`
- sezione Markdown e record JSON relativi a `docs/validations/README.md` contenuti in `39 - TODO e Json.md`

## Task storicamente associate

- `VALID-INDEX-001` — stato: completata  
  Argomento coinvolto: tassonomia documentale delle evidenze storiche, con distinzione fra stato complessivo del documento, stato dei singoli scenari e qualificatori relativi a evidenze o metadata mancanti.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `VALID-INDEX-002` — stato: completata  
  Argomento coinvolto: uniformità dei metadata delle validation e distinzione fra dato noto, non registrato, non archiviato e non applicabile. L'eventuale verifica automatizzata resta collegata all'owner storico `VALID-ROLL-006`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `VALID-INDEX-003` — stato: completata  
  Argomento coinvolto: identità delle run, naming stabile e conservazione immutabile degli artifact storici in caso di riesecuzione.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata e dichiarata non necessaria.
- Non risultano nuovi documenti canonici derivati dal README.
- Il documento è rimasto un unico punto breve di policy e indice, separato dagli artifact di validazione dettagliati e dal futuro ledger dei risultati.

## Struttura precedente da considerare

- confine fra evidenza storica, owner corrente, test automatico e prova sul commit corrente;
- regole per metadata e informazioni storicamente mancanti;
- vocabolario degli stati delle evidenze storiche;
- lifecycle e identità delle riesecuzioni;
- indice navigabile degli artifact presenti;
- guardrail di privacy e redazione.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- contenuto corrente di `docs/validations/README.md`;
- artifact correnti sotto `docs/validations/`, in particolare quelli indicizzati dal README;
- contratto corrente del validation runner e dei relativi risultati, limitatamente ai confini con gli stati storici;
- provenance corrente delle run e della working tree, limitatamente ai metadata richiamati dalla policy;
- eventuale ledger corrente delle validation, per evitare duplicazioni di ruolo.

## Owner/documenti collegati

- `docs/validations/source-identity-live-verification.md` — artifact storico di dominio indicizzato; non è owner del comportamento corrente.
- `docs/validations/betfair-live-validation-2026-07-04.md` — artifact storico di dominio indicizzato; non è owner del comportamento corrente.
- `docs/validations/documentation-migration-finalization-2026-08-03.md` — artifact storico della migrazione documentale.
- `docs/tennis-decision-ui/operations/04-validation-and-rollback.md` — owner collegato per workflow, runner, provenance e rollback; il README mantiene il solo vocabolario e indice storico.
- `docs/tennis-decision-ui/roadmap/01-current-state.md` — può riepilogare evidenze archiviate senza sostituire gli artifact né promuoverle a stato corrente.
- `IMPL-031` — owner storico associato al result ledger; il README non ne duplica schema e cronologia.

## Guardrail specifici per questo documento

- Conservare la distinzione fra evidenza storica, comportamento corrente, test automatico e prova sul commit corrente.
- Non presentare `live_observed` come equivalente a un PASS automatico.
- Non ricostruire per inferenza metadata storici assenti; mantenere esplicite le diverse semantiche di dato non registrato, artifact non archiviato e caso non applicabile.
- Mantenere il README come policy e indice navigabile, non come ledger completo delle run.
- Non indicizzare come validation eseguita un artifact inesistente e non creare placeholder per osservazioni prive di artifact.
- Mantenere informazioni di ambiente sufficienti a interpretare l'evidenza ma prive di segreti, identificatori sensibili, path locali e diagnostica raw non necessaria.
- Non modificare retroattivamente il significato di una validation storica per adeguarlo al comportamento corrente.

## Informazioni storiche da NON assumere come correnti

- Gli esiti e le osservazioni contenuti negli artifact storici non dimostrano lo stesso comportamento sul CODE AUTHORITY.
- Le tassonomie, i metadata e le convenzioni descritte dal report di audit non costituiscono da sole il contenuto corrente del README.
- I riferimenti storici a validation di launcher, Stop o runtime lifecycle non provano l'esistenza di artifact corrispondenti sotto `docs/validations/`.
- Le proposte di forma, naming e verification contenute nel report non devono essere trattate come prescrizioni attuali senza riscontro nella baseline tecnica.
- Gli owner e i contratti richiamati dai Change ID storici devono essere verificati nella loro forma corrente.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza individuata fra la sezione Markdown e i record JSON: `VALID-INDEX-001`, `VALID-INDEX-002` e `VALID-INDEX-003` risultano completate in entrambe le fonti.
- Il report documentale fotografa la documentation structure baseline, non il CODE AUTHORITY successivo.
- Le fonti storiche non attestano da sole quali formulazioni e strutture siano presenti oggi nel documento target.
