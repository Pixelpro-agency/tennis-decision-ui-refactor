TODO:

Report: [`Report documentale/62 - 03-operations-roadmap-e-controlli.md`](../Report%20documentale/62%20-%2003-operations-roadmap-e-controlli.md) — `TDUI-DOC-REPORT-062`.

Modularizzazione: **valutata, eseguita**.

File realizzati:

```text
implementazioni/audit-documentazione/03-operations-roadmap-e-controlli/01-operations-roadmap-b5.md
implementazioni/audit-documentazione/03-operations-roadmap-e-controlli/02-controlli-trasversali-b6.md
```

Il file `implementazioni/audit-documentazione/03-operations-roadmap-e-controlli.md` resta come facade stabile.

- [x] **`DOC-AUDIT-B56-001`** — **HIGH** — Riconciliare B5/B6 come checkpoint storici con lo stato post-migrazione: `DOC-020` e `DOC-023` diventano risolti, `DOC-021` resta root storicamente valida ma viene superseded da `DOC-031` come owner corrente, `DOC-022` resta aperto/parzialmente migliorato; preservare `WORKFLOW-002/003` completati e aggiungere pointer current per `IMPL-001`, `IMPL-005`, `TEST-003`, README `index.mdx`, roadmap future rimosse dal canonico, §15.5 e gli esiti B5/B6 senza riscrivere il checkpoint.
- [x] **`DOC-AUDIT-B56-002`** — **MEDIUM-HIGH** — Trasformare `03-operations-roadmap-e-controlli.md` in facade breve e separare B5 Operations/Roadmap da B6 Controlli trasversali nei due child proposti, preservando `DOC-020…023`, `WORKFLOW-002/003`, baseline B6, test-letti/non-eseguiti, path storici e current overlay; verificare registry checker, link checker, fast e `git diff --check`.

JSON:

```json
{
  "change_id": "DOC-AUDIT-B56-001",
  "report_id": "TDUI-DOC-REPORT-062",
  "document_path": "implementazioni/audit-documentazione/03-operations-roadmap-e-controlli.md",
  "priority": "high",
  "type": "historical_current_authority_supersession",
  "action": "Aggiungere la reconciliation B5/B6 post-migrazione: DOC-020 risolto, DOC-021 precursore storico superseded da DOC-031, DOC-022 ancora aperto/parziale, DOC-023 risolto; aggiornare pointer current per IMPL-001/005, TEST-003, README index.mdx e roadmap future senza riscrivere il checkpoint.",
  "checkbox": "[x]",
  "completed": true,
  "status": "completed"
},
{
  "change_id": "DOC-AUDIT-B56-002",
  "report_id": "TDUI-DOC-REPORT-062",
  "document_path": "implementazioni/audit-documentazione/03-operations-roadmap-e-controlli.md",
  "priority": "medium-high",
  "type": "modularization_context_boundary",
  "action": "Mantenere `03-operations-roadmap-e-controlli.md` come facade e separare B5 Operations/Roadmap e B6 Controlli trasversali nei due child proposti, preservando baseline, owner ID, provenance e current overlay.",
  "checkbox": "[x]",
  "completed": true,
  "status": "completed"
}
```

Nota di stato post-esecuzione: la modularizzazione documentale di `DOC-AUDIT-B56-002` risulta eseguita. I quattro gate repository-level citati nella descrizione della task non risultano invece verificati sulla working tree finale in questa esecuzione e non devono essere considerati PASS senza un report separato.
