TODO:

Report: [`Report documentale/34 - 03-betfair-diagnostics.md`](../Report%20documentale/34%20-%2003-betfair-diagnostics.md) — `TDUI-DOC-REPORT-034`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`BETFAIR-DIAG-001`** — priorità `high` — Rendere truthful la tassonomia health: `yellow/STALE` non significa soltanto age stale; documentare tutte le cause yellow correnti e diagnosticare tramite `message/reasons/checks/metrics`, con test dedicati.
- [ ] **`BETFAIR-DIAG-002`** — priorità `high` — Rendere esplicita la finestra degli ultimi tre tick e definire una vera authority di auth recovery; un singolo tick sano non garantisce clear immediato del red. Testare status-only → healthy 1/2/3 e healthy singolo senza nuovi tick.
- [x] **`BETFAIR-DIAG-003`** — priorità `critical` — Non trattare `hasFinished` ricevuto come finished authoritative finché il producer non è hardenizzato; coordinare `BETFAIR-SCRAPER-006` e `SOFA-LIVE-007`, senza creare un secondo finished detector.
- [x] **`BETFAIR-DIAG-004`** — priorità `high` — Distinguere Node runtime log, Python Betfair log e capture artifacts; `/api/betfair/log` è un tail globale del log Python e una riga recente non prova la sessione corrente. Definire correlazione bounded con identificatori approvati.
- [x] **`BETFAIR-DIAG-005`** — priorità `high` — Documentare la network capture per entrypoint: tracking Node off di default; `/odds` off salvo `networkCapture=true`; CLI Python standalone on di default salvo `--no-network-capture`. Verificare matrice Node/CLI e dump creation.
- [x] **`BETFAIR-DIAG-006`** — priorità `critical` — Non presentare `/api/betfair/odds` come route read-only diagnostica: dichiararla legacy e potenzialmente mutante, coordinare `BETFAIR-LIFE-006`/`BETFAIR-API-007` e definire un replacement diagnostico safe prima dell'eventuale rimozione.
- [x] **`BETFAIR-DIAG-007`** — priorità `high` — Non trattare `no_known_partial` come prova di scan riuscito; coordinare `JOURNAL-REC-004/005`, qualificare `recovery_failed` e consumare la futura tassonomia storage fail-closed senza crearne una seconda.
- [x] **`BETFAIR-DIAG-008`** — priorità `high` — Ampliare la verification matrix a cause yellow, auth recovery, log planes, Node vs CLI capture, legacy `/odds`, integrity degraded, finished authority e redaction; usare suite modulari correnti e live artifact solo con provenance reale.

JSON:

    {
      "change_id": "BETFAIR-DIAG-001",
      "report_id": "TDUI-DOC-REPORT-034",
      "document_path": "docs/tennis-decision-ui/operations/03-betfair-diagnostics.md",
      "priority": "high",
      "type": "diagnostic_health_semantics",
      "action": "Rendere truthful la tassonomia health: `yellow/STALE` non significa soltanto age stale; documentare tutte le cause yellow correnti e diagnosticare tramite `message/reasons/checks/metrics`, con test dedicati.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-DIAG-002",
      "report_id": "TDUI-DOC-REPORT-034",
      "document_path": "docs/tennis-decision-ui/operations/03-betfair-diagnostics.md",
      "priority": "high",
      "type": "auth_recovery_hysteresis",
      "action": "Rendere esplicita la finestra degli ultimi tre tick e definire una vera authority di auth recovery; un singolo tick sano non garantisce clear immediato del red. Testare status-only → healthy 1/2/3 e healthy singolo senza nuovi tick.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    },
    {
      "change_id": "BETFAIR-DIAG-003",
      "report_id": "TDUI-DOC-REPORT-034",
      "document_path": "docs/tennis-decision-ui/operations/03-betfair-diagnostics.md",
      "priority": "critical",
      "type": "finished_authority_alignment",
      "action": "Non trattare `hasFinished` ricevuto come finished authoritative finché il producer non è hardenizzato; coordinare BETFAIR-SCRAPER-006 e SOFA-LIVE-007, senza creare un secondo finished detector.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-DIAG-004",
      "report_id": "TDUI-DOC-REPORT-034",
      "document_path": "docs/tennis-decision-ui/operations/03-betfair-diagnostics.md",
      "priority": "high",
      "type": "diagnostic_log_provenance",
      "action": "Distinguere Node runtime log, Python Betfair log e capture artifacts; `/api/betfair/log` è un tail globale del log Python e una riga recente non prova la sessione corrente. Definire correlazione bounded con identificatori approvati.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-DIAG-005",
      "report_id": "TDUI-DOC-REPORT-034",
      "document_path": "docs/tennis-decision-ui/operations/03-betfair-diagnostics.md",
      "priority": "high",
      "type": "network_capture_activation_contract",
      "action": "Documentare la network capture per entrypoint: tracking Node off di default; `/odds` off salvo `networkCapture=true`; CLI Python standalone on di default salvo `--no-network-capture`. Verificare matrice Node/CLI e dump creation.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-DIAG-006",
      "report_id": "TDUI-DOC-REPORT-034",
      "document_path": "docs/tennis-decision-ui/operations/03-betfair-diagnostics.md",
      "priority": "critical",
      "type": "legacy_odds_diagnostic_boundary",
      "action": "Non presentare `/api/betfair/odds` come route read-only diagnostica: dichiararla legacy e potenzialmente mutante, coordinare BETFAIR-LIFE-006/BETFAIR-API-007 e definire un replacement diagnostico safe prima dell'eventuale rimozione.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-DIAG-007",
      "report_id": "TDUI-DOC-REPORT-034",
      "document_path": "docs/tennis-decision-ui/operations/03-betfair-diagnostics.md",
      "priority": "high",
      "type": "integrity_fail_closed_alignment",
      "action": "Non trattare `no_known_partial` come prova di scan riuscito; coordinare JOURNAL-REC-004/005, qualificare `recovery_failed` e consumare la futura tassonomia storage fail-closed senza crearne una seconda.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-DIAG-008",
      "report_id": "TDUI-DOC-REPORT-034",
      "document_path": "docs/tennis-decision-ui/operations/03-betfair-diagnostics.md",
      "priority": "high",
      "type": "verification_provenance_matrix",
      "action": "Ampliare la verification matrix a cause yellow, auth recovery, log planes, Node vs CLI capture, legacy `/odds`, integrity degraded, finished authority e redaction; usare suite modulari correnti e live artifact solo con provenance reale.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }