# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/ai/03-workflow-esecutivo.md`

Tipo di documento:  
documento metodologico / workflow operativo.

Ruolo documentale:  
owner del workflow esecutivo generale, dei ruoli, del lifecycle delle task, della revisione, dei collaudi, della pubblicazione e dei criteri di chiusura. Le fonti storiche indicano che i contratti dettagliati degli artefatti esecutivi e i criteri tecnici di diagnosi/modularizzazione sono stati separati o destinati a owner dedicati.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`
- `Report documentale — docs/tennis-decision-ui/ai/03-workflow-esecutivo.md` — `TDUI-DOC-REPORT-004`
- `04 - TODO e Json.md`

## Task storicamente associate

- `WF-DOC-001` — stato: completata  
  Argomento coinvolto: requisiti del prompt differenziati per modalità e criteri `PRONTO PER TASK`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `WF-DOC-002` — stato: completata  
  Argomento coinvolto: riproducibilità della generazione degli artefatti esecutivi e uso storico di Repomix.  
  Uso consentito: verificare nel CODE AUTHORITY quale contratto corrente sia rimasto nel workflow e quale appartenga all'owner degli artefatti.

- `WF-DOC-003` — stato: completata  
  Argomento coinvolto: integrità del contesto per artefatti di revisione grandi o segmentati.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente e l'eventuale ownership esterna al workflow.

- `WF-DOC-004` — stato: completata  
  Argomento coinvolto: evidenze richieste per task di sola cancellazione e rapporto con gli artefatti di revisione.  
  Uso consentito: verificare nel CODE AUTHORITY il comportamento documentato corrente.

- `WF-DOC-005` — stato: completata  
  Argomento coinvolto: separazione delle responsabilità tra workflow, diagnosi/modularizzazione e artefatti esecutivi.  
  Uso consentito: verificare nel CODE AUTHORITY la struttura documentale realmente presente e mantenere nel documento target soltanto il proprio ruolo corrente.

- `WF-DOC-006` — stato: completata  
  Argomento coinvolto: revisione condizionale, fasi di chiusura, controlli Git e protezione degli artefatti locali.  
  Uso consentito: verificare nel CODE AUTHORITY quali regole risultino correnti e pertinenti al workflow.

## Cambiamenti strutturali storicamente rilevanti

- Il report individuava tre responsabilità distinte: workflow e ruoli; artefatti esecutivi; diagnosi e modularizzazione.
- La struttura storicamente proposta era:
  - `03-workflow-esecutivo.md` come owner del lifecycle e dei ruoli;
  - `04-diagnosi-e-modularizzazione.md` come owner della diagnosi strutturale;
  - `05-artefatti-esecutivi.md` come owner di consegna, `fileModificati.md` e report.
- `WF-DOC-005` risulta successivamente marcata come completata nelle fonti TODO/JSON.
- L'effettiva struttura corrente deve essere verificata nella baseline tecnica prima di descriverla come vigente.

## Struttura precedente da considerare

Elementi storicamente centrali del documento:

- scopo e principi del workflow;
- quattro ruoli operativi;
- scelta della modalità;
- gerarchia delle fonti;
- regola dei tentativi;
- revisione della Chat Analisi;
- collaudi;
- Git e pubblicazione;
- criteri `PRONTO PER TASK`;
- fasi e criteri di chiusura;
- impatto documentale;
- collegamenti agli owner separati.

Il documento precedente conteneva anche sezioni dettagliate su `fileModificati.md`, ciclo `CHAT_ESECUTORE`, report finale e criteri tecnici di modularizzazione.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `docs/tennis-decision-ui/ai/03-workflow-esecutivo.md`
- `docs/tennis-decision-ui/ai/04-diagnosi-e-modularizzazione.md`
- `docs/tennis-decision-ui/ai/05-artefatti-esecutivi.md`
- `docs/tennis-decision-ui/ai/01-context-selection.md`
- `docs/tennis-decision-ui/ai/02-documentation-conventions.md`
- `docs/tennis-decision-ui/index.md`
- `.gitignore`
- `scripts/check_documentation_links.py`
- `scripts/check_registry_consistency.py`
- `scripts/validation/run.mjs`
- eventuale generatore project-owned degli artefatti: possibile fonte da verificare

## Owner/documenti collegati

- `docs/tennis-decision-ui/ai/01-context-selection.md` — contesto e selezione delle fonti; non dovrebbe duplicare il contratto completo dei ruoli.
- `docs/tennis-decision-ui/ai/02-documentation-conventions.md` — convenzioni documentali e collegamenti con il workflow.
- `docs/tennis-decision-ui/ai/04-diagnosi-e-modularizzazione.md` — owner storicamente previsto per diagnosi strutturale e criteri di modularizzazione.
- `docs/tennis-decision-ui/ai/05-artefatti-esecutivi.md` — owner storicamente previsto per consegna, artefatti esecutivi e report.
- `docs/tennis-decision-ui/index.md` — indice e collegamenti della documentazione.

## Guardrail specifici per questo documento

- Mantenere il documento come owner del workflow generale e non trasformarlo in un manuale tecnico di implementazione.
- Non reintrodurre automaticamente nel workflow i dettagli che risultano assegnati a `04-diagnosi-e-modularizzazione.md` o `05-artefatti-esecutivi.md`.
- Conservare la separazione concettuale fra analisi, esecuzione, collaudo, revisione e pubblicazione soltanto nella forma realmente supportata dallo stato corrente.
- Non trasformare finding, priorità o proposte del report storico in istruzioni correnti.
- Non assumere che una proposta storica sia implementata soltanto perché descritta nel report; usare la baseline tecnica per stabilire lo stato corrente.
- Mantenere i confini con `01-context-selection.md` e `02-documentation-conventions.md` evitando duplicazioni non necessarie.

## Informazioni storiche da NON assumere come correnti

- Le gravità e le priorità assegnate ai finding del report.
- Le formulazioni di soluzione contenute nelle sezioni “Modifica consigliata”.
- L'uso di `repomix@latest` come comportamento corrente.
- L'esistenza o il formato corrente di un pacchetto segmentato per `fileModificati`.
- Qualunque soglia numerica per segmentazione o dimensione degli artefatti.
- Lo stato corrente di `.gitignore` descritto nel report audit.
- I comandi Git proposti nel report come se fossero già il contratto vigente.
- L'esistenza di un generatore project-owned degli artefatti, se non confermata nel CODE AUTHORITY.
- Le strutture proposte per `04-diagnosi-e-modularizzazione.md` e `05-artefatti-esecutivi.md` se non confermate nella baseline corrente.
- I controlli elencati nel report come “previsti dopo un'eventuale modifica”: il report dichiara che non erano stati eseguiti durante l'analisi.

## Discrepanze o limiti delle fonti

- `DISCREPANZA STORICA DA NON RISOLVERE AUTOMATICAMENTE`: il PROMPT 0 allegato indica come documento target `docs/tennis-decision-ui/ai/02-documentation-conventions.md`, mentre il report e il TODO/JSON forniti riguardano `docs/tennis-decision-ui/ai/03-workflow-esecutivo.md`. La presente scheda usa `03-workflow-esecutivo.md` perché è il documento identificato in modo coerente dalle due fonti storiche specifiche.
- Il report rappresenta uno stato di audit precedente all'applicazione delle modifiche: descrive la modularizzazione e varie modifiche come proposte. Il TODO/JSON successivo marca `WF-DOC-001`–`WF-DOC-006` come completate. La baseline tecnica deve stabilire quali effetti siano realmente presenti.
- Il commit analizzato dal report coincide con la Documentation structure baseline (`4c5f43b007149f3210c27d7565357a447a3a6ef4`), ma non con il CODE AUTHORITY successivo (`12b344ea96e71b2bdaa6931c98419ce925b5c228`); le differenze tra i due stati non devono essere dedotte dalle sole fonti storiche.
