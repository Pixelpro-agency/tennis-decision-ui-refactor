# Scheda di contesto documentale

## Documento target

Percorso:
`README.md`

Tipo di documento:
documento introduttivo / punto di ingresso generale del progetto.

Ruolo documentale:
presentare a livello generale finalità del progetto, stack, requisiti, installazione, avvio, validazione, struttura del repository, gestione dei dati locali/sensibili e riferimenti alla documentazione tecnica. Il report storico identifica esplicitamente il README come «punto di ingresso generale del progetto».

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

* Mappa/registro modifiche relativo a `README.md`, fornito nel contesto corrente.
* JSON delle modifiche `README-001`, `README-002` e `README-STYLE-001`, fornito nel contesto corrente.
* `Report documentale/01 - Readme.md` — `TDUI-DOC-REPORT-001`, riferito alla precedente baseline documentale `4c5f43b007149f3210c27d7565357a447a3a6ef4`.
* `PROMPT 0 — Preparazione Scheda neutra per technical writing.txt`, usato esclusivamente come criterio metodologico per questa scheda; stabilisce che il materiale storico non costituisce authority tecnica e che la scheda non deve trasferire finding o prescrizioni alla fase di technical writing.

## Task storicamente associate

* `README-001` — stato: completata
  Argomento coinvolto: formulazione del requisito Node.js/npm e relativo allineamento ai manifest backend e frontend.
  Uso consentito: verificare nel CODE AUTHORITY quale requisito sia attualmente dichiarato dai manifest e descriverlo nel README soltanto al livello appropriato per un documento introduttivo. La formulazione storicamente applicata evitava di dichiarare una versione Node non esplicitamente stabilita dal repository.

* `README-002` — stato: completata
  Argomento coinvolto: rappresentazione dei dati locali sotto `backend/match_history/` e dei sidecar `.pending_commits/` e `.writer_authority/`.
  Uso consentito: verificare nel CODE AUTHORITY la struttura corrente della persistenza locale e riportare nel README soltanto i percorsi utili all'orientamento generale.

* `README-STYLE-001` — stato: completata
  Argomento coinvolto: terminologia usata per descrivere l'output JSON prodotto dai comandi di validazione.
  Uso consentito: verificare il comportamento corrente del validation runner e mantenere una formulazione italiana coerente con il resto del README.

## Cambiamenti strutturali storicamente rilevanti

Nessuno individuato.

La modularizzazione è stata valutata e non è risultata necessaria. Il report storico descrive il README come documento breve e unitario e non registra la creazione di nuovi documenti derivati.

## Struttura precedente da considerare

La versione analizzata organizzava il README attorno a questi argomenti generali:

* descrizione/finalità del progetto;
* stack tecnologico;
* requisiti;
* installazione e `.env`;
* avvio e porte;
* comandi di validazione;
* struttura del repository;
* dati locali e sensibili;
* collegamenti alla documentazione tecnica.

Da confrontare con il CODE AUTHORITY e con la documentation structure baseline, recuperando soltanto ciò che resta corrente e pertinente al ruolo introduttivo del README.

Mantenere la forma propria del documento senza imporre uno schema nuovo.

## Aree da verificare nel CODE AUTHORITY

* `README.md`
* `backend/package.json`
* `frontend/package.json`
* `backend/match_history/`
* `backend/match_history/.pending_commits/`
* `backend/match_history/.writer_authority/`
* manifest e runner dei profili di validazione citati dal README, limitatamente alle informazioni che il README continua a esporre
* `.env.example`, limitatamente ai requisiti di configurazione descritti nel README
* launcher/configurazione di avvio, limitatamente alle porte e al comportamento generale eventualmente riportati nel README

## Owner/documenti collegati

* `docs/tennis-decision-ui/index.md` — riferimento storico indicato dal README come ingresso alla documentazione tecnica canonica.
* `docs/tennis-decision-ui/roadmap/01-current-state.md` — riferimento storico al quadro dello stato corrente del progetto.
* Documentazione owner dello storage — collegata storicamente alla semantica di `.pending_commits/` e `.writer_authority/`; il percorso preciso dell'owner non è indicato nel report e deve essere ricavato dalla struttura documentale corrente, se necessario.

## Guardrail specifici per questo documento

* Conservare il README come punto di ingresso generale, senza trasformarlo in una copia dei documenti owner.
* Non usarlo come registro di task, decisioni o finding; il report storico indica esplicitamente questa separazione di ruolo.
* Non espandere automaticamente nel README contratti API, dettagli completi di storage, lifecycle o procedure diagnostiche che appartengono agli owner.
* Mantenere concise le informazioni sullo stack: il report storico considera appropriato non elencare ogni dipendenza dei manifest.
* Verificare ogni dato tecnico variabile — versioni, porte, profili di validazione, percorsi e configurazioni — contro il CODE AUTHORITY prima di conservarlo.
* Non introdurre una nuova modularizzazione del README sulla sola base del materiale storico.

## Informazioni storiche da NON assumere come correnti

* La specifica combinazione di framework e dipendenze riportata nel report.
* I requisiti Node.js/npm descritti nella precedente baseline.
* Le porte `9222`, `3001` e `3000` riportate nel precedente README.
* L'elenco e lo stato storico dei profili di validazione.
* La presenza e la semantica correnti di `.pending_commits/` e `.writer_authority/`.
* I nomi e i contenuti correnti delle variabili presenti in `.env.example`.
* La disponibilità e il ruolo corrente dei documenti collegati.
* Le valutazioni di coerenza, gravità o qualità contenute nel report di audit.

Questi elementi servono esclusivamente a identificare cosa confrontare con il CODE AUTHORITY.

## Discrepanze o limiti delle fonti

* Nessuna discrepanza individuata tra la mappa/JSON forniti e il report relativamente agli ID `README-001`, `README-002` e `README-STYLE-001`: tutte e tre le modifiche risultano storicamente completate.
* Il report documentale fotografa il commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`, mentre il technical writer dovrà usare come authority tecnica il commit `12b344ea96e71b2bdaa6931c98419ce925b5c228`; pertanto le descrizioni tecniche del report non devono essere trasferite automaticamente nel README corrente.
* Il percorso preciso della documentazione owner dello storage non è esplicitato nel report consultato.
TODO:



JSON: