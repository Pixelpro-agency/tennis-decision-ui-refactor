TODO:

Report: [`Report documentale/66 - 03-storage-recovery.md`](../Report%20documentale/66%20-%2003-storage-recovery.md) — `TDUI-DOC-REPORT-066`.

Modularizzazione: **valutata, non necessaria**.

- [ ] **`IMPL-STORAGE-001`** — **HIGH** — Registrare per `IMPL-019…021` il boundary fra primitive già implementate dalla Task 6 e contratto residuo: preservare journal/recovery, target verification, reopen incomplete, recovery bootstrap, summary bounded e stati `partial_persistence`/`recovery_failed`; esplicitare invece come mancanti event-scoped authority, revision/headCommitId, digest/base revision, schema/identity verification, ambiguous storage e recovery control-plane persistente.
- [ ] **`IMPL-STORAGE-002`** — **HIGH** — Normalizzare dependency graph e sequencing di `IMPL-019…021`: rendere coerente la relazione `IMPL-021↔IMPL-009` con l’ordine §18.2, chiarire il ruolo della baseline `IMPL-013` rispetto all’evoluzione del formato introdotta da `IMPL-020`, classificare `IMPL-008` come supporto di validazione e rimuovere ogni ciclo implicito senza eseguire implementazioni.

JSON:

    {
      "change_id": "IMPL-STORAGE-001",
      "report_id": "TDUI-DOC-REPORT-066",
      "document_path": "implementazioni/implementazioni-proposte/03-storage-recovery.md",
      "priority": "high",
      "type": "implementation_state_granularity_existing_recovery",
      "action": "Registrare per IMPL-019…021 il boundary fra primitive già implementate dalla Task 6 e contratto residuo: preservare journal/recovery, target verification, reopen incomplete, recovery bootstrap, summary bounded e stati partial/recovery_failed; esplicitare invece come mancanti event-scoped authority, revision/headCommitId, digest/base revision, schema/identity verification, ambiguous storage e recovery control-plane persistente.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    },
    {
      "change_id": "IMPL-STORAGE-002",
      "report_id": "TDUI-DOC-REPORT-066",
      "document_path": "implementazioni/implementazioni-proposte/03-storage-recovery.md",
      "priority": "high",
      "type": "dependency_metadata_sequencing_contradiction",
      "action": "Normalizzare dependency graph e sequencing di IMPL-019…021: rendere coerente la relazione IMPL-021↔IMPL-009 con l’ordine §18.2, chiarire il ruolo della baseline IMPL-013 rispetto all’evoluzione del formato introdotta da IMPL-020, classificare IMPL-008 come supporto di validazione e rimuovere ogni ciclo implicito senza eseguire implementazioni.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    }