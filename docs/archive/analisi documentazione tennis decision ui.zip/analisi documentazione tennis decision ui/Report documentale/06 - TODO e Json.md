TODO:

Report: [`../Report documentale/06 - 02-betfair.md`](../Report%20documentale/06%20-%2002-betfair.md) — `TDUI-DOC-REPORT-006`.

Modularizzazione: **richiesta**. File proposti: `docs/tennis-decision-ui/api/betfair/01-read-integrity-and-health.md`, `docs/tennis-decision-ui/api/betfair/02-money-flow-history.md`, `docs/tennis-decision-ui/api/betfair/03-odds-and-log.md`, `docs/tennis-decision-ui/api/betfair/04-login-window.md`.

- [x] **`BETFAIR-API-001`** — priorità `critical` — Validare `cdpUrl` di `/latest` con `classifyCdpBaseUrl`, rifiutare host non-loopback senza eseguire fetch, aggiornare il contratto read-only e aggiungere test dedicati a input, timeout ed errori.
- [x] **`BETFAIR-API-002`** — priorità `high` — Sostituire negli esempi `integrity.reason: commit_incomplete` con il valore canonico `pending_commit` e distinguere le reason di `recovery_failed`.
- [x] **`BETFAIR-API-003`** — priorità `high` — Documentare la vista timeline HTTP reale: normalizzazione di `timeline`, campo derivato `latest`, aggiunta di `integrity` e distinzione rispetto al documento persistito.
- [x] **`BETFAIR-API-004`** — priorità `high` — Precisare che missing, read failure e JSON invalido vengono collassati a `null`; valutare `loadTimelineResult` e status HTTP distinti coordinando la decisione con `MATCH-API-005`.
- [x] **`BETFAIR-API-005`** — priorità `medium` — Documentare il caso `/latest` con timeline presente ma nessun tick valido: `HTTP 200`, `ok:false`, `latest:null`; distinguere inoltre `latestTimestamp` da `metadata.updatedAt`.
- [x] **`BETFAIR-API-006`** — priorità `high` — Correggere le tolleranze Money Flow: `max(1, 10%)` per il confronto raw/computed e `max(1, 5%)` per runner rispetto al market delta, mantenendo distinti delta negativi e zero-vs-positivo.
- [x] **`BETFAIR-API-007`** — priorità `high` — Mettere in sicurezza `/odds`: eliminare `details: error.message`, usare code e messaggi bounded, validare protocollo e host Betfair e coordinare la correzione con l’eventuale rimozione della route.
- [x] **`BETFAIR-API-008`** — priorità `medium` — Documentare il fallback di `mode`, l’identità runtime e il fatto che il target URL non partecipa alla deduplica; decidere se preservare o modificare tali comportamenti.
- [x] **`BETFAIR-API-009`** — priorità `high` — Mantenere `02-betfair.md` come facade, creare quattro owner per letture/integrity/health, Money Flow, odds/log e login-window; aggiornare indice, link, syntax check e test di verifica.

JSON:

    {
      "change_id": "BETFAIR-API-001",
      "document_path": "docs/tennis-decision-ui/api/02-betfair.md",
      "report_id": "TDUI-DOC-REPORT-006",
      "report_path": "../Report documentale/06 - 02-betfair.md",
      "priority": "critical",
      "type": "cdp_status_security",
      "action": "Validare `cdpUrl` di `/latest` con `classifyCdpBaseUrl`, rifiutare host non-loopback senza eseguire fetch, aggiornare il contratto read-only e aggiungere test dedicati a input, timeout ed errori.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-API-002",
      "document_path": "docs/tennis-decision-ui/api/02-betfair.md",
      "report_id": "TDUI-DOC-REPORT-006",
      "report_path": "../Report documentale/06 - 02-betfair.md",
      "priority": "high",
      "type": "integrity_contract",
      "action": "Sostituire negli esempi `integrity.reason: commit_incomplete` con il valore canonico `pending_commit` e distinguere le reason di `recovery_failed`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-API-003",
      "document_path": "docs/tennis-decision-ui/api/02-betfair.md",
      "report_id": "TDUI-DOC-REPORT-006",
      "report_path": "../Report documentale/06 - 02-betfair.md",
      "priority": "high",
      "type": "timeline_payload_shape",
      "action": "Documentare la vista timeline HTTP reale: normalizzazione di `timeline`, campo derivato `latest`, aggiunta di `integrity` e distinzione rispetto al documento persistito.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-API-004",
      "document_path": "docs/tennis-decision-ui/api/02-betfair.md",
      "report_id": "TDUI-DOC-REPORT-006",
      "report_path": "../Report documentale/06 - 02-betfair.md",
      "priority": "high",
      "type": "read_error_semantics",
      "action": "Precisare che missing, read failure e JSON invalido vengono collassati a `null`; valutare `loadTimelineResult` e status HTTP distinti coordinando la decisione con `MATCH-API-005`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-API-005",
      "document_path": "docs/tennis-decision-ui/api/02-betfair.md",
      "report_id": "TDUI-DOC-REPORT-006",
      "report_path": "../Report documentale/06 - 02-betfair.md",
      "priority": "medium",
      "type": "latest_empty_state",
      "action": "Documentare il caso `/latest` con timeline presente ma nessun tick valido: `HTTP 200`, `ok:false`, `latest:null`; distinguere inoltre `latestTimestamp` da `metadata.updatedAt`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-API-006",
      "document_path": "docs/tennis-decision-ui/api/02-betfair.md",
      "report_id": "TDUI-DOC-REPORT-006",
      "report_path": "../Report documentale/06 - 02-betfair.md",
      "priority": "high",
      "type": "money_flow_numeric_contract",
      "action": "Correggere le tolleranze Money Flow: `max(1, 10%)` per il confronto raw/computed e `max(1, 5%)` per runner rispetto al market delta, mantenendo distinti delta negativi e zero-vs-positivo.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-API-007",
      "document_path": "docs/tennis-decision-ui/api/02-betfair.md",
      "report_id": "TDUI-DOC-REPORT-006",
      "report_path": "../Report documentale/06 - 02-betfair.md",
      "priority": "high",
      "type": "deprecated_odds_security",
      "action": "Mettere in sicurezza `/odds`: eliminare `details: error.message`, usare code e messaggi bounded, validare protocollo e host Betfair e coordinare la correzione con l’eventuale rimozione della route.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-API-008",
      "document_path": "docs/tennis-decision-ui/api/02-betfair.md",
      "report_id": "TDUI-DOC-REPORT-006",
      "report_path": "../Report documentale/06 - 02-betfair.md",
      "priority": "medium",
      "type": "login_contract",
      "action": "Documentare il fallback di `mode`, l’identità runtime e il fatto che il target URL non partecipa alla deduplica; decidere se preservare o modificare tali comportamenti.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-API-009",
      "document_path": "docs/tennis-decision-ui/api/02-betfair.md",
      "report_id": "TDUI-DOC-REPORT-006",
      "report_path": "../Report documentale/06 - 02-betfair.md",
      "priority": "high",
      "type": "document_modularization",
      "action": "Mantenere `02-betfair.md` come facade, creare quattro owner per letture/integrity/health, Money Flow, odds/log e login-window; aggiornare indice, link, syntax check e test di verifica.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }