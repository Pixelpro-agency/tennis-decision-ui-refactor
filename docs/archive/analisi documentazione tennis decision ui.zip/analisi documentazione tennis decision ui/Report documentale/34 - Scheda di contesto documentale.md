# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/operations/03-betfair-diagnostics.md`

Tipo di documento:  
Runbook operativo.

Ruolo documentale:  
Guidare la diagnosi dei problemi Betfair partendo dal sintomo, indicando le superfici informative pertinenti e indirizzando verso gli owner tecnici corretti. Non è owner delle implementazioni di health, scraper lifecycle, Graph URL, persistenza, recovery, Money Flow o Source Identity.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`
- `34 - Report 03-betfair-diagnostics.md` — `TDUI-DOC-REPORT-034`
- `34 - TODO e Json.md`

## Task storicamente associate

- `BETFAIR-DIAG-001` — stato: completata  
  Argomento coinvolto: tassonomia della session health e interpretazione di `yellow`, `STALE` e `DEGRADED` attraverso `message`, `reasons`, `checks` e `metrics`.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `BETFAIR-DIAG-002` — stato: non completata  
  Argomento coinvolto: memoria degli ultimi tick e condizioni di recupero dell’alert di autenticazione.  
  Uso consentito: non assumere come implementata una specifica authority di auth recovery; verificare soltanto il comportamento corrente nel CODE AUTHORITY.

- `BETFAIR-DIAG-003` — stato: completata  
  Argomento coinvolto: distinzione tra ricezione di `hasFinished` e authority del terminal state.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `BETFAIR-DIAG-004` — stato: completata  
  Argomento coinvolto: distinzione e provenienza di log Node, log Python Betfair e capture artifacts.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `BETFAIR-DIAG-005` — stato: completata  
  Argomento coinvolto: modalità di attivazione della network capture nei diversi entrypoint Node e Python.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `BETFAIR-DIAG-006` — stato: completata  
  Argomento coinvolto: confine operativo della route legacy `/api/betfair/odds` rispetto alla diagnostica read-only.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `BETFAIR-DIAG-007` — stato: completata  
  Argomento coinvolto: interpretazione degli stati di persistence integrity e recovery.  
  Uso consentito: verificare nel CODE AUTHORITY la tassonomia corrente pertinente.

- `BETFAIR-DIAG-008` — stato: completata  
  Argomento coinvolto: matrice di verifica diagnostica e provenienza delle validazioni live.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata ma non ritenuta necessaria.
- Non risultano nuovi documenti canonici creati come parte di queste task.
- Il documento è stato mantenuto come singolo runbook operativo.
- La revisione storica risulta mirata, non una riscrittura completa.
- Sette delle otto task associate risultano applicate e verificate semanticamente; `BETFAIR-DIAG-002` risulta ancora aperta.

## Struttura precedente da considerare

- Classificazione iniziale dei sintomi e degli stati.
- Distinzioni tra timeout, freshness, autenticazione, terminal state e persistence integrity.
- Percorso diagnostico per CDP, Graph URL, ladder, log e network capture.
- Regole operative read-only e assenza di repair manuale della persistenza.
- Checklist o decision tree per instradare il problema verso l’owner corretto.
- Verification matrix con separazione tra verifiche automatizzate e osservazioni live provviste di provenance.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/routes/betfair.js`
- `backend/src/routes/betfair/` — in particolare latest payload, integrity, log reader e gestione della route `/odds`
- `backend/src/sofa/betfairHealth.js`
- `backend/src/sofa/betfairHealth/`
- `backend/src/sofa/betfairFetch.js`
- `backend/src/sofa/betfair/scraperLifecycle/`
- `backend/src/sofa/betfair/timeline/statusOnlySnapshot.js`
- `backend/src/runtime/runtimeLogger.js`
- `scrapers/betfair/` — in particolare `cli.py`, `scrape.py`, `graph_url.py` e `network_capture.py`
- Test modulari direttamente associati a health, route Betfair, lifecycle e capture

## Owner/documenti collegati

- Owner Betfair API: contratti e superfici pubbliche delle route diagnostiche.
- Owner Betfair lifecycle: coordinamento Node/Python e stato della route legacy `/odds`.
- Owner Python scraper: scraping, capture, redaction e terminal state prodotto.
- Owner Graph URL: validazione e associazione delle Graph URL.
- Owner storage/journal recovery: tassonomia canonica di integrity e recovery.
- Owner frontend Betfair: rappresentazione UI di health e diagnostica.
- `docs/tennis-decision-ui/modules/python/05-betfair-diagnostics-and-network-capture.md` — documento specialistico storicamente proposto; verificarne l’esistenza nella baseline prima di considerarlo un owner corrente.

Questi owner forniscono i contratti tecnici; il documento target mantiene il confine di runbook operativo.

## Guardrail specifici per questo documento

- Mantenere distinta la sintesi dello stato dalla diagnosi concreta.
- Non trasformare il runbook nell’owner dei classifier, dello scraper, della persistenza o della recovery.
- Distinguere le superfici diagnostiche Node, Python e network capture.
- Qualificare sempre scope e provenance di log e validazioni live.
- Conservare il confine tra osservazione diagnostica e percorsi capaci di produrre side effect.
- Non descrivere fallback, tick sintetici o modifiche manuali di history, timeline e journal come procedure diagnostiche.
- Non presentare la task aperta `BETFAIR-DIAG-002` come comportamento già consolidato.

## Informazioni storiche da NON assumere come correnti

- I dettagli tecnici osservati nel report sul commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`.
- La finestra degli ultimi tre tick come policy definitiva di auth recovery.
- Le precedenti semantiche di `yellow`, `STALE`, `DEGRADED` e `ALERT`.
- Il comportamento storico di `hasFinished`.
- Lo stato e la natura corrente della route `/api/betfair/odds`.
- I default storici della network capture per Node e CLI Python.
- Le precedenti interpretazioni di `no_known_partial` e `recovery_failed`.
- L’esistenza del documento specialistico Python soltanto perché risultava proposto.
- Finding, priorità e verification matrix del report come istruzioni operative ancora valide.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza individuata tra gli stati riportati nella sezione TODO e nel JSON.
- Il report fu originariamente redatto sulla documentation structure baseline e contiene in coda un successivo esito di applicazione; il comportamento tecnico corrente deve essere ricavato esclusivamente dal CODE AUTHORITY.
- Le fonti non includono il documento target corrente, quindi forma e contenuto effettivi devono essere recuperati dalla baseline documentale.
