TODO:

Report: [`../Report documentale/20 - 01-session-shell.md`](../Report%20documentale/20%20-%2001-session-shell.md) — `TDUI-DOC-REPORT-020`.

Modularizzazione: **valutata, non necessaria**. Start, stato confirmed/active, poller activation, Source Identity, bootstrap, dashboard e Stop formano un unico lifecycle frontend.

- [x] **`FRONT-SESSION-001`** — priorità `high` — Dichiarato nel lifecycle frontend che il Preflight è opzionale e advisory e non autorizza né blocca Start; sequenza documentale corretta.
- [x] **`FRONT-SESSION-002`** — priorità `critical` — Sessione promoted soltanto dopo `/track` riuscito con rollback completo su failure.
- [x] **`FRONT-SESSION-003`** — priorità `critical` — Introdotta `sessionActive` come authority comune; poller disabilitati senza sessione attiva.
- [x] **`FRONT-SESSION-004`** — priorità `critical` — Bootstrap legato al `trackingSessionId` corrente e completabile soltanto dopo reset e nuovi dati.
- [x] **`FRONT-SESSION-005`** — priorità `high` — Risultati bounded per Start/Login/Stop, stato Start failure e parsing Stop safe.
- [x] **`FRONT-SESSION-006`** — priorità `high` — Conferma chiusa soltanto dopo refresh live `recording/aligned` della stessa sessione.
- [x] **`FRONT-SESSION-007`** — priorità `high` — Decline attende Stop e conserva modale/errore in caso di fallimento.
- [x] **`FRONT-SESSION-008`** — priorità `medium` — Confermato il modello full path e rimossi gli stati `chromeProfileName` legacy.
- [x] **`FRONT-SESSION-009`** — priorità `high` — Aggiunto persistence view state read-only uniforme senza accesso frontend allo storage.
- [x] **`FRONT-SESSION-010`** — priorità `high` — Aggiunte suite lifecycle per Start authority, bootstrap, Source Identity e persistence view state.

JSON:

    {
      "change_id": "FRONT-SESSION-001",
      "report_id": "TDUI-DOC-REPORT-020",
      "document_path": "docs/tennis-decision-ui/modules/frontend/01-session-shell.md",
      "priority": "high",
      "type": "session_start_contract",
      "action": "Dichiarare che il Preflight non è un gate; Coordinare `PREFLIGHT-API-005`; Se il target cambia, implementare il gate con test; Evitare una sequenza documentale che suggerisca authorization inesistente.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-SESSION-002",
      "report_id": "TDUI-DOC-REPORT-020",
      "document_path": "docs/tennis-decision-ui/modules/frontend/01-session-shell.md",
      "priority": "critical",
      "type": "session_activation_authority",
      "action": "Non promuovere la sessione a confirmed/active prima del successo `/track`; Oppure rollback completo su failure; Impedire che una failure lasci confirmed state; Coordinare con `IMPL-006`.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-SESSION-003",
      "report_id": "TDUI-DOC-REPORT-020",
      "document_path": "docs/tennis-decision-ui/modules/frontend/01-session-shell.md",
      "priority": "critical",
      "type": "frontend_lifecycle_authority",
      "action": "Introdurre una authority comune per gli effetti session-scoped; Impedire polling residuo dopo Start failure; Separare presenza URL da sessione attiva; Lasciare i dettagli stale-response al prossimo owner polling.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-SESSION-004",
      "report_id": "TDUI-DOC-REPORT-020",
      "document_path": "docs/tennis-decision-ui/modules/frontend/01-session-shell.md",
      "priority": "critical",
      "type": "dashboard_session_isolation",
      "action": "Non usare soltanto reset + `backendData` non-null; Legare readiness alla sessione corrente; Impedire che dati persistiti precedenti sblocchino un nuovo Start; Coordinare con trackingSessionId/IMPL-006.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-SESSION-005",
      "report_id": "TDUI-DOC-REPORT-020",
      "document_path": "docs/tennis-decision-ui/modules/frontend/01-session-shell.md",
      "priority": "high",
      "type": "frontend_action_error_contract",
      "action": "Risultati bounded comuni per Start/Login/Stop; Stato UI dedicato per Start failure; Preservare code login strutturato; Parsing Stop safe; Nessun raw error message non necessario.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-SESSION-006",
      "report_id": "TDUI-DOC-REPORT-020",
      "document_path": "docs/tennis-decision-ui/modules/frontend/01-session-shell.md",
      "priority": "high",
      "type": "source_identity_frontend_contract",
      "action": "Non trattare `payload.ok` come sinonimo di recording; Verificare live gate dopo POST; Non chiudere modale su refresh null/pending/error; Coordinare SOURCE-ID-003/004/006.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-SESSION-007",
      "report_id": "TDUI-DOC-REPORT-020",
      "document_path": "docs/tennis-decision-ui/modules/frontend/01-session-shell.md",
      "priority": "high",
      "type": "source_identity_ux_lifecycle",
      "action": "Chiudere la modale soltanto dopo Stop riuscito; Preservare errore se Stop fallisce; Lasciare sessione/pending UI coerente; Aggiungere test.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-SESSION-008",
      "report_id": "TDUI-DOC-REPORT-020",
      "document_path": "docs/tennis-decision-ui/modules/frontend/01-session-shell.md",
      "priority": "medium",
      "type": "session_state_cleanup",
      "action": "Allineare `buildProfilePath` al significato reale; Decidere path diretto vs base+profileName; Rimuovere `chromeProfileName` legacy se inutilizzato; Coordinare con BETFAIR-LIFE-003.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-SESSION-009",
      "report_id": "TDUI-DOC-REPORT-020",
      "document_path": "docs/tennis-decision-ui/modules/frontend/01-session-shell.md",
      "priority": "high",
      "type": "frontend_integrity_presentation",
      "action": "Introdurre un view state read-only uniforme; Usare integrity già ricevuta dagli hook; Non leggere journal/storage lato frontend; Rendere coerente la presentation cross-view.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "FRONT-SESSION-010",
      "report_id": "TDUI-DOC-REPORT-020",
      "document_path": "docs/tennis-decision-ui/modules/frontend/01-session-shell.md",
      "priority": "high",
      "type": "verification_ownership",
      "action": "Aggiungere test per live tracking actions; Aggiungere test bootstrap state; Aggiungere test Source Identity gate UI; Coprire Start failure/rollback/confirmation/decline; Spostare la validation manuale storica nell'owner validation.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }