TODO:

Report: [`Report documentale/55 - 03-storage-recovery.md`](../Report%20documentale/55%20-%2003-storage-recovery.md) — `TDUI-DOC-REPORT-055`.

Modularizzazione: **valutata, non necessaria**.

- Nessuna nuova task: gli approfondimenti successivi su timeline/history e journal/recovery sono già posseduti dalle famiglie `STORAGE-TH-*` e `JOURNAL-REC-*`; il modulo resta coerente con `STORAGE-001…012`, `SECURITY-006`, `IMPL-019…021` e `TEST-019…030`.

JSON:
