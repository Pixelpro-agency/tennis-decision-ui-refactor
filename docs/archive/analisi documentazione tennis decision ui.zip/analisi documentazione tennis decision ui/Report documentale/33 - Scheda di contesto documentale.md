# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/operations/02-live-tracking-control.md`

Tipo di documento:  
Runbook operativo.

Ruolo documentale:  
Descrivere come osservare e fermare una sessione live, distinguendo Stop Live Tracking, stato persistito e shutdown completo. Non è owner degli algoritmi dello scheduler, del registry Python, del Source Identity Gate o dello shutdown backend.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-174401).txt`
- `33 - Report 02-live-tracking-control.md` — `TDUI-DOC-REPORT-033`
- `33 - TODO e Json.md`

## Task storicamente associate

- `LIVE-CTRL-001` — stato: completata  
  Argomento coinvolto: distinzione tra sessione live corrente, dati persistiti e stato frontend `last-known`.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `LIVE-CTRL-002` — stato: completata  
  Argomento coinvolto: distinzione tra stop logico e completamento del cleanup dei processi Python.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `LIVE-CTRL-003` — stato: completata  
  Argomento coinvolto: confine tra Runtime Health dei processi Python e quiescenza delle operazioni Node.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `LIVE-CTRL-004` — stato: non completata  
  Argomento coinvolto: comportamento successivo a uno Stop con processi residui.  
  Uso consentito: non assumerne il target come comportamento implementato; verificare soltanto il contratto corrente.

- `LIVE-CTRL-005` — stato: completata  
  Argomento coinvolto: Source Identity Gate dopo Stop e letture persistite Betfair/Evidence.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `LIVE-CTRL-006` — stato: completata  
  Argomento coinvolto: differenza tra nuovo Start consentito dall’API e isolamento effettivo della nuova sessione; semantica del mismatch.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `LIVE-CTRL-007` — stato: non completata  
  Argomento coinvolto: provenance delle verifiche live e matrice di validation.  
  Uso consentito: non assumere disponibile un artifact completo; verificare soltanto le validation realmente presenti.

## Cambiamenti strutturali storicamente rilevanti

- Il runbook risulta storicamente aggiornato per separare sessione corrente, dati persistiti e stato `last-known`.
- Risulta introdotta una distinzione tra stop logico, cleanup Python e drain delle operazioni Node.
- Risultano precisate le superfici post-Stop, compreso il possibile `404` dello stato Source Identity e la permanenza di letture persistite.
- La modularizzazione è stata valutata e ritenuta non necessaria.
- Non risultano nuovi documenti canonici derivati da questo report.

## Struttura precedente da considerare

- Preflight operativo.
- Osservazione della sessione live.
- Stati e verifica del Source Identity Gate.
- Stop Live Tracking.
- Runtime Health.
- Shutdown completo.
- Validation e checklist operative.
- Regole di sicurezza operative.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/routes/match.js`
- `backend/src/routes/match/trackingResponses.js`
- `backend/src/sofa/matchTracker.js`
- `backend/src/runtime/pythonProcessRegistry.js`
- `backend/src/server.js`
- `frontend/src/hooks/useLiveTrackingActions.js`
- `frontend/src/services/liveSessionApi.js`
- Hook frontend relativi a Source Identity, polling Betfair ed Evidence.
- Test direttamente associati alle route di tracking e al registry dei processi Python.

## Owner/documenti collegati

- `modules/sofa/01-live-tracking.md` — dettagli del tracking SofaScore.
- `api/01-match.md` — contratto delle API match e Stop.
- `api/06-runtime-health.md` — contratto di Runtime Health.
- `modules/evidence/02-source-identity.md` — semantica del Source Identity Gate.
- `operations/01-local-runtime.md` — gestione del runtime locale.
- `modules/storage/02-commit-journal-and-recovery.md` — persistenza, journal e recovery.
- `docs/validations/source-identity-live-verification.md` — validation Source Identity storicamente collegata.

Il documento target conserva il confine operativo e non sostituisce questi owner specialistici.

## Guardrail specifici per questo documento

- Mantenere distinta la sessione live corrente dai dati persistiti dello stesso `eventId`.
- Non presentare timeline, Evidence, dashboard o ultimo tick come prova autonoma della sessione corrente.
- Distinguere Stop Live Tracking dallo shutdown completo del backend.
- Distinguere cleanup dei processi Python e drain delle operazioni Node.
- Conservare la differenza tra Stop globale backend, Stop dall’Overview e percorso di ritorno al form.
- Non trasformare il runbook in owner tecnico di scheduler, registry Python, Source Identity, writer authority o shutdown.
- Non descrivere dati Betfair/Evidence visibili dopo Stop come necessariamente correnti.
- Mantenere la forma unitaria del runbook senza imporre una nuova modularizzazione.

## Informazioni storiche da NON assumere come correnti

- Il recupero tramite una seconda chiamata Stop dopo `pythonCleanup.remaining > 0`, associato a `LIVE-CTRL-004`.
- L’esistenza di un artifact di validation completo con provenance e matrice operativa, associato a `LIVE-CTRL-007`.
- La disponibilità end-to-end di una specifica session authority o di `trackingSessionId`, senza verifica nel CODE AUTHORITY.
- Qualsiasi dettaglio tecnico ricavato dal report basato sul commit documentale precedente.
- Le proposte, i finding, le priorità e i test ipotizzati nel report storico.

## Discrepanze o limiti delle fonti

- Markdown e JSON concordano sugli ID e sullo stato delle sette task.
- Il report storico analizzava il commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`, non il CODE AUTHORITY corrente.
- Lo stato di applicazione documentale dichiara completate cinque task, ma i comportamenti risultanti devono essere verificati nella baseline tecnica corrente.
- Alcuni riferimenti storici a session authority e `trackingSessionId` non costituiscono prova della loro disponibilità attuale.
