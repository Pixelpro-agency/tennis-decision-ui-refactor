TODO:

Report: [`Report documentale/23 - 04-match-context-ui.md`](../Report%20documentale/23%20-%2004-match-context-ui.md) — `TDUI-DOC-REPORT-023`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`MATCH-CONTEXT-001`** — priorità `medium` — Copy corretto: il contesto è calcolato dal backend sui dati SofaScore; il frontend valida e formatta senza nuovi calcoli sportivi.
- [x] **`MATCH-CONTEXT-002`** — priorità `high` — Validata la coerenza di percentuali, punti/totalPoints, recent window e comparison; ogni incoerenza degrada a unavailable senza clamp, fallback o ricalcolo visualizzato.
- [x] **`MATCH-CONTEXT-003`** — priorità `high` — Il backend preserva `unsupported_or_ambiguous_score_transition` dalla decodifica alla reason canonica, con test dedicati.
- [x] **`MATCH-CONTEXT-004`** — priorità `medium` — Documentate availability indipendenti per match, recent e comparison, oltre al ruolo di `dataQuality.level`; corretto il wording globale degli stati unavailable.
- [x] **`MATCH-CONTEXT-005`** — priorità `medium` — `observedShift` documentato come cambio del lato leader, distinto dai delta percentuali e senza semantica di trend.
- [x] **`MATCH-CONTEXT-006`** — priorità `medium` — Il consumer accetta soltanto il contratto canonico `version: 1`, `source: project-calculated`, `purpose: descriptive-match-context`; ogni contratto diverso degrada a unavailable.
- [x] **`MATCH-CONTEXT-007`** — priorità `high` — Aggiunti test component-level di MatchContextCard e test backend sulla propagazione della reason recent.

JSON:
    {
      "change_id": "MATCH-CONTEXT-001",
      "report_id": "TDUI-DOC-REPORT-023",
      "document_path": "docs/tennis-decision-ui/modules/frontend/04-match-context-ui.md",
      "priority": "medium",
      "type": "data_provenance_presentation",
      "action": "Copy corretto: il contesto è calcolato dal backend sui dati SofaScore; il frontend valida e formatta senza nuovi calcoli sportivi.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MATCH-CONTEXT-002",
      "report_id": "TDUI-DOC-REPORT-023",
      "document_path": "docs/tennis-decision-ui/modules/frontend/04-match-context-ui.md",
      "priority": "high",
      "type": "frontend_contract_validation",
      "action": "Validata la coerenza di percentuali, punti/totalPoints, recent window e comparison; ogni incoerenza degrada a unavailable senza clamp, fallback o ricalcolo visualizzato.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MATCH-CONTEXT-003",
      "report_id": "TDUI-DOC-REPORT-023",
      "document_path": "docs/tennis-decision-ui/modules/frontend/04-match-context-ui.md",
      "priority": "high",
      "type": "diagnostic_reason_contract",
      "action": "Il backend preserva `unsupported_or_ambiguous_score_transition` dalla decodifica alla reason canonica, con test dedicati.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MATCH-CONTEXT-004",
      "report_id": "TDUI-DOC-REPORT-023",
      "document_path": "docs/tennis-decision-ui/modules/frontend/04-match-context-ui.md",
      "priority": "medium",
      "type": "availability_semantics",
      "action": "Documentate availability indipendenti per match, recent e comparison, oltre al ruolo di `dataQuality.level`; corretto il wording globale degli stati unavailable.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MATCH-CONTEXT-005",
      "report_id": "TDUI-DOC-REPORT-023",
      "document_path": "docs/tennis-decision-ui/modules/frontend/04-match-context-ui.md",
      "priority": "medium",
      "type": "semantic_naming",
      "action": "`observedShift` documentato come cambio del lato leader, distinto dai delta percentuali e senza semantica di trend.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MATCH-CONTEXT-006",
      "report_id": "TDUI-DOC-REPORT-023",
      "document_path": "docs/tennis-decision-ui/modules/frontend/04-match-context-ui.md",
      "priority": "medium",
      "type": "schema_compatibility",
      "action": "Il consumer accetta soltanto il contratto canonico `version: 1`, `source: project-calculated`, `purpose: descriptive-match-context`; ogni contratto diverso degrada a unavailable.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "MATCH-CONTEXT-007",
      "report_id": "TDUI-DOC-REPORT-023",
      "document_path": "docs/tennis-decision-ui/modules/frontend/04-match-context-ui.md",
      "priority": "high",
      "type": "verification_contract",
      "action": "Aggiunti test component-level di MatchContextCard e test backend sulla propagazione della reason recent.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }