# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/api/05-runtime-health.md`  
Il materiale storico analizzava lo stesso documento con il precedente nome `06-runtime-health.md`; il Prompt 0 registra esplicitamente la rinomina successiva alla rimozione di Strategy.

Tipo di documento:  
API / contratto HTTP.

Ruolo documentale:  
Owner documentale del contratto pubblico `GET /api/health`, relativo alla raggiungibilità e identità del backend e allo snapshot pubblico dei processi Python. Il report storico lo identifica espressamente come «contratto HTTP di GET /api/health».

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`
- `10 - Report 06-runtime-health.md` — `TDUI-DOC-REPORT-010`
- `10 - TODO e Json.md` — registro successivo delle task e relativo JSON.

## Task storicamente associate

- `RUNTIME-HEALTH-001` — stato: completata  
  Argomento coinvolto: confine locale del backend, bind loopback e policy Host/Origin.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `RUNTIME-HEALTH-002` — stato: completata  
  Argomento coinvolto: normalizzazione della response Health e allow-list positiva dello snapshot pubblico.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `RUNTIME-HEALTH-003` — stato: completata  
  Argomento coinvolto: semantica di `ok:true` e riconoscimento dell'identità backend da parte del Preflight.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `RUNTIME-HEALTH-004` — stato: completata  
  Argomento coinvolto: significato di `instanceId` e `startedAt` e loro distinzione da sessione live, writer authority e launcher ownership.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `RUNTIME-HEALTH-005` — stato: completata  
  Argomento coinvolto: semantica pubblica di `pythonProcesses`, inclusi conteggi, `pid` nullable e lifecycle delle entry.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `RUNTIME-HEALTH-006` — stato: completata  
  Argomento coinvolto: policy HTTP di caching della response Health.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `RUNTIME-HEALTH-007` — stato: completata  
  Argomento coinvolto: authority dell'endpoint Health e relazione storica con `/api/test/health`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `RUNTIME-HEALTH-008` — stato: completata  
  Argomento coinvolto: copertura di verifica del contratto Health, del registry e del confine locale.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

Il TODO e il JSON concordano nel registrare tutte le otto task come completate. 
## Cambiamenti strutturali storicamente rilevanti

- Il documento è stato rinumerato da `06-runtime-health.md` a `05-runtime-health.md`.
- La modularizzazione è stata valutata e non ritenuta necessaria: il documento resta associato a un solo endpoint e non risultano nuovi documenti derivati.
- Il registro successivo indica storicamente la rimozione di `/api/test/health` e il mantenimento di `/api/health` come authority canonica; tale stato va verificato nel CODE AUTHORITY.

## Struttura precedente da considerare

- documento focalizzato su un singolo endpoint;
- contratto della response principale;
- snapshot pubblico `pythonProcesses`;
- semantica dei principali campi di identità e lifecycle;
- confine tra dati pubblici e dati interni;
- sezione di verifica del contratto.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente. Il report storico descrive il documento come corto, focalizzato e privo della necessità di suddivisione.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/server.js`
- `backend/src/server.test.mjs`
- `backend/src/runtime/pythonProcessRegistry.js`
- `backend/src/runtime/pythonProcessRegistry.test.mjs`
- `frontend/src/hooks/usePreflightChecks.js`
- response builder/normalizzatore pubblico della Health risultante dalla task `RUNTIME-HEALTH-002` — possibile fonte da individuare nel CODE AUTHORITY.

Queste sono le principali aree direttamente associate al contratto nel report storico.

## Owner/documenti collegati

- `docs/tennis-decision-ui/operations/01-local-runtime.md` — contesto del runtime locale e del confine di esposizione del backend.
- `docs/tennis-decision-ui/architecture/01-system-boundaries.md` — confini architetturali collegati al servizio.
- percorso storico `docs/tennis-decision-ui/api/05-preflight.md` — consumer/relazione API con il Preflight; la numerazione corrente deve essere verificata dopo la rimozione di Strategy.

## Guardrail specifici per questo documento

- Mantenere il documento come contratto di `GET /api/health`, senza trasformarlo in una descrizione generale della salute dell'intera sessione live.
- Non assimilare `ok:true` alla salute di tracking, persistenza, fonti esterne o processi Python senza conferma nel CODE AUTHORITY; storicamente il report distingueva la reachability del backend dalla salute complessiva.
- Non assimilare `instanceId` a tracking session, writer authority o launcher ownership senza riscontro corrente.
- Non interpretare lo `status` delle entry Python come health funzionale dello scraper: storicamente rappresentava il lifecycle pubblico del registry.
- Conservare il carattere read-only dell'endpoint soltanto se confermato dal CODE AUTHORITY.
- Non ampliare il documento verso Stop, shutdown, tracking o altri owner se non per chiarire esplicitamente un confine.

## Informazioni storiche da NON assumere come correnti

- Le condizioni tecniche descritte dal report originale come mancanti o incomplete appartengono al commit storico `4c5f43b007149f3210c27d7565357a447a3a6ef4`, non alla CODE AUTHORITY corrente.
- In particolare, non assumere come correnti l'assenza del bind loopback, l'assenza della normalizzazione HTTP, l'assenza di `Cache-Control: no-store` o l'esistenza di `/api/test/health`: le corrispondenti task risultano successivamente marcate come completate.
- Non assumere automaticamente come corrente la shape del payload, l'elenco dei campi pubblici, gli stati del registry o il comportamento del consumer Preflight descritti nel report storico.
- Le priorità e i finding del report sono metadata storici dell'audit e non costituiscono istruzioni per il technical writer.

## Discrepanze o limiti delle fonti

- Il report documentale riguarda il precedente percorso `docs/tennis-decision-ui/api/06-runtime-health.md`, mentre Prompt 0 e JSON indicano il percorso rinumerato `docs/tennis-decision-ui/api/05-runtime-health.md`; la rinomina è esplicitamente spiegata dal Prompt 0 e non costituisce una divergenza da risolvere.
- Le otto task risultano completate nel TODO/JSON, ma tra le fonti fornite non è presente un separato report di applicazione/verifica con il dettaglio delle modifiche e degli output dei test. Lo stato va quindi trattato come stato storico registrato, mentre il comportamento corrente deve essere ricavato dal CODE AUTHORITY.
- Nessuna discrepanza tra checkbox TODO e stato JSON è stata individuata.