# Scheda di contesto documentale

## Documento target

Percorso:
`docs/tennis-decision-ui/modules/frontend/03-betfair-and-market-reactions-ui.md`

Tipo di documento:
facade di owner tecnici frontend.

Ruolo documentale:
presentare i confini comuni della UI Betfair e Market Reactions e rinviare agli owner derivati per i contratti specifici. Il lifecycle UI di Source Identity resta esterno a questo documento.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `22 - Report 03-betfair-and-market-reactions-ui.md` — report `TDUI-DOC-REPORT-022`, inclusivo dell’aggiornamento successivo.
- `22 - TODO e Json.md` — mappa delle task e relativi record JSON.

## Task storicamente associate

- `FRONT-BETFAIR-001` — stato: completata. Argomento coinvolto: presentazione separata di persistence/read status nelle superfici Betfair e Market Reactions. Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.
- `FRONT-BETFAIR-002` — stato: completata. Argomento coinvolto: scala condivisa e coerente del Money Flow. Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.
- `FRONT-BETFAIR-003` — stato: completata. Argomento coinvolto: distinzione fra zero osservato e slot empty, invalid o anomaly. Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.
- `FRONT-BETFAIR-004` — stato: completata. Argomento coinvolto: rappresentazione dei valori Betfair mancanti distinta dallo zero reale. Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.
- `FRONT-BETFAIR-005` — stato: completata. Argomento coinvolto: stato runtime della card collegato a polling, Stop, attesa, errore e persistence. Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.
- `FRONT-BETFAIR-006` — stato: completata. Argomento coinvolto: distinzione fra dati current e last-known con read status e timestamp sorgente. Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.
- `FRONT-BETFAIR-007` — stato: completata. Argomento coinvolto: contratto della superficie diagnostica Health e trattamento redatto di `graphLoginRequiredUrl`. Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.
- `FRONT-BETFAIR-008` — stato: completata. Argomento coinvolto: validation JSX delle superfici Betfair, Health e Market Reactions. Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.
- `FRONT-BETFAIR-009` — stato: completata. Argomento coinvolto: modularizzazione documentale in una facade e due owner derivati. Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- `03-betfair-and-market-reactions-ui.md` è stato mantenuto come facade.
- Sono stati creati `05-betfair-depth-and-health-ui.md` e `06-market-reactions-ui.md` come owner derivati.
- Il lifecycle UI di Source Identity è rimasto di competenza di `01-session-shell.md`.
- La sequenza originaria dei 72 documenti è rimasta invariata.

## Struttura precedente da considerare

- La versione alla documentation structure baseline riuniva nello stesso documento Depth e ladder Betfair, Money Flow, Betfair Health, persistence UI, Market Reactions, Evidence e riferimenti a Source Identity.
- Conservava come invarianti documentali il volume abbinato non direzionale, l’assenza di attribuzioni causali e la separazione fra health, persistence e Source Identity.
- Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente alla funzione di facade.

## Aree da verificare nel CODE AUTHORITY

- `frontend/src/App.jsx`
- `frontend/src/components/BetfairDepthCard.jsx`
- `frontend/src/components/betfair/MoneyFlowChart.jsx`
- `frontend/src/components/betfair/BetfairHealthDebugPanel.jsx`
- `frontend/src/components/MarketReactionsPage.jsx`
- `frontend/src/hooks/useBetfairJson.js`
- `frontend/src/hooks/useMarketReactionEvidence.js`
- validation JSX direttamente associate alle superfici Betfair e Market Reactions

## Owner/documenti collegati

- `docs/tennis-decision-ui/modules/frontend/05-betfair-depth-and-health-ui.md` — owner derivato di Depth, ladder runner, Money Flow, Betfair Health e presentazione della persistence Betfair.
- `docs/tennis-decision-ui/modules/frontend/06-market-reactions-ui.md` — owner derivato di Market Reactions, osservazioni Market/Field, availability e reasons, Evidence integrity e presentazione non causale.
- `docs/tennis-decision-ui/modules/frontend/01-session-shell.md` — owner del lifecycle UI di Source Identity; nella facade è pertinente soltanto il confine con tale lifecycle.

## Guardrail specifici per questo documento

- Mantenere la funzione di facade ed evitare di duplicare i contratti dettagliati posseduti dai documenti `05` e `06`.
- Descrivere il frontend come consumatore e presentatore di read model già classificati, senza attribuirgli ricostruzione di Evidence, journal o recovery.
- Conservare distinti health Betfair, persistence integrity, Source Identity e disponibilità/correnza dei dati.
- Trattare il Money Flow come volume abbinato neutro e non direzionale; non ricondurlo a Back/Lay, WOM, pressure o intenzione dei trader.
- Trattare le Market Reactions come osservazioni temporalmente prossime, non come prova di causalità.
- Non trasferire nella documentazione dettagli di storage, payload del journal, path locali o dati diagnostici raw non appartenenti alla superficie approvata.

## Informazioni storiche da NON assumere come correnti

- Le descrizioni del report antecedenti all’aggiornamento finale rappresentano lo stato osservato alla documentation structure baseline e non il comportamento corrente.
- Finding, target, pseudo-soluzioni, test proposti e ordine di applicazione contenuti nel report non costituiscono authority tecnica.
- La presenza storica di `computeFlowWom` nell’utility non implica il suo uso nel rendering Money Flow corrente.
- Le viste Strategy legacy/deprecate citate nel report non appartengono al dominio documentale Market Reactions.
- I dettagli della struttura precedente non devono essere ripristinati automaticamente dopo la modularizzazione.

## Discrepanze o limiti delle fonti

- Nessuna discrepanza individuata fra la mappa Markdown e i record JSON: entrambe le fonti registrano `FRONT-BETFAIR-001`–`FRONT-BETFAIR-009` come completate.
- Le fonti sono storiche e non sostituiscono la verifica del comportamento e della struttura correnti nel CODE AUTHORITY.
