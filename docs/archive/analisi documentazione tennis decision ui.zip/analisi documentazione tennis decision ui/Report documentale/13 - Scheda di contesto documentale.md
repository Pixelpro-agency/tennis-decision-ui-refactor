# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/index.md`

Tipo di documento:  
indice.

Ruolo documentale:  
punto di ingresso canonico della documentazione tecnica corrente; storicamente concepito come singola mappa di navigazione verso gli owner documentali, senza assumere il ruolo di registro dei finding o di specifica futura.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `TDUI-DOC-REPORT-013` — report documentale relativo a `docs/tennis-decision-ui/index.md`.
- `13 - TODO e Json.md` — stato storico e metadata strutturati delle task `INDEX-001..006`.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing` — criteri e baseline della presente scheda.

## Task storicamente associate

- `INDEX-001` — stato: completata  
  Argomento coinvolto: distinzione tra authority dei fatti correnti e authority di target/decisioni approvate.  
  Uso consentito: verificare nel CODE AUTHORITY e nella documentazione corrente quale formulazione risulta effettivamente presente e pertinente all’indice.

- `INDEX-002` — stato: completata  
  Argomento coinvolto: semantica documentale di `docs/archive/` come area non canonica e potenzialmente vuota o assente.  
  Uso consentito: verificare lo stato corrente prima di descriverne presenza o contenuto.

- `INDEX-003` — stato: completata  
  Argomento coinvolto: separazione tra funzione di navigazione dell’indice e registrazione di limiti/finding.  
  Uso consentito: verificare la forma corrente dell’indice e mantenere il relativo confine documentale se ancora presente.

- `INDEX-004` — stato: completata  
  Argomento coinvolto: interpretazione dei documenti di stato rispetto alla baseline dichiarata al loro interno.  
  Uso consentito: verificare come il collegamento alla roadmap viene qualificato nella versione corrente.

- `INDEX-005` — stato: completata  
  Argomento coinvolto: normalizzazione dell’heading permanente relativo a fondazione e architettura.  
  Uso consentito: verificare la struttura corrente e recuperare la formulazione storica soltanto se ancora pertinente.

- `INDEX-006` — stato: completata  
  Argomento coinvolto: contratto di manutenzione dell’indice in relazione a creazione, rimozione o cambiamento degli owner canonici.  
  Uso consentito: verificare nella versione corrente quali regole di manutenzione risultano effettivamente presenti.

## Cambiamenti strutturali storicamente rilevanti

- Nessuna modularizzazione del documento: la valutazione storica ha mantenuto `index.md` come singolo punto di ingresso.
- Nessun nuovo documento risultava proposto come conseguenza diretta dell’audit dell’indice.
- La struttura storica distingueva documentazione corrente, materiale deprecato, validazioni storiche e materiale non canonico.
- La migrazione MDX → Markdown risultava già conclusa nella baseline documentale dell’audit; questo dato è storico e non sostituisce una verifica sulla baseline corrente.

## Struttura precedente da considerare

- singolo indice canonico;
- navigazione organizzata per aree della documentazione;
- collegamenti agli owner di architettura, API, moduli, operations, reference e roadmap;
- sezione separata per validazioni storiche;
- collegamenti sintetici ai registri/facade dell’audit e delle implementazioni;
- distinzione tra materiale corrente, deprecato, storico e non canonico.

Da confrontare con il CODE AUTHORITY e con la documentation structure baseline, recuperando soltanto gli elementi ancora pertinenti al ruolo dell’indice. La struttura unitaria era considerata intenzionale per evitare più punti di ingresso concorrenti.

## Aree da verificare nel CODE AUTHORITY

- struttura corrente di `docs/tennis-decision-ui/`;
- presenza e percorsi effettivi degli owner canonici raggiungibili dall’indice;
- `docs/validations/`;
- eventuale stato corrente di `docs/archive/`;
- `scripts/check_documentation_links.py`;
- `scripts/check_registry_consistency.py`;
- facades/registri richiamati dall’indice sotto `implementazioni/`.

Il report storico registrava 37 file canonici, con gli altri 36 documenti raggiungibili dall’indice, ma questa cardinalità appartiene al checkpoint auditato e non va assunta automaticamente per il CODE AUTHORITY successivo.

## Owner/documenti collegati

- `docs/tennis-decision-ui/ai/02-documentation-conventions.md` — convenzioni documentali e distinzione fra stato implementato e target.
- `docs/tennis-decision-ui/reference/01-repository-map.md` — riferimento alla struttura del repository.
- `docs/tennis-decision-ui/roadmap/01-current-state.md` — documento di stato con propria baseline dichiarata.
- `docs/validations/README.md` — ingresso delle validazioni storiche.
- `implementazioni/03-audit-codice.md` — facade dei registri di audit.
- `implementazioni/06-implementazioni-proposte.md` — facade delle implementazioni/proposte registrate.
- `implementazioni/99-decisioni-utente.md` — registro delle decisioni utente richiamato storicamente dall’indice.

## Guardrail specifici per questo documento

- Mantenere il ruolo di indice/navigazione, senza trasformarlo in owner tecnico delle funzionalità descritte nei documenti collegati.
- La presenza di un documento nell’indice identifica storicamente un owner corrente; non certifica l’assenza di limiti o finding aperti.
- Tenere distinti i fatti sullo stato implementato dalle decisioni o dai target non ancora verificati nel codice corrente.
- Non promuovere automaticamente nell’indice documenti soltanto proposti o futuri.
- I documenti di stato e le validazioni possono avere una propria baseline temporale; il titolo del collegamento non costituisce da solo prova di equivalenza con il checkpoint corrente.
- La descrizione di `docs/archive/`, se ancora presente, non deve implicare automaticamente che la directory contenga materiale nel checkpoint corrente.

## Informazioni storiche da NON assumere come correnti

- il conteggio storico di `37` owner Markdown canonici e `36` documenti collegati dall’indice;
- l’assenza di file `.mdx` rilevata durante l’audit;
- l’eventuale assenza o vuotezza di `docs/archive/` al checkpoint del report;
- la baseline tecnica indicata internamente da `roadmap/01-current-state.md` durante l’audit;
- la presenza o assenza corrente di endpoint, documenti deprecati o owner citati dall’indice storico;
- qualunque proposta di nuovi owner API/AI citata nel report ma non ancora materializzata nella baseline da documentare.

## Discrepanze o limiti delle fonti

- Il report `TDUI-DOC-REPORT-013` analizzava il commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`, mentre il CODE AUTHORITY assegnato alla successiva attività di technical writing è `12b344ea96e71b2bdaa6931c98419ce925b5c228`. Il report è quindi contesto storico, non authority dello stato tecnico corrente.
- Il report descrive `INDEX-001..006` come modifiche proposte al momento dell’audit, mentre il successivo TODO/JSON le registra tutte come completate. Non è una discrepanza da risolvere: rappresenta una progressione storica dello stato delle task.
