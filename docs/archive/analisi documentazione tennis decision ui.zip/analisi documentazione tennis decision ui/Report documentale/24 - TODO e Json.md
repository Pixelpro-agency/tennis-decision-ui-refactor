TODO:

Report: [`Report documentale/24 - 01-entrypoints-and-runtime.md`](../Report%20documentale/24%20-%2001-entrypoints-and-runtime.md) — `TDUI-DOC-REPORT-024`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`PY-RUNTIME-001`** — priorità `high` — Distinti e testati i contratti Sofa scrape, Betfair scrape e Betfair login-only; stdout JSON resta result channel soltanto nelle modalità scrape.
- [x] **`PY-RUNTIME-002`** — priorità `high` — Il logger SofaScore riusa la redazione bounded, mantenendo diagnostica su stderr e payload pubblici statici.
- [x] **`PY-RUNTIME-003`** — priorità `critical` — Stdout SofaScore limitato a 2 MiB; overflow azzera il buffer, termina il child owned e restituisce un errore statico.
- [x] **`PY-RUNTIME-004`** — priorità `critical` — Grace launcher portata a 8 secondi, oltre il budget backend di 6 secondi, con test dell'invariante.
- [x] **`PY-RUNTIME-005`** — priorità `high` — `write_manifest` propaga le failure I/O dopo il cleanup; testate creazione e replace fallite e conversione bounded nei percorsi safe.
- [x] **`PY-RUNTIME-006`** — priorità `high` — Formalizzati `starting/ready/unavailable`; aggiunti tre probe bounded post-helper e test delayed-ready/never-ready.
- [x] **`PY-RUNTIME-007`** — priorità `high` — Documentati separatamente probe e bind loopback; verificato il bind backend corrente su `127.0.0.1` introdotto dall'owner approvato.
- [x] **`PY-RUNTIME-008`** — priorità `low` — Direct Node start confermato come authority launcher; `start-backend-dev.ps1` classificato come helper manuale, non dipendenza runtime.
- [x] **`PY-RUNTIME-009`** — priorità `medium` — Definiti i confini: questo file possiede i contratti tecnici Python/launcher, Operations possiede il runbook e Validations le evidenze live.
- [x] **`PY-RUNTIME-010`** — priorità `high` — Estesa la matrice test a CLI mode, redazione Sofa, stdout overflow, manifest failure, CDP provisional, timeout shutdown e bind locale.

JSON:

    {
      "change_id": "PY-RUNTIME-001",
      "report_id": "TDUI-DOC-REPORT-024",
      "document_path": "docs/tennis-decision-ui/modules/python/01-entrypoints-and-runtime.md",
      "priority": "high",
      "type": "entrypoint_contract",
      "action": "Distinti e testati i contratti Sofa scrape, Betfair scrape e Betfair login-only; stdout JSON resta result channel soltanto nelle modalità scrape.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PY-RUNTIME-002",
      "report_id": "TDUI-DOC-REPORT-024",
      "document_path": "docs/tennis-decision-ui/modules/python/01-entrypoints-and-runtime.md",
      "priority": "high",
      "type": "diagnostic_redaction",
      "action": "Il logger SofaScore riusa la redazione bounded, mantenendo diagnostica su stderr e payload pubblici statici.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PY-RUNTIME-003",
      "report_id": "TDUI-DOC-REPORT-024",
      "document_path": "docs/tennis-decision-ui/modules/python/01-entrypoints-and-runtime.md",
      "priority": "critical",
      "type": "subprocess_output_boundedness",
      "action": "Stdout SofaScore limitato a 2 MiB; overflow azzera il buffer, termina il child owned e restituisce un errore statico.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PY-RUNTIME-004",
      "report_id": "TDUI-DOC-REPORT-024",
      "document_path": "docs/tennis-decision-ui/modules/python/01-entrypoints-and-runtime.md",
      "priority": "critical",
      "type": "shutdown_coordination",
      "action": "Grace launcher portata a 8 secondi, oltre il budget backend di 6 secondi, con test dell'invariante.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PY-RUNTIME-005",
      "report_id": "TDUI-DOC-REPORT-024",
      "document_path": "docs/tennis-decision-ui/modules/python/01-entrypoints-and-runtime.md",
      "priority": "high",
      "type": "manifest_durability",
      "action": "`write_manifest` propaga le failure I/O dopo il cleanup; testate creazione e replace fallite e conversione bounded nei percorsi safe.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PY-RUNTIME-006",
      "report_id": "TDUI-DOC-REPORT-024",
      "document_path": "docs/tennis-decision-ui/modules/python/01-entrypoints-and-runtime.md",
      "priority": "high",
      "type": "cdp_readiness_semantics",
      "action": "Formalizzati `starting/ready/unavailable`; aggiunti tre probe bounded post-helper e test delayed-ready/never-ready.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PY-RUNTIME-007",
      "report_id": "TDUI-DOC-REPORT-024",
      "document_path": "docs/tennis-decision-ui/modules/python/01-entrypoints-and-runtime.md",
      "priority": "high",
      "type": "local_runtime_boundary",
      "action": "Documentati separatamente probe e bind loopback; verificato il bind backend corrente su `127.0.0.1` introdotto dall'owner approvato.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PY-RUNTIME-008",
      "report_id": "TDUI-DOC-REPORT-024",
      "document_path": "docs/tennis-decision-ui/modules/python/01-entrypoints-and-runtime.md",
      "priority": "low",
      "type": "launcher_configuration_cleanup",
      "action": "Direct Node start confermato come authority launcher; `start-backend-dev.ps1` classificato come helper manuale, non dipendenza runtime.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PY-RUNTIME-009",
      "report_id": "TDUI-DOC-REPORT-024",
      "document_path": "docs/tennis-decision-ui/modules/python/01-entrypoints-and-runtime.md",
      "priority": "medium",
      "type": "documentation_ownership",
      "action": "Definiti i confini: questo file possiede i contratti tecnici Python/launcher, Operations possiede il runbook e Validations le evidenze live.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "PY-RUNTIME-010",
      "report_id": "TDUI-DOC-REPORT-024",
      "document_path": "docs/tennis-decision-ui/modules/python/01-entrypoints-and-runtime.md",
      "priority": "high",
      "type": "verification_contract",
      "action": "Estesa la matrice test a CLI mode, redazione Sofa, stdout overflow, manifest failure, CDP provisional, timeout shutdown e bind locale.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }