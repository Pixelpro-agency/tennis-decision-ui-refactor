# Scheda di contesto documentale

## Documento target

Percorso:  
`implementazioni/audit-codice/04-evidence-market-reactions.md`

Tipo di documento:  
Modulo owner dell’audit del codice.

Ruolo documentale:  
Record storico del secondo audit del Punto 5, dedicato alla pipeline cross-source di Evidence e Market Reactions. Il perimetro comprende provenance temporale, alignment, eligibility, Significant Flow, identità dei runner, comparabilità dei prezzi e semantica delle osservazioni di mercato.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-235017).txt`
- `56 - Report 04-evidence-market-reactions.md`
- `56 - TODO e Json.md`

## Task storicamente associate

- `EVIDENCE-001…009` — stato: non completate  
  Argomento coinvolto: identità temporale dei runner, eligibility dei tick, distinzione fra attività e osservazione, transizioni degli eventi, provenance temporale, comparabilità dei prezzi, copertura dei runner, Significant Flow e stati delle osservazioni.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente senza assumere che i comportamenti descritti come target siano presenti.

- `IMPL-022` — stato: non completata  
  Argomento coinvolto: provenance temporale, alignment, freshness, skew e policy temporale delle finestre.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `IMPL-023` — stato: non completata  
  Argomento coinvolto: eligibility, stati dei branch, distinzione fra attività e osservazione, transizioni, coverage, Significant Flow, cluster e finestre.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `IMPL-024` — stato: non completata  
  Argomento coinvolto: identità temporale dei runner, provenance e comparabilità dei prezzi, baseline e coverage.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `DOC-026` e `DOC-027` — stato: non completate  
  Argomento coinvolto: terminologia temporale e distinzione fra dato calcolato, input disponibile, evento sorgente, attività, osservazione qualificata e stato della finestra.  
  Uso consentito: verificare nel CODE AUTHORITY quali semantiche siano correnti prima di documentarle.

- `TEST-031…043` — stato: non completate  
  Argomento coinvolto: verifiche storicamente associate ai contratti del Punto 5.  
  Uso consentito: non assumere come testati o convalidati i relativi comportamenti.

- `PLAN-AUDIT-003` — stato: completata  
  Argomento coinvolto: completamento dell’attività di audit del Punto 5, distinto dal completamento delle implementazioni associate.  
  Uso consentito: preservare la natura storica del documento.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata e dichiarata non necessaria.
- Non risultano nuovi file, nuove task o nuovi owner introdotti dal report.
- Gli ambiti esecutivi risultano distribuiti storicamente fra `IMPL-022`, `IMPL-023` e `IMPL-024`, senza dividere il record di audit.

## Struttura precedente da considerare

- Identificazione come Parte 4 di 7.
- Un solo audit point: Punto 5.
- Baseline tecnica dichiarata nel documento storico.
- Indicazione esplicita di analisi statica e suite lette ma non rieseguite.
- Confini della pipeline Evidence read-only.
- Separazione fra provenance temporale, identità/comparabilità ed eligibility/semantica delle osservazioni.
- Riferimenti agli owner IMPL, DOC e TEST senza duplicarne le specifiche.
- Matrici storiche di verifica associate agli owner.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/matchEvidence/latestMatchEvidence.js`
- `backend/src/sofa/matchEvidence/evidenceBuilder.js`
- `backend/src/sofa/matchEvidence/alignment.js`
- `backend/src/sofa/matchEvidence/dataQuality.js`
- `backend/src/sofa/fieldLedReactionEvidence.js`
- `backend/src/sofa/marketReactionEvidence.js`
- `backend/src/sofa/significantMarketFlowEvidence.js`
- `backend/src/sofa/significantMarketFlow/`
- `backend/src/sofa/marketLedObservationEvidence/observationWindow.js`
- Test direttamente associati alla pipeline Evidence e Market Reactions.

## Owner/documenti collegati

- `implementazioni/implementazioni-proposte/04-evidence-provenance.md` — owner storico delle specifiche complete di `IMPL-022…024`.
- `implementazioni/03-audit-codice.md` — contesto superiore dell’audit del codice.
- `implementazioni/99-decisioni-utente.md` — registro storico delle decisioni richiamate.
- `DOC-017` — riferimento documentale già esistente, da non duplicare.
- `METHOD-EVIDENCE-001` — metodologia generale di validazione; distinta dalla semantica di dominio posseduta dal documento target.
- Documento frontend relativo al Punto 6 — possiede rendering e mapping UI, mentre il documento target mantiene il confine backend/Evidence.

## Guardrail specifici per questo documento

- Mantenere il documento come record di audit, senza trasformarlo in guida di implementazione o descrizione automatica dello stato corrente.
- Conservare il confine read-only di Match Evidence, se confermato dal CODE AUTHORITY.
- Non presentare Market Reactions o Significant Flow come segnale, fair odds, consiglio operativo o inferenza causale.
- Conservare la distinzione fra prossimità temporale e causalità.
- Non fondere Source Identity, persistence integrity, health tecnico ed eligibility algoritmica.
- Non fondere attività di mercato, variazione del runner e osservazione qualificata.
- Non trasferire nel documento target le responsabilità proprie del frontend o degli owner IMPL collegati.
- Mantenere il dominio come pipeline cross-source unitaria, salvo evidenze strutturali diverse nella baseline corrente.

## Informazioni storiche da NON assumere come correnti

- La baseline tecnica dichiarata nel documento storico: `2959fba5bc3e0480cc3ea03f4469361cbb629ae6`.
- Le descrizioni del codice contenute nel report 056.
- I comportamenti indicati come target da `EVIDENCE-001…009`.
- Le strutture associate a `IMPL-022…024`, storicamente approvate ma non completate.
- Le semantiche documentali associate a `DOC-026/027`.
- L’esistenza o il superamento di `TEST-031…043`.
- Le matrici di verifica future e la dependency chain storica.
- Qualunque indicazione di priorità proveniente dall’audit.

## Discrepanze o limiti delle fonti

- Il file `56 - TODO e Json.md` contiene una breve nota Markdown, ma nessun contenuto JSON dopo l’intestazione `JSON:`. Non è quindi possibile effettuare la conferma strutturata documento-task-report richiesta tramite JSON.
- La mappa e il JSON consolidati non risultavano ancora aggiornati nel report 056, poiché il consolidamento era rinviato alla chiusura del blocco 053–057.
- Il report storico confrontava il codice con una baseline precedente al CODE AUTHORITY assegnato alla successiva fase di technical writing.
