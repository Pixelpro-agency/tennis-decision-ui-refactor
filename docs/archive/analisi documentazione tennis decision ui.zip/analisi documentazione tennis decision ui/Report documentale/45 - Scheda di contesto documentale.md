# Scheda di contesto documentale

## Documento target

Percorso:
`implementazioni/01-piano-generale-audit.md`

Tipo di documento:
piano generale e cronologia storica dell’audit.

Ruolo documentale:
conservare la sequenza originaria delle fasi di audit, i relativi criteri metodologici e gli snapshot di avanzamento, distinguendoli dallo stato operativo corrente posseduto dagli appositi registri e documenti owner.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `45 - Report 01-piano-generale-audit.md` — report `TDUI-DOC-REPORT-045` relativo al documento target.
- `45 - TODO e Json.md` — stato checkbox e metadata JSON delle task associate.
- `PROMPT 0 — Preparazione Scheda neutra per technical writing` — criteri e formato della presente scheda.

## Task storicamente associate

- `PLAN-AUDIT-001` — stato: completata  
  Argomento coinvolto: distinzione tra piano originario e snapshot storici, da una parte, e stato operativo corrente posseduto da Todo, audit tecnico e root registry, dall’altra.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `PLAN-AUDIT-002` — stato: completata  
  Argomento coinvolto: provenance degli snapshot 8.3–8.4, con indicazione delle informazioni dimostrabili e uso di `non registrato` quando la baseline storica non è ricostruibile.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `PLAN-AUDIT-003` — stato: completata  
  Argomento coinvolto: distinzione fra completamento dell’attività nel perimetro dichiarato e copertura esaustiva, inclusi test e validazione live.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- È stata storicamente applicata una revisione mirata della cornice temporale del documento, senza riscrivere retroattivamente gli snapshot.
- È stata registrata la provenance disponibile per gli snapshot 8.3–8.4, mantenendo espliciti gli eventuali dati non registrati.
- È stata chiarita la semantica di completamento delle attività rispetto a copertura, test e validazione live.
- La modularizzazione è stata valutata e non ritenuta necessaria; non risultano nuovi documenti canonici creati per separare piano e checkpoint.

## Struttura precedente da considerare

- Sequenza originaria A→G: baseline e inventario; audit documentazione; audit codice; ricontrollo delle task completate; implementazioni utili; audit docs/planning; integrazione workflow.
- Snapshot 8.1–8.4 come cronologia di checkpoint distinti.
- Blocco D con distinzione fra implementazione, test automatici e validazione live, oltre agli esiti separati del ricontrollo D1–D18.
- Blocco E con criteri storici di classificazione delle proposte e separazione fra audit e implementazione.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- Nessun file di codice applicativo specifico è direttamente posseduto dal documento target.
- Stato repository corrente richiamato sinteticamente dal piano, limitatamente ai comportamenti o alle attività che il documento menziona come checkpoint.
- Stato effettivo delle task storiche citate, senza assumere che proposte o next step contenuti negli snapshot rappresentino funzionalità correnti.
- Test e validazioni richiamati dal documento, soltanto per mantenere corretta la distinzione fra attività eseguita, verifica offline e validazione live.

## Owner/documenti collegati

- `implementazioni/README.md` — indice e ordine di lettura del corpus `implementazioni`.
- `implementazioni/00-metodo-e-stati.md` — owner delle definizioni metodologiche e degli stati.
- `implementazioni/03-audit-codice.md` — owner dell’indice corrente dell’audit tecnico e dei relativi domini.
- `implementazioni/04-task-completate.md` — owner degli esiti e delle prove dettagliate per D1–D18.
- `implementazioni/05-audit-docs-planning.md` — owner della classificazione e del trattamento delle fonti locali di planning.
- `implementazioni/audit-codice/07-post-audit-e-migrazione.md` — riferimento collegato alle fasi successive di post-audit e migrazione.
- `todo-list-tennis-decision-ui.md` — owner dello stato operativo e delle attività correnti.

Questi documenti definiscono stato, dettaglio o metodo nei rispettivi ambiti; il documento target conserva invece la sequenza e il significato storico delle fasi dell’audit.

## Guardrail specifici per questo documento

- Mantenere riconoscibili il piano originario A→G e gli snapshot 8.1–8.4 come contenuto storico.
- Non trasformare il documento in una roadmap tecnica corrente, in un duplicato della Todo o in un registro completo dello stato del progetto.
- Non duplicare esiti, prove o dettagli posseduti dagli owner collegati; sono sufficienti riferimenti sintetici coerenti con il ruolo del piano.
- Conservare la distinzione fra implementazione, test automatici, verifica offline e validazione live.
- Non interpretare riferimenti storici a `.mdx`, planning locale, proposte o sequenze operative come istruzioni correnti.
- Non riaprire task storicamente completate e non introdurre nuove task sulla base del solo materiale di audit.

## Informazioni storiche da NON assumere come correnti

- Le proposte `IMPL-006…009` e `IMPL-012…015` nello stato registrato dai rispettivi snapshot.
- I next step e la sequenza operativa descritti nello snapshot 8.3.
- I riferimenti a file `.mdx`, materiali locali e planning presenti nel piano originario.
- I conteggi e gli esiti D1–D18 come rappresentazione dello stato complessivo attuale del progetto.
- Qualsiasi finding, priorità, soluzione proposta, test richiesto o scenario futuro contenuto nel report storico.
- Il commit che registra testualmente uno snapshot come prova automatica della baseline tecnica verificata in quello snapshot.

## Discrepanze o limiti delle fonti

- Il report documentale fotografa l’audit alla baseline `4c5f43b007149f3210c27d7565357a447a3a6ef4`, mentre la futura verifica tecnica dovrà usare il CODE AUTHORITY `12b344ea96e71b2bdaa6931c98419ce925b5c228`.
- Il report storico descriveva tre interventi documentali; la fonte TODO/JSON e l’esito applicativo aggiunto al report li registrano tutti come completati. La loro resa corrente deve essere verificata nella baseline successiva senza rieseguire le task.
- Per alcuni checkpoint storici, la provenance completa può non essere ricostruibile; i dati mancanti non devono essere dedotti.
