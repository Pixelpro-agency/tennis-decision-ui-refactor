# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/modules/sofa/01-live-tracking.md`

Tipo di documento:  
Owner tecnico e documento coordinatore del live tracking.

Ruolo documentale:  
Descrivere l’orchestrazione del live tracking SofaScore/Betfair: Start, scheduler, aggiornamenti delle fonti, integrazione con Source Identity Gate, autorizzazione alla persistenza, Stop, mismatch e shutdown/drain. Deve mantenere distinti il coordinamento centrale e le responsabilità degli owner specialistici.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-130309).txt`
- `Report documentale/28 - 01-live-tracking.md` — `TDUI-DOC-REPORT-028`
- `28 - TODO e Json.md`, comprendente registro Markdown e metadati JSON associati

## Task storicamente associate

- `SOFA-LIVE-001` — stato: completata  
  Argomento coinvolto: identità e autorità della sessione tracking rispetto a tracker membership, Python generation e Source Identity buffer generation.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOFA-LIVE-002` — stato: completata  
  Argomento coinvolto: contratto di acknowledgement della Start.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOFA-LIVE-003` — stato: completata  
  Argomento coinvolto: distinzione tra stop logico e completamento del cleanup fisico.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOFA-LIVE-004` — stato: completata  
  Argomento coinvolto: lifecycle e osservabilità del cleanup in caso di mismatch.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOFA-LIVE-005` — stato: completata  
  Argomento coinvolto: semantica dei campioni Betfair tecnici e del percorso `repairOnly`.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOFA-LIVE-006` — stato: completata  
  Argomento coinvolto: diagnostica tecnica Betfair, redazione dei dati ed esposizione runtime/health.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOFA-LIVE-007` — stato: completata  
  Argomento coinvolto: autorità dell’informazione di fine match e conseguente auto-stop Betfair.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOFA-LIVE-008` — stato: completata  
  Argomento coinvolto: semantica temporale dello scheduler e distinzione tra completion, acquisizione, tick canonico e commit.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `SOFA-LIVE-009` — stato: completata  
  Argomento coinvolto: matrice di verifica, percorsi dei test e provenienza delle validazioni live.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata ma non ritenuta necessaria.
- Non risultano nuovi documenti canonici derivati da questo documento.
- La fonte storica dichiara una revisione mirata completata il 10 agosto 2026.
- Il documento è rimasto owner centrale del lifecycle, con rinvii agli owner specialistici per i dettagli dei sottodomini.

## Struttura precedente da considerare

- Flusso coordinato Start → scheduler → aggiornamento fonti → Source Identity Gate → persistenza → Stop/mismatch/shutdown.
- Sezioni distinte per scheduler, bootstrap, Stop ordinario, mismatch e terminal drain.
- Confini di ownership rispetto a browser, storage, Evidence, point-by-point, Source Identity e runtime Python.
- Sezione di verifica con suite automatiche e riferimenti a validation live.
- Distinzione fra tracking logico, session authority, processi Python, operazioni Node in-flight, gate, persistenza e runtime health.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/sofa/matchTracker.js`
- `backend/src/routes/match/trackingResponses.js`
- `backend/src/sofa/trackerUpdate.js`
- `backend/src/sofa/betfair/trackerUpdate.js`
- `backend/src/sofa/sourceIdentityGate/`
- `backend/src/sofa/betfair/processor.js` e relativo percorso di persistenza
- `backend/src/runtime/pythonProcessRegistry.js`
- `backend/src/server.js`
- Test direttamente associati a tracker, route tracking, Source Identity lifecycle e runtime health

## Owner/documenti collegati

- Source Identity: possiede valutazione, lifecycle e isolamento del gate; il documento target ne descrive l’integrazione nel tracking.
- Betfair lifecycle e scraper: possiedono acquisizione, classificazione tecnica e autorità dei segnali provenienti dallo scraper.
- Storage/writer authority: possiede journal, persistenza canonica e recovery; il live tracking coordina quando il flusso può raggiungerli.
- Runtime Python: possiede process registry, generation e terminazione fisica dei processi.
- Frontend session lifecycle: consuma gli esiti pubblici di Start e Stop senza appartenere all’owner backend.
- `docs/validations/source-identity-live-verification.md`: conserva evidenze live storiche con limiti e provenienza propri.

## Guardrail specifici per questo documento

- Mantenere il documento come coordinator/facade del live tracking, senza trasferirgli algoritmi o contratti posseduti dagli owner specialistici.
- Distinguere Start/Stop logici, autorità della sessione, operazioni Node in-flight e lifecycle fisico dei processi.
- Distinguere Stop ordinario, mismatch e shutdown terminale.
- Non presentare Python generation o gate generation come equivalenti all’autorità end-to-end della sessione senza verifica nel CODE AUTHORITY.
- Distinguere scheduler completion, tentativo di scrape, acquisizione riuscita, tick canonico e commit.
- Trattare i dati runtime Betfair come effimeri ma potenzialmente esposti dalle API health.
- Conservare la distinzione tra campione tecnico corrente e recovery di un commit precedente.
- Non attribuire al tracker ownership di browser, file storage, Evidence, point-by-point, algoritmo Source Identity o writer authority.
- Non trasformare PASS o osservazioni live storiche in prova dello stato corrente.

## Informazioni storiche da NON assumere come correnti

- Tutti i finding, gli esempi di codice e le descrizioni del comportamento riferiti al commit documentale auditato.
- Le proposte implementative, l’ordine di applicazione e i test indicati come futuri nel corpo del report.
- I percorsi dei test elencati nella vecchia sezione di verifica.
- Le precedenti descrizioni di `trackMatch`, Stop, mismatch, `repairOnly`, redazione diagnostica, `hasFinished` e scheduler.
- Le dipendenze storicamente aperte citate nel report.
- Le osservazioni live inline prive di una provenance completa.
- La sintesi tecnica pre-intervento conservata nella parte finale del report.

## Discrepanze o limiti delle fonti

- Markdown TODO e JSON concordano sul completamento di `SOFA-LIVE-001..009`.
- Il report dichiara a sua volta le task completate il 10 agosto 2026, ma conserva nel corpo e nella decisione finale numerose descrizioni pre-intervento. Queste rappresentano contesto storico e non devono essere trattate come stato corrente.
- Il report afferma che i test mirati sono stati superati, ma la Scheda non dispone dei relativi report di applicazione o dell’elenco completo degli esiti.
- La forma e il contenuto correnti del documento target non sono inclusi tra le fonti consultate e devono essere recuperati dalla baseline indicata.
