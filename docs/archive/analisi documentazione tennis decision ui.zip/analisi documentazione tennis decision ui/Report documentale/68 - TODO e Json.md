TODO:

Report: [`Report documentale/68 - 05-frontend-session-polling.md`](../Report%20documentale/68%20-%2005-frontend-session-polling.md) — `TDUI-DOC-REPORT-068`.

Modularizzazione: **valutata, non necessaria**.

- [ ] **`IMPL-FRONTEND-001`** — **HIGH** — Riallineare `IMPL-025/026/027` sostituendo `STRUTTURA COMPLETAMENTE ASSENTE` con uno stato bounded `APPROVATA, NON COMPLETATA`: registrare le primitive frontend già presenti (session input/confirmed state, Start/Stop actions, shell/bootstrap, poller esistenti, async guards Evidence/Source Identity, Market Reactions UI) e separarle dai contratti ancora mancanti (single live-session controller, `trackingSessionId`/command authority, shared session-scoped polling runtime, Stop di tutti i poller, retain policy e dedicated Market Reactions view model). Preservare le protezioni async già robuste e non promuovere `TEST-044…059`.

JSON:

    {
      "change_id": "IMPL-FRONTEND-001",
      "report_id": "TDUI-DOC-REPORT-068",
      "document_path": "implementazioni/implementazioni-proposte/05-frontend-session-polling.md",
      "priority": "high",
      "type": "owner_state_granularity_existing_frontend_primitives",
      "action": "Riallineare IMPL-025/026/027 sostituendo `STRUTTURA COMPLETAMENTE ASSENTE` con uno stato bounded `APPROVATA, NON COMPLETATA`: registrare le primitive frontend già presenti (session input/confirmed state, Start/Stop actions, shell/bootstrap, poller esistenti, async guards Evidence/Source Identity, Market Reactions UI) e separarle dai contratti ancora mancanti (single live-session controller, trackingSessionId/command authority, shared session-scoped polling runtime, Stop di tutti i poller, retain policy e dedicated Market Reactions view model). Preservare le protezioni async già robuste e non promuovere TEST-044…059.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    }