TODO:

Report: [`Report documentale/35 - 04-validation-and-rollback.md`](../Report%20documentale/35%20-%2004-validation-and-rollback.md) — `TDUI-DOC-REPORT-035`.

Modularizzazione: **valutata, non necessaria**.

- [ ] **`VALID-ROLL-001`** — priorità `critical` — Distinguere HEAD SHA dal contenuto esatto della working tree; aggiungere provenance bounded pre/post run, qualificare state unavailable/unknown e collegare la provenance al rollback selettivo senza diff raw o path sensibili.
- [ ] **`VALID-ROLL-002`** — priorità `critical` — Trattare `requires` come dichiarativo: fast/full-offline non sono capability sandbox e i child ereditano `process.env`; minimizzare/sanitizzare l'environment offline, ridefinire ciò che `TEST-073` prova e verificare la policy effettiva.
- [ ] **`VALID-ROLL-003`** — priorità `high` — Rendere machine-checkable la closure di `full-offline`: una nuova entry offline non deve poter essere dimenticata; introdurre eligibility/exclusion reason esplicita e test di profile completeness.
- [x] **`VALID-ROLL-004`** — priorità `high` — Correggere la semantica dei risultati: `counts.passed` conta manifest entry, non assertion, e `perTestResults` include anche build/checker/compile; distinguere workflow state da runner status e coordinare `IMPL-031`.
- [ ] **`VALID-ROLL-005`** — priorità `high` — Estendere timeout/cleanup all'intero process tree owned con graceful/force bounded, incluso il caso parent exits ma descendant resta; nessun kill per porta/PID non owned e `termination_unconfirmed` se il drain non è dimostrato.
- [x] **`VALID-ROLL-006`** — priorità `medium` — Distinguere link checker, registry checker e controlli strutturali; mappare ogni requisito a automatic/manual/historical e non usare un link-check verde come validazione documentale globale. Valutare checker read-only separati per i requisiti mancanti.
- [x] **`VALID-ROLL-007`** — priorità `high` — Aggiungere `TEST-072` ai limiti correnti: non implicare che esista già un route HTTP harness riusabile completo; usare test HTTP specifici quando disponibili e mantenere porta dinamica e cleanup owned.

JSON:

    {
      "change_id": "VALID-ROLL-001",
      "report_id": "TDUI-DOC-REPORT-035",
      "document_path": "docs/tennis-decision-ui/operations/04-validation-and-rollback.md",
      "priority": "critical",
      "type": "working_tree_provenance_rollback_scope",
      "action": "Distinguere HEAD SHA dal contenuto esatto della working tree; aggiungere provenance bounded pre/post run, qualificare state unavailable/unknown e collegare la provenance al rollback selettivo senza diff raw o path sensibili.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    },
    {
      "change_id": "VALID-ROLL-002",
      "report_id": "TDUI-DOC-REPORT-035",
      "document_path": "docs/tennis-decision-ui/operations/04-validation-and-rollback.md",
      "priority": "critical",
      "type": "offline_capability_isolation",
      "action": "Trattare `requires` come dichiarativo: fast/full-offline non sono capability sandbox e i child ereditano `process.env`; minimizzare/sanitizzare l'environment offline, ridefinire ciò che TEST-073 prova e verificare la policy effettiva.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    },
    {
      "change_id": "VALID-ROLL-003",
      "report_id": "TDUI-DOC-REPORT-035",
      "document_path": "docs/tennis-decision-ui/operations/04-validation-and-rollback.md",
      "priority": "high",
      "type": "full_offline_completeness",
      "action": "Rendere machine-checkable la closure di `full-offline`: una nuova entry offline non deve poter essere dimenticata; introdurre eligibility/exclusion reason esplicita e test di profile completeness.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    },
    {
      "change_id": "VALID-ROLL-004",
      "report_id": "TDUI-DOC-REPORT-035",
      "document_path": "docs/tennis-decision-ui/operations/04-validation-and-rollback.md",
      "priority": "high",
      "type": "result_state_count_semantics",
      "action": "Correggere la semantica dei risultati: `counts.passed` conta manifest entry, non assertion, e `perTestResults` include anche build/checker/compile; distinguere workflow state da runner status e coordinare IMPL-031.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "VALID-ROLL-005",
      "report_id": "TDUI-DOC-REPORT-035",
      "document_path": "docs/tennis-decision-ui/operations/04-validation-and-rollback.md",
      "priority": "high",
      "type": "timeout_process_tree",
      "action": "Estendere timeout/cleanup all'intero process tree owned con graceful/force bounded, incluso il caso parent exits ma descendant resta; nessun kill per porta/PID non owned e `termination_unconfirmed` se il drain non è dimostrato.",
      "checkbox": "[ ]",
      "completed": false,
      "status": "pending"
    },
    {
      "change_id": "VALID-ROLL-006",
      "report_id": "TDUI-DOC-REPORT-035",
      "document_path": "docs/tennis-decision-ui/operations/04-validation-and-rollback.md",
      "priority": "medium",
      "type": "documentation_verification_coverage",
      "action": "Distinguere link checker, registry checker e controlli strutturali; mappare ogni requisito a automatic/manual/historical e non usare un link-check verde come validazione documentale globale. Valutare checker read-only separati per i requisiti mancanti.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "VALID-ROLL-007",
      "report_id": "TDUI-DOC-REPORT-035",
      "document_path": "docs/tennis-decision-ui/operations/04-validation-and-rollback.md",
      "priority": "high",
      "type": "route_http_harness_boundary",
      "action": "Aggiungere TEST-072 ai limiti correnti: non implicare che esista già un route HTTP harness riusabile completo; usare test HTTP specifici quando disponibili e mantenere porta dinamica e cleanup owned.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }