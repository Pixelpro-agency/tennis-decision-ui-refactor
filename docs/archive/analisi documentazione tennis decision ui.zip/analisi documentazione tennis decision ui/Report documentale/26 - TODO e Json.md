TODO:

Report: [`Report documentale/26 - 03-betfair-scraper.md`](../Report%20documentale/26%20-%2003-betfair-scraper.md) — `TDUI-DOC-REPORT-026`.

Modularizzazione: **eseguita**. File creati: `docs/tennis-decision-ui/modules/python/05-betfair-diagnostics-and-network-capture.md`.

- [x] **`BETFAIR-SCRAPER-001`** — priorità `critical` — Cache key collision-resistant, opaca e coerente con request/runtime; impedire hit incompatibili e bypass Graph/capture.
- [x] **`BETFAIR-SCRAPER-002`** — priorità `high` — Definire cache eligibility e equivalenza fresh/cached; evitare retry suppression implicita di failure transitorie.
- [x] **`BETFAIR-SCRAPER-003`** — priorità `high` — Rimuovere/redigere `network_capture.dump_dir` e path locali dal result pubblico; allow-list diagnostica.
- [x] **`BETFAIR-SCRAPER-004`** — priorità `high` — Tracciare task async capture, bounded collector e drain bounded prima del summary/return.
- [x] **`BETFAIR-SCRAPER-005`** — priorità `critical` — Coordinare timeout Node 90s con budget Python main/Graph/capture/cleanup; nessun kill prematuro del child.
- [x] **`BETFAIR-SCRAPER-006`** — priorità `critical` — Weak visible-text finished hint non deve produrre auto-stop; `hasFinished` solo da evidenza authoritative.
- [x] **`BETFAIR-SCRAPER-007`** — priorità `high` — Separare `auth_required`, `security_challenge`, `no_ladder_rows`, `temporary_error`; rafforzare fallback login/break policy.
- [x] **`BETFAIR-SCRAPER-008`** — priorità `high` — Verificare e minimizzare `--ignore-certificate-errors`, `--no-sandbox`, `--disable-setuid-sandbox`; test live prima di cambiare.
- [x] **`BETFAIR-SCRAPER-009`** — priorità `high` — Includere `cdp_url_test`/`graph_url_test` e aggiungere test scrape/browser/network capture, finished/login/cache/timeout.
- [x] **`BETFAIR-SCRAPER-010`** — priorità `medium` — Mantenere `03-*` core/facade e creare `05-betfair-diagnostics-and-network-capture.md`; spostare capture/redaction/logger/dump policy/test e aggiornare link.

JSON:

    {
      "change_id": "BETFAIR-SCRAPER-001",
      "report_id": "TDUI-DOC-REPORT-026",
      "document_path": "docs/tennis-decision-ui/modules/python/03-betfair-scraper.md",
      "priority": "critical",
      "type": "cache_identity_runtime_consistency",
      "action": "Cache key collision-resistant, opaca e coerente con request/runtime; impedire hit incompatibili e bypass Graph/capture.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-SCRAPER-002",
      "report_id": "TDUI-DOC-REPORT-026",
      "document_path": "docs/tennis-decision-ui/modules/python/03-betfair-scraper.md",
      "priority": "high",
      "type": "cache_content_contract",
      "action": "Definire cache eligibility e equivalenza fresh/cached; evitare retry suppression implicita di failure transitorie.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-SCRAPER-003",
      "report_id": "TDUI-DOC-REPORT-026",
      "document_path": "docs/tennis-decision-ui/modules/python/03-betfair-scraper.md",
      "priority": "high",
      "type": "diagnostic_exposure",
      "action": "Rimuovere/redigere `network_capture.dump_dir` e path locali dal result pubblico; allow-list diagnostica.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-SCRAPER-004",
      "report_id": "TDUI-DOC-REPORT-026",
      "document_path": "docs/tennis-decision-ui/modules/python/03-betfair-scraper.md",
      "priority": "high",
      "type": "async_lifecycle_diagnostics_boundedness",
      "action": "Tracciare task async capture, bounded collector e drain bounded prima del summary/return.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-SCRAPER-005",
      "report_id": "TDUI-DOC-REPORT-026",
      "document_path": "docs/tennis-decision-ui/modules/python/03-betfair-scraper.md",
      "priority": "critical",
      "type": "runtime_timeout_coordination",
      "action": "Coordinare timeout Node 90s con budget Python main/Graph/capture/cleanup; nessun kill prematuro del child.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-SCRAPER-006",
      "report_id": "TDUI-DOC-REPORT-026",
      "document_path": "docs/tennis-decision-ui/modules/python/03-betfair-scraper.md",
      "priority": "critical",
      "type": "live_stop_authority",
      "action": "Weak visible-text finished hint non deve produrre auto-stop; `hasFinished` solo da evidenza authoritative.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-SCRAPER-007",
      "report_id": "TDUI-DOC-REPORT-026",
      "document_path": "docs/tennis-decision-ui/modules/python/03-betfair-scraper.md",
      "priority": "high",
      "type": "diagnostic_classifier",
      "action": "Separare `auth_required`, `security_challenge`, `no_ladder_rows`, `temporary_error`; rafforzare fallback login/break policy.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-SCRAPER-008",
      "report_id": "TDUI-DOC-REPORT-026",
      "document_path": "docs/tennis-decision-ui/modules/python/03-betfair-scraper.md",
      "priority": "high",
      "type": "browser_hardening",
      "action": "Verificare e minimizzare `--ignore-certificate-errors`, `--no-sandbox`, `--disable-setuid-sandbox`; test live prima di cambiare.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-SCRAPER-009",
      "report_id": "TDUI-DOC-REPORT-026",
      "document_path": "docs/tennis-decision-ui/modules/python/03-betfair-scraper.md",
      "priority": "high",
      "type": "verification_contract",
      "action": "Includere `cdp_url_test`/`graph_url_test` e aggiungere test scrape/browser/network capture, finished/login/cache/timeout.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    },
    {
      "change_id": "BETFAIR-SCRAPER-010",
      "report_id": "TDUI-DOC-REPORT-026",
      "document_path": "docs/tennis-decision-ui/modules/python/03-betfair-scraper.md",
      "priority": "medium",
      "type": "documentation_modularization",
      "action": "Mantenere `03-*` core/facade e creare `05-betfair-diagnostics-and-network-capture.md`; spostare capture/redaction/logger/dump policy/test e aggiornare link.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }