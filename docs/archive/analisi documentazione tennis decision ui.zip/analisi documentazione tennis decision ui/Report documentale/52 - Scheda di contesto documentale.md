# Scheda di contesto documentale

## Documento target

Percorso:
`implementazioni/README.md`

Tipo di documento:
indice del registro modulare della revisione.

Ruolo documentale:
orientare la navigazione e la selezione del solo modulo pertinente. Non sostituisce la documentazione tecnica canonica e non è owner di stati, decisioni, schede o comportamenti applicativi.

## Baseline

Code authority:
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `52 - Report README-implementazioni.md` — report `TDUI-DOC-REPORT-052`.
- `52 - TODO e Json.md` — checklist e record strutturato associati al documento.

## Task storicamente associate

- `REGISTRY-README-001` — stato: completata.
  Argomento coinvolto: rappresentazione uniforme dei rami modulari 02/03/06 e descrizione sintetica dei ruoli di 05 e 06, senza duplicare stati o schede.
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- Il registro risulta organizzato in tre rami modulari: audit documentazione (4 moduli), audit codice (7 moduli) e implementazioni proposte (7 moduli).
- La modularizzazione del README è stata valutata come non necessaria; non risultano nuovi file canonici associati alla task.
- Il report di verifica dichiara la task applicata e nessuna task residua per questo documento.

## Struttura precedente da considerare

- Titolo e identità di “Registro modulare della revisione”.
- Boundary esplicito rispetto alla documentazione tecnica canonica.
- Ordine di lettura minimo: metodo, piano generale, modulo tematico pertinente, decisioni utente quando rilevanti.
- Regole su ID globali, owner unico, Todo come vista sintetica, selezione mirata del contesto, assenza di owner card duplicate e controllo ricorsivo dei registri.
- Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `implementazioni/README.md`
- `implementazioni/02-audit-documentazione.md` e relativi moduli indicizzati.
- `implementazioni/03-audit-codice.md` e relativi moduli indicizzati.
- `implementazioni/05-audit-docs-planning.md`
- `implementazioni/06-implementazioni-proposte.md` e relativi moduli indicizzati.
- Verifica dei link relativi e del controllo ricorsivo del registro, limitatamente a quanto serve a descrivere correttamente l’indice.

## Owner/documenti collegati

- `implementazioni/00-metodo-e-stati.md` — metodo e stati del registro.
- `implementazioni/01-piano-generale-audit.md` — orientamento generale dell’audit.
- `implementazioni/02-audit-documentazione.md`, `03-audit-codice.md` e `06-implementazioni-proposte.md` — facade dei tre rami modulari; le schede complete restano nei rispettivi moduli.
- `implementazioni/04-task-completate.md` — registro collegato delle task completate.
- `implementazioni/05-audit-docs-planning.md` — closeout storico dell’audit e della pulizia delle fonti locali, secondo il ruolo corrente da verificare.
- `implementazioni/99-decisioni-utente.md` — decisioni da consultare soltanto quando pertinenti.
- `todo-list-tennis-decision-ui.md` — vista sintetica degli stati; il README non ne duplica il contenuto.

## Guardrail specifici per questo documento

- Mantenere il file come indice breve di navigazione e selezione del contesto.
- Non trasformarlo in owner tecnico, Todo, decision log, changelog o raccolta di schede complete.
- Non duplicare finding, stati dettagliati, contratti, test o decisioni contenuti negli owner collegati.
- Non descrivere i registri della revisione come documentazione tecnica canonica.
- Conservare una convenzione uniforme per rappresentare i facade modulari, sulla base del contenuto effettivo della baseline.

## Informazioni storiche da NON assumere come correnti

- Le formulazioni, i conteggi e i giudizi del report 052 descrivono la situazione osservata nella baseline documentale storica, non il contenuto corrente del CODE AUTHORITY.
- La precedente descrizione di 05 come “trattamento differito” e di 06 come insieme di implementazioni soltanto “da valutare” non va assunta come corrente.
- Il vecchio disallineamento con il solo ramo 03 espanso non va assunto come ancora presente, poiché la task associata risulta completata.
- Priorità, finding, raccomandazioni e ordine di applicazione presenti nel report restano metadata storici e non istruzioni per il technical writer.

## Discrepanze o limiti delle fonti

- Le fonti fornite concordano su ID e stato completato della task; nessuna discrepanza storica individuata.
- Non sono stati forniti il documento corrente né il contenuto del CODE AUTHORITY: gli effetti effettivi della task e la forma corrente dei link devono essere verificati nella baseline tecnica indicata.
