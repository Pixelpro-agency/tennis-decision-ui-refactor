# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/modules/python/04-betfair-graph-url-validation.md`

Tipo di documento:  
Owner tecnico.

Ruolo documentale:  
Owner della grammatica delle Graph URL Betfair e del mapping runtime Python tra identità del mercato, `selectionId` del runner e assegnazione della ladder. Il documento mantiene separati il controllo sintattico condivisibile con il preflight e le verifiche runtime dipendenti dai dati Betfair.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing(20260813-130240).txt`
- `27 - TODO e Json.md`
- `27 - Report 04-betfair-graph-url-validation.md` — `TDUI-DOC-REPORT-027`

## Task storicamente associate

- `GRAPH-URL-001` — stato: completata  
  Argomento coinvolto: distinzione tra identità upstream del mercato assente o non valida e reale mismatch della Graph URL.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `GRAPH-URL-002` — stato: completata  
  Argomento coinvolto: unicità dei `selectionId` provenienti dal payload API e gestione fail-closed delle identità ambigue.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `GRAPH-URL-003` — stato: completata  
  Argomento coinvolto: forma canonica della Graph URL e coerenza tra identità analizzata e URL usata per la navigazione.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `GRAPH-URL-004` — stato: completata  
  Argomento coinvolto: verifica d’integrazione del Graph loop, inclusi skip della pagina, contatori, assegnazione ladder, casi empty/error, prenotazione dei duplicati e liste miste.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `GRAPH-URL-005` — stato: completata  
  Argomento coinvolto: separazione tra verifiche deterministiche offline e osservazioni dipendenti da browser o sorgente reale.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `GRAPH-URL-006` — stato: completata  
  Argomento coinvolto: provenienza delle evidenze storiche di validazione e delimitazione dei claim live documentabili.  
  Uso consentito: verificare nel CODE AUTHORITY e negli artifact citati l’effetto corrente pertinente.

- `GRAPH-URL-007` — stato: completata  
  Argomento coinvolto: rapporto tra grammatica condivisa con il preflight e mapping runtime mantenuto dal codice Python.  
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

## Cambiamenti strutturali storicamente rilevanti

- La modularizzazione è stata valutata e dichiarata non necessaria.
- Non risultano nuovi documenti canonici derivati.
- Il documento resta un owner unitario per sintassi della Graph URL, identità di mercato e runner, mapping e assegnazione della ladder.
- Le verifiche deterministiche e le osservazioni live risultano storicamente distinte.

## Struttura precedente da considerare

- Pipeline esplicita: Graph URL → parsing → verifica `marketId` → risoluzione `selectionId` → gestione duplicati → apertura ladder → assegnazione.
- Contratto della grammatica Graph URL.
- Mapping delle identità di mercato e runner.
- Policy di prenotazione delle selection duplicate.
- Contatori e diagnostica delle failure.
- Separazione tra verifica deterministica e osservazione live.
- Provenienza delle evidenze storiche.
- Confine tra preflight e runtime Python.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `scrapers/betfair/graph_url.py`
- `scrapers/betfair/graph_url_test.py`
- `scrapers/betfair/scrape.py`
- `scrapers/betfair/ladder.py`
- `scrapers/betfair/market_api.py`
- Test d’integrazione direttamente associati al Graph loop.
- `backend/src/routes/test/graphUrlValidation.js` e relativi test del preflight.
- `docs/validations/betfair-live-validation-2026-07-04.md`, limitatamente alla provenienza delle evidenze richiamate.

## Owner/documenti collegati

- `docs/tennis-decision-ui/api/05-preflight.md` — collegato per la grammatica sintattica condivisa; il mapping basato su mercato, runner e ladder resta nel runtime Python.
- `docs/tennis-decision-ui/operations/04-validation-and-rollback.md` — collegato per il confine tra verifiche deterministiche e osservazioni live.
- `docs/validations/README.md` — collegato per le regole di provenienza delle evidenze storiche.
- `docs/validations/betfair-live-validation-2026-07-04.md` — artifact storico citato per le osservazioni live effettivamente registrate.

## Guardrail specifici per questo documento

- Conservare il ruolo di owner della grammatica e del mapping Graph URL Python, senza estenderlo all’intero scraper Betfair.
- Distinguere la validità sintattica della URL dall’autorizzazione del mapping runtime.
- Non descrivere fallback per nome, indice o ordine se non risultano nel CODE AUTHORITY.
- Mantenere esplicito il confine tra grammatica condivisa con il preflight e verifiche runtime basate sui dati Betfair.
- Documentare claim live soltanto quando supportati da un artifact storico identificabile.
- Non trasformare task storiche completate in istruzioni di implementazione.

## Informazioni storiche da NON assumere come correnti

- Il comportamento tecnico descritto dal report, basato sul commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`.
- I problemi, le soluzioni proposte e l’ordine di applicazione contenuti nella parte di audit del report.
- La sola dichiarazione storica di completamento delle task come prova del comportamento presente.
- Il claim `mode=cdp reale` quando non sostenuto da un artifact canonico che lo registri esplicitamente.
- Lo stato storico delle dipendenze `PREFLIGHT-API-004`, `TECH-SAMPLE-002`, `BETFAIR-SCRAPER-006`, `BETFAIR-SCRAPER-007` e `BETFAIR-SCRAPER-009`.
- I dettagli dei test e dei controlli elencati come previsti nel report, finché non confermati nel CODE AUTHORITY.

## Discrepanze o limiti delle fonti

- Markdown e JSON concordano sull’associazione al documento, sugli ID e sullo stato completato delle sette task.
- Il report contiene sia finding originari sia una decisione finale che dichiara le task applicate; il comportamento corrente deve quindi essere ricavato dal CODE AUTHORITY.
- Le fonti non includono il documento target corrente né il codice della baseline tecnica.
- Nessuna discrepanza storica tra mappa e JSON individuata.
