# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/api/04-strategy.md`

Tipo di documento:  
API / contratto HTTP relativo alla superficie Strategy legacy. Il report storico lo identifica come «contratto HTTP della Strategy legacy».

Ruolo documentale:  
Descrivere la superficie API Strategy nel relativo stato storico. Le fonti successive registrano però l'applicazione di `CODE-001` e la rimozione della superficie Strategy; il technical writer deve quindi verificare nel CODE AUTHORITY se il documento esista ancora e quale ruolo documentale residuo, se presente, sia effettivamente corrente.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`
- `08 - TODO e Json.md`
- `08 - Report 04-strategy.md` — `TDUI-DOC-REPORT-008`

Il report analizza la versione del documento al commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`; TODO e JSON registrano uno stato storico successivo delle task.

## Task storicamente associate

- `STRATEGY-API-001` — stato: completata  
  Argomento coinvolto: ruolo transitorio del documento Strategy e destinazione finale dopo la rimozione della superficie.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `STRATEGY-API-002` — stato: completata  
  Argomento coinvolto: distinzione fra il `marketEvidence` legacy della Strategy e le authority canoniche di Evidence, Source Identity e persistenza.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `STRATEGY-API-003` — stato: completata  
  Argomento coinvolto: semantica degli output direzionali legacy rispetto alla decisione operativa disabilitata.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `STRATEGY-API-004` — stato: completata  
  Argomento coinvolto: contesto e selezione del target runner nella superficie Strategy legacy.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `STRATEGY-API-005` — stato: completata  
  Argomento coinvolto: input `url` della route Strategy. La fonte storica più recente lo registra come assorbito da `CODE-001` in seguito alla rimozione della route.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `STRATEGY-API-006` — stato: completata  
  Argomento coinvolto: superficie pubblica degli errori Strategy. La fonte storica più recente la registra come rimossa con `CODE-001`.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `STRATEGY-API-007` — stato: completata  
  Argomento coinvolto: logging esclusivo della route Strategy. La fonte storica più recente registra la sua eliminazione insieme alla route.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `STRATEGY-API-008` — stato: completata  
  Argomento coinvolto: rimozione della superficie runtime Strategy. TODO e JSON registrano `CODE-001` come applicato, con rimozione di route, mount backend, polling, viste, componenti e moduli esclusivi e preservazione delle superfici canoniche indicate.
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

- `STRATEGY-API-009` — stato: completata  
  Argomento coinvolto: allineamento storico dello schema e della verifica della superficie Strategy durante la fase transitoria verso la rimozione.  
  Uso consentito: verificare nel CODE AUTHORITY l'effetto corrente pertinente.

Markdown TODO e JSON concordano nel registrare tutte le nove task come completate.

## Cambiamenti strutturali storicamente rilevanti

- Modularizzazione valutata e risultata non necessaria: un solo endpoint, una sola feature legacy e nessun nuovo file proposto.
- Destinazione storicamente registrata: eliminazione di `04-strategy.md` dopo l'applicazione verificata di `CODE-001`.
- La fonte TODO successiva registra `CODE-001` come applicato e la superficie Strategy runtime come rimossa.
- Le superfici Evidence, Market Reactions, Source Identity, Money Flow canonico, tracking e letture Betfair risultano indicate come elementi da preservare durante tale rimozione.

## Struttura precedente da considerare

Il report registra un documento di 207 righe con un solo endpoint e una sola feature legacy. Proponeva inoltre una struttura transitoria di dismissione da usare soltanto finché `CODE-001` non fosse stato eseguito; non costituisce quindi una struttura da ripristinare automaticamente dopo la successiva applicazione di `CODE-001`.

Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/server.js` — verificare lo stato corrente del mount `/api/strategy`.
- `backend/src/routes/strategy.js` e `backend/src/routes/strategy/` — percorsi storici della superficie Strategy; verificarne l'eventuale assenza nel CODE AUTHORITY.
- `frontend/src/App.jsx` — verificare l'assenza o presenza di rami Strategy.
- `frontend/src/components/Sidebar.jsx` — verificare l'assenza o presenza delle voci Strategy.
- `frontend/src/components/LayTheWinner.jsx`, `BancaServizio.jsx`, `Superbreak.jsx` e `frontend/src/components/strategy/` — percorsi storici dei consumer/componenti esclusivi Strategy; verificarne l'eventuale assenza.
- relativi test Strategy, limitatamente a quanto necessario per determinare lo stato corrente della superficie.

Queste sono le principali aree che il report aveva associato direttamente al documento e alla rimozione della Strategy.

## Owner/documenti collegati

- Match Evidence — superficie canonica esplicitamente distinta dalla Strategy legacy e indicata come da preservare.
- Market Reactions — superficie canonica da preservare.
- Source Identity — authority separata che la Strategy legacy non sostituiva.
- API/letture Betfair e Money Flow canonico — superfici indicate come preservate dalla successiva rimozione Strategy.
- `DEC-008`, `CODE-001`, `DOC-012` — riferimenti storici indicati dal report come sedi in cui mantenere decisione e storico dopo l'eliminazione del documento Strategy.
- `docs/tennis-decision-ui/index.md` — collegamento documentale storico da verificare rispetto all'eventuale rimozione del documento target.

## Guardrail specifici per questo documento

- Verificare innanzitutto se `docs/tennis-decision-ui/api/04-strategy.md` esista nel CODE AUTHORITY; le fonti storiche indicano come destinazione finale la sua eliminazione e registrano successivamente `CODE-001` come applicato.
- Non ricreare automaticamente il documento sulla sola base del report precedente a `CODE-001`.
- Non trasformare la superficie Strategy legacy in un nuovo owner documentale.
- Non assumere il `marketEvidence` Strategy come Match Evidence o Evidence canonica.
- Non trasferire nel documento corrente descrizioni approfondite degli algoritmi o degli indicatori legacy soltanto perché presenti nel report storico.
- Non introdurre una modularizzazione `strategy/`: la valutazione storica conclude che non erano necessari nuovi documenti.
- Mantenere separati gli owner canonici preservati dalla rimozione Strategy.

## Informazioni storiche da NON assumere come correnti

- Che `/api/strategy` sia ancora montata.
- Che il consumer frontend Strategy sia ancora attivo.
- Che `LayTheWinner`, `BancaServizio`, `Superbreak` o i componenti sotto `frontend/src/components/strategy/` esistano ancora.
- Che continui a esistere un polling Strategy ogni tre secondi.
- Che il payload legacy esponga ancora `marketEvidence`, pressure, confidence, money-flow trend o altri indicatori della Strategy.
- Che esistano ancora la query `url`, il mapping degli errori Strategy o il logging Strategy su `backend_debug.log`.

Il report descriveva infatti una superficie ancora raggiungibile prima dell'applicazione di `CODE-001`, mentre il TODO successivo registra route, polling, UI e moduli esclusivi come rimossi. 
## Discrepanze o limiti delle fonti

Non emerge una discrepanza fra Markdown TODO e JSON sullo stato delle nove task: risultano tutte completate.

Esiste invece una differenza temporale fra le fonti da non interpretare come contraddizione: il report `TDUI-DOC-REPORT-008` fotografa la superficie Strategy prima di `CODE-001`, quando backend e consumer frontend risultavano ancora attivi; TODO e JSON registrano uno stato successivo nel quale `CODE-001` risulta applicato. 
Le fonti fornite non costituiscono authority tecnica sul commit `12b344ea96e71b2bdaa6931c98419ce925b5c228`; esistenza del documento target, assenza effettiva della superficie Strategy e stato degli owner preservati devono essere verificati nel CODE AUTHORITY prima di descrivere il comportamento corrente.