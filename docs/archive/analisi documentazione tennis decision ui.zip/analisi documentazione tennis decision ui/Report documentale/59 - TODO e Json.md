TODO:

Report: [`Report documentale/59 - 07-post-audit-e-migrazione.md`](../Report%20documentale/59%20-%2007-post-audit-e-migrazione.md) — `TDUI-DOC-REPORT-059`.

Modularizzazione: **valutata, non necessaria**.

- [x] **`AUDIT-CODE-POST-001`** — **HIGH** — Riallineare le owner card post-completion senza cancellare la cronologia: `TEST-077`, `TEST-078` e `TEST-079` devono esporre lo stato corrente `COMPLETATO` preservando il precedente stato Batch 0 come storico; in §24.1 `IMPL-028` distinguere lo stato iniziale “da validare” dallo stato finale “implementata e validata localmente”, mantenendo i cinque profili PASS come evidence storica locale e senza riaprire `IMPL-028`, `IMPL-032` o i TEST già chiusi.

JSON:

    {
      "change_id": "AUDIT-CODE-POST-001",
      "report_id": "TDUI-DOC-REPORT-059",
      "document_path": "implementazioni/audit-codice/07-post-audit-e-migrazione.md",
      "priority": "high",
      "type": "owner_status_drift_post_completion",
      "action": "Riallineare gli owner post-completion: TEST-077/078/079 devono riflettere lo stato COMPLETATO già registrato nella Todo e §24.1 deve distinguere lo stato iniziale IMPL-028 'da validare' dallo stato finale 'implementata e validata localmente', preservando la cronologia.",
      "checkbox": "[x]",
      "completed": true,
      "status": "completed"
    }