# Scheda di contesto documentale

## Documento target

Percorso:  
`docs/tennis-decision-ui/api/03-evidence.md`

Tipo di documento:  
API / contratto HTTP. Il report storico identifica il documento come contratto HTTP del router Evidence.

Ruolo documentale:  
Descrivere la superficie HTTP Evidence — endpoint, input, response pubbliche, status e invarianti osservabili — mantenendo separati gli aspetti algoritmici posseduti dai moduli Evidence. Il documento riguarda tre endpoint: latest Evidence, conferma Source Identity e revoca Source Identity.

## Baseline

Code authority:  
`12b344ea96e71b2bdaa6931c98419ce925b5c228`

Documentation structure baseline:  
`4c5f43b007149f3210c27d7565357a447a3a6ef4`

## Fonti storiche consultate

- `PROMPT 0 — Preparazione Scheda neutra per technical writing`
- `07 - Report 03-evidence.md` — `TDUI-DOC-REPORT-007`, relativo a `docs/tennis-decision-ui/api/03-evidence.md`.
- `07 - TODO e Json.md` — registro storico delle task `EVIDENCE-API-001`–`EVIDENCE-API-010`.

## Task storicamente associate

- `EVIDENCE-API-001` — stato: **non completata / riaperta**
  Argomento coinvolto: validazione canonica e condivisa di `eventId`. La fonte storica segnala che API e writer principali usano `backend/src/utils/eventId.js`, mentre altri punti mantengono validator locali.
  Uso consentito: non assumere che la canonicalizzazione condivisa sia completa; verificare nel CODE AUTHORITY il contratto effettivamente pertinente all’API Evidence.

- `EVIDENCE-API-002` — stato: **completata**
  Argomento coinvolto: semantica pubblica di `integrity.reason`, inclusa la distinzione fra reason aggregata e reason per fonte.
  Uso consentito: verificare nel CODE AUTHORITY l’effetto corrente pertinente.

- `EVIDENCE-API-003` — stato: **completata**
  Argomento coinvolto: significato di `sofaTimelineFound` e `betfairTimelineFound`.
  Uso consentito: verificare nel CODE AUTHORITY la semantica pubblica corrente dei flag.

- `EVIDENCE-API-004` — stato: **completata**
  Argomento coinvolto: distinzione o rappresentazione di missing, discovery failure, read failure e JSON invalido.
  Uso consentito: verificare nel CODE AUTHORITY il comportamento corrente esposto da Evidence.

- `EVIDENCE-API-005` — stato: **completata**
  Argomento coinvolto: forma pubblica dell’errore `500` del latest e redazione dei dettagli interni.
  Uso consentito: verificare nel CODE AUTHORITY la response pubblica corrente.

- `EVIDENCE-API-006` — stato: **completata**
  Argomento coinvolto: osservabilità delle failure del confirmation store durante latest.
  Uso consentito: verificare nel CODE AUTHORITY quale stato o contratto pubblico ne deriva.

- `EVIDENCE-API-007` — stato: **completata**
  Argomento coinvolto: mapping HTTP degli errori della conferma gate-aware, inclusi input, conflitto, race e failure server.
  Uso consentito: verificare nel CODE AUTHORITY status e code pubblici correnti.

- `EVIDENCE-API-008` — stato: **completata**
  Argomento coinvolto: coerenza fra persistenza della conferma e bootstrap.
  Uso consentito: verificare nel CODE AUTHORITY la semantica corrente senza assumere quale delle alternative storicamente proposte sia stata adottata.

- `EVIDENCE-API-009` — stato: **completata**
  Argomento coinvolto: struttura della verifica e copertura delle tre route Evidence.
  Uso consentito: verificare nel CODE AUTHORITY i test modulari realmente presenti e pertinenti.

- `EVIDENCE-API-010` — stato: **completata**
  Argomento coinvolto: ruolo di `03-evidence.md` come facade, separazione dei contratti latest e conferma/revoca e mantenimento degli algoritmi nei relativi owner Evidence.
  Uso consentito: verificare nel CODE AUTHORITY e nella baseline documentale quale struttura risulta effettivamente corrente.

## Cambiamenti strutturali storicamente rilevanti

- Il report individuava nel documento due responsabilità HTTP separabili: latest Evidence e conferma/revoca Source Identity.
- `EVIDENCE-API-010` risulta storicamente completata e riguardava il mantenimento di `03-evidence.md` come facade e la separazione dei contratti specifici.
- I nomi storicamente associati alla modularizzazione sono:
  - `docs/tennis-decision-ui/api/evidence/01-latest-snapshot.md`
  - `docs/tennis-decision-ui/api/evidence/02-source-identity-confirmation.md`
- La reale presenza e forma corrente di tali file deve essere verificata nella baseline documentale/CODE AUTHORITY, perché il TODO fornito conserva anche la dicitura “Modularizzazione: richiesta” e “File proposti”.

## Struttura precedente da considerare

- La versione analizzata dal report aveva 589 righe e riuniva nello stesso documento il contratto latest Evidence e il contratto conferma/revoca Source Identity.
- Comprendeva, fra gli altri, superficie HTTP, validazione `eventId`, latest, integrity, flag delle timeline, status/errori, conferma gate-aware e fallback, revoca, data quality, Source Identity e verifica.
- La struttura proposta storicamente per la facade manteneva scopo, mount, tabella endpoint, validazione comune, principi di sicurezza, collegamenti ai contratti specifici e matrici sintetiche di status e test.
- Da confrontare con il CODE AUTHORITY e recuperare soltanto se ancora utile e pertinente.

## Aree da verificare nel CODE AUTHORITY

- `backend/src/routes/evidence.js`
- `backend/src/routes/evidence/evidenceResponses.js`
- `backend/src/sofa/matchEvidence/latestMatchEvidence.js`
- `backend/src/sofa/matchEvidence/evidenceBuilder.js`
- `backend/src/sofa/matchEvidence/sourceIdentityConfirmation.js`
- `backend/src/sofa/matchEvidence/sourceIdentityConfirmationStore.js`
- `backend/src/sofa/sourceIdentityGate/manualConfirmation.js`
- `backend/src/utils/eventId.js` per il contratto `eventId` pertinente alla route
- relativi test route, Evidence e Source Identity

Il report storico utilizzava direttamente queste aree, insieme ai relativi test, per confrontare il documento con l’implementazione.

## Owner/documenti collegati

- `modules/evidence/01-match-evidence-snapshot.md` — owner dell’algoritmo/snapshot Match Evidence.
- `modules/evidence/02-source-identity.md` — owner di Source Identity e relativo lifecycle.
- `modules/evidence/03-quality-flow-and-alignment.md` — owner di quality flow e alignment.
- `modules/evidence/04-market-reactions.md` — owner di Market Reactions.

Storicamente la separazione prevista lasciava questi algoritmi ai rispettivi owner, mentre il documento API manteneva il contratto HTTP osservabile.

Possibili documenti API figli da verificare nella struttura corrente:

- `api/evidence/01-latest-snapshot.md`
- `api/evidence/02-source-identity-confirmation.md`

## Guardrail specifici per questo documento

- Mantenere il focus sul **contratto HTTP Evidence**, non trasformare `03-evidence.md` in un secondo owner degli algoritmi Evidence.
- Distinguere la lettura latest dalle operazioni di conferma/revoca: storicamente latest è descritta come read-only rispetto a timeline, history e journal, mentre conferma e revoca possono interessare il confirmation store.
- Documentare soltanto endpoint, input/precondizioni, status, shape pubbliche e invarianti osservabili che risultano dal CODE AUTHORITY.
- Non trasferire nel documento finale alternative progettuali o soluzioni contenute nel report storico.
- Per `EVIDENCE-API-001`, non descrivere come pienamente completata la canonicalizzazione condivisa di `eventId` finché il CODE AUTHORITY non lo dimostra.
- Non assumere automaticamente che la struttura modulare storicamente prevista coincida con quella attuale.

## Informazioni storiche da NON assumere come correnti

- I comportamenti osservati nel report sul commit documentale/tecnico precedente, inclusi reason, flag timeline, gestione delle failure di lettura, forma del `500`, mapping degli errori gate e sequenza conferma/bootstrap.
- I percorsi dei test indicati nella vecchia versione del documento.
- Le soluzioni e le alternative proposte dal report per le task `EVIDENCE-API-001`–`010`.
- La vecchia struttura monolitica di 589 righe.
- La piena conclusione di `EVIDENCE-API-001`, che la fonte TODO indica esplicitamente come riaperta.
- L’esistenza effettiva dei due file `api/evidence/*` sulla sola base della proposta originaria: il loro stato corrente va verificato.

## Discrepanze o limiti delle fonti

- Il report è riferito al commit `4c5f43b007149f3210c27d7565357a447a3a6ef4`, mentre il CODE AUTHORITY assegnato alla successiva verifica è `12b344ea96e71b2bdaa6931c98419ce925b5c228`; il report non è quindi authority tecnica corrente. - La fonte TODO/JSON concorda sullo stato delle task: `EVIDENCE-API-001` è pending/non completata e `EVIDENCE-API-002`–`010` risultano completed.
- **DISCREPANZA STORICA DA NON RISOLVERE AUTOMATICAMENTE:** nello stesso TODO, `EVIDENCE-API-010` risulta completata, ma l’intestazione continua a descrivere la modularizzazione come “richiesta” e i due file come “proposti”. Con i soli allegati forniti non è possibile stabilire se tale intestazione sia rimasta obsoleta o se la creazione fisica dei due documenti non sia stata completata.